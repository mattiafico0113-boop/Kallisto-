import React, { useEffect, useMemo, useRef, useState } from 'react';
import { CalendarDays, Check, ClipboardList, Droplets, FileEdit, HeartPulse, MessageSquare, Palette, Trophy, User, Volume2, VolumeX, X } from 'lucide-react';
import { getExerciseById } from './data/exercises';
import { SKILL_NODE_MAP } from './data/skills';
import { AuthScreen } from './components/AuthScreen';
import { CaliProLogo } from './components/CaliProLogo';
import { CoachView } from './components/CoachView';
import { CognitiveWarmupModal } from './components/CognitiveWarmupModal';
import { DualTimerSheet } from './components/DualTimerSheet';
import { HistoryView } from './components/HistoryView';
import { OfflineIndicator } from './components/OfflineIndicator';
import { OnboardingWizard } from './components/OnboardingWizard';
import { PostWorkoutSummaryModal } from './components/PostWorkoutSummaryModal';
import { ProfileView } from './components/ProfileView';
import { PWAInstallButton } from './components/PWAInstallButton';
import { ScheduleBuilderModal } from './components/ScheduleBuilderModal';
import { SkillTreeView } from './components/SkillTreeView';
import { WellnessView } from './components/WellnessView';
import { WorkoutView } from './components/WorkoutView';
import type {
  ActiveTimerState,
  AppTab,
  AthleteProfile,
  AuthSession,
  BodyWeightEntry,
  CoachActionProposal,
  CoachMessage,
  ComboFlowPreset,
  CompletedExerciseRecord,
  DailyNutritionLog,
  EnergyLevel,
  ManualWorkoutIntensity,
  MorningCheckinRecord,
  MorningJointStatus,
  SleepQuality,
  StretchExerciseItem,
  UnlockedSkillRecord,
  WarmupExerciseItem,
  WorkoutDayPlan,
  WorkoutExerciseItem,
  WorkoutSessionLog,
} from './types/calisthenics';
import { generateWeeklyPlanWithPuterAI } from './utils/aiPlanGenerator';
import {
  adaptExercisesForTimeBudget,
  computePostWorkoutSummary,
  type ExpressMinutesOption,
  getLocalDateKey,
  isExerciseStressedByJoint,
  pickSafeAlternativeForJoint,
  type PostWorkoutSummaryData,
} from './utils/athletePillars';
import {
  isSoundEffectsEnabled,
  playLevelUpFanfare,
  playSetCompleteTone,
  playTechClick,
  setSoundEffectsEnabled,
} from './utils/audio';
import { applyCoachProposalToPlan } from './utils/coachEngine';
import {
  buildWorkoutNotificationBody,
  getTodayWeekdayId,
  sendWorkoutNotification,
} from './utils/notifications';
import { loadProgressPhotos, replaceProgressPhotosForAccount } from './utils/photoDiaryDB';
import {
  generateStretchingForDay,
  generateWarmupForDay,
  generateWeeklyProgram,
} from './utils/programGenerator';
import { decodeWorkoutPlanFromCode } from './utils/qrCodeGenerator';
import { computeWeeklyMissions } from './utils/recoveryAndMissions';
import { computeRpgProgress } from './utils/rpgProgression';
import {
  clearPersistedState,
  createBackupPayload,
  getLastNotifiedDate,
  loadAuthSession,
  loadPersistedState,
  parseBackupPayload,
  saveAuthSession,
  savePersistedState,
  setLastNotifiedDate,
  type ActiveWorkoutDraft,
} from './utils/storage';
import {
  applyThemePreset,
  loadSavedThemeId,
  THEME_PRESETS,
  type ThemePresetId,
} from './utils/themeManager';

interface ScreenWakeLockSentinel {
  released?: boolean;
  release: () => Promise<void>;
}

const TRANSITION_DEFAULT_KEY = 'kallisto_transition_sec';

function loadSavedTransitionSeconds(): number {
  try {
    const raw = localStorage.getItem(TRANSITION_DEFAULT_KEY);
    if (!raw) return 120;
    const parsed = Number(raw);
    return Number.isFinite(parsed) && parsed >= 30 && parsed <= 300 ? parsed : 120;
  } catch {
    return 120;
  }
}

function cloneDayExercises(day: WorkoutDayPlan | undefined): WorkoutExerciseItem[] {
  if (!day) return [];
  return day.exercises.map((ex) => ({
    ...ex,
    sets: ex.sets.map((s) => ({ ...s })),
  }));
}

function cloneDayWarmup(
  day: WorkoutDayPlan | undefined,
  profile?: AthleteProfile | null
): WarmupExerciseItem[] {
  if (!day) return [];
  if (Array.isArray(day.warmup)) {
    return day.warmup.map((w) => ({ ...w }));
  }
  return generateWarmupForDay(day.title, profile?.equipment, profile?.injuries);
}

function cloneDayStretch(
  day: WorkoutDayPlan | undefined,
  profile?: AthleteProfile | null
): StretchExerciseItem[] {
  if (!day) return [];
  if (Array.isArray(day.stretch)) {
    return day.stretch.map((s) => ({ ...s }));
  }
  return generateStretchingForDay(day.title, profile?.equipment);
}

export default function App() {
  const [session, setSession] = useState<AuthSession | null>(() => loadAuthSession());

  const [profile, setProfile] = useState<AthleteProfile | null>(null);
  const [weeklyPlan, setWeeklyPlan] = useState<WorkoutDayPlan[]>([]);
  const [selectedDayIndex, setSelectedDayIndex] = useState<number>(0);
  const [activeDraft, setActiveDraft] = useState<ActiveWorkoutDraft | null>(null);
  const [history, setHistory] = useState<WorkoutSessionLog[]>([]);
  const [coachMessages, setCoachMessages] = useState<CoachMessage[]>([]);
  const [unlockedSkills, setUnlockedSkills] = useState<UnlockedSkillRecord[]>([]);
  const [prehabCompletedDates, setPrehabCompletedDates] = useState<string[]>([]);
  const [claimedMissionKeys, setClaimedMissionKeys] = useState<string[]>([]);
  const [morningCheckins, setMorningCheckins] = useState<MorningCheckinRecord[]>([]);
  const [nutritionLogs, setNutritionLogs] = useState<DailyNutritionLog[]>([]);
  const [exerciseNotes, setExerciseNotes] = useState<Record<string, string>>({});
  const [weightLog, setWeightLog] = useState<BodyWeightEntry[]>([]);
  const [totalVoiceGuide, setTotalVoiceGuide] = useState<boolean>(false);
  const [manualWorkoutDays, setManualWorkoutDays] = useState<Record<string, ManualWorkoutIntensity>>({});
  const [savedCombos, setSavedCombos] = useState<ComboFlowPreset[]>([]);
  const [expressMinutes, setExpressMinutes] = useState<ExpressMinutesOption | null>(null);
  const [loadedAccountId, setLoadedAccountId] = useState<string | null>(null);
  const bonusMissionXp = claimedMissionKeys.length * 150;

  const [activeTab, setActiveTab] = useState<AppTab>('benessere');
  const [isEditingOnboarding, setIsEditingOnboarding] = useState(false);
  const [builderState, setBuilderState] = useState<{ open: boolean; startBlank: boolean }>({
    open: false,
    startBlank: false,
  });
  const [activeTimer, setActiveTimer] = useState<ActiveTimerState | null>(null);
  const [pendingCheckinSessionId, setPendingCheckinSessionId] = useState<string | null>(null);
  const [pendingVisionPrompt, setPendingVisionPrompt] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [confirmResetModal, setConfirmResetModal] = useState(false);
  const [isGeneratingAiPlan, setIsGeneratingAiPlan] = useState(false);
  const [postWorkoutSummary, setPostWorkoutSummary] = useState<PostWorkoutSummaryData | null>(
    null
  );

  // Global Session Stopwatch, Hydration Counter, Cognitive Warmup & Inter-Exercise Transition
  const [sessionStatus, setSessionStatus] = useState<'idle' | 'running' | 'paused'>('idle');
  const [sessionElapsedSeconds, setSessionElapsedSeconds] = useState<number>(0);
  const [cognitiveWarmupOpen, setCognitiveWarmupOpen] = useState<boolean>(false);
  const [waterSipsCount, setWaterSipsCount] = useState<number>(0);
  const [waterReminderOpen, setWaterReminderOpen] = useState<boolean>(false);
  const [transitionSeconds, setTransitionSeconds] = useState<number>(() =>
    loadSavedTransitionSeconds()
  );
  const transitionSecondsRef = useRef<number>(transitionSeconds);
  transitionSecondsRef.current = transitionSeconds;
  const pendingTransitionRef = useRef<{ nextExerciseName: string } | null>(null);
  const waterTimerRef = useRef<number | null>(null);
  const [sfxEnabled, setSfxEnabled] = useState<boolean>(() => isSoundEffectsEnabled());
  const [themeId, setThemeId] = useState<ThemePresetId>(() => loadSavedThemeId());
  const [themeMenuOpen, setThemeMenuOpen] = useState<boolean>(false);
  const themeMenuRef = useRef<HTMLDivElement | null>(null);
  const wakeLockRef = useRef<ScreenWakeLockSentinel | null>(null);
  const prevRpgLevelRef = useRef<{ accountId: string | null; level: number }>({
    accountId: null,
    level: 1,
  });

  // Apply active theme preset immediately and on change
  useEffect(() => {
    applyThemePreset(themeId);
  }, [themeId]);

  // Close header theme popover on outside click
  useEffect(() => {
    if (!themeMenuOpen) return;
    const handleOutside = (ev: MouseEvent | TouchEvent) => {
      if (themeMenuRef.current && !themeMenuRef.current.contains(ev.target as Node)) {
        setThemeMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('touchstart', handleOutside);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('touchstart', handleOutside);
    };
  }, [themeMenuOpen]);

  // Screen Wake Lock API: keep screen awake while workout session is active
  useEffect(() => {
    const nav = navigator as Navigator & {
      wakeLock?: { request: (type: 'screen') => Promise<ScreenWakeLockSentinel> };
    };
    const isWorkoutActive = sessionStatus !== 'idle';
    let cancelled = false;

    const releaseWakeLock = () => {
      const current = wakeLockRef.current;
      wakeLockRef.current = null;
      if (current) {
        current.release().catch(() => {});
      }
    };

    const requestWakeLock = async () => {
      if (cancelled || !nav.wakeLock) return;
      try {
        if (wakeLockRef.current && !wakeLockRef.current.released) return;
        const sentinel = await nav.wakeLock.request('screen');
        if (cancelled) {
          sentinel.release().catch(() => {});
          return;
        }
        wakeLockRef.current = sentinel;
      } catch {
        // Silently ignore on unsupported devices / low-battery mode
      }
    };

    if (!isWorkoutActive) {
      releaseWakeLock();
      return;
    }

    requestWakeLock();

    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        requestWakeLock();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    return () => {
      cancelled = true;
      document.removeEventListener('visibilitychange', handleVisibility);
      releaseWakeLock();
    };
  }, [sessionStatus]);

  // Load account-specific data whenever session changes
  useEffect(() => {
    if (!session) {
      setLoadedAccountId(null);
      return;
    }
    const loaded = loadPersistedState(session.accountId);
    setProfile(loaded.profile);
    setWeeklyPlan(loaded.weeklyPlan);
    setSelectedDayIndex(loaded.selectedDayIndex);
    setActiveDraft(loaded.activeDraft);
    setHistory(loaded.history);
    setCoachMessages(loaded.coachMessages);
    setUnlockedSkills(loaded.unlockedSkills ?? []);
    setPrehabCompletedDates(loaded.prehabCompletedDates ?? []);
    setClaimedMissionKeys(loaded.claimedMissionKeys ?? []);
    setMorningCheckins(loaded.morningCheckins ?? []);
    setNutritionLogs(loaded.nutritionLogs ?? []);
    setExerciseNotes(loaded.exerciseNotes ?? {});
    setWeightLog(loaded.weightLog ?? []);
    setTotalVoiceGuide(Boolean(loaded.totalVoiceGuide));
    setManualWorkoutDays(loaded.manualWorkoutDays ?? {});
    setSavedCombos(loaded.savedCombos ?? []);
    setExpressMinutes(null);
    setPostWorkoutSummary(null);
    setLoadedAccountId(session.accountId);
    setActiveTab('benessere');
    setIsEditingOnboarding(false);
    setPendingCheckinSessionId(null);
    setPendingVisionPrompt(null);
    setSessionStatus('idle');
    setSessionElapsedSeconds(0);
    setWaterSipsCount(0);
    setWaterReminderOpen(false);
    const loadedMissionXp = (loaded.claimedMissionKeys?.length ?? 0) * 150;
    prevRpgLevelRef.current = {
      accountId: session.accountId,
      level: computeRpgProgress(loaded.unlockedSkills ?? [], loaded.history, loadedMissionXp).level,
    };
  }, [session]);

  // Handle PWA Home Shortcuts (?tab=..., ?action=water) and Shared Plan Imports (?importPlan=...)
  useEffect(() => {
    if (!session || loadedAccountId !== session.accountId || typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const rawPlan = params.get('importPlan');
    const tabParam = params.get('tab');
    const actionParam = params.get('action');

    if (!rawPlan && !tabParam && !actionParam) return;

    let urlChanged = false;

    if (rawPlan) {
      const decoded = decodeWorkoutPlanFromCode(rawPlan);
      if (decoded && decoded.length > 0) {
        setWeeklyPlan(decoded);
        setSelectedDayIndex(0);
        setExpressMinutes(null);
        setActiveDraft({
          dayId: decoded[0].id,
          startedAtISO: new Date().toISOString(),
          warmup: cloneDayWarmup(decoded[0], profile),
          stretch: cloneDayStretch(decoded[0], profile),
          exercises: cloneDayExercises(decoded[0]),
        });
        setActiveTab('scheda');
        showToast(`Scheda condivisa importata con successo (${decoded.length} giorni)!`);
      }
      params.delete('importPlan');
      urlChanged = true;
    }

    const validTabs: AppTab[] = ['benessere', 'scheda', 'skill', 'coach', 'storico', 'profilo'];
    if (tabParam && validTabs.includes(tabParam as AppTab) && !rawPlan) {
      setActiveTab(tabParam as AppTab);
      params.delete('tab');
      urlChanged = true;
    } else if (tabParam) {
      params.delete('tab');
      urlChanged = true;
    }

    if (actionParam === 'water') {
      const todayKey = getLocalDateKey();
      setNutritionLogs((prev) => {
        const existing = prev.find((l) => l.dateKey === todayKey) ?? {
          dateKey: todayKey,
          waterMl: 0,
          proteinMeals: 0,
          creatineTaken: false,
        };
        const updated = { ...existing, waterMl: existing.waterMl + 250 };
        return [updated, ...prev.filter((l) => l.dateKey !== todayKey)];
      });
      playSetCompleteTone();
      setActiveTab('benessere');
      showToast('💧 +250 ml di acqua registrati in Benessere!');
      params.delete('action');
      urlChanged = true;
    } else if (actionParam) {
      params.delete('action');
      urlChanged = true;
    }

    if (urlChanged) {
      const nextSearch = params.toString();
      const cleanUrl = `${window.location.pathname}${nextSearch ? `?${nextSearch}` : ''}${window.location.hash}`;
      window.history.replaceState({}, '', cleanUrl);
    }
  }, [session, loadedAccountId]);

  // Detect RPG Level Up inside active session and play futuristic fanfare + vibration
  useEffect(() => {
    if (!session || loadedAccountId !== session.accountId) return;
    const rpg = computeRpgProgress(unlockedSkills, history, bonusMissionXp);
    if (prevRpgLevelRef.current.accountId !== session.accountId) {
      prevRpgLevelRef.current = { accountId: session.accountId, level: rpg.level };
      return;
    }
    if (rpg.level > prevRpgLevelRef.current.level) {
      prevRpgLevelRef.current = { accountId: session.accountId, level: rpg.level };
      playLevelUpFanfare();
      showToast(`LEVEL UP! Sei salito al Livello ${rpg.level} (${rpg.rankTitle})!`);
    } else {
      prevRpgLevelRef.current = { accountId: session.accountId, level: rpg.level };
    }
  }, [session, loadedAccountId, unlockedSkills, history, bonusMissionXp]);

  // Global Session Stopwatch tick
  useEffect(() => {
    if (sessionStatus !== 'running') return;
    const intervalId = window.setInterval(() => {
      setSessionElapsedSeconds((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(intervalId);
  }, [sessionStatus]);

  // Cleanup water reminder auto-close timeout on unmount
  useEffect(() => {
    return () => {
      if (waterTimerRef.current !== null) {
        window.clearTimeout(waterTimerRef.current);
      }
    };
  }, []);

  // Persist state strictly scoped to the active account
  useEffect(() => {
    if (!session || loadedAccountId !== session.accountId) return;
    savePersistedState(session.accountId, {
      profile,
      weeklyPlan,
      selectedDayIndex,
      activeDraft,
      history,
      coachMessages,
      unlockedSkills,
      prehabCompletedDates,
      claimedMissionKeys,
      morningCheckins,
      nutritionLogs,
      exerciseNotes,
      weightLog,
      totalVoiceGuide,
      manualWorkoutDays,
      savedCombos,
    });
  }, [
    session,
    loadedAccountId,
    profile,
    weeklyPlan,
    selectedDayIndex,
    activeDraft,
    history,
    coachMessages,
    unlockedSkills,
    prehabCompletedDates,
    claimedMissionKeys,
    morningCheckins,
    nutritionLogs,
    exerciseNotes,
    weightLog,
    totalVoiceGuide,
    manualWorkoutDays,
    savedCombos,
  ]);

  // Real Web Notification Reminder Scheduler (checks every 20s for selected weekday + time)
  useEffect(() => {
    if (!session || !profile?.reminderEnabled || !profile.reminderTime) return;

    const checkReminder = () => {
      const now = new Date();
      const todayWeekday = getTodayWeekdayId(now);
      if (!profile.trainingDays.includes(todayWeekday)) return;

      const hh = String(now.getHours()).padStart(2, '0');
      const mm = String(now.getMinutes()).padStart(2, '0');
      const currentTime = `${hh}:${mm}`;
      if (currentTime !== profile.reminderTime) return;

      const todayKey = `${now.getFullYear()}-${now.getMonth() + 1}-${now.getDate()}`;
      if (getLastNotifiedDate(session.accountId) === todayKey) return;

      setLastNotifiedDate(session.accountId, todayKey);
      const body = buildWorkoutNotificationBody(profile, weeklyPlan);
      sendWorkoutNotification('CALI PRO', body);
    };

    checkReminder();
    const intervalId = window.setInterval(checkReminder, 20000);
    return () => window.clearInterval(intervalId);
  }, [session, profile, weeklyPlan]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    window.setTimeout(() => {
      setToastMessage((cur) => (cur === msg ? null : cur));
    }, 3200);
  };

  const launchPendingTransitionIfAny = () => {
    const pending = pendingTransitionRef.current;
    if (!pending) return;
    pendingTransitionRef.current = null;
    setActiveTimer({
      mode: 'transition',
      nextExerciseName: pending.nextExerciseName,
      targetSeconds: transitionSecondsRef.current,
      voiceEnabled: true,
      handsFreeVoice: totalVoiceGuide,
      autoStart: true,
    });
  };

  const openWaterReminder = () => {
    setWaterReminderOpen(true);
    if (waterTimerRef.current !== null) {
      window.clearTimeout(waterTimerRef.current);
    }
    waterTimerRef.current = window.setTimeout(() => {
      setWaterReminderOpen(false);
      waterTimerRef.current = null;
      launchPendingTransitionIfAny();
    }, 6000);
  };

  const handleDismissWater = () => {
    if (waterTimerRef.current !== null) {
      window.clearTimeout(waterTimerRef.current);
      waterTimerRef.current = null;
    }
    setWaterReminderOpen(false);
    launchPendingTransitionIfAny();
  };

  const handleAcknowledgeWater = () => {
    setWaterSipsCount((c) => c + 1);
    handleDismissWater();
  };

  const handleStartSession = () => {
    playTechClick();
    if (sessionStatus === 'idle') {
      setCognitiveWarmupOpen(true);
      return;
    }
    setSessionStatus('running');
    showToast('Cronometro sessione ripreso!');
  };

  const handleFinishCognitiveWarmup = () => {
    setCognitiveWarmupOpen(false);
    setSessionElapsedSeconds(0);
    setSessionStatus('running');
    showToast('Attivazione completata! Cronometro sessione avviato.');
  };

  const handleTogglePauseSession = () => {
    setSessionStatus((cur) => (cur === 'running' ? 'paused' : 'running'));
  };

  const handleChangeTransitionDefault = (sec: number) => {
    const clamped = Math.max(30, Math.min(300, sec));
    setTransitionSeconds(clamped);
    try {
      localStorage.setItem(TRANSITION_DEFAULT_KEY, String(clamped));
    } catch {
      // ignore storage quota errors
    }
  };

  const handleVoiceTimerAction = (action: 'start' | 'stop') => {
    setActiveTimer((prev) =>
      prev
        ? {
            ...prev,
            externalAction: { type: action, nonce: Date.now() },
          }
        : null
    );
  };

  // Ensure activeDraft aligns with selectedDay
  const currentDay = weeklyPlan[selectedDayIndex] ?? weeklyPlan[0];
  const activeExercises: WorkoutExerciseItem[] = useMemo(() => {
    if (!currentDay) return [];
    if (activeDraft && activeDraft.dayId === currentDay.id) {
      return activeDraft.exercises;
    }
    return cloneDayExercises(currentDay);
  }, [currentDay, activeDraft]);

  const activeWarmup: WarmupExerciseItem[] = useMemo(() => {
    if (!currentDay) return [];
    if (activeDraft && activeDraft.dayId === currentDay.id && Array.isArray(activeDraft.warmup)) {
      return activeDraft.warmup;
    }
    return cloneDayWarmup(currentDay, profile);
  }, [currentDay, activeDraft, profile]);

  const activeStretch: StretchExerciseItem[] = useMemo(() => {
    if (!currentDay) return [];
    if (activeDraft && activeDraft.dayId === currentDay.id && Array.isArray(activeDraft.stretch)) {
      return activeDraft.stretch;
    }
    return cloneDayStretch(currentDay, profile);
  }, [currentDay, activeDraft, profile]);

  const weeklyMissions = useMemo(
    () =>
      computeWeeklyMissions({
        history,
        activeExercises,
        activeStretch,
        prehabCompletedDates,
      }),
    [history, activeExercises, activeStretch, prehabCompletedDates]
  );

  // Automatically award +150 XP once for each newly completed weekly mission
  useEffect(() => {
    if (!session || loadedAccountId !== session.accountId) return;
    const newlyCompleted = weeklyMissions.filter(
      (m) => m.completed && !claimedMissionKeys.includes(m.claimKey)
    );
    if (newlyCompleted.length === 0) return;

    setClaimedMissionKeys((prev) => {
      const merged = new Set(prev);
      for (const m of newlyCompleted) {
        merged.add(m.claimKey);
      }
      return Array.from(merged);
    });
    playSetCompleteTone();
    const totalBonus = newlyCompleted.reduce((acc, m) => acc + m.xpBonus, 0);
    showToast(`Missione completata: +${totalBonus} XP!`);
  }, [session, loadedAccountId, weeklyMissions, claimedMissionKeys]);

  const handleAuthenticated = (nextSession: AuthSession) => {
    setSession(nextSession);
    showToast(
      nextSession.isGuest
        ? 'Accesso come Ospite attivo'
        : `Bentornato ${nextSession.email}`
    );
  };

  const handleLogout = () => {
    saveAuthSession(null);
    setSession(null);
    setLoadedAccountId(null);
    setProfile(null);
    setWeeklyPlan([]);
    setHistory([]);
    setCoachMessages([]);
    setUnlockedSkills([]);
    setPrehabCompletedDates([]);
    setClaimedMissionKeys([]);
    setMorningCheckins([]);
    setNutritionLogs([]);
    setExerciseNotes({});
    setWeightLog([]);
    setTotalVoiceGuide(false);
    setManualWorkoutDays({});
    setSavedCombos([]);
    setExpressMinutes(null);
    setPendingVisionPrompt(null);
    setPostWorkoutSummary(null);
    setActiveDraft(null);
    setSessionStatus('idle');
    setSessionElapsedSeconds(0);
    setCognitiveWarmupOpen(false);
    setWaterSipsCount(0);
    pendingTransitionRef.current = null;
    handleDismissWater();
  };

  const handleOnboardingComplete = (newProfile: AthleteProfile) => {
    const newPlan = generateWeeklyProgram(newProfile);
    setProfile(newProfile);
    setWeeklyPlan(newPlan);
    setSelectedDayIndex(0);
    setActiveDraft(
      newPlan[0]
        ? {
            dayId: newPlan[0].id,
            startedAtISO: new Date().toISOString(),
            warmup: cloneDayWarmup(newPlan[0], newProfile),
            stretch: cloneDayStretch(newPlan[0], newProfile),
            exercises: cloneDayExercises(newPlan[0]),
          }
        : null
    );
    setIsEditingOnboarding(false);
    setActiveTab('scheda');
    showToast('Scheda personalizzata generata!');
  };

  const handleOnboardingCustomSchedule = (newProfile: AthleteProfile) => {
    setProfile(newProfile);
    setIsEditingOnboarding(false);
    setActiveTab('scheda');
    setBuilderState({ open: true, startBlank: true });
  };

  const handleSaveCustomPlan = (newPlan: WorkoutDayPlan[]) => {
    setWeeklyPlan(newPlan);
    setSelectedDayIndex(0);
    setExpressMinutes(null);
    setActiveDraft(
      newPlan[0]
        ? {
            dayId: newPlan[0].id,
            startedAtISO: new Date().toISOString(),
            warmup: cloneDayWarmup(newPlan[0], profile),
            stretch: cloneDayStretch(newPlan[0], profile),
            exercises: cloneDayExercises(newPlan[0]),
          }
        : null
    );
    setBuilderState({ open: false, startBlank: false });
    showToast('La tua scheda personalizzata è stata salvata!');
  };

  const handleSelectDay = (idx: number) => {
    setSelectedDayIndex(idx);
    setExpressMinutes(null);
    setSessionStatus('idle');
    setSessionElapsedSeconds(0);
    setCognitiveWarmupOpen(false);
    setWaterSipsCount(0);
    pendingTransitionRef.current = null;
    handleDismissWater();
    const day = weeklyPlan[idx];
    if (day) {
      setActiveDraft({
        dayId: day.id,
        startedAtISO: new Date().toISOString(),
        warmup: cloneDayWarmup(day, profile),
        stretch: cloneDayStretch(day, profile),
        exercises: cloneDayExercises(day),
      });
    }
  };

  const mutateDayWarmup = (
    updater: (list: WarmupExerciseItem[]) => WarmupExerciseItem[],
    persistTemplate = true
  ) => {
    if (!currentDay) return;
    const base =
      activeDraft && activeDraft.dayId === currentDay.id && Array.isArray(activeDraft.warmup)
        ? activeDraft.warmup
        : cloneDayWarmup(currentDay, profile);
    const nextWarmup = updater(base);

    setActiveDraft((prev) => ({
      dayId: currentDay.id,
      startedAtISO: prev?.dayId === currentDay.id ? prev.startedAtISO : new Date().toISOString(),
      warmup: nextWarmup,
      stretch:
        prev && prev.dayId === currentDay.id && Array.isArray(prev.stretch)
          ? prev.stretch
          : cloneDayStretch(currentDay, profile),
      exercises:
        prev && prev.dayId === currentDay.id ? prev.exercises : cloneDayExercises(currentDay),
    }));

    if (persistTemplate) {
      setWeeklyPlan((prevPlan) =>
        prevPlan.map((d, idx) =>
          idx === selectedDayIndex
            ? {
                ...d,
                warmup: nextWarmup.map((w) => ({ ...w, completed: false })),
              }
            : d
        )
      );
    }
  };

  const handleToggleWarmupItem = (warmupId: string) => {
    mutateDayWarmup(
      (list) => list.map((w) => (w.id === warmupId ? { ...w, completed: !w.completed } : w)),
      false
    );
  };

  const handleAddWarmupItem = (item: { name: string; targetLabel: string; notes?: string }) => {
    const created: WarmupExerciseItem = {
      id: `warm_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: item.name,
      targetLabel: item.targetLabel,
      notes: item.notes,
      completed: false,
      isCustom: true,
    };
    mutateDayWarmup((list) => [...list, created], true);
    showToast(`Aggiunto al riscaldamento: ${item.name}`);
  };

  const handleRemoveWarmupItem = (warmupId: string) => {
    mutateDayWarmup((list) => list.filter((w) => w.id !== warmupId), true);
  };

  const handleResetWarmupToDefault = () => {
    if (!currentDay) return;
    const fresh = generateWarmupForDay(currentDay.title, profile?.equipment, profile?.injuries);
    mutateDayWarmup(() => fresh, true);
    showToast('Riscaldamento automatico ripristinato');
  };

  const mutateDayStretch = (
    updater: (list: StretchExerciseItem[]) => StretchExerciseItem[],
    persistTemplate = true
  ) => {
    if (!currentDay) return;
    const base =
      activeDraft && activeDraft.dayId === currentDay.id && Array.isArray(activeDraft.stretch)
        ? activeDraft.stretch
        : cloneDayStretch(currentDay, profile);
    const nextStretch = updater(base);

    setActiveDraft((prev) => ({
      dayId: currentDay.id,
      startedAtISO: prev?.dayId === currentDay.id ? prev.startedAtISO : new Date().toISOString(),
      warmup:
        prev && prev.dayId === currentDay.id && Array.isArray(prev.warmup)
          ? prev.warmup
          : cloneDayWarmup(currentDay, profile),
      stretch: nextStretch,
      exercises:
        prev && prev.dayId === currentDay.id ? prev.exercises : cloneDayExercises(currentDay),
    }));

    if (persistTemplate) {
      setWeeklyPlan((prevPlan) =>
        prevPlan.map((d, idx) =>
          idx === selectedDayIndex
            ? {
                ...d,
                stretch: nextStretch.map((s) => ({ ...s, completed: false })),
              }
            : d
        )
      );
    }
  };

  const handleToggleStretchItem = (stretchId: string) => {
    mutateDayStretch(
      (list) => list.map((s) => (s.id === stretchId ? { ...s, completed: !s.completed } : s)),
      false
    );
  };

  const handleAddStretchItem = (item: { name: string; targetLabel: string; notes?: string }) => {
    const created: StretchExerciseItem = {
      id: `stretch_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name: item.name,
      targetLabel: item.targetLabel,
      notes: item.notes,
      completed: false,
      isCustom: true,
    };
    mutateDayStretch((list) => [...list, created], true);
    showToast(`Aggiunto allo stretching: ${item.name}`);
  };

  const handleRemoveStretchItem = (stretchId: string) => {
    mutateDayStretch((list) => list.filter((s) => s.id !== stretchId), true);
  };

  const handleResetStretchToDefault = () => {
    if (!currentDay) return;
    const fresh = generateStretchingForDay(currentDay.title, profile?.equipment);
    mutateDayStretch(() => fresh, true);
    showToast('Stretching finale automatico ripristinato');
  };

  const handleUnlockSkill = (record: UnlockedSkillRecord) => {
    playLevelUpFanfare();
    setUnlockedSkills((prev) => {
      const existing = prev.findIndex((r) => r.skillId === record.skillId);
      if (existing >= 0) {
        return prev.map((r, i) => (i === existing ? record : r));
      }
      return [...prev, record];
    });
    const skillName = SKILL_NODE_MAP[record.skillId]?.name ?? record.skillId;
    showToast(`Skill Sbloccata e Certificata: ${skillName}!`);
  };

  const mutateDraftExercises = (updater: (list: WorkoutExerciseItem[]) => WorkoutExerciseItem[]) => {
    if (!currentDay) return;
    setActiveDraft((prev) => {
      const base =
        prev && prev.dayId === currentDay.id ? prev.exercises : cloneDayExercises(currentDay);
      const baseWarmup =
        prev && prev.dayId === currentDay.id && Array.isArray(prev.warmup)
          ? prev.warmup
          : cloneDayWarmup(currentDay, profile);
      const baseStretch =
        prev && prev.dayId === currentDay.id && Array.isArray(prev.stretch)
          ? prev.stretch
          : cloneDayStretch(currentDay, profile);
      return {
        dayId: currentDay.id,
        startedAtISO: prev?.dayId === currentDay.id ? prev.startedAtISO : new Date().toISOString(),
        warmup: baseWarmup,
        stretch: baseStretch,
        exercises: updater(base),
      };
    });
  };

  const handleSetTechnicalScore = (exerciseInstanceId: string, score: 1 | 2 | 3) => {
    playSetCompleteTone();
    mutateDraftExercises((list) =>
      list.map((ex) =>
        ex.instanceId === exerciseInstanceId
          ? { ...ex, technicalScore: ex.technicalScore === score ? null : score }
          : ex
      )
    );
  };

  const handleUpdateSet = (
    exerciseInstanceId: string,
    setId: string,
    patch: { actualValue?: number; addedWeightKg?: number; rpe?: number | null; completed?: boolean }
  ) => {
    const targetEx = activeExercises.find((ex) => ex.instanceId === exerciseInstanceId);
    if (patch.completed === true) {
      let prevBestValue = 0;
      if (targetEx) {
        for (const sess of history) {
          const match = sess.exercises.find((e) => e.exerciseId === targetEx.exerciseId);
          if (match) {
            prevBestValue = match.bestValue;
            break;
          }
        }
      }
      const targetSet = targetEx?.sets.find((s) => s.id === setId);
      const nextVal = patch.actualValue ?? targetSet?.actualValue ?? 0;
      const alreadyBeatToday = targetEx
        ? targetEx.sets.some((s) => s.completed && s.id !== setId && s.actualValue > prevBestValue)
        : false;
      const isGhostRecordBroken =
        prevBestValue > 0 && nextVal > prevBestValue && !alreadyBeatToday;

      if (isGhostRecordBroken && targetEx) {
        playLevelUpFanfare();
        const exName =
          targetEx.customName ?? getExerciseById(targetEx.exerciseId)?.name ?? targetEx.exerciseId;
        showToast(
          `🔥 Nuovo Record su ${exName}: ${nextVal}${targetEx.isIsometric ? 's' : ' rep'}!`
        );
      } else {
        playSetCompleteTone();
      }
    }
    if (targetEx && targetEx.sets.length > 0 && patch.completed === true) {
      const wasAllDone = targetEx.sets.every((s) => s.completed);
      const nextSets = targetEx.sets.map((s) => (s.id === setId ? { ...s, ...patch } : s));
      const isNowAllDone = nextSets.every((s) => s.completed);
      if (!wasAllDone && isNowAllDone) {
        const nextIncomplete = activeExercises.find(
          (ex) => ex.instanceId !== exerciseInstanceId && ex.sets.some((s) => !s.completed)
        );
        if (nextIncomplete) {
          const nextDef = getExerciseById(nextIncomplete.exerciseId);
          pendingTransitionRef.current = {
            nextExerciseName:
              nextIncomplete.customName ?? nextDef?.name ?? nextIncomplete.exerciseId,
          };
        } else {
          pendingTransitionRef.current = null;
        }
        openWaterReminder();
      }
    }

    mutateDraftExercises((list) =>
      list.map((ex) => {
        if (ex.instanceId !== exerciseInstanceId) return ex;
        return {
          ...ex,
          sets: ex.sets.map((s) => (s.id === setId ? { ...s, ...patch } : s)),
        };
      })
    );
  };

  const handleAddSet = (exerciseInstanceId: string) => {
    mutateDraftExercises((list) =>
      list.map((ex) => {
        if (ex.instanceId !== exerciseInstanceId) return ex;
        const last = ex.sets[ex.sets.length - 1];
        return {
          ...ex,
          sets: [
            ...ex.sets,
            {
              id: `set_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
              targetValue: last?.targetValue ?? (ex.isIsometric ? 15 : 8),
              actualValue: last?.actualValue ?? (ex.isIsometric ? 15 : 8),
              addedWeightKg: last?.addedWeightKg ?? 0,
              rpe: null,
              completed: false,
            },
          ],
        };
      })
    );
  };

  const handleSwapExercise = (exerciseInstanceId: string, newExerciseId: string) => {
    const newDef = getExerciseById(newExerciseId);
    if (!newDef) return;
    mutateDraftExercises((list) =>
      list.map((ex) => {
        if (ex.instanceId !== exerciseInstanceId) return ex;
        const target = newDef.type === 'isometric' ? 15 : 8;
        return {
          ...ex,
          exerciseId: newDef.id,
          customName: undefined,
          customCategory: undefined,
          isIsometric: newDef.type === 'isometric',
          isNegative: newDef.isNegative,
          negativeSeconds: newDef.negativeSeconds,
          variantNote: newDef.variantHint,
          restSeconds: newDef.defaultRestSec,
          sets: ex.sets.map((s) => ({
            ...s,
            targetValue: target,
            actualValue: target,
            addedWeightKg: newDef.supportsWeight ? s.addedWeightKg : 0,
            completed: false,
            rpe: null,
          })),
        };
      })
    );
    showToast(`Esercizio sostituito con ${newDef.name}`);
  };

  const handleApplyIsometricSeconds = (
    exerciseInstanceId: string,
    setId: string,
    seconds: number
  ) => {
    handleUpdateSet(exerciseInstanceId, setId, {
      actualValue: seconds,
      completed: true,
      rpe: 8,
    });
    showToast(`Salvati ${seconds}s nella serie`);
  };

  const handleApplyNegativeReps = (
    exerciseInstanceId: string,
    setId: string,
    reps: number
  ) => {
    handleUpdateSet(exerciseInstanceId, setId, {
      actualValue: reps,
      completed: true,
      rpe: 8,
    });
    showToast(`Salvate ${reps} negative nella serie`);
  };

  const handleFinishWorkout = () => {
    if (!currentDay || !profile) return;

    const records: CompletedExerciseRecord[] = activeExercises.map((item) => {
      const def = getExerciseById(item.exerciseId);
      const completedSets = item.sets.filter((s) => s.completed);
      const evalSets = completedSets.length > 0 ? completedSets : item.sets;

      const bestValue = Math.max(...evalSets.map((s) => s.actualValue), 0);
      const totalVolume = evalSets.reduce((acc, s) => acc + s.actualValue, 0);
      const rpes = evalSets.map((s) => s.rpe).filter((r): r is number => r !== null);
      const avgRpe = rpes.length > 0 ? rpes.reduce((a, b) => a + b, 0) / rpes.length : 8;
      const maxAddedWeightKg = Math.max(...evalSets.map((s) => s.addedWeightKg), 0);

      return {
        exerciseId: item.exerciseId,
        exerciseName: item.customName ?? def?.name ?? item.exerciseId,
        category: item.customCategory ?? def?.category ?? 'Tirata',
        isIsometric: item.isIsometric,
        targetValue: item.sets[0]?.targetValue ?? 0,
        sets: item.sets,
        bestValue,
        totalVolume,
        avgRpe,
        maxAddedWeightKg,
        technicalScore: item.technicalScore ?? null,
      };
    });

    const allRpes = records.map((r) => r.avgRpe);
    const avgRpe = allRpes.length > 0 ? allRpes.reduce((a, b) => a + b, 0) / allRpes.length : 8;
    const maxRpe = Math.max(
      ...activeExercises.flatMap((e) => e.sets.map((s) => s.rpe ?? 0)),
      avgRpe
    );
    const ratedTechScores = records
      .map((r) => r.technicalScore)
      .filter((v): v is 1 | 2 | 3 => v === 1 || v === 2 || v === 3);
    const avgTechnicalScore =
      ratedTechScores.length > 0
        ? ratedTechScores.reduce((a, b) => a + b, 0) / ratedTechScores.length
        : null;

    const startedMs = activeDraft?.startedAtISO
      ? new Date(activeDraft.startedAtISO).getTime()
      : Date.now() - 45 * 60000;
    const elapsedFallbackSec = Math.max(
      60,
      Math.min(14400, Math.round((Date.now() - startedMs) / 1000))
    );
    const durationSeconds =
      sessionElapsedSeconds > 0 ? sessionElapsedSeconds : elapsedFallbackSec;
    const durationMinutes = Math.max(1, Math.round(durationSeconds / 60));

    const newSession: WorkoutSessionLog = {
      id: `sess_${Date.now()}`,
      dateISO: new Date().toISOString(),
      dayPlanId: currentDay.id,
      dayTitle: currentDay.title,
      durationMinutes,
      durationSeconds,
      exercises: records,
      avgRpe,
      maxRpe,
      avgTechnicalScore,
      stretchesCompletedCount: activeStretch.filter((s) => s.completed).length,
    };

    setSessionStatus('idle');
    setSessionElapsedSeconds(0);
    setCognitiveWarmupOpen(false);
    setWaterSipsCount(0);
    pendingTransitionRef.current = null;
    handleDismissWater();

    const summary = computePostWorkoutSummary(newSession, history);
    setHistory((prev) => [newSession, ...prev]);
    setPendingCheckinSessionId(newSession.id);
    setPostWorkoutSummary(summary);

    // Advance to next day in split for next workout
    const nextDayIdx = (selectedDayIndex + 1) % weeklyPlan.length;
    setSelectedDayIndex(nextDayIdx);
    const nextDay = weeklyPlan[nextDayIdx];
    setActiveDraft(
      nextDay
        ? {
            dayId: nextDay.id,
            startedAtISO: new Date().toISOString(),
            warmup: cloneDayWarmup(nextDay, profile),
            stretch: cloneDayStretch(nextDay, profile),
            exercises: cloneDayExercises(nextDay),
          }
        : null
    );
    showToast('Allenamento salvato! Riepilogo pronto.');
  };

  const todayDateKey = getLocalDateKey();
  const todayCheckin = useMemo(
    () => morningCheckins.find((c) => c.dateKey === todayDateKey) ?? null,
    [morningCheckins, todayDateKey]
  );

  const handleSaveMorningCheckin = (values: {
    sleepQuality: SleepQuality;
    energyLevel: EnergyLevel;
    jointStatus: MorningJointStatus;
  }) => {
    const today = getLocalDateKey();
    const record: MorningCheckinRecord = {
      id: todayCheckin?.id ?? `chk_${today}`,
      dateKey: today,
      timestampISO: new Date().toISOString(),
      sleepQuality: values.sleepQuality,
      energyLevel: values.energyLevel,
      jointStatus: values.jointStatus,
      volumeAdapted: todayCheckin?.volumeAdapted,
      jointProtectedApplied: todayCheckin?.jointProtectedApplied,
    };
    setMorningCheckins((prev) => [
      record,
      ...prev.filter((c) => c.dateKey !== today),
    ]);
    const isOptimal =
      values.sleepQuality !== 'scarso' &&
      values.energyLevel !== 'bassa' &&
      values.jointStatus === 'ok';
    if (isOptimal) {
      showToast('Check-in salvato! Pronto per dare il massimo.');
    } else {
      showToast('Check-in salvato! Adattamento intelligente disponibile.');
    }
  };

  const handleSetManualWorkoutDay = (
    dateKey: string,
    intensity: ManualWorkoutIntensity | null
  ) => {
    setManualWorkoutDays((prev) => {
      const next = { ...prev };
      if (!intensity) {
        delete next[dateKey];
      } else {
        next[dateKey] = intensity;
      }
      return next;
    });
  };

  const handleApplyExpressTime = (minutes: ExpressMinutesOption | null) => {
    if (!currentDay) return;
    setExpressMinutes(minutes);
    if (!minutes) {
      mutateDraftExercises(() => cloneDayExercises(currentDay));
      showToast('Scheda ripristinata al volume standard.');
      return;
    }
    const adapted = adaptExercisesForTimeBudget(currentDay, minutes);
    mutateDraftExercises(() => adapted);
    showToast(`Scheda adattata per ${minutes} minuti (${adapted.length} esercizi)!`);
  };

  const handleSaveCombo = (combo: ComboFlowPreset) => {
    setSavedCombos((prev) => [combo, ...prev.filter((c) => c.id !== combo.id)]);
    showToast(`Combo "${combo.name}" salvata!`);
  };

  const handleUpdateComboRecord = (comboId: string, durationSec: number) => {
    setSavedCombos((prev) =>
      prev.map((c) => {
        if (c.id !== comboId) return c;
        const nextBest =
          c.bestDurationSeconds == null || durationSec < c.bestDurationSeconds
            ? durationSec
            : c.bestDurationSeconds;
        return { ...c, bestDurationSeconds: nextBest };
      })
    );
  };

  const handleDeleteCombo = (comboId: string) => {
    setSavedCombos((prev) => prev.filter((c) => c.id !== comboId));
  };

  const handleImportSharedPlan = (importedPlan: WorkoutDayPlan[]) => {
    if (importedPlan.length === 0) return;
    setWeeklyPlan(importedPlan);
    setSelectedDayIndex(0);
    setExpressMinutes(null);
    setActiveDraft({
      dayId: importedPlan[0].id,
      startedAtISO: new Date().toISOString(),
      warmup: cloneDayWarmup(importedPlan[0], profile),
      stretch: cloneDayStretch(importedPlan[0], profile),
      exercises: cloneDayExercises(importedPlan[0]),
    });
    showToast(`Scheda condivisa caricata (${importedPlan.length} giorni)!`);
  };

  const handleSendVisionToCoach = (analysisText: string) => {
    setPendingVisionPrompt(analysisText);
    setActiveTab('coach');
    showToast('Analisi Coach Vision inviata al Coach AI!');
  };

  const handleAdaptVolumeMinusOne = () => {
    if (!currentDay) return;
    mutateDraftExercises((list) =>
      list.map((ex) => {
        if (ex.sets.length <= 1) return ex;
        const lastUncompletedIdx = [...ex.sets]
          .reverse()
          .findIndex((s) => !s.completed);
        const removeIndex =
          lastUncompletedIdx >= 0
            ? ex.sets.length - 1 - lastUncompletedIdx
            : ex.sets.length - 1;
        return {
          ...ex,
          sets: ex.sets.filter((_, idx) => idx !== removeIndex),
        };
      })
    );
    const today = getLocalDateKey();
    setMorningCheckins((prev) =>
      prev.map((c) => (c.dateKey === today ? { ...c, volumeAdapted: true } : c))
    );
    showToast('Scheda di oggi adattata: -1 serie per esercizio!');
  };

  const handleProtectJointExercises = (joint: MorningJointStatus): number => {
    if (!currentDay || joint === 'ok') return 0;
    let replacedCount = 0;
    mutateDraftExercises((list) =>
      list.map((ex) => {
        if (!isExerciseStressedByJoint(ex.exerciseId, ex.customName, joint)) {
          return ex;
        }
        const def = getExerciseById(ex.exerciseId);
        const category = ex.customCategory ?? def?.category ?? 'Spinta';
        const safeAlt = pickSafeAlternativeForJoint(ex.exerciseId, category, joint);
        if (!safeAlt) return ex;
        replacedCount += 1;
        const target = safeAlt.type === 'isometric' ? 15 : 8;
        return {
          ...ex,
          exerciseId: safeAlt.id,
          customName: undefined,
          customCategory: undefined,
          isIsometric: safeAlt.type === 'isometric',
          isNegative: safeAlt.isNegative,
          negativeSeconds: safeAlt.negativeSeconds,
          variantNote: `${safeAlt.variantHint} · Sostituito per protezione articolare`,
          restSeconds: safeAlt.defaultRestSec,
          sets: ex.sets.map((s) => ({
            ...s,
            targetValue: target,
            actualValue: target,
            addedWeightKg: safeAlt.supportsWeight ? s.addedWeightKg : 0,
            completed: false,
            rpe: null,
          })),
        };
      })
    );
    const today = getLocalDateKey();
    setMorningCheckins((prev) =>
      prev.map((c) =>
        c.dateKey === today ? { ...c, jointProtectedApplied: true } : c
      )
    );
    showToast(
      replacedCount > 0
        ? `Sostituiti ${replacedCount} esercizi per proteggere l'articolazione!`
        : 'Routine Prehab protettiva avviata!'
    );
    return replacedCount;
  };

  const handleUpdateTodayNutrition = (
    updater: (cur: DailyNutritionLog) => DailyNutritionLog
  ) => {
    const today = getLocalDateKey();
    setNutritionLogs((prev) => {
      const existing = prev.find((l) => l.dateKey === today) ?? {
        dateKey: today,
        waterMl: 0,
        proteinMeals: 0,
        creatineTaken: false,
      };
      const updated = updater(existing);
      return [updated, ...prev.filter((l) => l.dateKey !== today)];
    });
  };

  const handleUpdateExerciseNote = (exerciseKey: string, note: string) => {
    setExerciseNotes((prev) => ({
      ...prev,
      [exerciseKey]: note,
    }));
  };

  const handleAddExtraExercise = (item: WorkoutExerciseItem) => {
    mutateDraftExercises((list) => [...list, item]);
    const exName = item.customName ?? getExerciseById(item.exerciseId)?.name ?? item.exerciseId;
    showToast(`Aggiunto alla sessione di oggi: ${exName}`);
  };

  const handleAddWeightEntry = (entry: { dateISO: string; weightKg: number }) => {
    const cleanWeight = Math.round(entry.weightKg * 10) / 10;
    setWeightLog((prev) => {
      const filtered = prev.filter((e) => e.dateISO !== entry.dateISO);
      const next = [
        ...filtered,
        {
          id: `wt_${entry.dateISO}_${Date.now()}`,
          dateISO: entry.dateISO,
          weightKg: cleanWeight,
        },
      ].sort((a, b) => a.dateISO.localeCompare(b.dateISO));
      const latest = next[next.length - 1];
      if (latest) {
        setProfile((curProfile) =>
          curProfile ? { ...curProfile, weightKg: latest.weightKg } : curProfile
        );
      }
      return next;
    });
    showToast(`Peso registrato: ${cleanWeight} kg`);
  };

  const handleDeleteWeightEntry = (id: string) => {
    setWeightLog((prev) => {
      const next = prev.filter((e) => e.id !== id);
      const latest = next[next.length - 1];
      if (latest) {
        setProfile((curProfile) =>
          curProfile ? { ...curProfile, weightKg: latest.weightKg } : curProfile
        );
      }
      return next;
    });
  };

  const handleApplyCoachProposal = (messageId: string, proposal: CoachActionProposal) => {
    if (!profile) return;
    const { updatedPlan, updatedProfile } = applyCoachProposalToPlan(proposal, weeklyPlan, profile);
    setWeeklyPlan(updatedPlan);
    setProfile(updatedProfile);

    // Sync activeDraft if matching current day
    const matchingDay = updatedPlan[selectedDayIndex];
    if (matchingDay) {
      setActiveDraft({
        dayId: matchingDay.id,
        startedAtISO: new Date().toISOString(),
        warmup: cloneDayWarmup(matchingDay, updatedProfile),
        stretch: cloneDayStretch(matchingDay, updatedProfile),
        exercises: cloneDayExercises(matchingDay),
      });
    }

    setCoachMessages((prev) =>
      prev.map((m) =>
        m.id === messageId
          ? {
              ...m,
              appliedProposalIds: [...(m.appliedProposalIds ?? []), proposal.id],
            }
          : m
      )
    );

    if (history[0]) {
      setHistory((prev) =>
        prev.map((s, idx) =>
          idx === 0
            ? {
                ...s,
                coachFeedback: proposal.title,
              }
            : s
        )
      );
    }

    showToast(`Scheda aggiornata: ${proposal.title}`);
  };

  const handleExportBackup = async () => {
    if (!session) return;
    const photoDiary = await loadProgressPhotos(session.accountId);
    const payload = createBackupPayload(
      {
        profile,
        weeklyPlan,
        selectedDayIndex,
        activeDraft,
        history,
        coachMessages,
        unlockedSkills,
        prehabCompletedDates,
        claimedMissionKeys,
        morningCheckins,
        nutritionLogs,
        exerciseNotes,
        weightLog,
        totalVoiceGuide,
        manualWorkoutDays,
        savedCombos,
      },
      {
        photoDiary,
      }
    );
    const blob = new Blob([JSON.stringify(payload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const dateStr = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = `calipro-backup-${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    showToast('Backup completo (dati, disciplina e foto) esportato!');
  };

  const handleImportBackup = async (jsonText: string) => {
    if (!session) return;
    const parsed = parseBackupPayload(jsonText);
    if (!parsed) {
      showToast('File di backup non valido.');
      return;
    }
    const { state, photoDiary } = parsed;
    setProfile(state.profile);
    setWeeklyPlan(state.weeklyPlan);
    setSelectedDayIndex(state.selectedDayIndex);
    setActiveDraft(state.activeDraft);
    setHistory(state.history);
    setCoachMessages(state.coachMessages);
    setUnlockedSkills(state.unlockedSkills ?? []);
    setPrehabCompletedDates(state.prehabCompletedDates ?? []);
    setClaimedMissionKeys(state.claimedMissionKeys ?? []);
    setMorningCheckins(state.morningCheckins ?? []);
    setNutritionLogs(state.nutritionLogs ?? []);
    setExerciseNotes(state.exerciseNotes ?? {});
    setWeightLog(state.weightLog ?? []);
    setTotalVoiceGuide(Boolean(state.totalVoiceGuide));
    setManualWorkoutDays(state.manualWorkoutDays ?? {});
    setSavedCombos(state.savedCombos ?? []);
    if (photoDiary && photoDiary.length > 0) {
      await replaceProgressPhotosForAccount(session.accountId, photoDiary);
    }
    showToast('Backup completo importato e ripristinato!');
  };

  const handleGenerateAiPlan = async (redirectToScheda = false) => {
    if (!profile || isGeneratingAiPlan) return;
    setIsGeneratingAiPlan(true);
    try {
      const generatedPlan = await generateWeeklyPlanWithPuterAI(profile);
      setWeeklyPlan(generatedPlan);
      setSelectedDayIndex(0);
      setActiveDraft(
        generatedPlan[0]
          ? {
              dayId: generatedPlan[0].id,
              startedAtISO: new Date().toISOString(),
              warmup: cloneDayWarmup(generatedPlan[0], profile),
              stretch: cloneDayStretch(generatedPlan[0], profile),
              exercises: cloneDayExercises(generatedPlan[0]),
            }
          : null
      );
      setSessionStatus('idle');
      setSessionElapsedSeconds(0);
      pendingTransitionRef.current = null;
      handleDismissWater();
      if (redirectToScheda) {
        setActiveTab('scheda');
      }
      showToast('Scheda personalizzata generata dall’AI e salvata!');
    } catch (err) {
      const msg =
        err instanceof Error
          ? err.message
          : 'Errore durante la generazione della scheda AI.';
      showToast(msg);
      throw err;
    } finally {
      setIsGeneratingAiPlan(false);
    }
  };

  // 1. Auth gate
  if (!session) {
    return <AuthScreen onAuthenticated={handleAuthenticated} />;
  }

  // Wait until account state finishes hydrating on session switch
  if (loadedAccountId !== session.accountId) {
    return <div className="min-h-screen bg-[#05070A]" />;
  }

  // 2. Onboarding gate
  if (!profile || !profile.onboardingCompleted || isEditingOnboarding) {
    return (
      <OnboardingWizard
        initialProfile={profile}
        onComplete={handleOnboardingComplete}
        onCreateCustomSchedule={handleOnboardingCustomSchedule}
        onCancel={isEditingOnboarding ? () => setIsEditingOnboarding(false) : undefined}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#05070A] text-[#FFFFFF] flex flex-col">
      <OfflineIndicator />

      {/* Compact Sticky Top App Bar centered for 7-inch smartphones */}
      <header className="sticky top-0 z-30 h-14 bg-[#090D16]/90 backdrop-blur-md border-b border-[#1E293B] px-3">
        <div className="max-w-[500px] mx-auto h-full flex items-center justify-between gap-2">
          <CaliProLogo size="sm" />

          <div className="flex items-center gap-1.5 shrink-0">
            <div ref={themeMenuRef} className="relative">
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  setThemeMenuOpen((o) => !o);
                }}
                aria-label="Cambia tema colore"
                title="Cambia tema colore"
                aria-expanded={themeMenuOpen}
                className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl border flex items-center justify-center transition ${
                  themeMenuOpen
                    ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]'
                    : 'bg-[#0F172A] border-[#1E293B] text-[#00D2FF] hover:border-[#00D2FF]/60'
                }`}
              >
                <Palette className="w-4 h-4" />
              </button>

              {themeMenuOpen && (
                <div
                  role="menu"
                  aria-label="Seleziona tema colore"
                  className="absolute right-0 mt-2 w-60 rounded-2xl bg-[#0F172A] border border-[#1E293B] shadow-2xl p-2 space-y-1 z-50"
                >
                  <p className="px-2 py-1 text-[10px] font-extrabold uppercase tracking-wider text-[#94A3B8]">
                    Tema Colore
                  </p>
                  {THEME_PRESETS.map((preset) => {
                    const active = preset.id === themeId;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        role="menuitem"
                        onClick={() => {
                          playTechClick();
                          setThemeId(preset.id);
                          setThemeMenuOpen(false);
                          showToast(`Tema attivo: ${preset.name}`);
                        }}
                        className={`w-full px-2.5 py-2 rounded-xl text-left flex items-center justify-between gap-2 transition ${
                          active
                            ? 'bg-[#132347] border border-[#00D2FF]/70 text-[#FFFFFF]'
                            : 'hover:bg-[#131C31] text-[#CBD5E1]'
                        }`}
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <span
                            className="inline-flex items-center gap-0.5 p-1 rounded-md border border-white/15 shrink-0"
                            style={{ backgroundColor: preset.swatchBg }}
                          >
                            <span
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: preset.swatchPrimary }}
                            />
                            <span
                              className="w-2 h-2 rounded-full"
                              style={{ backgroundColor: preset.swatchAccent }}
                            />
                          </span>
                          <span className="text-xs font-bold truncate">{preset.name}</span>
                        </div>
                        {active && <Check className="w-3.5 h-3.5 text-[#00D2FF] shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                const next = !sfxEnabled;
                setSfxEnabled(next);
                setSoundEffectsEnabled(next);
                if (next) {
                  playTechClick();
                }
                showToast(next ? 'Effetti sonori attivi' : 'Effetti sonori disattivati');
              }}
              aria-label={sfxEnabled ? 'Disattiva effetti sonori' : 'Attiva effetti sonori'}
              title={sfxEnabled ? 'Suoni ON' : 'Suoni OFF'}
              className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl border flex items-center justify-center transition ${
                sfxEnabled
                  ? 'bg-[#0F172A] border-[#00D2FF]/50 text-[#00D2FF] hover:border-[#00D2FF]'
                  : 'bg-[#0F172A] border-[#1E293B] text-[#64748B] hover:text-[#94A3B8]'
              }`}
            >
              {sfxEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <PWAInstallButton compact />

            <button
              type="button"
              onClick={() => {
                playTechClick();
                setBuilderState({ open: true, startBlank: false });
              }}
              aria-label="Crea o modifica scheda"
              title="Crea o modifica scheda"
              className="w-8 h-8 sm:w-9 sm:h-9 rounded-xl bg-[#0F172A] border border-[#1E293B] hover:border-[#38BDF8]/60 flex items-center justify-center text-[#38BDF8] hover:text-[#00D2FF] transition"
            >
              <FileEdit className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => {
                playTechClick();
                setActiveTab('profilo');
              }}
              aria-label="Profilo Atleta"
              title="Profilo Atleta"
              aria-current={activeTab === 'profilo' ? 'page' : undefined}
              className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl border flex items-center justify-center transition ${
                activeTab === 'profilo'
                  ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF] shadow-[0_0_12px_rgba(37,99,235,0.45)]'
                  : 'bg-[#0F172A] border-[#1E293B] text-[#38BDF8] hover:border-[#00D2FF]/60'
              }`}
            >
              <User className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Toast Feedback */}
      {toastMessage && (
        <div
          role="status"
          className="fixed top-16 left-1/2 -translate-x-1/2 w-[calc(100%-24px)] max-w-[476px] z-40 rounded-2xl bg-[#0F172A] border border-[#38BDF8]/60 text-[#FFFFFF] px-4 py-3 text-xs font-bold shadow-xl text-center"
        >
          {toastMessage}
        </div>
      )}

      {/* Main Content Area centered at 500px for 7-inch displays */}
      <main className="flex-1 w-full max-w-[500px] mx-auto px-3 sm:px-4 pt-3.5 pb-24">
        {activeTab === 'scheda' && (
          <WorkoutView
            profile={profile}
            weeklyPlan={weeklyPlan}
            selectedDayIndex={selectedDayIndex}
            activeWarmup={activeWarmup}
            activeStretch={activeStretch}
            activeExercises={activeExercises}
            history={history}
            weeklyMissions={weeklyMissions}
            defaultWeightKg={profile.weightKg}
            todayCheckin={todayCheckin}
            onProtectJointExercises={handleProtectJointExercises}
            expressMinutes={expressMinutes}
            onApplyExpressTime={handleApplyExpressTime}
            savedCombos={savedCombos}
            onSaveCombo={handleSaveCombo}
            onUpdateComboRecord={handleUpdateComboRecord}
            onDeleteCombo={handleDeleteCombo}
            onImportSharedPlan={handleImportSharedPlan}
            exerciseNotes={exerciseNotes}
            onUpdateExerciseNote={handleUpdateExerciseNote}
            onAddExtraExercise={handleAddExtraExercise}
            totalVoiceGuide={totalVoiceGuide}
            onToggleTotalVoiceGuide={() => {
              const next = !totalVoiceGuide;
              setTotalVoiceGuide(next);
              showToast(
                next
                  ? 'Guida Vocale Totale attivata: il Coach annuncia ogni fase.'
                  : 'Guida Vocale Totale disattivata.'
              );
            }}
            sessionStatus={sessionStatus}
            sessionElapsedSeconds={sessionElapsedSeconds}
            waterSipsCount={waterSipsCount}
            hasActiveTimerModal={Boolean(activeTimer)}
            isGeneratingAiPlan={isGeneratingAiPlan}
            onGenerateAiPlan={() => {
              handleGenerateAiPlan(false).catch(() => {});
            }}
            onPrehabCompleted={() => {
              setPrehabCompletedDates((prev) => [...prev, new Date().toISOString()]);
              showToast('Routine Prehab completata! Progresso missioni aggiornato.');
            }}
            onStartSession={handleStartSession}
            onTogglePauseSession={handleTogglePauseSession}
            onAddWaterSip={() => setWaterSipsCount((c) => c + 1)}
            onVoiceTimerAction={handleVoiceTimerAction}
            onSelectDay={handleSelectDay}
            onOpenHistory={() => setActiveTab('storico')}
            onToggleWarmupItem={handleToggleWarmupItem}
            onAddWarmupItem={handleAddWarmupItem}
            onRemoveWarmupItem={handleRemoveWarmupItem}
            onResetWarmupToDefault={handleResetWarmupToDefault}
            onToggleStretchItem={handleToggleStretchItem}
            onAddStretchItem={handleAddStretchItem}
            onRemoveStretchItem={handleRemoveStretchItem}
            onResetStretchToDefault={handleResetStretchToDefault}
            onUpdateSet={handleUpdateSet}
            onAddSet={handleAddSet}
            onSwapExercise={handleSwapExercise}
            onSetTechnicalScore={handleSetTechnicalScore}
            onOpenTimer={(state) => setActiveTimer(state)}
            onFinishWorkout={handleFinishWorkout}
          />
        )}

        {activeTab === 'skill' && (
          <SkillTreeView
            unlockedSkills={unlockedSkills}
            history={history}
            manualWorkoutDays={manualWorkoutDays}
            profile={profile}
            onUnlockSkill={handleUnlockSkill}
            onSendVisionToCoach={handleSendVisionToCoach}
          />
        )}

        {activeTab === 'benessere' && (
          <WellnessView
            profile={profile}
            todayCheckin={todayCheckin}
            morningCheckins={morningCheckins}
            hasJointRiskExercises={
              Boolean(todayCheckin && todayCheckin.jointStatus !== 'ok') &&
              activeExercises.some((ex) =>
                isExerciseStressedByJoint(
                  ex.exerciseId,
                  ex.customName,
                  todayCheckin?.jointStatus ?? 'ok'
                )
              )
            }
            nutritionLogs={nutritionLogs}
            history={history}
            unlockedSkills={unlockedSkills}
            bonusMissionXp={bonusMissionXp}
            manualWorkoutDays={manualWorkoutDays}
            onSaveMorningCheckin={handleSaveMorningCheckin}
            onAdaptVolumeMinusOne={handleAdaptVolumeMinusOne}
            onProtectJointExercises={handleProtectJointExercises}
            onUpdateTodayNutrition={handleUpdateTodayNutrition}
            onPrehabCompleted={() => {
              setPrehabCompletedDates((prev) => [...prev, new Date().toISOString()]);
              showToast('Routine Prehab completata! Progresso missioni aggiornato.');
            }}
            onGoToWorkout={() => setActiveTab('scheda')}
            onGoToSkills={() => setActiveTab('skill')}
          />
        )}

        {activeTab === 'coach' && (
          <CoachView
            profile={profile}
            weeklyPlan={weeklyPlan}
            history={history}
            morningCheckins={morningCheckins}
            messages={coachMessages}
            pendingCheckinSessionId={pendingCheckinSessionId}
            onClearPendingCheckin={() => setPendingCheckinSessionId(null)}
            pendingVisionPrompt={pendingVisionPrompt}
            onClearPendingVision={() => setPendingVisionPrompt(null)}
            onAppendMessage={(msg) => setCoachMessages((prev) => [...prev, msg])}
            onApplyProposal={handleApplyCoachProposal}
          />
        )}

        {activeTab === 'storico' && (
          <HistoryView
            history={history}
            profile={profile}
            morningCheckins={morningCheckins}
            manualWorkoutDays={manualWorkoutDays}
            onSetManualWorkoutDay={handleSetManualWorkoutDay}
            weightLog={weightLog}
            onAddWeightEntry={handleAddWeightEntry}
            onDeleteWeightEntry={handleDeleteWeightEntry}
            unlockedSkills={unlockedSkills}
            accountId={session.accountId}
            currentWeightKg={profile.weightKg}
          />
        )}

        {activeTab === 'profilo' && (
          <ProfileView
            profile={profile}
            session={session}
            weeklyPlan={weeklyPlan}
            unlockedSkills={unlockedSkills}
            history={history}
            prehabCompletedDates={prehabCompletedDates}
            bonusMissionXp={bonusMissionXp}
            nutritionLogs={nutritionLogs}
            weightLog={weightLog}
            onUpdateTodayNutrition={handleUpdateTodayNutrition}
            onAddWeightEntry={handleAddWeightEntry}
            onDeleteWeightEntry={handleDeleteWeightEntry}
            themeId={themeId}
            onChangeTheme={(nextId) => {
              playTechClick();
              setThemeId(nextId);
              const preset = THEME_PRESETS.find((p) => p.id === nextId);
              if (preset) showToast(`Tema attivo: ${preset.name}`);
            }}
            isGeneratingAiPlan={isGeneratingAiPlan}
            onGenerateAiPlan={() => handleGenerateAiPlan(true)}
            onUpdateProfile={(next) => setProfile(next)}
            onEditOnboarding={() => setIsEditingOnboarding(true)}
            onRegeneratePlan={() => {
              const newPlan = generateWeeklyProgram(profile);
              setWeeklyPlan(newPlan);
              setSelectedDayIndex(0);
              setActiveDraft(
                newPlan[0]
                  ? {
                      dayId: newPlan[0].id,
                      startedAtISO: new Date().toISOString(),
                      warmup: cloneDayWarmup(newPlan[0], profile),
                      stretch: cloneDayStretch(newPlan[0], profile),
                      exercises: cloneDayExercises(newPlan[0]),
                    }
                  : null
              );
              showToast('Scheda rigenerata dai tuoi parametri attuali');
            }}
            onExportBackup={() => {
              handleExportBackup().catch(() => {
                showToast('Errore durante esportazione backup.');
              });
            }}
            onImportBackup={(jsonText) => {
              handleImportBackup(jsonText).catch(() => {
                showToast('Errore durante importazione backup.');
              });
            }}
            onLogout={handleLogout}
            onResetAll={() => setConfirmResetModal(true)}
          />
        )}
      </main>

      {/* Fixed Bottom 5-Tab Navigation Bar (Profilo in Top Header) */}
      <nav
        aria-label="Navigazione principale"
        className="fixed bottom-0 left-0 right-0 z-40 bg-[#0F172A]/95 backdrop-blur-md border-t border-[#1E293B] pb-safe"
      >
        <div className="max-w-[500px] mx-auto grid grid-cols-5 h-16 px-1">
          {(
            [
              { id: 'benessere', label: 'Benessere', Icon: HeartPulse },
              { id: 'scheda', label: 'Scheda', Icon: ClipboardList },
              { id: 'skill', label: 'Skill', Icon: Trophy },
              { id: 'coach', label: 'Coach AI', Icon: MessageSquare },
              { id: 'storico', label: 'Storico', Icon: CalendarDays },
            ] as const
          ).map(({ id, label, Icon }) => {
            const active = activeTab === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => {
                  playTechClick();
                  setActiveTab(id);
                }}
                className={`flex flex-col items-center justify-center min-h-[44px] px-1 transition ${
                  active ? 'text-[#38BDF8]' : 'text-[#94A3B8] hover:text-[#FFFFFF]'
                }`}
              >
                <Icon
                  className={`w-5 h-5 ${
                    active ? 'stroke-[2.5] text-[#00D2FF]' : 'stroke-[1.75]'
                  }`}
                />
                <span className="text-[11px] font-bold mt-1 tracking-tight whitespace-nowrap">
                  {label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Floating "Bevi Acqua" End-of-Exercise Popup (auto-closes after 6s) */}
      {waterReminderOpen && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-20 left-4 right-4 sm:left-auto sm:right-6 sm:w-[400px] z-[60] rounded-2xl bg-[#0B1D36]/95 backdrop-blur-md border border-[#00D2FF] p-3.5 shadow-2xl flex items-center justify-between gap-3"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-[#132347] border border-[#00D2FF]/60 flex items-center justify-center shrink-0">
              <Droplets className="w-5 h-5 text-[#00D2FF]" />
            </div>
            <div className="min-w-0">
              <p className="text-xs font-extrabold text-[#FFFFFF] leading-snug">
                Esercizio completato! Ricordati di bere un sorso d&apos;acqua 💧
              </p>
              <p className="text-[11px] text-[#7DD3FC] mt-0.5 tabular-nums">
                Sorsi registrati: {waterSipsCount}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={handleAcknowledgeWater}
              className="min-h-[38px] px-3.5 rounded-xl bg-[#00D2FF] text-[#05070A] text-xs font-extrabold hover:bg-[#38BDF8] transition"
            >
              Fatto
            </button>
            <button
              type="button"
              onClick={handleDismissWater}
              aria-label="Chiudi promemoria acqua"
              className="min-h-[38px] min-w-[34px] rounded-xl bg-[#131C31] text-[#94A3B8] hover:text-[#FFFFFF] flex items-center justify-center transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Integrated Dual Timer Modal/Sheet */}
      <DualTimerSheet
        timerState={activeTimer}
        onClose={() => setActiveTimer(null)}
        onSwitchMode={(mode) =>
          setActiveTimer((prev) =>
            prev
              ? {
                  ...prev,
                  mode,
                  targetSeconds:
                    mode === 'rest'
                      ? 90
                      : mode === 'isometric'
                      ? 20
                      : mode === 'transition'
                      ? transitionSeconds
                      : prev.targetReps ?? 5,
                  negativeSeconds: prev.negativeSeconds ?? 5,
                  targetReps: prev.targetReps ?? 5,
                }
              : null
          )
        }
        onChangeTransitionDefault={handleChangeTransitionDefault}
        onApplyIsometricSeconds={handleApplyIsometricSeconds}
        onApplyNegativeReps={handleApplyNegativeReps}
      />

      {/* Pre-Workout Cognitive Activation Mini-Game */}
      <CognitiveWarmupModal
        isOpen={cognitiveWarmupOpen}
        onStartWorkout={handleFinishCognitiveWarmup}
        onClose={() => setCognitiveWarmupOpen(false)}
      />

      {/* Custom Schedule Builder Modal */}
      {builderState.open && (
        <ScheduleBuilderModal
          initialPlan={weeklyPlan}
          initialDayIndex={selectedDayIndex}
          startBlank={builderState.startBlank}
          onSave={handleSaveCustomPlan}
          onClose={() => setBuilderState({ open: false, startBlank: false })}
        />
      )}

      {/* Shareable Strava-style Post-Workout Summary Modal */}
      <PostWorkoutSummaryModal
        summary={postWorkoutSummary}
        athleteName={profile.name || 'Atleta CALI PRO'}
        onContinueToCoach={() => {
          setPostWorkoutSummary(null);
          setActiveTab('coach');
          showToast('Il Coach AI sta analizzando la tua sessione...');
        }}
      />

      {/* Safe Confirm Reset Modal */}
      {confirmResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070A]/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#0F172A] border border-[#1E293B] p-6 shadow-2xl space-y-4">
            <h3 className="text-lg font-bold text-[#FFFFFF]">Azzerare i dati di questo account?</h3>
            <p className="text-sm text-[#94A3B8] leading-relaxed">
              Verranno eliminati profilo, scheda settimanale, storico e chat con il Coach di questo account su questo dispositivo.
            </p>
            <div className="grid grid-cols-2 gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setConfirmResetModal(false)}
                className="min-h-[44px] rounded-xl bg-[#131C31] border border-[#1E293B] text-sm font-bold text-[#FFFFFF] hover:bg-[#1E293B] transition"
              >
                Annulla
              </button>
              <button
                type="button"
                onClick={() => {
                  clearPersistedState(session.accountId);
                  setConfirmResetModal(false);
                  setProfile(null);
                  setWeeklyPlan([]);
                  setHistory([]);
                  setCoachMessages([]);
                  setUnlockedSkills([]);
                  setPrehabCompletedDates([]);
                  setClaimedMissionKeys([]);
                  setMorningCheckins([]);
                  setNutritionLogs([]);
                  setExerciseNotes({});
                  setWeightLog([]);
                  setTotalVoiceGuide(false);
                  setManualWorkoutDays({});
                  setSavedCombos([]);
                  setExpressMinutes(null);
                  setPendingVisionPrompt(null);
                  setPostWorkoutSummary(null);
                  setActiveDraft(null);
                  setSessionStatus('idle');
                  setSessionElapsedSeconds(0);
                  setCognitiveWarmupOpen(false);
                  setWaterSipsCount(0);
                  pendingTransitionRef.current = null;
                  handleDismissWater();
                }}
                className="min-h-[44px] rounded-xl bg-[#2563EB] text-sm font-bold text-[#FFFFFF] hover:bg-[#3B82F6] transition"
              >
                Azzera tutto
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
