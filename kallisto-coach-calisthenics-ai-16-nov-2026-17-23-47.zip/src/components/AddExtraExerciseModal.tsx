import React, { useMemo, useState } from 'react';
import { Plus, Search, X } from 'lucide-react';
import { EXERCISE_CATALOG } from '../data/exercises';
import type { ExerciseCategory, WorkoutExerciseItem } from '../types/calisthenics';
import { playTechClick } from '../utils/audio';

interface AddExtraExerciseModalProps {
  isOpen: boolean;
  initialCategory: ExerciseCategory;
  onAddExercise: (item: WorkoutExerciseItem) => void;
  onClose: () => void;
}

const CATEGORIES: ExerciseCategory[] = ['Spinta', 'Tirata', 'Core', 'Gambe', 'Skill'];

export const AddExtraExerciseModal: React.FC<AddExtraExerciseModalProps> = ({
  isOpen,
  initialCategory,
  onAddExercise,
  onClose,
}) => {
  const [tab, setTab] = useState<'catalog' | 'custom'>('catalog');
  const [selectedCategory, setSelectedCategory] = useState<'Tutte' | ExerciseCategory>(
    initialCategory
  );
  const [query, setQuery] = useState('');

  // Custom exercise fields
  const [customName, setCustomName] = useState('');
  const [customCategory, setCustomCategory] = useState<ExerciseCategory>(initialCategory);
  const [customIsIso, setCustomIsIso] = useState(false);
  const [customSetsCount, setCustomSetsCount] = useState(3);
  const [customTarget, setCustomTarget] = useState(10);

  React.useEffect(() => {
    if (isOpen) {
      setSelectedCategory(initialCategory);
      setCustomCategory(initialCategory);
    }
  }, [isOpen, initialCategory]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return EXERCISE_CATALOG.filter((ex) => {
      const catOk = selectedCategory === 'Tutte' || ex.category === selectedCategory;
      const qOk =
        !q ||
        ex.name.toLowerCase().includes(q) ||
        ex.variantHint.toLowerCase().includes(q);
      return catOk && qOk;
    });
  }, [selectedCategory, query]);

  if (!isOpen) return null;

  const handlePickCatalog = (exId: string) => {
    const def = EXERCISE_CATALOG.find((e) => e.id === exId);
    if (!def) return;
    playTechClick();
    const targetVal = def.type === 'isometric' ? 20 : 8;
    const now = Date.now();
    const item: WorkoutExerciseItem = {
      instanceId: `extra_${now}_${Math.random().toString(36).slice(2, 6)}`,
      exerciseId: def.id,
      variantNote: def.variantHint,
      isIsometric: def.type === 'isometric',
      isNegative: def.isNegative,
      negativeSeconds: def.negativeSeconds,
      restSeconds: def.defaultRestSec,
      sets: Array.from({ length: 3 }, (_, idx) => ({
        id: `set_${now}_${idx}_${Math.random().toString(36).slice(2, 5)}`,
        targetValue: targetVal,
        actualValue: targetVal,
        addedWeightKg: 0,
        rpe: null,
        completed: false,
      })),
    };
    onAddExercise(item);
    setQuery('');
    onClose();
  };

  const handleCreateCustom = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = customName.trim();
    if (!clean) return;
    playTechClick();
    const now = Date.now();
    const setsNum = Math.max(1, Math.min(8, customSetsCount));
    const target = Math.max(1, Math.min(180, customTarget));

    const item: WorkoutExerciseItem = {
      instanceId: `custom_${now}_${Math.random().toString(36).slice(2, 6)}`,
      exerciseId: `custom_${clean.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`,
      customName: clean,
      customCategory,
      variantNote: 'Esercizio extra aggiunto alla seduta corrente',
      isIsometric: customIsIso,
      restSeconds: 90,
      sets: Array.from({ length: setsNum }, (_, idx) => ({
        id: `set_${now}_${idx}_${Math.random().toString(36).slice(2, 5)}`,
        targetValue: target,
        actualValue: target,
        addedWeightKg: 0,
        rpe: null,
        completed: false,
      })),
    };
    onAddExercise(item);
    setCustomName('');
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Aggiungi esercizio extra alla seduta"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#05070A]/80 backdrop-blur-sm p-3 sm:p-4"
    >
      <div
        className="w-full max-w-lg max-h-[86vh] rounded-3xl border flex flex-col overflow-hidden shadow-2xl"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-subtle)',
          color: 'var(--text-main)',
        }}
      >
        <div
          className="p-4 border-b flex items-center justify-between gap-3"
          style={{ borderColor: 'var(--border-subtle)' }}
        >
          <h3 className="text-base font-extrabold">+ Aggiungi Esercizio Extra</h3>
          <button
            type="button"
            onClick={onClose}
            aria-label="Chiudi aggiunta esercizio"
            className="min-h-[40px] min-w-[40px] rounded-xl border flex items-center justify-center"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-muted)',
            }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Switch */}
        <div
          className="p-3 border-b grid grid-cols-2 gap-2"
          style={{ borderColor: 'var(--border-subtle)', backgroundColor: 'var(--bg-elevated)' }}
        >
          <button
            type="button"
            onClick={() => setTab('catalog')}
            className="min-h-[40px] rounded-xl text-xs font-extrabold transition"
            style={{
              backgroundColor: tab === 'catalog' ? 'var(--primary)' : 'var(--bg-card)',
              color: tab === 'catalog' ? '#FFFFFF' : 'var(--text-secondary)',
            }}
          >
            Scegli dal Catalogo
          </button>
          <button
            type="button"
            onClick={() => setTab('custom')}
            className="min-h-[40px] rounded-xl text-xs font-extrabold transition"
            style={{
              backgroundColor: tab === 'custom' ? 'var(--primary)' : 'var(--bg-card)',
              color: tab === 'custom' ? '#FFFFFF' : 'var(--text-secondary)',
            }}
          >
            Crea Personalizzato al Volo
          </button>
        </div>

        {tab === 'catalog' ? (
          <>
            <div
              className="p-3.5 space-y-2.5 border-b"
              style={{ borderColor: 'var(--border-subtle)' }}
            >
              <div className="relative">
                <Search
                  className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2"
                  style={{ color: 'var(--text-muted)' }}
                />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Cerca nel catalogo completo..."
                  className="w-full min-h-[42px] pl-9 pr-3 rounded-xl border text-xs focus:outline-none"
                  style={{
                    backgroundColor: 'var(--bg-main)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-main)',
                  }}
                />
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                {(['Tutte', ...CATEGORIES] as const).map((cat) => {
                  const active = selectedCategory === cat;
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setSelectedCategory(cat)}
                      className="min-h-[34px] px-2.5 rounded-lg border text-xs font-bold whitespace-nowrap transition"
                      style={{
                        backgroundColor: active ? 'var(--primary)' : 'var(--bg-elevated)',
                        borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                        color: active ? '#FFFFFF' : 'var(--text-secondary)',
                      }}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto divide-y" style={{ borderColor: 'var(--border-subtle)' }}>
              {filtered.map((ex) => (
                <button
                  key={ex.id}
                  type="button"
                  onClick={() => handlePickCatalog(ex.id)}
                  className="w-full text-left p-3.5 flex items-center justify-between gap-3 transition"
                  style={{
                    borderColor: 'var(--border-subtle)',
                  }}
                >
                  <div className="min-w-0">
                    <p className="text-sm font-bold truncate">{ex.name}</p>
                    <p className="text-xs truncate" style={{ color: 'var(--text-muted)' }}>
                      {ex.category} · {ex.type === 'isometric' ? 'Isometria' : 'Ripetizioni'} ·{' '}
                      {ex.variantHint}
                    </p>
                  </div>
                  <span
                    className="min-h-[34px] px-2.5 rounded-xl text-xs font-extrabold inline-flex items-center gap-1 shrink-0"
                    style={{
                      backgroundColor: 'var(--bg-elevated)',
                      color: 'var(--accent)',
                    }}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Aggiungi
                  </span>
                </button>
              ))}
            </div>
          </>
        ) : (
          <form onSubmit={handleCreateCustom} className="p-4 space-y-3.5 overflow-y-auto">
            <div>
              <label className="block text-xs font-bold mb-1" style={{ color: 'var(--text-secondary)' }}>
                Nome Esercizio
              </label>
              <input
                type="text"
                required
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                placeholder="Es. Face Pull con elastico, Calf Raise..."
                className="w-full min-h-[44px] rounded-xl border px-3 text-sm focus:outline-none"
                style={{
                  backgroundColor: 'var(--bg-main)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-main)',
                }}
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: 'var(--text-secondary)' }}>
                  Reparto Muscolare
                </label>
                <select
                  value={customCategory}
                  onChange={(e) => setCustomCategory(e.target.value as ExerciseCategory)}
                  className="w-full min-h-[44px] rounded-xl border px-3 text-xs font-bold focus:outline-none"
                  style={{
                    backgroundColor: 'var(--bg-main)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-main)',
                  }}
                >
                  {CATEGORIES.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: 'var(--text-secondary)' }}>
                  Modalità
                </label>
                <button
                  type="button"
                  onClick={() => setCustomIsIso((v) => !v)}
                  className="w-full min-h-[44px] rounded-xl border px-3 text-xs font-extrabold"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--accent)',
                    color: 'var(--accent)',
                  }}
                >
                  {customIsIso ? 'Isometria (secondi)' : 'Ripetizioni'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5">
              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: 'var(--text-secondary)' }}>
                  Numero Serie
                </label>
                <input
                  type="number"
                  min={1}
                  max={8}
                  value={customSetsCount}
                  onChange={(e) => setCustomSetsCount(Number(e.target.value) || 3)}
                  className="w-full min-h-[44px] rounded-xl border px-3 font-mono text-sm font-bold"
                  style={{
                    backgroundColor: 'var(--bg-main)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-main)',
                  }}
                />
              </div>

              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: 'var(--text-secondary)' }}>
                  Target ({customIsIso ? 'secondi' : 'ripetizioni'})
                </label>
                <input
                  type="number"
                  min={1}
                  max={180}
                  value={customTarget}
                  onChange={(e) => setCustomTarget(Number(e.target.value) || 10)}
                  className="w-full min-h-[44px] rounded-xl border px-3 font-mono text-sm font-bold"
                  style={{
                    backgroundColor: 'var(--bg-main)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-main)',
                  }}
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full min-h-[48px] rounded-xl font-extrabold text-sm flex items-center justify-center gap-2 transition"
              style={{
                backgroundColor: 'var(--primary)',
                color: '#FFFFFF',
              }}
            >
              <Plus className="w-4 h-4" />
              <span>Aggiungi alla Sessione di Oggi</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
