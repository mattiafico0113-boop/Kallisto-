import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Shield, Sparkles, UserCheck } from 'lucide-react';
import type {
  AthleteAvatarConfig,
  AvatarAccessoryId,
  AvatarAuraTheme,
  AvatarBodyType,
  AvatarHairStyle,
  UnlockedSkillRecord,
  WorkoutSessionLog,
} from '../types/calisthenics';
import { computeRpgProgress, DEFAULT_AVATAR_CONFIG } from '../utils/rpgProgression';

interface AthleteAvatarCardProps {
  athleteName: string;
  avatar?: AthleteAvatarConfig;
  unlockedSkills: UnlockedSkillRecord[];
  history: WorkoutSessionLog[];
  bonusMissionXp?: number;
  onChangeAvatar: (next: AthleteAvatarConfig) => void;
}

const BODY_OPTIONS: { id: AvatarBodyType; label: string }[] = [
  { id: 'atletico_m', label: 'Atletico' },
  { id: 'atletico_f', label: 'Atletica' },
  { id: 'snello', label: 'Snello' },
  { id: 'potente', label: 'Potente' },
];

const HAIR_OPTIONS: { id: AvatarHairStyle; label: string }[] = [
  { id: 'corto', label: 'Corto' },
  { id: 'rasato', label: 'Rasato' },
  { id: 'ciuffo', label: 'Ciuffo' },
  { id: 'coda', label: 'Coda' },
  { id: 'fascia_barba', label: 'Barba Pro' },
];

const AURA_COLOR_OPTIONS: {
  id: AvatarAuraTheme;
  label: string;
  primary: string;
  bright: string;
  suit: string;
}[] = [
  { id: 'blue', label: 'Blu', primary: '#2563EB', bright: '#3B82F6', suit: '#132347' },
  { id: 'cyan', label: 'Ciano', primary: '#38BDF8', bright: '#00D2FF', suit: '#0B1D36' },
  { id: 'ice', label: 'Ghiaccio', primary: '#7DD3FC', bright: '#FFFFFF', suit: '#1E3A6E' },
  { id: 'neon', label: 'Neon', primary: '#00D2FF', bright: '#7DD3FC', suit: '#0B1D36' },
];

const ACCESSORY_OPTIONS: { id: AvatarAccessoryId; label: string }[] = [
  { id: 'polsini', label: 'Polsini' },
  { id: 'fascia', label: 'Fascia fronte' },
  { id: 'canotta', label: 'Canotta Pro' },
];

export const AthleteAvatarCard: React.FC<AthleteAvatarCardProps> = ({
  athleteName,
  avatar,
  unlockedSkills,
  history,
  bonusMissionXp = 0,
  onChangeAvatar,
}) => {
  const [customizeOpen, setCustomizeOpen] = useState(false);
  const cfg = avatar ?? DEFAULT_AVATAR_CONFIG;
  const rpg = computeRpgProgress(unlockedSkills, history, bonusMissionXp);

  const auraTheme =
    AURA_COLOR_OPTIONS.find((o) => o.id === cfg.auraTheme) ?? AURA_COLOR_OPTIONS[1];

  // Silhouette proportions by body type
  const shoulderW =
    cfg.bodyType === 'potente'
      ? 28
      : cfg.bodyType === 'atletico_m'
      ? 24
      : cfg.bodyType === 'atletico_f'
      ? 20
      : 19;
  const waistW =
    cfg.bodyType === 'potente'
      ? 16
      : cfg.bodyType === 'atletico_m'
      ? 13
      : cfg.bodyType === 'atletico_f'
      ? 10.5
      : 11.5;
  const armStroke = cfg.bodyType === 'potente' ? 7.2 : cfg.bodyType === 'snello' ? 5.2 : 6.2;

  const hasWristWraps = cfg.accessories.includes('polsini');
  const hasHeadband = cfg.accessories.includes('fascia');
  const hasTankTop = cfg.accessories.includes('canotta');

  const toggleAccessory = (id: AvatarAccessoryId) => {
    const exists = cfg.accessories.includes(id);
    const nextAcc = exists
      ? cfg.accessories.filter((a) => a !== id)
      : [...cfg.accessories, id];
    onChangeAvatar({ ...cfg, accessories: nextAcc });
  };

  return (
    <section className="rounded-2xl bg-[#0B1D36] border border-[#2563EB]/70 p-4 sm:p-5 space-y-4">
      {/* Top Row: Interactive Vector Athlete + RPG Rank & Aura Frame */}
      <div className="flex flex-col sm:flex-row items-center gap-4">
        {/* Futuristic Athlete SVG Frame with Unlockable Aura Tiers */}
        <div className="relative w-32 h-32 shrink-0 flex items-center justify-center">
          <svg
            viewBox="0 0 140 140"
            className="w-full h-full overflow-visible"
            role="img"
            aria-label={`Avatar sportivo di ${athleteName}, Livello ${rpg.level}`}
          >
            <defs>
              <radialGradient id="avatarGlowBg" cx="50%" cy="50%" r="50%">
                <stop offset="0%" stopColor={auraTheme.bright} stopOpacity={rpg.auraTier >= 2 ? 0.34 : 0.16} />
                <stop offset="70%" stopColor={auraTheme.primary} stopOpacity="0.08" />
                <stop offset="100%" stopColor="#05070A" stopOpacity="0" />
              </radialGradient>
            </defs>

            {/* Aura Glow Field */}
            <circle cx="70" cy="70" r="64" fill="url(#avatarGlowBg)" />

            {/* Tier 4: Master Neon Hexagon Crown */}
            {rpg.auraTier >= 4 && (
              <polygon
                points="70,4 128,37 128,103 70,136 12,103 12,37"
                fill="none"
                stroke="#00D2FF"
                strokeWidth="2.2"
                strokeDasharray="10 4"
              />
            )}

            {/* Tier 3: Orbital Ring & Energy Arcs */}
            {rpg.auraTier >= 3 && (
              <circle
                cx="70"
                cy="70"
                r="60"
                fill="none"
                stroke="#38BDF8"
                strokeWidth="1.6"
                strokeDasharray="18 8"
              />
            )}

            {/* Tier 2+: Bright Cyan Outer Hexagon Shield */}
            <polygon
              points="70,12 120,41 120,99 70,128 20,99 20,41"
              fill="#05070A"
              stroke={
                rpg.auraTier >= 2
                  ? auraTheme.bright
                  : rpg.auraTier >= 1
                  ? '#2563EB'
                  : '#1E293B'
              }
              strokeWidth={rpg.auraTier >= 1 ? 3 : 2}
            />

            {/* Inner Tech Ring */}
            <circle
              cx="70"
              cy="70"
              r="45"
              fill="#090D16"
              stroke={rpg.auraTier >= 1 ? auraTheme.primary : '#1E293B'}
              strokeWidth="1.5"
              strokeOpacity="0.7"
            />

            {/* Athlete Silhouette */}
            <g>
              {/* Torso / Tank Silhouette */}
              <path
                d={`M ${70 - shoulderW} 68 Q 70 62 ${70 + shoulderW} 68 L ${70 + waistW} 112 L ${70 - waistW} 112 Z`}
                fill={hasTankTop ? auraTheme.suit : '#0F172A'}
                stroke={auraTheme.bright}
                strokeWidth="2"
                strokeLinejoin="round"
              />

              {/* Athletic Singlet Straps / Chest Energy Line */}
              {hasTankTop && (
                <>
                  <path
                    d={`M ${70 - shoulderW + 6} 67 L ${70 - 8} 84 L ${70 + 8} 84 L ${70 + shoulderW - 6} 67`}
                    fill="none"
                    stroke="#00D2FF"
                    strokeWidth="2.2"
                    strokeLinecap="round"
                  />
                  <line
                    x1="70"
                    y1="85"
                    x2="70"
                    y2="108"
                    stroke={auraTheme.primary}
                    strokeWidth="2"
                    strokeLinecap="round"
                  />
                </>
              )}

              {/* Left & Right Athletic Arms (crossed / athletic stance) */}
              <path
                d={`M ${70 - shoulderW + 2} 70 L ${70 - shoulderW - 9} 92 L ${70 - shoulderW - 3} 109`}
                fill="none"
                stroke="#CBD5E1"
                strokeWidth={armStroke}
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d={`M ${70 + shoulderW - 2} 70 L ${70 + shoulderW + 9} 92 L ${70 + shoulderW + 3} 109`}
                fill="none"
                stroke="#CBD5E1"
                strokeWidth={armStroke}
                strokeLinecap="round"
                strokeLinejoin="round"
              />

              {/* Wrist Wraps Accessory (Polsini) */}
              {hasWristWraps && (
                <>
                  <line
                    x1={70 - shoulderW - 6}
                    y1="101"
                    x2={70 - shoulderW - 3}
                    y2="108"
                    stroke="#00D2FF"
                    strokeWidth={armStroke + 1.5}
                    strokeLinecap="round"
                  />
                  <line
                    x1={70 + shoulderW + 6}
                    y1="101"
                    x2={70 + shoulderW + 3}
                    y2="108"
                    stroke="#00D2FF"
                    strokeWidth={armStroke + 1.5}
                    strokeLinecap="round"
                  />
                </>
              )}

              {/* Neck */}
              <rect x="64" y="54" width="12" height="12" rx="4" fill="#E2E8F0" />

              {/* Hair back (for Coda / long silhouette) */}
              {cfg.hairStyle === 'coda' && (
                <path
                  d="M 80 34 Q 95 40 91 58 Q 84 52 81 44 Z"
                  fill="#0B1D36"
                  stroke={auraTheme.primary}
                  strokeWidth="1.5"
                />
              )}

              {/* Head */}
              <circle
                cx="70"
                cy="42"
                r="14.5"
                fill="#FFFFFF"
                stroke={auraTheme.bright}
                strokeWidth="2"
              />

              {/* Tech Athletic Eyes / Brow */}
              <line x1="63" y1="42" x2="67" y2="42" stroke="#090D16" strokeWidth="2.2" strokeLinecap="round" />
              <line x1="73" y1="42" x2="77" y2="42" stroke="#090D16" strokeWidth="2.2" strokeLinecap="round" />

              {/* Hair Styles */}
              {cfg.hairStyle === 'corto' && (
                <path
                  d="M 56 38 Q 60 24 70 25 Q 81 24 84 38 Q 76 31 70 32 Q 63 31 56 38 Z"
                  fill="#090D16"
                  stroke={auraTheme.primary}
                  strokeWidth="1.2"
                />
              )}
              {cfg.hairStyle === 'ciuffo' && (
                <path
                  d="M 55 39 Q 57 22 71 21 Q 85 20 84 37 Q 76 29 66 32 Q 59 34 55 39 Z"
                  fill="#090D16"
                  stroke={auraTheme.bright}
                  strokeWidth="1.4"
                />
              )}
              {cfg.hairStyle === 'coda' && (
                <path
                  d="M 56 38 Q 62 24 70 25 Q 79 24 84 38 Q 70 31 56 38 Z"
                  fill="#090D16"
                />
              )}
              {cfg.hairStyle === 'fascia_barba' && (
                <>
                  <path
                    d="M 57 37 Q 62 25 70 26 Q 78 25 83 37 Q 70 32 57 37 Z"
                    fill="#090D16"
                  />
                  {/* Sculpted athletic beard */}
                  <path
                    d="M 57.5 46 Q 63 58 70 57.5 Q 77 58 82.5 46 Q 77 52 70 51.5 Q 63 52 57.5 46 Z"
                    fill="#090D16"
                  />
                </>
              )}

              {/* Headband Accessory (Fascia fronte) */}
              {hasHeadband && (
                <path
                  d="M 55.5 35 Q 70 31 84.5 35"
                  fill="none"
                  stroke="#00D2FF"
                  strokeWidth="3.6"
                  strokeLinecap="round"
                />
              )}
            </g>

            {/* Level Medallion Badge at Bottom Vertex */}
            <circle
              cx="70"
              cy="126"
              r="11.5"
              fill="#2563EB"
              stroke="#00D2FF"
              strokeWidth="2"
            />
            <text
              x="70"
              y="130"
              textAnchor="middle"
              fill="#FFFFFF"
              fontSize="10.5"
              fontFamily="JetBrains Mono, monospace"
              fontWeight="800"
            >
              {rpg.level}
            </text>
          </svg>
        </div>

        {/* RPG Level, Title, Aura Status & Toggle Customize */}
        <div className="flex-1 w-full min-w-0 space-y-2.5">
          <div className="flex flex-wrap items-start justify-between gap-2">
            <div className="min-w-0">
              <p className="text-[11px] font-extrabold text-[#00D2FF] uppercase tracking-wider">
                Livello {rpg.level} · {rpg.rankTitle}
              </p>
              <h2 className="text-xl sm:text-2xl font-extrabold text-[#FFFFFF] truncate">
                {athleteName}
              </h2>
              <p className="text-xs text-[#94A3B8] mt-0.5 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-[#38BDF8] shrink-0" />
                <span>
                  Aura sbloccata: <strong className="text-[#CBD5E1]">{rpg.auraName}</strong>
                </span>
              </p>
            </div>

            <button
              type="button"
              onClick={() => setCustomizeOpen((o) => !o)}
              className="min-h-[40px] px-3 rounded-xl bg-[#132347] border border-[#38BDF8]/50 text-xs font-extrabold text-[#38BDF8] hover:text-[#FFFFFF] hover:border-[#00D2FF] inline-flex items-center gap-1.5 transition shrink-0"
            >
              <UserCheck className="w-4 h-4" />
              <span>Personalizza</span>
              {customizeOpen ? (
                <ChevronUp className="w-3.5 h-3.5" />
              ) : (
                <ChevronDown className="w-3.5 h-3.5" />
              )}
            </button>
          </div>

          {/* Luminous Cyan XP Progress Bar */}
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3 space-y-1.5">
            <div className="flex items-center justify-between gap-2 text-xs tabular-nums">
              <span className="font-bold text-[#FFFFFF] inline-flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#00D2FF]" />
                <span>Esperienza (XP)</span>
              </span>
              <span className="font-mono font-extrabold text-[#00D2FF]">
                {rpg.totalXp} XP
                {rpg.nextLevelXp !== null ? ` / ${rpg.nextLevelXp}` : ' · MAX'}
              </span>
            </div>

            <div className="h-2.5 w-full rounded-full bg-[#05070A] border border-[#1E293B] overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#2563EB] via-[#38BDF8] to-[#00D2FF] transition-all duration-500 shadow-[0_0_12px_rgba(0,210,255,0.65)]"
                style={{ width: `${rpg.progressPct}%` }}
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-[#94A3B8]">
              <span className="tabular-nums">
                Skill: {rpg.skillXp} XP · Allenamenti: {rpg.workoutXp} XP
                {rpg.missionXp > 0 ? ` · Missioni: +${rpg.missionXp} XP` : ''}
              </span>
              <span className="text-[#7DD3FC] font-medium">
                {rpg.nextLevelXp !== null
                  ? `-${rpg.xpToNext} XP al Livello ${rpg.level + 1}`
                  : rpg.nextAuraHint}
              </span>
            </div>
          </div>

          <p className="text-[11px] text-[#94A3B8]">
            Prossima cornice: <span className="text-[#CBD5E1]">{rpg.nextAuraHint}</span>
          </p>
        </div>
      </div>

      {/* Inline Avatar Customization Panel */}
      {customizeOpen && (
        <div className="pt-3 border-t border-[#1E293B] space-y-3.5">
          {/* Body Type */}
          <div>
            <p className="text-[11px] font-bold text-[#94A3B8] mb-1.5">
              Corporatura / Stile atleta
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {BODY_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeAvatar({ ...cfg, bodyType: opt.id })}
                  className={`min-h-[40px] px-2.5 rounded-xl border text-xs font-bold transition ${
                    cfg.bodyType === opt.id
                      ? 'bg-[#2563EB] border-[#00D2FF] text-[#FFFFFF]'
                      : 'bg-[#090D16] border-[#1E293B] text-[#CBD5E1] hover:text-[#FFFFFF]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Hair / Beard */}
          <div>
            <p className="text-[11px] font-bold text-[#94A3B8] mb-1.5">
              Capelli e Stile viso
            </p>
            <div className="flex flex-wrap gap-1.5">
              {HAIR_OPTIONS.map((opt) => (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => onChangeAvatar({ ...cfg, hairStyle: opt.id })}
                  className={`min-h-[38px] px-3 rounded-xl border text-xs font-bold transition ${
                    cfg.hairStyle === opt.id
                      ? 'bg-[#2563EB] border-[#00D2FF] text-[#FFFFFF]'
                      : 'bg-[#090D16] border-[#1E293B] text-[#CBD5E1] hover:text-[#FFFFFF]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Aura / Gear Colors + Accessories */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <p className="text-[11px] font-bold text-[#94A3B8] mb-1.5">
                Colore Aura &amp; Divisa
              </p>
              <div className="grid grid-cols-4 gap-1.5">
                {AURA_COLOR_OPTIONS.map((opt) => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => onChangeAvatar({ ...cfg, auraTheme: opt.id })}
                    className={`min-h-[40px] px-2 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition ${
                      cfg.auraTheme === opt.id
                        ? 'bg-[#132347] border-[#00D2FF] text-[#FFFFFF]'
                        : 'bg-[#090D16] border-[#1E293B] text-[#CBD5E1] hover:text-[#FFFFFF]'
                    }`}
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: opt.bright }}
                    />
                    <span>{opt.label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-[11px] font-bold text-[#94A3B8] mb-1.5">
                Accessori Sportivi
              </p>
              <div className="flex flex-wrap gap-1.5">
                {ACCESSORY_OPTIONS.map((acc) => {
                  const active = cfg.accessories.includes(acc.id);
                  return (
                    <button
                      key={acc.id}
                      type="button"
                      onClick={() => toggleAccessory(acc.id)}
                      className={`min-h-[40px] px-3 rounded-xl border text-xs font-bold transition ${
                        active
                          ? 'bg-[#38BDF8] border-[#00D2FF] text-[#05070A]'
                          : 'bg-[#090D16] border-[#1E293B] text-[#CBD5E1] hover:text-[#FFFFFF]'
                      }`}
                    >
                      {acc.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
