import React, { useMemo, useState } from 'react';
import { Award, Download, Loader2, Shield, Sparkles, Trophy, X } from 'lucide-react';
import { SKILL_NODE_MAP } from '../data/skills';
import type {
  AthleteProfile,
  UnlockedSkillRecord,
  WorkoutSessionLog,
} from '../types/calisthenics';
import { playTechClick } from '../utils/audio';
import type { TrophyDefinition } from '../utils/recoveryAndMissions';
import {
  computeAthleteRadarMetrics,
  computeRpgProgress,
  DEFAULT_AVATAR_CONFIG,
} from '../utils/rpgProgression';
import { CaliProLogo } from './CaliProLogo';

interface AthleteCardModalProps {
  isOpen: boolean;
  profile: AthleteProfile;
  unlockedSkills: UnlockedSkillRecord[];
  history: WorkoutSessionLog[];
  bonusMissionXp?: number;
  unlockedTrophies?: TrophyDefinition[];
  onClose: () => void;
}

const AURA_COLORS = {
  blue: { primary: '#2563EB', bright: '#3B82F6', suit: '#132347' },
  cyan: { primary: '#38BDF8', bright: '#00D2FF', suit: '#0B1D36' },
  ice: { primary: '#7DD3FC', bright: '#FFFFFF', suit: '#1E3A6E' },
  neon: { primary: '#00D2FF', bright: '#7DD3FC', suit: '#0B1D36' },
} as const;

export const AthleteCardModal: React.FC<AthleteCardModalProps> = ({
  isOpen,
  profile,
  unlockedSkills,
  history,
  bonusMissionXp = 0,
  unlockedTrophies = [],
  onClose,
}) => {
  const [exporting, setExporting] = useState(false);

  const rpg = useMemo(
    () => computeRpgProgress(unlockedSkills, history, bonusMissionXp),
    [unlockedSkills, history, bonusMissionXp]
  );

  const radarStats = useMemo(
    () => computeAthleteRadarMetrics(history, unlockedSkills),
    [history, unlockedSkills]
  );

  if (!isOpen) return null;

  const ovr = Math.max(
    45,
    Math.min(
      99,
      Math.round(
        radarStats.reduce((acc, s) => acc + s.score, 0) / Math.max(1, radarStats.length)
      ) || 45
    )
  );

  const cfg = profile.avatar ?? DEFAULT_AVATAR_CONFIG;
  const auraPalette = AURA_COLORS[cfg.auraTheme] ?? AURA_COLORS.cyan;

  const statByKey = (key: 'Skill' | 'Core' | 'Spinta' | 'Tirata' | 'Gambe') =>
    radarStats.find((s) => s.key === key)?.score ?? 0;

  const topSkills = unlockedSkills
    .map((rec) => SKILL_NODE_MAP[rec.skillId])
    .filter((d): d is NonNullable<typeof d> => Boolean(d))
    .slice(0, 6);

  const handleDownloadPng = () => {
    playTechClick();
    setExporting(true);
    try {
      const W = 760;
      const H = 1060;
      const canvas = document.createElement('canvas');
      canvas.width = W;
      canvas.height = H;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Deep black carbon background
      const bgGrad = ctx.createLinearGradient(0, 0, W, H);
      bgGrad.addColorStop(0, '#05070A');
      bgGrad.addColorStop(0.5, '#090D16');
      bgGrad.addColorStop(1, '#05070A');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, W, H);

      // Subtle diagonal tech lines texture
      ctx.strokeStyle = 'rgba(37, 99, 235, 0.11)';
      ctx.lineWidth = 1;
      for (let x = -H; x < W + H; x += 28) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x + H * 0.45, H);
        ctx.stroke();
      }

      // Outer FIFA/RPG Shield Frame
      const drawShield = (pad: number) => {
        ctx.beginPath();
        ctx.moveTo(pad + 50, pad);
        ctx.lineTo(W - pad - 50, pad);
        ctx.lineTo(W - pad, pad + 56);
        ctx.lineTo(W - pad, H - pad - 110);
        ctx.lineTo(W / 2, H - pad);
        ctx.lineTo(pad, H - pad - 110);
        ctx.lineTo(pad, pad + 56);
        ctx.closePath();
      };

      drawShield(26);
      const cardGrad = ctx.createLinearGradient(0, 30, 0, H - 30);
      cardGrad.addColorStop(0, '#0F172A');
      cardGrad.addColorStop(0.55, '#0B1D36');
      cardGrad.addColorStop(1, '#090D16');
      ctx.fillStyle = cardGrad;
      ctx.fill();

      ctx.shadowColor = '#00D2FF';
      ctx.shadowBlur = 24;
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 4;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Inner electric blue frame
      drawShield(42);
      ctx.strokeStyle = '#2563EB';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Header Brand Tag
      ctx.fillStyle = '#38BDF8';
      ctx.font = 'bold 18px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText('CALI PRO · ATHLETE CARD', W / 2, 92);

      // OVR & Level Top-Left Block
      ctx.textAlign = 'left';
      ctx.fillStyle = '#00D2FF';
      ctx.font = '800 88px monospace';
      ctx.fillText(String(ovr), 82, 198);

      ctx.fillStyle = '#94A3B8';
      ctx.font = 'bold 20px sans-serif';
      ctx.fillText('OVR', 86, 226);

      ctx.fillStyle = '#FFFFFF';
      ctx.font = 'bold 24px monospace';
      ctx.fillText(`LV ${rpg.level}`, 86, 266);

      // Avatar Center Hexagon & Stylized Vector Athlete
      const avX = W / 2 + 54;
      const avY = 235;
      const hexR = 112;
      ctx.beginPath();
      for (let i = 0; i < 6; i++) {
        const angle = (-Math.PI / 2) + (i * Math.PI) / 3;
        const px = avX + hexR * Math.cos(angle);
        const py = avY + hexR * Math.sin(angle);
        if (i === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fillStyle = '#05070A';
      ctx.fill();
      ctx.strokeStyle = auraPalette.bright;
      ctx.lineWidth = 4;
      ctx.stroke();

      // Torso & shoulders
      const shW = cfg.bodyType === 'potente' ? 48 : cfg.bodyType === 'snello' ? 34 : 42;
      ctx.beginPath();
      ctx.moveTo(avX - shW, avY + 12);
      ctx.lineTo(avX + shW, avY + 12);
      ctx.lineTo(avX + shW * 0.56, avY + 92);
      ctx.lineTo(avX - shW * 0.56, avY + 92);
      ctx.closePath();
      ctx.fillStyle = auraPalette.suit;
      ctx.fill();
      ctx.strokeStyle = auraPalette.bright;
      ctx.lineWidth = 3;
      ctx.stroke();

      // Head
      ctx.beginPath();
      ctx.arc(avX, avY - 34, 28, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      ctx.strokeStyle = auraPalette.bright;
      ctx.lineWidth = 3;
      ctx.stroke();

      // Divider line above name
      ctx.strokeStyle = '#2563EB';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(86, 392);
      ctx.lineTo(W - 86, 392);
      ctx.stroke();

      // Athlete Name & Rank Title
      ctx.textAlign = 'center';
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '800 44px sans-serif';
      ctx.fillText(profile.name.toUpperCase().slice(0, 18), W / 2, 448);

      ctx.fillStyle = '#00D2FF';
      ctx.font = 'bold 22px sans-serif';
      ctx.fillText(`${rpg.rankTitle.toUpperCase()} · ${rpg.totalXp} XP`, W / 2, 484);

      // 5 Key Stats Grid
      const statItems = [
        { k: 'SKILL', v: statByKey('Skill') },
        { k: 'CORE', v: statByKey('Core') },
        { k: 'SPINTA', v: statByKey('Spinta') },
        { k: 'TIRATA', v: statByKey('Tirata') },
        { k: 'GAMBE', v: statByKey('Gambe') },
      ];

      const boxW = 118;
      const gap = 14;
      const startX = (W - (boxW * 5 + gap * 4)) / 2;
      statItems.forEach((st, idx) => {
        const bx = startX + idx * (boxW + gap);
        const by = 524;
        ctx.fillStyle = '#090D16';
        ctx.fillRect(bx, by, boxW, 114);
        ctx.strokeStyle = '#1E3A6E';
        ctx.lineWidth = 2;
        ctx.strokeRect(bx, by, boxW, 114);

        ctx.textAlign = 'center';
        ctx.fillStyle = '#00D2FF';
        ctx.font = '800 38px monospace';
        ctx.fillText(String(st.v), bx + boxW / 2, by + 56);

        ctx.fillStyle = '#94A3B8';
        ctx.font = 'bold 16px sans-serif';
        ctx.fillText(st.k, bx + boxW / 2, by + 92);
      });

      // Certified Skills Section
      ctx.textAlign = 'center';
      ctx.fillStyle = '#38BDF8';
      ctx.font = 'bold 20px sans-serif';
      ctx.fillText(
        `SKILL CERTIFICATE SBLOCCATE (${unlockedSkills.length})`,
        W / 2,
        694
      );

      if (topSkills.length === 0) {
        ctx.fillStyle = '#94A3B8';
        ctx.font = '19px sans-serif';
        ctx.fillText('Nessuna skill ancora certificata nell’Albero', W / 2, 744);
      } else {
        const cols = 2;
        const badgeW = 288;
        const badgeH = 54;
        const bxStart = (W - (badgeW * cols + 20)) / 2;
        topSkills.forEach((sk, idx) => {
          const col = idx % 2;
          const row = Math.floor(idx / 2);
          const x = bxStart + col * (badgeW + 20);
          const y = 720 + row * (badgeH + 14);
          ctx.fillStyle = '#132347';
          ctx.fillRect(x, y, badgeW, badgeH);
          ctx.strokeStyle = '#38BDF8';
          ctx.lineWidth = 1.5;
          ctx.strokeRect(x, y, badgeW, badgeH);

          ctx.textAlign = 'center';
          ctx.fillStyle = '#FFFFFF';
          ctx.font = 'bold 18px sans-serif';
          ctx.fillText(`★ ${sk.name}`, x + badgeW / 2, y + 34);
        });
      }

      // Physical & Trophies Bottom Footer inside Shield Tip
      const earnedTrophies = unlockedTrophies.filter((t) => t.unlocked);
      if (earnedTrophies.length > 0) {
        ctx.textAlign = 'center';
        ctx.fillStyle = '#FACC15';
        ctx.font = 'bold 17px sans-serif';
        ctx.fillText(
          `🏆 ${earnedTrophies.map((t) => t.title).slice(0, 3).join(' · ')}`,
          W / 2,
          930
        );
      }

      ctx.textAlign = 'center';
      ctx.fillStyle = '#94A3B8';
      ctx.font = 'bold 18px monospace';
      const physText =
        profile.heightCm && profile.weightKg
          ? `${profile.heightCm} CM  ·  ${profile.weightKg} KG`
          : `${history.length} SESSIONI COMPLETATE`;
      ctx.fillText(physText, W / 2, 968);

      const dataUrl = canvas.toDataURL('image/png');
      const link = document.createElement('a');
      const safeName = profile.name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
      link.download = `calipro-card-${safeName || 'atleta'}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      link.remove();
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#05070A]/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-md space-y-3 my-auto">
        {/* Top Modal Controls */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#00D2FF]" />
            <h2 className="text-sm font-extrabold text-[#FFFFFF]">Card Atleta Digitale</h2>
          </div>
          <button
            type="button"
            onClick={() => {
              playTechClick();
              onClose();
            }}
            aria-label="Chiudi Card Atleta"
            className="min-h-[40px] min-w-[40px] rounded-xl bg-[#0F172A] border border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF] flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* FIFA / RPG Digital Shield Card */}
        <div
          className="relative rounded-3xl p-5 border-2 border-[#00D2FF] shadow-[0_0_36px_rgba(0,210,255,0.28)] overflow-hidden"
          style={{
            background:
              'repeating-linear-gradient(135deg, rgba(37,99,235,0.08) 0px, rgba(37,99,235,0.08) 1px, transparent 1px, transparent 18px), linear-gradient(180deg, #0F172A 0%, #0B1D36 55%, #05070A 100%)',
          }}
        >
          {/* Card Brand Logo + Kicker */}
          <div className="flex items-center justify-between gap-2 mb-3">
            <CaliProLogo size="sm" />
            <span className="text-[10px] font-extrabold tracking-[0.2em] text-[#38BDF8] uppercase">
              PRO CARD
            </span>
          </div>

          {/* Top Split: OVR/Level + SVG Athlete Avatar */}
          <div className="flex items-center justify-between gap-3 px-2">
            <div>
              <p className="font-mono text-5xl font-black text-[#00D2FF] leading-none tabular-nums">
                {ovr}
              </p>
              <p className="text-xs font-extrabold text-[#94A3B8] tracking-widest mt-1">
                OVR
              </p>
              <div className="mt-2.5 inline-flex items-center gap-1.5 rounded-lg bg-[#132347] border border-[#38BDF8]/50 px-2.5 py-1">
                <Shield className="w-3.5 h-3.5 text-[#00D2FF]" />
                <span className="font-mono text-xs font-extrabold text-[#FFFFFF] tabular-nums">
                  LV {rpg.level}
                </span>
              </div>
            </div>

            {/* Compact Vector Avatar Mirror */}
            <svg viewBox="0 0 120 120" className="w-32 h-32 shrink-0" aria-hidden="true">
              <polygon
                points="60,8 106,34 106,86 60,112 14,86 14,34"
                fill="#05070A"
                stroke={auraPalette.bright}
                strokeWidth="3"
              />
              <path
                d={`M ${60 - (cfg.bodyType === 'potente' ? 24 : 20)} 62 Q 60 56 ${
                  60 + (cfg.bodyType === 'potente' ? 24 : 20)
                } 62 L 72 96 L 48 96 Z`}
                fill={auraPalette.suit}
                stroke={auraPalette.bright}
                strokeWidth="2"
              />
              <circle cx="60" cy="40" r="13" fill="#FFFFFF" stroke={auraPalette.bright} strokeWidth="2" />
              {cfg.accessories.includes('fascia') && (
                <path
                  d="M 48 34 Q 60 31 72 34"
                  fill="none"
                  stroke="#00D2FF"
                  strokeWidth="3"
                  strokeLinecap="round"
                />
              )}
            </svg>
          </div>

          {/* Athlete Name & RPG Rank */}
          <div className="text-center border-y border-[#2563EB]/60 py-2.5 my-3.5">
            <h3 className="text-2xl font-black text-[#FFFFFF] tracking-wide uppercase truncate">
              {profile.name}
            </h3>
            <p className="text-xs font-bold text-[#00D2FF] tracking-wider uppercase mt-0.5">
              {rpg.rankTitle} · {rpg.totalXp} XP
            </p>
          </div>

          {/* 5 Radar Attributes Grid */}
          <div className="grid grid-cols-5 gap-1.5 text-center">
            {(
              [
                { k: 'SKILL', v: statByKey('Skill') },
                { k: 'CORE', v: statByKey('Core') },
                { k: 'SPINTA', v: statByKey('Spinta') },
                { k: 'TIRATA', v: statByKey('Tirata') },
                { k: 'GAMBE', v: statByKey('Gambe') },
              ] as const
            ).map((item) => (
              <div
                key={item.k}
                className="rounded-xl bg-[#090D16] border border-[#1E3A6E] py-2 px-1"
              >
                <p className="font-mono text-lg font-extrabold text-[#00D2FF] tabular-nums leading-tight">
                  {item.v}
                </p>
                <p className="text-[9px] font-extrabold text-[#94A3B8] tracking-wider mt-0.5">
                  {item.k}
                </p>
              </div>
            ))}
          </div>

          {/* Certified Unlocked Skill Badges */}
          <div className="mt-4 space-y-2">
            <p className="text-center text-[10px] font-extrabold text-[#38BDF8] uppercase tracking-wider">
              Skill Certificate ({unlockedSkills.length})
            </p>
            {topSkills.length === 0 ? (
              <p className="text-center text-xs text-[#94A3B8]">
                Sblocca la prima skill per esporre il badge sulla Card
              </p>
            ) : (
              <div className="grid grid-cols-2 gap-1.5">
                {topSkills.map((sk) => (
                  <div
                    key={sk.id}
                    className="rounded-xl bg-[#132347] border border-[#38BDF8]/50 px-2.5 py-1.5 flex items-center gap-1.5"
                  >
                    <Award className="w-3.5 h-3.5 text-[#00D2FF] shrink-0" />
                    <span className="text-[11px] font-bold text-[#FFFFFF] truncate">
                      {sk.name}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Unlocked Trophies Strip */}
          {unlockedTrophies.some((t) => t.unlocked) && (
            <div className="mt-3 pt-3 border-t border-[#2563EB]/40 space-y-1.5">
              <p className="text-center text-[10px] font-extrabold text-[#FACC15] uppercase tracking-wider">
                Trofei Sbloccati ({unlockedTrophies.filter((t) => t.unlocked).length})
              </p>
              <div className="flex flex-wrap items-center justify-center gap-1.5">
                {unlockedTrophies
                  .filter((t) => t.unlocked)
                  .map((tr) => (
                    <span
                      key={tr.id}
                      className="inline-flex items-center gap-1 rounded-lg bg-[#090D16] border border-[#FACC15]/60 px-2 py-1 text-[10px] font-extrabold text-[#FACC15]"
                    >
                      <Trophy className="w-3 h-3 shrink-0" />
                      <span>{tr.title}</span>
                    </span>
                  ))}
              </div>
            </div>
          )}
        </div>

        {/* Download PNG Button */}
        <button
          type="button"
          disabled={exporting}
          onClick={handleDownloadPng}
          className="w-full min-h-[48px] rounded-2xl bg-[#00D2FF] text-[#05070A] text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#38BDF8] transition shadow-[0_0_24px_rgba(0,210,255,0.3)]"
        >
          {exporting ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Generazione PNG...</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4" />
              <span>Salva Card come Immagine</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
