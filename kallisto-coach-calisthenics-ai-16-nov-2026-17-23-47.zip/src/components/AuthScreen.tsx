import React, { useState } from 'react';
import { ArrowRight, Eye, EyeOff, Lock, Mail, UserCheck } from 'lucide-react';
import type { AuthSession } from '../types/calisthenics';
import { loginAccount, loginAsGuest, registerAccount } from '../utils/storage';
import { CaliProLogo } from './CaliProLogo';

interface AuthScreenProps {
  onAuthenticated: (session: AuthSession) => void;
}

export const AuthScreen: React.FC<AuthScreenProps> = ({ onAuthenticated }) => {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const result =
        mode === 'login'
          ? await loginAccount(email, password)
          : await registerAccount(email, password);
      if (!result.ok) {
        setError(result.error);
      } else {
        onAuthenticated(result.session);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const handleGuest = () => {
    const session = loginAsGuest();
    onAuthenticated(session);
  };

  return (
    <div className="min-h-screen bg-[#05070A] text-[#FFFFFF] flex flex-col justify-center px-4 py-8">
      <div className="w-full max-w-md mx-auto space-y-6">
        {/* Brand Intro */}
        <div className="text-center flex flex-col items-center">
          <CaliProLogo
            size="lg"
            subtitle="Personal Trainer AI e diario a corpo libero. Accedi per mantenere schede, storico e chat separati per ogni atleta."
          />
        </div>

        {/* Auth Card */}
        <div className="rounded-3xl bg-[#0F172A] border border-[#1E293B] p-5 sm:p-6 space-y-5">
          {/* Segmented Switch */}
          <div className="grid grid-cols-2 gap-1 p-1 rounded-2xl bg-[#090D16] border border-[#1E293B]">
            <button
              type="button"
              onClick={() => {
                setMode('login');
                setError(null);
              }}
              className={`min-h-[42px] rounded-xl text-sm font-bold transition ${
                mode === 'login'
                  ? 'bg-[#2563EB] text-[#FFFFFF]'
                  : 'text-[#94A3B8] hover:text-[#FFFFFF]'
              }`}
            >
              Accedi
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError(null);
              }}
              className={`min-h-[42px] rounded-xl text-sm font-bold transition ${
                mode === 'register'
                  ? 'bg-[#2563EB] text-[#FFFFFF]'
                  : 'text-[#94A3B8] hover:text-[#FFFFFF]'
              }`}
            >
              Registrati
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="auth-email" className="block text-xs font-semibold text-[#94A3B8] mb-1.5">
                Email
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#94A3B8] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="auth-email"
                  type="email"
                  required
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="nome@esempio.it"
                  className="w-full min-h-[48px] pl-10 pr-4 rounded-2xl bg-[#090D16] border border-[#1E293B] text-sm text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                />
              </div>
            </div>

            <div>
              <label htmlFor="auth-password" className="block text-xs font-semibold text-[#94A3B8] mb-1.5">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-[#94A3B8] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  id="auth-password"
                  type={showPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Minimo 6 caratteri"
                  className="w-full min-h-[48px] pl-10 pr-12 rounded-2xl bg-[#090D16] border border-[#1E293B] text-sm text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((s) => !s)}
                  aria-label={showPassword ? 'Nascondi password' : 'Mostra password'}
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center absolute right-1 top-1/2 -translate-y-1/2 text-[#94A3B8] hover:text-[#FFFFFF]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {error && (
              <p role="alert" className="rounded-xl bg-[#131C31] border border-[#38BDF8]/40 px-3.5 py-2.5 text-xs font-semibold text-[#38BDF8]">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full min-h-[50px] rounded-2xl bg-[#2563EB] text-[#FFFFFF] text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#3B82F6] active:scale-[0.98] disabled:opacity-50 transition"
            >
              <span>{mode === 'login' ? 'Accedi al tuo profilo' : 'Crea account'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <div className="relative py-1 flex items-center justify-center">
            <div className="border-t border-[#1E293B] w-full" />
            <span className="bg-[#0F172A] px-3 text-[11px] font-medium text-[#94A3B8] shrink-0">
              oppure
            </span>
            <div className="border-t border-[#1E293B] w-full" />
          </div>

          <button
            type="button"
            onClick={handleGuest}
            className="w-full min-h-[48px] rounded-2xl bg-[#131C31] border border-[#1E293B] text-sm font-bold text-[#FFFFFF] flex items-center justify-center gap-2 hover:bg-[#1E293B] active:scale-[0.98] transition"
          >
            <UserCheck className="w-4 h-4 text-[#38BDF8]" />
            <span>Continua come Ospite</span>
          </button>
        </div>
      </div>
    </div>
  );
};
