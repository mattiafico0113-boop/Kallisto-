import React, { useEffect, useState } from 'react';
import { Award, Minus, Pause, Play, Plus, RotateCcw, Swords, Trophy, X } from 'lucide-react';
import { playLevelUpFanfare, playSetCompleteTone, playTechClick } from '../utils/audio';

interface Battle1v1ModalProps {
  isOpen: boolean;
  defaultAthlete1Name?: string;
  onClose: () => void;
}

type ChallengePresetId = 'pullups' | 'dips' | 'dead_hang' | 'lsit';

const CHALLENGE_PRESETS: {
  id: ChallengePresetId;
  label: string;
  mode: 'reps' | 'time';
  subtitle: string;
}[] = [
  { id: 'pullups', label: 'Max Trazioni', mode: 'reps', subtitle: 'Conteggio ripetizioni alla sbarra' },
  { id: 'dips', label: 'Max Dip', mode: 'reps', subtitle: 'Conteggio ripetizioni alle parallele' },
  { id: 'dead_hang', label: 'Resistenza Dead Hang', mode: 'time', subtitle: 'Doppio cronometro indipendente' },
  { id: 'lsit', label: 'Resistenza L-Sit', mode: 'time', subtitle: 'Doppio cronometro tenuta' },
];

export const Battle1v1Modal: React.FC<Battle1v1ModalProps> = ({
  isOpen,
  defaultAthlete1Name = 'Atleta 1',
  onClose,
}) => {
  const [phase, setPhase] = useState<'setup' | 'arena' | 'winner'>('setup');
  const [challengeId, setChallengeId] = useState<ChallengePresetId>('pullups');
  const [name1, setName1] = useState(defaultAthlete1Name || 'Atleta 1');
  const [name2, setName2] = useState('Sfidante');

  const [reps1, setReps1] = useState(0);
  const [reps2, setReps2] = useState(0);

  const [ms1, setMs1] = useState(0);
  const [ms2, setMs2] = useState(0);
  const [running1, setRunning1] = useState(false);
  const [running2, setRunning2] = useState(false);

  const preset = CHALLENGE_PRESETS.find((c) => c.id === challengeId) ?? CHALLENGE_PRESETS[0];

  useEffect(() => {
    if (!isOpen || phase !== 'arena' || preset.mode !== 'time') return;
    if (!running1 && !running2) return;

    let last = performance.now();
    const id = window.setInterval(() => {
      const now = performance.now();
      const dt = now - last;
      last = now;
      if (running1) setMs1((p) => p + dt);
      if (running2) setMs2((p) => p + dt);
    }, 80);

    return () => window.clearInterval(id);
  }, [isOpen, phase, preset.mode, running1, running2]);

  if (!isOpen) return null;

  const resetArena = () => {
    setReps1(0);
    setReps2(0);
    setMs1(0);
    setMs2(0);
    setRunning1(false);
    setRunning2(false);
  };

  const formatTime = (ms: number): string => {
    const totalSec = ms / 1000;
    const mins = Math.floor(totalSec / 60);
    const secs = Math.floor(totalSec % 60);
    const tenths = Math.floor((ms % 1000) / 100);
    if (mins > 0) {
      return `${mins}:${String(secs).padStart(2, '0')}.${tenths}`;
    }
    return `${secs}.${tenths}s`;
  };

  const score1 = preset.mode === 'reps' ? reps1 : Math.round(ms1 / 100);
  const score2 = preset.mode === 'reps' ? reps2 : Math.round(ms2 / 100);
  const winnerSide: 1 | 2 | 'tie' = score1 > score2 ? 1 : score2 > score1 ? 2 : 'tie';

  const handleFinishBattle = () => {
    setRunning1(false);
    setRunning2(false);
    playLevelUpFanfare();
    setPhase('winner');
  };

  return (
    <div className="fixed inset-0 z-[80] bg-[#05070A]/95 backdrop-blur-md flex flex-col p-3 sm:p-5 overflow-y-auto">
      <div className="w-full max-w-4xl mx-auto flex-1 flex flex-col justify-center space-y-4">
        {/* Top Header */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Swords className="w-5 h-5 shrink-0" style={{ color: 'var(--accent)' }} />
            <div className="min-w-0">
              <h2 className="text-base sm:text-lg font-black uppercase tracking-wide text-[#FFFFFF]">
                Battle 1vs1 · Sfida dal Vivo
              </h2>
              <p className="text-[11px] truncate" style={{ color: 'var(--text-muted)' }}>
                {preset.label} — {preset.subtitle}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              setRunning1(false);
              setRunning2(false);
              onClose();
            }}
            aria-label="Chiudi Battle 1vs1"
            className="min-h-[42px] min-w-[42px] rounded-xl border flex items-center justify-center shrink-0"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {phase === 'setup' && (
          <div
            className="rounded-3xl border p-5 space-y-4"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          >
            <div className="space-y-2">
              <p className="text-xs font-extrabold uppercase tracking-wider" style={{ color: 'var(--accent)' }}>
                1. Scegli la sfida
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {CHALLENGE_PRESETS.map((c) => {
                  const active = c.id === challengeId;
                  return (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        playTechClick();
                        setChallengeId(c.id);
                      }}
                      className="p-3 rounded-2xl border text-left transition"
                      style={{
                        backgroundColor: active ? 'var(--primary)' : 'var(--bg-elevated)',
                        borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                        color: active ? '#FFFFFF' : 'var(--text-main)',
                      }}
                    >
                      <p className="text-sm font-extrabold">{c.label}</p>
                      <p
                        className="text-[11px] mt-0.5"
                        style={{ color: active ? '#E2E8F0' : 'var(--text-muted)' }}
                      >
                        {c.subtitle}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: 'var(--primary)' }}>
                  Atleta 1 (Lato Blu)
                </label>
                <input
                  type="text"
                  value={name1}
                  onChange={(e) => setName1(e.target.value)}
                  className="w-full min-h-[44px] rounded-xl border px-3 text-sm font-bold focus:outline-none"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--primary)',
                    color: 'var(--text-main)',
                  }}
                />
              </div>
              <div>
                <label className="block text-xs font-bold mb-1" style={{ color: 'var(--accent)' }}>
                  Atleta 2 (Lato Azzurro/Ciano)
                </label>
                <input
                  type="text"
                  value={name2}
                  onChange={(e) => setName2(e.target.value)}
                  className="w-full min-h-[44px] rounded-xl border px-3 text-sm font-bold focus:outline-none"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--accent)',
                    color: 'var(--text-main)',
                  }}
                />
              </div>
            </div>

            <button
              type="button"
              onClick={() => {
                playSetCompleteTone();
                resetArena();
                setPhase('arena');
              }}
              className="w-full min-h-[52px] rounded-2xl font-black text-base flex items-center justify-center gap-2 transition"
              style={{
                backgroundColor: 'var(--accent)',
                color: '#05070A',
              }}
            >
              <Swords className="w-5 h-5" />
              <span>Avvia Arena 1vs1</span>
            </button>
          </div>
        )}

        {phase === 'arena' && (
          <div className="space-y-3.5">
            {/* Split Screen High-Contrast 1vs1 */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {/* ATHLETE 1 (PRIMARY BLUE) */}
              <div
                className="rounded-3xl border-2 p-5 flex flex-col items-center justify-between gap-4 min-h-[250px]"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--primary)',
                }}
              >
                <div className="text-center">
                  <span
                    className="text-[11px] font-black uppercase tracking-widest"
                    style={{ color: 'var(--primary)' }}
                  >
                    Angolo Blu
                  </span>
                  <h3 className="text-xl font-black text-[#FFFFFF] mt-0.5">{name1 || 'Atleta 1'}</h3>
                </div>

                <p
                  className="font-mono text-6xl font-black tabular-nums leading-none"
                  style={{ color: '#FFFFFF' }}
                >
                  {preset.mode === 'reps' ? reps1 : formatTime(ms1)}
                </p>

                {preset.mode === 'reps' ? (
                  <div className="flex items-center gap-3 w-full">
                    <button
                      type="button"
                      onClick={() => {
                        playTechClick();
                        setReps1((r) => Math.max(0, r - 1));
                      }}
                      aria-label="Riduci ripetizioni Atleta 1"
                      className="min-h-[58px] min-w-[64px] rounded-2xl border flex items-center justify-center transition active:scale-95"
                      style={{
                        backgroundColor: 'var(--bg-elevated)',
                        borderColor: 'var(--border-subtle)',
                        color: 'var(--text-main)',
                      }}
                    >
                      <Minus className="w-6 h-6" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        playSetCompleteTone();
                        setReps1((r) => r + 1);
                      }}
                      className="flex-1 min-h-[58px] rounded-2xl font-black text-lg flex items-center justify-center gap-2 transition active:scale-95"
                      style={{
                        backgroundColor: 'var(--primary)',
                        color: '#FFFFFF',
                      }}
                    >
                      <Plus className="w-6 h-6 stroke-[3]" />
                      <span>+1 REP</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2.5 w-full">
                    <button
                      type="button"
                      onClick={() => {
                        playTechClick();
                        setRunning1((r) => !r);
                      }}
                      className="flex-1 min-h-[56px] rounded-2xl font-black text-base flex items-center justify-center gap-2 transition active:scale-95"
                      style={{
                        backgroundColor: 'var(--primary)',
                        color: '#FFFFFF',
                      }}
                    >
                      {running1 ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
                      <span>{running1 ? 'Stop' : ms1 > 0 ? 'Riprendi' : 'Start'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setRunning1(false);
                        setMs1(0);
                      }}
                      aria-label="Azzera timer Atleta 1"
                      className="min-h-[56px] min-w-[56px] rounded-2xl border flex items-center justify-center"
                      style={{
                        backgroundColor: 'var(--bg-elevated)',
                        borderColor: 'var(--border-subtle)',
                        color: 'var(--text-muted)',
                      }}
                    >
                      <RotateCcw className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>

              {/* ATHLETE 2 (BRIGHT CYAN / ACCENT) */}
              <div
                className="rounded-3xl border-2 p-5 flex flex-col items-center justify-between gap-4 min-h-[250px]"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--accent)',
                }}
              >
                <div className="text-center">
                  <span
                    className="text-[11px] font-black uppercase tracking-widest"
                    style={{ color: 'var(--accent)' }}
                  >
                    Angolo Ciano
                  </span>
                  <h3 className="text-xl font-black text-[#FFFFFF] mt-0.5">{name2 || 'Atleta 2'}</h3>
                </div>

                <p
                  className="font-mono text-6xl font-black tabular-nums leading-none"
                  style={{ color: 'var(--accent)' }}
                >
                  {preset.mode === 'reps' ? reps2 : formatTime(ms2)}
                </p>

                {preset.mode === 'reps' ? (
                  <div className="flex items-center gap-3 w-full">
                    <button
                      type="button"
                      onClick={() => {
                        playTechClick();
                        setReps2((r) => Math.max(0, r - 1));
                      }}
                      aria-label="Riduci ripetizioni Atleta 2"
                      className="min-h-[58px] min-w-[64px] rounded-2xl border flex items-center justify-center transition active:scale-95"
                      style={{
                        backgroundColor: 'var(--bg-elevated)',
                        borderColor: 'var(--border-subtle)',
                        color: 'var(--text-main)',
                      }}
                    >
                      <Minus className="w-6 h-6" />
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        playSetCompleteTone();
                        setReps2((r) => r + 1);
                      }}
                      className="flex-1 min-h-[58px] rounded-2xl font-black text-lg flex items-center justify-center gap-2 transition active:scale-95"
                      style={{
                        backgroundColor: 'var(--accent)',
                        color: '#05070A',
                      }}
                    >
                      <Plus className="w-6 h-6 stroke-[3]" />
                      <span>+1 REP</span>
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2.5 w-full">
                    <button
                      type="button"
                      onClick={() => {
                        playTechClick();
                        setRunning2((r) => !r);
                      }}
                      className="flex-1 min-h-[56px] rounded-2xl font-black text-base flex items-center justify-center gap-2 transition active:scale-95"
                      style={{
                        backgroundColor: 'var(--accent)',
                        color: '#05070A',
                      }}
                    >
                      {running2 ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 fill-current" />}
                      <span>{running2 ? 'Stop' : ms2 > 0 ? 'Riprendi' : 'Start'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setRunning2(false);
                        setMs2(0);
                      }}
                      aria-label="Azzera timer Atleta 2"
                      className="min-h-[56px] min-w-[56px] rounded-2xl border flex items-center justify-center"
                      style={{
                        backgroundColor: 'var(--bg-elevated)',
                        borderColor: 'var(--border-subtle)',
                        color: 'var(--text-muted)',
                      }}
                    >
                      <RotateCcw className="w-5 h-5" />
                    </button>
                  </div>
                )}
              </div>
            </div>

            {preset.mode === 'time' && (
              <button
                type="button"
                onClick={() => {
                  playSetCompleteTone();
                  const startBoth = !running1 || !running2;
                  setRunning1(startBoth);
                  setRunning2(startBoth);
                }}
                className="w-full min-h-[46px] rounded-2xl border text-xs sm:text-sm font-extrabold transition"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-main)',
                }}
              >
                {running1 && running2
                  ? 'Metti in Pausa Entrambi i Cronometri'
                  : 'Avvia Entrambi i Cronometri Simultaneamente'}
              </button>
            )}

            <button
              type="button"
              onClick={handleFinishBattle}
              className="w-full min-h-[52px] rounded-2xl font-black text-sm sm:text-base flex items-center justify-center gap-2 transition"
              style={{
                backgroundColor: 'var(--primary)',
                color: '#FFFFFF',
              }}
            >
              <Trophy className="w-5 h-5" />
              <span>Termina Sfida &amp; Proclama Vincitore</span>
            </button>
          </div>
        )}

        {phase === 'winner' && (
          <div
            className="rounded-3xl border-2 p-6 sm:p-8 text-center space-y-5 shadow-2xl"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--accent)',
              color: 'var(--text-main)',
            }}
          >
            <div
              className="w-16 h-16 rounded-2xl mx-auto flex items-center justify-center border"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--accent)',
                color: 'var(--accent)',
              }}
            >
              <Award className="w-8 h-8" />
            </div>

            <div>
              <p className="text-xs font-extrabold uppercase tracking-widest" style={{ color: 'var(--accent)' }}>
                Risultato Finale · {preset.label}
              </p>
              <h3 className="text-2xl sm:text-4xl font-black mt-1">
                {winnerSide === 'tie'
                  ? 'PAREGGIO EPICO!'
                  : `${winnerSide === 1 ? name1 || 'Atleta 1' : name2 || 'Atleta 2'} VINCE!`}
              </h3>
            </div>

            <div className="grid grid-cols-2 gap-3 max-w-md mx-auto">
              <div
                className="rounded-2xl border p-4"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: winnerSide === 1 ? 'var(--accent)' : 'var(--primary)',
                }}
              >
                <p className="text-xs font-bold truncate" style={{ color: 'var(--text-muted)' }}>
                  {name1 || 'Atleta 1'}
                </p>
                <p className="font-mono text-3xl font-black mt-1 tabular-nums">
                  {preset.mode === 'reps' ? `${reps1} rep` : formatTime(ms1)}
                </p>
              </div>
              <div
                className="rounded-2xl border p-4"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: winnerSide === 2 ? 'var(--accent)' : 'var(--border-subtle)',
                }}
              >
                <p className="text-xs font-bold truncate" style={{ color: 'var(--text-muted)' }}>
                  {name2 || 'Atleta 2'}
                </p>
                <p
                  className="font-mono text-3xl font-black mt-1 tabular-nums"
                  style={{ color: 'var(--accent)' }}
                >
                  {preset.mode === 'reps' ? `${reps2} rep` : formatTime(ms2)}
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2.5 pt-2 max-w-md mx-auto">
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  resetArena();
                  setPhase('arena');
                }}
                className="min-h-[48px] rounded-xl font-extrabold text-xs sm:text-sm"
                style={{
                  backgroundColor: 'var(--accent)',
                  color: '#05070A',
                }}
              >
                Rivincita Immediata
              </button>
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  setPhase('setup');
                }}
                className="min-h-[48px] rounded-xl border font-extrabold text-xs sm:text-sm"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-main)',
                }}
              >
                Cambia Sfida
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
