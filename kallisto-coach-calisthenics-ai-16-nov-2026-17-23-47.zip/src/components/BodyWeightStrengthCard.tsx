import React, { useMemo, useState } from 'react';
import { Gauge, Plus, Scale, Trash2, TrendingUp } from 'lucide-react';
import type { AthleteProfile, BodyWeightEntry, WorkoutSessionLog } from '../types/calisthenics';
import { playSetCompleteTone, playTechClick } from '../utils/audio';
import { computeRelativeStrengthMetrics, getLocalDateKey } from '../utils/athletePillars';

interface BodyWeightStrengthCardProps {
  profile: AthleteProfile | null;
  history: WorkoutSessionLog[];
  weightLog: BodyWeightEntry[];
  onAddWeightEntry: (entry: { dateISO: string; weightKg: number }) => void;
  onDeleteWeightEntry: (id: string) => void;
}

export const BodyWeightStrengthCard: React.FC<BodyWeightStrengthCardProps> = ({
  profile,
  history,
  weightLog,
  onAddWeightEntry,
  onDeleteWeightEntry,
}) => {
  const [weightInput, setWeightInput] = useState<string>(
    profile?.weightKg ? String(profile.weightKg) : ''
  );
  const [dateInput, setDateInput] = useState<string>(getLocalDateKey());

  const sortedLog = useMemo(() => {
    return [...weightLog].sort(
      (a, b) => new Date(a.dateISO).getTime() - new Date(b.dateISO).getTime()
    );
  }, [weightLog]);

  const latestLoggedWeight =
    sortedLog.length > 0 ? sortedLog[sortedLog.length - 1].weightKg : profile?.weightKg;

  const strength = useMemo(
    () => computeRelativeStrengthMetrics(profile, history, latestLoggedWeight),
    [profile, history, latestLoggedWeight]
  );

  const handleSaveWeight = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(weightInput.replace(',', '.'));
    if (!Number.isFinite(num) || num < 30 || num > 250) return;
    playSetCompleteTone();
    const iso = dateInput ? new Date(`${dateInput}T12:00:00`).toISOString() : new Date().toISOString();
    onAddWeightEntry({
      dateISO: iso,
      weightKg: Math.round(num * 10) / 10,
    });
  };

  // Weight delta vs previous entry
  const deltaKg =
    sortedLog.length >= 2
      ? Math.round(
          (sortedLog[sortedLog.length - 1].weightKg -
            sortedLog[sortedLog.length - 2].weightKg) *
            10
        ) / 10
      : null;

  return (
    <section
      aria-label="Peso Corporeo e Rapporto Peso/Potenza"
      className="rounded-2xl border p-4 sm:p-5 space-y-4"
      style={{
        backgroundColor: 'var(--bg-card)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-main)',
      }}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Scale className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
          <h3 className="text-sm sm:text-base font-extrabold">
            Peso Corporeo &amp; Rapporto Peso/Potenza
          </h3>
        </div>
        <span
          className="font-mono text-xs font-extrabold tabular-nums"
          style={{ color: 'var(--accent)' }}
        >
          {strength.bodyWeightKg} kg
          {deltaKg !== null && ` (${deltaKg >= 0 ? `+${deltaKg}` : deltaKg} kg)`}
        </span>
      </div>

      {/* Relative Strength Index Hero */}
      <div
        className="rounded-xl border p-3.5 space-y-2.5"
        style={{
          backgroundColor: 'var(--bg-elevated)',
          borderColor: 'var(--accent)',
        }}
      >
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
              Indice di Forza Relativa (Media 1RM Trazioni &amp; Dip / Peso Corporeo)
            </p>
            <div className="flex items-baseline gap-2.5 mt-1">
              <span
                className="font-mono text-2xl sm:text-3xl font-black tabular-nums"
                style={{ color: 'var(--accent)' }}
              >
                {strength.combinedRatio.toFixed(2)}× BW
              </span>
              <span className="text-xs font-extrabold" style={{ color: 'var(--text-main)' }}>
                · Efficienza {strength.efficiencyScore}/100 ({strength.readinessLabel})
              </span>
            </div>
          </div>

          <div
            className="w-11 h-11 rounded-xl border flex items-center justify-center shrink-0"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--accent)',
            }}
          >
            <Gauge className="w-5 h-5" />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div
            className="rounded-lg border px-2.5 py-2"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
              Trazioni 1RM Stimato
            </p>
            <p className="font-mono font-extrabold tabular-nums mt-0.5">
              {strength.bestPullOneRmTotalKg} kg ({strength.pullRatio.toFixed(2)}×)
            </p>
          </div>
          <div
            className="rounded-lg border px-2.5 py-2"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
              Dip 1RM Stimato
            </p>
            <p className="font-mono font-extrabold tabular-nums mt-0.5">
              {strength.bestDipOneRmTotalKg} kg ({strength.dipRatio.toFixed(2)}×)
            </p>
          </div>
        </div>

        <p className="text-[11px] leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
          {strength.readinessDetail}
        </p>
      </div>

      {/* Quick Weekly Weight Logger */}
      <form onSubmit={handleSaveWeight} className="grid grid-cols-1 sm:grid-cols-[1fr_1fr_auto] gap-2">
        <input
          type="number"
          step="0.1"
          min={30}
          max={250}
          inputMode="decimal"
          value={weightInput}
          onChange={(e) => setWeightInput(e.target.value)}
          placeholder="Peso attuale (es. 71.5 kg)"
          className="min-h-[42px] rounded-xl border px-3 font-mono text-xs font-bold focus:outline-none"
          style={{
            backgroundColor: 'var(--bg-main)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        />
        <input
          type="date"
          value={dateInput}
          onChange={(e) => setDateInput(e.target.value)}
          className="min-h-[42px] rounded-xl border px-3 font-mono text-xs font-bold focus:outline-none"
          style={{
            backgroundColor: 'var(--bg-main)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        />
        <button
          type="submit"
          className="min-h-[42px] px-4 rounded-xl font-extrabold text-xs inline-flex items-center justify-center gap-1.5 transition whitespace-nowrap"
          style={{
            backgroundColor: 'var(--primary)',
            color: '#FFFFFF',
          }}
        >
          <Plus className="w-4 h-4" />
          <span>Registra Peso</span>
        </button>
      </form>

      {/* Weight Trend Line Chart */}
      {sortedLog.length > 0 ? (
        <div
          className="rounded-xl border p-3 space-y-2"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div className="flex items-center justify-between text-[11px]">
            <span className="inline-flex items-center gap-1 font-bold" style={{ color: 'var(--text-secondary)' }}>
              <TrendingUp className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} />
              Andamento Peso nel Tempo
            </span>
            <span className="font-mono tabular-nums" style={{ color: 'var(--text-muted)' }}>
              {sortedLog.length} {sortedLog.length === 1 ? 'rilevazione' : 'rilevazioni'}
            </span>
          </div>

          {(() => {
            const recent = sortedLog.slice(-10);
            const weights = recent.map((p) => p.weightKg);
            const minW = Math.min(...weights) - 1;
            const maxW = Math.max(...weights) + 1;
            const range = Math.max(1, maxW - minW);
            const w = 340;
            const h = 104;
            const padX = 22;
            const padY = 18;
            const coords = recent.map((pt, idx) => {
              const x =
                recent.length === 1 ? w / 2 : padX + (idx / (recent.length - 1)) * (w - padX * 2);
              const y = h - padY - ((pt.weightKg - minW) / range) * (h - padY * 2);
              const dateLabel = new Date(pt.dateISO).toLocaleDateString('it-IT', {
                day: '2-digit',
                month: '2-digit',
              });
              return { ...pt, x, y, dateLabel };
            });
            const poly = coords.map((c) => `${c.x},${c.y}`).join(' ');
            return (
              <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-28 overflow-visible">
                <line
                  x1={padX}
                  y1={h - padY}
                  x2={w - padX}
                  y2={h - padY}
                  stroke="var(--border-subtle)"
                />
                <line
                  x1={padX}
                  y1={padY}
                  x2={w - padX}
                  y2={padY}
                  stroke="var(--border-subtle)"
                  strokeDasharray="3 3"
                />
                {coords.length > 1 && (
                  <polyline
                    fill="none"
                    stroke="var(--accent)"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={poly}
                  />
                )}
                {coords.map((c) => (
                  <g key={c.id}>
                    <circle
                      cx={c.x}
                      cy={c.y}
                      r="4.5"
                      fill="var(--bg-main)"
                      stroke="var(--accent)"
                      strokeWidth="2.5"
                    />
                    <text
                      x={c.x}
                      y={c.y - 9}
                      textAnchor="middle"
                      fill="var(--text-main)"
                      fontSize="9"
                      fontFamily="JetBrains Mono, monospace"
                      fontWeight="700"
                    >
                      {c.weightKg}
                    </text>
                    <text
                      x={c.x}
                      y={h - 2}
                      textAnchor="middle"
                      fill="var(--text-muted)"
                      fontSize="8"
                    >
                      {c.dateLabel}
                    </text>
                  </g>
                ))}
              </svg>
            );
          })()}

          {/* Latest entries list with quick delete */}
          <div className="flex flex-wrap gap-1.5 pt-1">
            {[...sortedLog].reverse().slice(0, 5).map((entry) => (
              <div
                key={entry.id}
                className="px-2 py-1 rounded-lg border text-[11px] font-mono inline-flex items-center gap-1.5"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-secondary)',
                }}
              >
                <span>
                  {new Date(entry.dateISO).toLocaleDateString('it-IT', {
                    day: '2-digit',
                    month: '2-digit',
                  })}{' '}
                  · <strong>{entry.weightKg} kg</strong>
                </span>
                <button
                  type="button"
                  aria-label="Elimina rilevazione peso"
                  onClick={() => {
                    playTechClick();
                    onDeleteWeightEntry(entry.id);
                  }}
                  style={{ color: 'var(--text-muted)' }}
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
          Registra il tuo peso settimanale qui sopra per visualizzare l&apos;andamento e monitorare il rapporto peso/potenza.
        </p>
      )}
    </section>
  );
};
