import React from 'react';

interface CaliProLogoProps {
  size?: 'sm' | 'lg';
  subtitle?: string;
}

export const CaliProLogo: React.FC<CaliProLogoProps> = ({ size = 'sm', subtitle }) => {
  const isLarge = size === 'lg';
  const uid = isLarge ? 'lg' : 'sm';

  return (
    <div
      className={`inline-flex items-center ${
        isLarge ? 'flex-col gap-3 text-center' : 'gap-2.5 min-w-0'
      }`}
    >
      <div
        className={`relative flex items-center justify-center shrink-0 ${
          isLarge ? 'w-20 h-20' : 'w-9 h-9'
        }`}
      >
        <svg
          viewBox="0 0 80 80"
          fill="none"
          aria-hidden="true"
          className="w-full h-full overflow-visible"
        >
          <defs>
            <filter id={`calipro-glow-${uid}`} x="-30%" y="-30%" width="160%" height="160%">
              <feGaussianBlur stdDeviation="2" result="blur" />
              <feMerge>
                <feMergeNode in="blur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>

          {/* Angular Tech Hexagon - Pure Black Base + Primary Outer Glow */}
          <polygon
            points="40,3 73,21 73,59 40,77 7,59 7,21"
            fill="#05070A"
            style={{ stroke: 'var(--primary)' }}
            strokeWidth="3.5"
            strokeLinejoin="miter"
          />

          {/* Inner Luminous Accent Hexagon Border */}
          <polygon
            points="40,9 67,24 67,56 40,71 13,56 13,24"
            fill="#05070A"
            style={{ stroke: 'var(--accent)' }}
            strokeWidth="1.6"
            strokeLinejoin="miter"
            filter={`url(#calipro-glow-${uid})`}
          />

          {/* Top Pull-up Bar (horizontal crossbar with end caps) */}
          <line
            x1="21"
            y1="23"
            x2="59"
            y2="23"
            style={{ stroke: 'var(--accent)' }}
            strokeWidth="3.2"
            strokeLinecap="square"
            filter={`url(#calipro-glow-${uid})`}
          />
          <line
            x1="23"
            y1="23"
            x2="23"
            y2="27"
            style={{ stroke: 'var(--primary)' }}
            strokeWidth="2.5"
            strokeLinecap="square"
          />
          <line
            x1="57"
            y1="23"
            x2="57"
            y2="27"
            style={{ stroke: 'var(--primary)' }}
            strokeWidth="2.5"
            strokeLinecap="square"
          />

          {/* Two Parallel Bars forming the vertical spine of the "K" */}
          <line
            x1="27"
            y1="26"
            x2="27"
            y2="58"
            stroke="#FFFFFF"
            strokeWidth="4.2"
            strokeLinecap="square"
          />
          <line
            x1="34"
            y1="29"
            x2="34"
            y2="58"
            style={{ stroke: 'var(--primary)' }}
            strokeWidth="3.4"
            strokeLinecap="square"
          />

          {/* Sharp Stylized Lightning Bolt completing the aggressive "K" */}
          <polygon
            points="54,28 40,42 48,42 36,58 56,39 47,39"
            style={{ fill: 'var(--accent)' }}
            filter={`url(#calipro-glow-${uid})`}
          />
          <polyline
            points="54,28 38,43 49,43 37,57"
            fill="none"
            stroke="#FFFFFF"
            strokeWidth="1.6"
            strokeLinejoin="miter"
          />
        </svg>
      </div>

      <div className="min-w-0">
        <div
          className={`font-display font-black tracking-wider leading-none whitespace-nowrap uppercase ${
            isLarge ? 'text-3xl sm:text-4xl' : 'text-lg sm:text-xl'
          }`}
        >
          <span className="text-[#FFFFFF]">CALI</span>{' '}
          <span className="text-[#38BDF8]" style={{ color: 'var(--accent)' }}>
            PRO
          </span>
        </div>
        {subtitle && (
          <p className="text-xs mt-1.5 leading-relaxed" style={{ color: 'var(--text-muted)' }}>
            {subtitle}
          </p>
        )}
      </div>
    </div>
  );
};
