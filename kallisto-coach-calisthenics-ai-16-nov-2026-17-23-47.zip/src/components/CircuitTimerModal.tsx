import React, { useEffect, useRef, useState } from 'react';
import {
  Activity,
  Flame,
  Pause,
  Play,
  RotateCcw,
  Timer,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { playTechClick, playTickBeep, playTimerCompleteChime } from '../utils/audio';
import { speakItalian, stopSpeaking } from '../utils/voiceCoach';

export type CircuitMode = 'emom' | 'tabata' | 'tut';

interface CircuitTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CircuitTimerModal: React.FC<CircuitTimerModalProps> = ({ isOpen, onClose }) => {
  const [mode, setMode] = useState<CircuitMode>('emom');
  const [voiceOn, setVoiceOn] = useState(true);
  const [running, setRunning] = useState(false);

  // EMOM config & state
  const [emomTotalRounds, setEmomTotalRounds] = useState(10);
  const [emomRound, setEmomRound] = useState(1);
  const [emomSecLeft, setEmomSecLeft] = useState(60);
  const [emomDone, setEmomDone] = useState(false);

  // TABATA config & state
  const [tabataWorkSec, setTabataWorkSec] = useState(20);
  const [tabataRestSec, setTabataRestSec] = useState(10);
  const [tabataTotalRounds, setTabataTotalRounds] = useState(8);
  const [tabataPhase, setTabataPhase] = useState<'work' | 'rest'>('work');
  const [tabataRound, setTabataRound] = useState(1);
  const [tabataSecLeft, setTabataSecLeft] = useState(20);
  const [tabataDone, setTabataDone] = useState(false);

  // Metronomo TUT config & state
  const [tutEccentric, setTutEccentric] = useState(4);
  const [tutPause, setTutPause] = useState(1);
  const [tutConcentric, setTutConcentric] = useState(1);
  const [tutTargetReps, setTutTargetReps] = useState(6);
  const [tutPhase, setTutPhase] = useState<'eccentric' | 'pause' | 'concentric'>('eccentric');
  const [tutPhaseSec, setTutPhaseSec] = useState(1);
  const [tutRep, setTutRep] = useState(1);
  const [tutDone, setTutDone] = useState(false);

  // Keep refs for interval step logic
  const voiceRef = useRef(voiceOn);
  voiceRef.current = voiceOn;

  const emomStateRef = useRef({ round: emomRound, secLeft: emomSecLeft, total: emomTotalRounds });
  emomStateRef.current = { round: emomRound, secLeft: emomSecLeft, total: emomTotalRounds };

  const tabataStateRef = useRef({
    phase: tabataPhase,
    round: tabataRound,
    secLeft: tabataSecLeft,
    workSec: tabataWorkSec,
    restSec: tabataRestSec,
    totalRounds: tabataTotalRounds,
  });
  tabataStateRef.current = {
    phase: tabataPhase,
    round: tabataRound,
    secLeft: tabataSecLeft,
    workSec: tabataWorkSec,
    restSec: tabataRestSec,
    totalRounds: tabataTotalRounds,
  };

  const tutStateRef = useRef({
    phase: tutPhase,
    sec: tutPhaseSec,
    rep: tutRep,
    ecc: tutEccentric,
    pause: tutPause,
    conc: tutConcentric,
    targetReps: tutTargetReps,
  });
  tutStateRef.current = {
    phase: tutPhase,
    sec: tutPhaseSec,
    rep: tutRep,
    ecc: tutEccentric,
    pause: tutPause,
    conc: tutConcentric,
    targetReps: tutTargetReps,
  };

  useEffect(() => {
    if (!isOpen) {
      setRunning(false);
      stopSpeaking();
    }
    return () => {
      stopSpeaking();
    };
  }, [isOpen]);

  const resetCurrentMode = (targetMode: CircuitMode = mode) => {
    setRunning(false);
    stopSpeaking();
    if (targetMode === 'emom') {
      setEmomRound(1);
      setEmomSecLeft(60);
      setEmomDone(false);
    } else if (targetMode === 'tabata') {
      setTabataPhase('work');
      setTabataRound(1);
      setTabataSecLeft(tabataWorkSec);
      setTabataDone(false);
    } else {
      setTutPhase('eccentric');
      setTutPhaseSec(1);
      setTutRep(1);
      setTutDone(false);
    }
  };

  // Main 1-second timer loop
  useEffect(() => {
    if (!isOpen || !running) return;

    const intervalId = window.setInterval(() => {
      const useVoice = voiceRef.current;

      if (mode === 'emom') {
        const st = emomStateRef.current;
        if (st.secLeft > 1) {
          const nextSec = st.secLeft - 1;
          setEmomSecLeft(nextSec);
          if (nextSec <= 3) {
            playTickBeep(false);
            if (useVoice) speakItalian(String(nextSec), { rate: 1.1 });
          }
        } else {
          if (st.round >= st.total) {
            setEmomSecLeft(0);
            setEmomDone(true);
            setRunning(false);
            playTimerCompleteChime();
            if (useVoice) speakItalian('Circuito EMOM completato!', { rate: 1.0 });
          } else {
            const nextR = st.round + 1;
            setEmomRound(nextR);
            setEmomSecLeft(60);
            playTickBeep(true);
            if (useVoice) speakItalian(`Round ${nextR} di ${st.total}, via!`, { rate: 1.05 });
          }
        }
        return;
      }

      if (mode === 'tabata') {
        const st = tabataStateRef.current;
        if (st.secLeft > 1) {
          const nextSec = st.secLeft - 1;
          setTabataSecLeft(nextSec);
          if (nextSec <= 3) {
            playTickBeep(false);
            if (useVoice) speakItalian(String(nextSec), { rate: 1.15 });
          }
        } else if (st.phase === 'work') {
          if (st.round >= st.totalRounds) {
            setTabataSecLeft(0);
            setTabataDone(true);
            setRunning(false);
            playTimerCompleteChime();
            if (useVoice) speakItalian('Tabata completato! Ottimo lavoro!', { rate: 1.0 });
          } else {
            setTabataPhase('rest');
            setTabataSecLeft(st.restSec);
            playTickBeep(false);
            if (useVoice) speakItalian('Riposo!', { rate: 1.05 });
          }
        } else {
          const nextR = st.round + 1;
          setTabataPhase('work');
          setTabataRound(nextR);
          setTabataSecLeft(st.workSec);
          playTickBeep(true);
          if (useVoice) speakItalian(`Lavoro! Round ${nextR}, via!`, { rate: 1.08 });
        }
        return;
      }

      // TUT Metronome
      const tut = tutStateRef.current;
      if (tut.phase === 'eccentric') {
        if (tut.sec < tut.ecc) {
          const nextSec = tut.sec + 1;
          setTutPhaseSec(nextSec);
          playTickBeep(false);
          if (useVoice) speakItalian(String(nextSec), { rate: 1.15 });
        } else if (tut.pause > 0) {
          setTutPhase('pause');
          setTutPhaseSec(1);
          playTickBeep(false);
          if (useVoice) speakItalian('Fermo', { rate: 1.1 });
        } else {
          setTutPhase('concentric');
          setTutPhaseSec(1);
          playTickBeep(true);
          if (useVoice) speakItalian('Sali!', { rate: 1.1 });
        }
      } else if (tut.phase === 'pause') {
        if (tut.sec < tut.pause) {
          const nextSec = tut.sec + 1;
          setTutPhaseSec(nextSec);
          playTickBeep(false);
        } else {
          setTutPhase('concentric');
          setTutPhaseSec(1);
          playTickBeep(true);
          if (useVoice) speakItalian('Sali!', { rate: 1.1 });
        }
      } else {
        if (tut.sec < tut.conc) {
          const nextSec = tut.sec + 1;
          setTutPhaseSec(nextSec);
          playTickBeep(false);
        } else if (tut.rep >= tut.targetReps) {
          setTutDone(true);
          setRunning(false);
          playTimerCompleteChime();
          if (useVoice) speakItalian('Serie TUT completata!', { rate: 1.0 });
        } else {
          const nextRep = tut.rep + 1;
          setTutRep(nextRep);
          setTutPhase('eccentric');
          setTutPhaseSec(1);
          playTickBeep(false);
          if (useVoice) speakItalian(`Rep ${nextRep}, scendi`, { rate: 1.05 });
        }
      }
    }, 1000);

    return () => window.clearInterval(intervalId);
  }, [isOpen, running, mode]);

  if (!isOpen) return null;

  const handleToggleStartPause = () => {
    playTechClick();
    if (running) {
      setRunning(false);
      stopSpeaking();
      return;
    }

    if (mode === 'emom') {
      if (emomDone) resetCurrentMode('emom');
      playTickBeep(true);
      if (voiceOn) {
        speakItalian(`Round ${emomDone ? 1 : emomRound} di ${emomTotalRounds}, via!`, {
          rate: 1.05,
        });
      }
    } else if (mode === 'tabata') {
      if (tabataDone) resetCurrentMode('tabata');
      playTickBeep(true);
      if (voiceOn) {
        speakItalian(
          tabataPhase === 'work' || tabataDone
            ? `Lavoro! Round ${tabataDone ? 1 : tabataRound}, via!`
            : 'Riposo!',
          { rate: 1.05 }
        );
      }
    } else {
      if (tutDone) resetCurrentMode('tut');
      playTickBeep(true);
      if (voiceOn) {
        speakItalian(`Rep ${tutDone ? 1 : tutRep}, scendi`, { rate: 1.05 });
      }
    }
    setRunning(true);
  };

  const isTabataWorkHighlight = mode === 'tabata' && running && tabataPhase === 'work';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Timer Circuiti PRO — EMOM, TABATA e Metronomo TUT"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#05070A]/85 backdrop-blur-md p-3 sm:p-4"
    >
      <div
        className="w-full max-w-md rounded-3xl border p-4 sm:p-5 shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto transition-colors"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: isTabataWorkHighlight ? 'var(--accent)' : 'var(--border-subtle)',
          color: 'var(--text-main)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <div
              className="w-9 h-9 rounded-xl border flex items-center justify-center shrink-0"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--accent)',
                color: 'var(--accent)',
              }}
            >
              <Timer className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <h3 className="text-sm sm:text-base font-extrabold truncate">
                Circuiti PRO &amp; Metronomo
              </h3>
              <p className="text-[11px] truncate" style={{ color: 'var(--text-muted)' }}>
                EMOM · TABATA · Tempo Under Tension vocale
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                const next = !voiceOn;
                setVoiceOn(next);
                if (!next) stopSpeaking();
              }}
              aria-label={voiceOn ? 'Disattiva voce guida' : 'Attiva voce guida'}
              className="w-9 h-9 rounded-xl border flex items-center justify-center transition"
              style={{
                backgroundColor: voiceOn ? 'var(--bg-elevated)' : 'var(--bg-main)',
                borderColor: voiceOn ? 'var(--accent)' : 'var(--border-subtle)',
                color: voiceOn ? 'var(--accent)' : 'var(--text-muted)',
              }}
            >
              {voiceOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={() => {
                setRunning(false);
                stopSpeaking();
                onClose();
              }}
              aria-label="Chiudi Timer Circuiti"
              className="w-9 h-9 rounded-xl border flex items-center justify-center transition"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--border-subtle)',
                color: 'var(--text-muted)',
              }}
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Mode Tabs */}
        <div
          className="grid grid-cols-3 gap-1.5 p-1 rounded-2xl border"
          style={{
            backgroundColor: 'var(--bg-main)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          {(
            [
              { id: 'emom', label: 'EMOM' },
              { id: 'tabata', label: 'TABATA' },
              { id: 'tut', label: 'Metronomo TUT' },
            ] as const
          ).map((tab) => {
            const active = mode === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => {
                  playTechClick();
                  setRunning(false);
                  stopSpeaking();
                  setMode(tab.id);
                }}
                className="min-h-[38px] px-2 rounded-xl text-xs font-extrabold transition"
                style={{
                  backgroundColor: active ? 'var(--primary)' : 'transparent',
                  color: active ? '#FFFFFF' : 'var(--text-muted)',
                }}
              >
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Main Display Panel */}
        <div
          className="rounded-2xl border p-5 text-center space-y-2 transition-colors"
          style={{
            backgroundColor: isTabataWorkHighlight ? 'var(--accent-soft)' : 'var(--bg-main)',
            borderColor: isTabataWorkHighlight ? 'var(--accent)' : 'var(--border-subtle)',
          }}
        >
          {mode === 'emom' && (
            <>
              <p className="text-[11px] font-extrabold uppercase tracking-wider" style={{ color: 'var(--accent)' }}>
                {emomDone ? 'EMOM COMPLETATO!' : `ROUND ${emomRound} DI ${emomTotalRounds}`}
              </p>
              <p className="font-mono text-5xl font-black tabular-nums leading-none">
                {String(Math.floor(emomSecLeft / 60)).padStart(2, '0')}:
                {String(emomSecLeft % 60).padStart(2, '0')}
              </p>
              <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
                Ogni minuto scatta il segnale vocale per il nuovo round
              </p>
            </>
          )}

          {mode === 'tabata' && (
            <>
              <div className="inline-flex items-center gap-1.5 text-xs font-extrabold uppercase tracking-wider px-2.5 py-0.5 rounded-lg" style={{
                backgroundColor: tabataPhase === 'work' ? 'var(--accent)' : 'var(--bg-elevated)',
                color: tabataPhase === 'work' ? '#05070A' : 'var(--accent)',
              }}>
                <Flame className="w-3.5 h-3.5" />
                <span>
                  {tabataDone
                    ? 'COMPLETATO!'
                    : tabataPhase === 'work'
                    ? `LAVORO · ROUND ${tabataRound}/${tabataTotalRounds}`
                    : `RECUPERO · ROUND ${tabataRound}/${tabataTotalRounds}`}
                </span>
              </div>
              <p className="font-mono text-5xl font-black tabular-nums leading-none pt-1">
                {tabataSecLeft}s
              </p>
              <p className="text-xs" style={{ color: 'var(--text-secondary)' }}>
                {tabataWorkSec}s lavoro / {tabataRestSec}s recupero × {tabataTotalRounds} round
              </p>
            </>
          )}

          {mode === 'tut' && (
            <>
              <p className="text-[11px] font-extrabold uppercase tracking-wider" style={{ color: 'var(--accent)' }}>
                {tutDone ? 'SERIE COMPLETATA!' : `RIPETIZIONE ${tutRep} DI ${tutTargetReps}`}
              </p>
              <p className="text-2xl sm:text-3xl font-black tracking-tight" style={{
                color: tutPhase === 'eccentric' ? 'var(--accent)' : tutPhase === 'concentric' ? '#10B981' : 'var(--text-main)',
              }}>
                {tutDone
                  ? 'OTTIMO TEMPO!'
                  : tutPhase === 'eccentric'
                  ? `SCENDI (${tutPhaseSec}/${tutEccentric}s)`
                  : tutPhase === 'pause'
                  ? `FERMO (${tutPhaseSec}/${tutPause}s)`
                  : `SALI! (${tutPhaseSec}/${tutConcentric}s)`}
              </p>
              <p className="font-mono text-xs font-bold" style={{ color: 'var(--text-muted)' }}>
                Tempo impostato: {tutEccentric}s discesa · {tutPause}s fermo · {tutConcentric}s salita
              </p>
            </>
          )}
        </div>

        {/* Config Steppers */}
        {mode === 'emom' && (
          <div
            className="rounded-xl border p-3 flex items-center justify-between gap-2"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <span className="text-xs font-bold">Durata totale (Round / Minuti)</span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={running}
                onClick={() => setEmomTotalRounds((r) => Math.max(2, r - 1))}
                className="w-8 h-8 rounded-lg border font-bold disabled:opacity-40"
                style={{ backgroundColor: 'var(--bg-main)', borderColor: 'var(--border-subtle)' }}
              >
                -
              </button>
              <span className="font-mono text-sm font-extrabold min-w-[44px] text-center tabular-nums" style={{ color: 'var(--accent)' }}>
                {emomTotalRounds} min
              </span>
              <button
                type="button"
                disabled={running}
                onClick={() => setEmomTotalRounds((r) => Math.min(40, r + 1))}
                className="w-8 h-8 rounded-lg border font-bold disabled:opacity-40"
                style={{ backgroundColor: 'var(--bg-main)', borderColor: 'var(--border-subtle)' }}
              >
                +
              </button>
            </div>
          </div>
        )}

        {mode === 'tabata' && (
          <div className="grid grid-cols-3 gap-2">
            {[
              {
                label: 'Lavoro',
                val: `${tabataWorkSec}s`,
                dec: () => {
                  const next = Math.max(10, tabataWorkSec - 5);
                  setTabataWorkSec(next);
                  if (!running) setTabataSecLeft(next);
                },
                inc: () => {
                  const next = Math.min(90, tabataWorkSec + 5);
                  setTabataWorkSec(next);
                  if (!running) setTabataSecLeft(next);
                },
              },
              {
                label: 'Riposo',
                val: `${tabataRestSec}s`,
                dec: () => setTabataRestSec((v) => Math.max(5, v - 5)),
                inc: () => setTabataRestSec((v) => Math.min(60, v + 5)),
              },
              {
                label: 'Round',
                val: String(tabataTotalRounds),
                dec: () => setTabataTotalRounds((v) => Math.max(2, v - 1)),
                inc: () => setTabataTotalRounds((v) => Math.min(20, v + 1)),
              },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-xl border p-2 text-center space-y-1.5"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: 'var(--border-subtle)',
                }}
              >
                <p className="text-[10px] font-bold uppercase" style={{ color: 'var(--text-muted)' }}>
                  {item.label}
                </p>
                <p className="font-mono text-sm font-extrabold tabular-nums" style={{ color: 'var(--accent)' }}>
                  {item.val}
                </p>
                <div className="flex items-center justify-center gap-1">
                  <button
                    type="button"
                    disabled={running}
                    onClick={item.dec}
                    className="w-7 h-7 rounded-lg border text-xs font-bold disabled:opacity-40"
                    style={{ backgroundColor: 'var(--bg-main)', borderColor: 'var(--border-subtle)' }}
                  >
                    -
                  </button>
                  <button
                    type="button"
                    disabled={running}
                    onClick={item.inc}
                    className="w-7 h-7 rounded-lg border text-xs font-bold disabled:opacity-40"
                    style={{ backgroundColor: 'var(--bg-main)', borderColor: 'var(--border-subtle)' }}
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {mode === 'tut' && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              {
                label: 'Discesa',
                val: `${tutEccentric}s`,
                dec: () => setTutEccentric((v) => Math.max(1, v - 1)),
                inc: () => setTutEccentric((v) => Math.min(10, v + 1)),
              },
              {
                label: 'Fermo',
                val: `${tutPause}s`,
                dec: () => setTutPause((v) => Math.max(0, v - 1)),
                inc: () => setTutPause((v) => Math.min(6, v + 1)),
              },
              {
                label: 'Salita',
                val: `${tutConcentric}s`,
                dec: () => setTutConcentric((v) => Math.max(1, v - 1)),
                inc: () => setTutConcentric((v) => Math.min(6, v + 1)),
              },
              {
                label: 'Rep Target',
                val: String(tutTargetReps),
                dec: () => setTutTargetReps((v) => Math.max(1, v - 1)),
                inc: () => setTutTargetReps((v) => Math.min(20, v + 1)),
              },
            ].map((item) => (
              <div
                key={item.label}
                className="rounded-xl border p-2 text-center space-y-1"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: 'var(--border-subtle)',
                }}
              >
                <p className="text-[10px] font-bold uppercase" style={{ color: 'var(--text-muted)' }}>
                  {item.label}
                </p>
                <p className="font-mono text-sm font-extrabold tabular-nums" style={{ color: 'var(--accent)' }}>
                  {item.val}
                </p>
                <div className="flex items-center justify-center gap-1">
                  <button
                    type="button"
                    disabled={running}
                    onClick={item.dec}
                    className="w-7 h-7 rounded-lg border text-xs font-bold disabled:opacity-40"
                    style={{ backgroundColor: 'var(--bg-main)', borderColor: 'var(--border-subtle)' }}
                  >
                    -
                  </button>
                  <button
                    type="button"
                    disabled={running}
                    onClick={item.inc}
                    className="w-7 h-7 rounded-lg border text-xs font-bold disabled:opacity-40"
                    style={{ backgroundColor: 'var(--bg-main)', borderColor: 'var(--border-subtle)' }}
                  >
                    +
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Controls */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleToggleStartPause}
            className="flex-1 min-h-[46px] rounded-xl text-sm font-extrabold flex items-center justify-center gap-2 transition"
            style={{
              backgroundColor: running ? 'var(--primary)' : 'var(--accent)',
              color: running ? '#FFFFFF' : '#05070A',
            }}
          >
            {running ? (
              <>
                <Pause className="w-4 h-4" />
                <span>Pausa</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>
                  {mode === 'emom'
                    ? 'Avvia EMOM'
                    : mode === 'tabata'
                    ? 'Avvia TABATA'
                    : 'Avvia Metronomo'}
                </span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={() => {
              playTechClick();
              resetCurrentMode();
            }}
            aria-label="Azzera timer"
            className="min-h-[46px] px-4 rounded-xl border text-xs font-bold inline-flex items-center gap-1.5 transition"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          >
            <RotateCcw className="w-4 h-4" />
            <span>Reset</span>
          </button>
        </div>

        <p className="text-[11px] flex items-center justify-center gap-1.5" style={{ color: 'var(--text-muted)' }}>
          <Activity className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} />
          <span>Guida vocale italiana e segnali sonori integrati</span>
        </p>
      </div>
    </div>
  );
};
