import React, { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Check,
  Crosshair,
  Loader2,
  RotateCcw,
  Send,
  ShieldAlert,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import { EXERCISE_CATALOG } from '../data/exercises';
import type {
  AthleteProfile,
  CoachActionProposal,
  CoachMessage,
  MorningCheckinRecord,
  WorkoutDayPlan,
  WorkoutSessionLog,
} from '../types/calisthenics';
import { formatMorningCheckinSummary } from '../utils/athletePillars';
import { playTechClick } from '../utils/audio';
import { CoachVisionModal } from './CoachVisionModal';

interface PuterChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

interface PuterContentBlock {
  text?: string;
}

interface PuterChatResponse {
  message?: {
    role?: string;
    content?: string | PuterContentBlock[];
  };
  text?: string;
  toString?: () => string;
}

declare global {
  interface Window {
    puter?: {
      ai?: {
        chat: (
          messages: string | PuterChatMessage[],
          options?: Record<string, unknown>
        ) => Promise<PuterChatResponse | string>;
      };
    };
  }
}

interface CoachViewProps {
  profile: AthleteProfile;
  weeklyPlan: WorkoutDayPlan[];
  history: WorkoutSessionLog[];
  morningCheckins?: MorningCheckinRecord[];
  messages: CoachMessage[];
  pendingCheckinSessionId: string | null;
  onClearPendingCheckin: () => void;
  pendingVisionPrompt?: string | null;
  onClearPendingVision?: () => void;
  onAppendMessage: (msg: CoachMessage) => void;
  onApplyProposal: (messageId: string, proposal: CoachActionProposal) => void;
}

const COACH_CHARACTER_PROMPT =
  "Sei un Personal Trainer di Calisthenics simpatico, amichevole e competente. Parla in italiano naturale come un vero coach su WhatsApp: se l'utente ti saluta dicendo 'ciao', rispondigli calorosamente e poi fagli domande mirate sui suoi allenamenti, sulla tecnica come scapole, polsi e gomiti o su come si sente. Sii conversazionale e non robotico.";

function extractPuterReplyText(result: PuterChatResponse | string): string {
  if (typeof result === 'string') {
    return result.trim();
  }
  if (!result || typeof result !== 'object') {
    return '';
  }

  const content = result.message?.content;
  if (typeof content === 'string') {
    return content.trim();
  }
  if (Array.isArray(content)) {
    return content
      .map((block) => (typeof block === 'string' ? block : block?.text ?? ''))
      .join('\n')
      .trim();
  }
  if (typeof result.text === 'string') {
    return result.text.trim();
  }
  if (typeof result.toString === 'function') {
    const str = result.toString().trim();
    if (str && str !== '[object Object]') {
      return str;
    }
  }
  return '';
}

function formatPuterError(err: unknown): string {
  if (err instanceof Error) {
    return err.message;
  }
  if (typeof err === 'string') {
    return err;
  }
  if (err && typeof err === 'object') {
    const record = err as { message?: unknown; error?: { message?: unknown } };
    if (typeof record.message === 'string') return record.message;
    if (typeof record.error?.message === 'string') return record.error.message;
    try {
      return JSON.stringify(err);
    } catch {
      return 'Errore sconosciuto durante la chiamata a Puter AI.';
    }
  }
  return 'Errore sconosciuto durante la chiamata a Puter AI.';
}

export const CoachView: React.FC<CoachViewProps> = ({
  profile,
  weeklyPlan,
  history,
  morningCheckins = [],
  messages,
  pendingCheckinSessionId,
  onClearPendingCheckin,
  pendingVisionPrompt = null,
  onClearPendingVision,
  onAppendMessage,
  onApplyProposal,
}) => {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [visionOpen, setVisionOpen] = useState(false);
  const [lastFailedPayload, setLastFailedPayload] = useState<{
    mode: 'checkin' | 'chat';
    userMessage?: string;
  } | null>(null);

  const bottomRef = useRef<HTMLDivElement | null>(null);
  const triggeredCheckinIdRef = useRef<string | null>(null);
  const triggeredVisionPromptRef = useRef<string | null>(null);

  const latestSession = history[0];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length, loading]);

  const buildUserDataSummary = (): string => {
    const planText = weeklyPlan
      .map((d) => {
        const exList = d.exercises
          .map((e) => {
            const name =
              e.customName ??
              EXERCISE_CATALOG.find((c) => c.id === e.exerciseId)?.name ??
              e.exerciseId;
            const unit = e.isIsometric ? 's' : ' rep';
            const wt =
              (e.sets[0]?.addedWeightKg ?? 0) > 0
                ? ` (+${e.sets[0].addedWeightKg}kg)`
                : '';
            return `${name} ${e.sets.length}x${e.sets[0]?.targetValue ?? 0}${unit}${wt}`;
          })
          .join(', ');
        return `- ${d.title}: ${exList}`;
      })
      .join('\n');

    const latestWorkoutText = latestSession
      ? `Ultimo allenamento svolto (${new Date(latestSession.dateISO).toLocaleDateString('it-IT')} - ${latestSession.dayTitle}, durata ${latestSession.durationMinutes} min, RPE medio ${latestSession.avgRpe.toFixed(1)}):\n` +
        latestSession.exercises
          .map((e) => {
            const unit = e.isIsometric ? 's' : ' rep';
            const wt = e.maxAddedWeightKg > 0 ? `, zavorra +${e.maxAddedWeightKg}kg` : '';
            const techDesc =
              e.technicalScore === 3
                ? ', voto qualità tecnica: 3/3 (Molto semplice/Pulita — pronto ad aumentare carico o difficoltà)'
                : e.technicalScore === 2
                ? ', voto qualità tecnica: 2/3 (Tirata/Al limite — consolida prima di aumentare)'
                : e.technicalScore === 1
                ? ', voto qualità tecnica: 1/3 (Molto sporca/Tecnica persa — mantieni o riduci difficoltà per consolidare la tecnica)'
                : '';
            return `- ${e.exerciseName}: svolto max ${e.bestValue}${unit} (target ${e.targetValue}${unit}, totale ${e.totalVolume}${unit}, RPE ${e.avgRpe.toFixed(1)}${wt}${techDesc})`;
          })
          .join('\n')
      : 'Nessun allenamento ancora registrato.';

    const latestCheckin = morningCheckins[0];
    const checkinText = latestCheckin
      ? `Check-in Mattutino più recente (${latestCheckin.dateKey}): ${formatMorningCheckinSummary(latestCheckin)}${latestCheckin.volumeAdapted ? ' [Volume adattato -1 serie]' : ''}${latestCheckin.jointProtectedApplied ? ' [Protezione articolare applicata]' : ''}.`
      : 'Nessun check-in mattutino registrato oggi.';

    return [
      `Atleta: ${profile.name} | Obiettivo: ${profile.goal}${profile.targetSkill ? ` (${profile.targetSkill})` : ''} | Giorni: ${profile.trainingDays.join(', ')} | Zone da proteggere/infortuni: ${profile.injuries.length > 0 ? profile.injuries.join(', ') : 'nessuno'} | Massimali iniziali: Pull-up ${profile.baselines.pullups}, Dip ${profile.baselines.dips}, Push-up ${profile.baselines.pushups}, Leg Raises ${profile.baselines.legRaises}.`,
      checkinText,
      `Scheda attuale:\n${planText || 'Non ancora configurata.'}`,
      latestWorkoutText,
    ].join('\n\n');
  };

  const requestCoachResponse = async (
    mode: 'checkin' | 'chat',
    userText?: string
  ) => {
    setLoading(true);
    setLastFailedPayload(null);

    const effectiveUserText = (userText ?? '').trim();

    try {
      const chatFn = window.puter?.ai?.chat;
      if (typeof chatFn !== 'function') {
        throw new Error(
          'Puter.js non è pronto o non è stato caricato nel browser. Controlla la connessione e ricarica la pagina.'
        );
      }

      const historyMessages: PuterChatMessage[] = messages
        .filter((m) => !m.error)
        .slice(-10)
        .map((m) => ({
          role: m.role === 'coach' ? 'assistant' : 'user',
          content: m.content,
        }));

      const currentTurnContent =
        mode === 'checkin'
          ? 'Ho appena concluso questo allenamento! Commentalo in modo amichevole partendo dai miei dati reali e fammi qualche domanda su come è andata.'
          : effectiveUserText;

      const puterMessages: PuterChatMessage[] = [
        {
          role: 'system',
          content: `${COACH_CHARACTER_PROMPT}\n\nDATI SALVATI DELL'UTENTE:\n${buildUserDataSummary()}`,
        },
        ...historyMessages,
        {
          role: 'user',
          content: currentTurnContent,
        },
      ];

      const result = await chatFn(puterMessages);
      const replyText = extractPuterReplyText(result);

      if (!replyText) {
        throw new Error('Puter AI ha restituito una risposta vuota.');
      }

      onAppendMessage({
        id: `coach_${Date.now()}`,
        role: 'coach',
        content: replyText,
        timestampISO: new Date().toISOString(),
        source: 'puter',
      });
    } catch (err) {
      const clearError = formatPuterError(err);
      setLastFailedPayload({ mode, userMessage: effectiveUserText });
      onAppendMessage({
        id: `coach_err_${Date.now()}`,
        role: 'coach',
        content: `Errore Coach AI: ${clearError}`,
        timestampISO: new Date().toISOString(),
        error: true,
      });
    } finally {
      setLoading(false);
    }
  };

  // Automatically trigger check-in when finishing a session
  useEffect(() => {
    if (
      pendingCheckinSessionId &&
      triggeredCheckinIdRef.current !== pendingCheckinSessionId &&
      latestSession?.id === pendingCheckinSessionId
    ) {
      triggeredCheckinIdRef.current = pendingCheckinSessionId;
      onClearPendingCheckin();
      requestCoachResponse('checkin');
    }
  }, [pendingCheckinSessionId, latestSession?.id]);

  const handleSubmitPosturalAnalysis = async (analysisText: string) => {
    if (!analysisText.trim() || loading) return;
    const userMsg: CoachMessage = {
      id: `usr_vis_${Date.now()}`,
      role: 'user',
      content: analysisText.trim(),
      timestampISO: new Date().toISOString(),
    };
    onAppendMessage(userMsg);
    await requestCoachResponse('chat', analysisText.trim());
  };

  // Automatically process incoming Coach Vision prompt triggered from Skill Tree
  useEffect(() => {
    if (
      pendingVisionPrompt &&
      triggeredVisionPromptRef.current !== pendingVisionPrompt &&
      !loading
    ) {
      triggeredVisionPromptRef.current = pendingVisionPrompt;
      onClearPendingVision?.();
      handleSubmitPosturalAnalysis(pendingVisionPrompt);
    }
  }, [pendingVisionPrompt, loading]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed || loading) return;

    const userMsg: CoachMessage = {
      id: `usr_${Date.now()}`,
      role: 'user',
      content: trimmed,
      timestampISO: new Date().toISOString(),
    };
    onAppendMessage(userMsg);
    setInput('');
    await requestCoachResponse('chat', trimmed);
  };

  return (
    <div className="flex flex-col h-[calc(100vh-10.5rem)] sm:h-[calc(100vh-11rem)] max-w-3xl mx-auto">
      {/* Latest Session Context Strip + Coach Vision Launcher */}
      <div className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-3.5 mb-3 shrink-0 space-y-2.5">
        {latestSession ? (
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <p className="text-xs text-[#94A3B8] truncate">
                Ultima seduta letta dal Coach ·{' '}
                {new Date(latestSession.dateISO).toLocaleDateString('it-IT', {
                  day: '2-digit',
                  month: 'short',
                })}
              </p>
              <p className="text-sm font-bold text-[#FFFFFF] truncate">{latestSession.dayTitle}</p>
            </div>
            <div className="text-right shrink-0 tabular-nums">
              <p className="font-mono text-sm font-bold text-[#38BDF8]">
                RPE {latestSession.avgRpe.toFixed(1)}
              </p>
              <p className="text-xs text-[#94A3B8]">{latestSession.exercises.length} esercizi</p>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-sm font-bold text-[#FFFFFF]">Coach AI Calisthenics</p>
              <p className="text-xs text-[#94A3B8]">
                Chatta liberamente sul tuo allenamento, sulla tecnica o su come ti senti oggi.
              </p>
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={() => {
            playTechClick();
            setVisionOpen(true);
          }}
          className="w-full min-h-[40px] px-3.5 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--accent)',
            color: 'var(--accent)',
          }}
        >
          <Crosshair className="w-4 h-4 shrink-0" />
          <span>Controlla la mia Forma (Foto) · Coach Vision</span>
        </button>
      </div>

      {/* Messages Feed */}
      <div className="flex-1 overflow-y-auto space-y-3 pr-1 pb-2">
        {messages.length === 0 && !loading && (
          <div className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-5 space-y-3">
            <div className="flex items-center gap-2 text-sm font-bold text-[#38BDF8]">
              <Sparkles className="w-4 h-4" />
              <span>Chatta con il tuo Personal Trainer AI</span>
            </div>
            <p className="text-sm text-[#CBD5E1] leading-relaxed">
              Scrivigli come su WhatsApp: salutalo, raccontagli com’è andato l’allenamento o chiedigli consigli su tecnica, scapole, polsi e gomiti.
            </p>
            {latestSession && (
              <button
                type="button"
                onClick={() => requestCoachResponse('checkin')}
                className="min-h-[42px] px-4 rounded-xl bg-[#131C31] border border-[#38BDF8]/40 text-xs font-bold text-[#38BDF8] hover:bg-[#1E293B] transition"
              >
                Chiedi un parere sull’ultima seduta
              </button>
            )}
          </div>
        )}

        {messages.map((msg, idx) => {
          const isCoach = msg.role === 'coach';
          const isErrorBubble = Boolean(msg.error);
          const isLatestError = isErrorBubble && idx === messages.length - 1;
          return (
            <div key={msg.id} className={`flex flex-col ${isCoach ? 'items-start' : 'items-end'}`}>
              <div
                role={isErrorBubble ? 'alert' : undefined}
                className={`max-w-[92%] sm:max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-line ${
                  isErrorBubble
                    ? 'bg-[#0B1D36] border border-[#00D2FF] text-[#FFFFFF]'
                    : isCoach
                    ? 'bg-[#0F172A] border border-[#1E293B] text-[#FFFFFF]'
                    : 'bg-[#2563EB] text-[#FFFFFF] font-semibold'
                }`}
              >
                {isErrorBubble ? (
                  <div className="flex items-start gap-2.5">
                    <AlertCircle className="w-4 h-4 text-[#00D2FF] shrink-0 mt-0.5" />
                    <div className="min-w-0 space-y-2.5">
                      <p className="break-words text-xs leading-relaxed text-[#CBD5E1]">
                        {msg.content}
                      </p>
                      {isLatestError && lastFailedPayload && !loading && (
                        <button
                          type="button"
                          onClick={() =>
                            requestCoachResponse(
                              lastFailedPayload.mode,
                              lastFailedPayload.userMessage
                            )
                          }
                          className="min-h-[38px] px-3.5 rounded-xl bg-[#2563EB] border border-[#38BDF8]/60 text-xs font-bold text-[#FFFFFF] inline-flex items-center gap-1.5 hover:bg-[#3B82F6] transition"
                        >
                          <RotateCcw className="w-3.5 h-3.5" />
                          <span>Riprova</span>
                        </button>
                      )}
                    </div>
                  </div>
                ) : (
                  msg.content
                )}
              </div>

              {/* Actionable Schedule Proposals (for any existing saved messages) */}
              {isCoach && !isErrorBubble && msg.proposals && msg.proposals.length > 0 && (
                <div className="mt-2 w-full max-w-[92%] sm:max-w-[82%] space-y-2">
                  {msg.proposals.map((prop) => {
                    const isApplied = msg.appliedProposalIds?.includes(prop.id);
                    const isJoint = prop.type === 'joint_swap';
                    return (
                      <div
                        key={prop.id}
                        className={`rounded-2xl p-3.5 border ${
                          isJoint
                            ? 'bg-[#0B1D36] border-[#00D2FF]/50'
                            : 'bg-[#132347] border-[#38BDF8]/40'
                        }`}
                      >
                        <div className="flex items-start gap-2.5">
                          {isJoint ? (
                            <ShieldAlert className="w-4 h-4 text-[#00D2FF] shrink-0 mt-0.5" />
                          ) : (
                            <TrendingUp className="w-4 h-4 text-[#38BDF8] shrink-0 mt-0.5" />
                          )}
                          <div className="min-w-0 flex-1">
                            <p className="text-xs font-extrabold text-[#FFFFFF]">{prop.title}</p>
                            <p className="text-xs text-[#94A3B8] mt-0.5 leading-relaxed">
                              {prop.description}
                            </p>
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={isApplied}
                          onClick={() => onApplyProposal(msg.id, prop)}
                          className={`mt-3 w-full min-h-[42px] rounded-xl text-xs font-extrabold flex items-center justify-center gap-1.5 transition ${
                            isApplied
                              ? 'bg-[#131C31] text-[#38BDF8] cursor-default'
                              : isJoint
                              ? 'bg-[#38BDF8] text-[#05070A] hover:bg-[#00D2FF]'
                              : 'bg-[#2563EB] text-[#FFFFFF] hover:bg-[#3B82F6]'
                          }`}
                        >
                          <Check className="w-4 h-4" />
                          <span>
                            {isApplied ? 'Scheda aggiornata' : 'Conferma e aggiorna la scheda'}
                          </span>
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}

        {loading && (
          <div className="flex items-center gap-2 text-xs text-[#94A3B8] px-2 py-2">
            <Loader2 className="w-4 h-4 animate-spin text-[#38BDF8]" />
            <span>Il Coach sta scrivendo...</span>
          </div>
        )}

        <div ref={bottomRef} />
      </div>

      {/* Free-form Conversational Input */}
      <form onSubmit={handleSend} className="pt-2 flex items-center gap-2 shrink-0">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Scrivi un messaggio al Coach (es. ciao!)..."
          className="flex-1 min-h-[48px] rounded-2xl bg-[#0F172A] border border-[#1E293B] px-4 text-sm text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
        />
        <button
          type="submit"
          disabled={!input.trim() || loading}
          aria-label="Invia messaggio al Coach"
          className="min-h-[48px] min-w-[48px] rounded-2xl bg-[#2563EB] text-[#FFFFFF] flex items-center justify-center disabled:opacity-40 hover:bg-[#3B82F6] active:scale-95 transition shrink-0"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>

      <CoachVisionModal
        isOpen={visionOpen}
        onSendPosturalAnalysisToCoach={(analysisText) => {
          handleSubmitPosturalAnalysis(analysisText);
        }}
        onClose={() => setVisionOpen(false)}
      />
    </div>
  );
};
