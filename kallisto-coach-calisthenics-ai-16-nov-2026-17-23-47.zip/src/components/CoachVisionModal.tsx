import React, { useMemo, useRef, useState } from 'react';
import { Camera, Crosshair, RotateCcw, Send, Sparkles, Upload, X } from 'lucide-react';
import { playTechClick } from '../utils/audio';

interface CoachVisionModalProps {
  isOpen: boolean;
  defaultSkillName?: string;
  onSendPosturalAnalysisToCoach: (analysisText: string) => void;
  onClose: () => void;
}

interface JointPin {
  id: 'shoulder' | 'hip' | 'ankle';
  label: string;
  x: number; // normalized 0..100
  y: number; // normalized 0..100
}

const DEFAULT_PINS: JointPin[] = [
  { id: 'shoulder', label: 'Spalla', x: 32, y: 38 },
  { id: 'hip', label: 'Bacino', x: 52, y: 44 },
  { id: 'ankle', label: 'Caviglia', x: 74, y: 50 },
];

const SKILL_OPTIONS = [
  'Planche / Tuck Planche',
  'Front Lever',
  'Handstand / Verticale',
  'Push-up / Plank',
  'Pull-up / Trazioni',
  'Dip alle Parallele',
  'L-Sit',
];

function computeAngleDeg(a: JointPin, b: JointPin, c: JointPin): number {
  const v1x = a.x - b.x;
  const v1y = a.y - b.y;
  const v2x = c.x - b.x;
  const v2y = c.y - b.y;
  const dot = v1x * v2x + v1y * v2y;
  const mag1 = Math.hypot(v1x, v1y);
  const mag2 = Math.hypot(v2x, v2y);
  if (mag1 < 0.001 || mag2 < 0.001) return 180;
  const cos = Math.max(-1, Math.min(1, dot / (mag1 * mag2)));
  return Math.round((Math.acos(cos) * 180) / Math.PI);
}

function computeLineTiltDeg(a: JointPin, c: JointPin): number {
  const dy = c.y - a.y;
  const dx = c.x - a.x;
  return Math.round((Math.atan2(dy, dx) * 180) / Math.PI);
}

export const CoachVisionModal: React.FC<CoachVisionModalProps> = ({
  isOpen,
  defaultSkillName,
  onSendPosturalAnalysisToCoach,
  onClose,
}) => {
  const [skillName, setSkillName] = useState<string>(defaultSkillName || SKILL_OPTIONS[0]);
  const [photoDataUrl, setPhotoDataUrl] = useState<string | null>(null);
  const [pins, setPins] = useState<JointPin[]>(DEFAULT_PINS);
  const [draggingId, setDraggingId] = useState<JointPin['id'] | null>(null);
  const [notes, setNotes] = useState('');

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);

  const metrics = useMemo(() => {
    const shoulder = pins[0];
    const hip = pins[1];
    const ankle = pins[2];
    const hipAngle = computeAngleDeg(shoulder, hip, ankle);
    const deviationFromStraight = Math.abs(180 - hipAngle);
    const bodyTiltDeg = Math.abs(computeLineTiltDeg(shoulder, ankle));
    const postureStatus =
      deviationFromStraight <= 10
        ? 'Linea corporea quasi perfettamente allineata!'
        : hip.y < (shoulder.y + ankle.y) / 2
        ? `Bacino leggermente alto (piking di ${deviationFromStraight}°)`
        : `Bacino leggermente caduto / inarcamento lombare (${deviationFromStraight}°)`;

    return {
      hipAngle,
      deviationFromStraight,
      bodyTiltDeg,
      postureStatus,
    };
  }, [pins]);

  if (!isOpen) return null;

  const handleLoadImage = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPhotoDataUrl(reader.result);
        setPins(DEFAULT_PINS);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const updatePinFromPointer = (clientX: number, clientY: number) => {
    if (!draggingId || !stageRef.current) return;
    const rect = stageRef.current.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;
    const nx = Math.max(4, Math.min(96, ((clientX - rect.left) / rect.width) * 100));
    const ny = Math.max(4, Math.min(96, ((clientY - rect.top) / rect.height) * 100));
    setPins((prev) => prev.map((p) => (p.id === draggingId ? { ...p, x: nx, y: ny } : p)));
  };

  const handleSendToCoach = () => {
    playTechClick();
    const prompt = [
      `📸 ANALISI POSTURALE COACH VISION — Skill/Esercizio: ${skillName}`,
      `• Angolo Spalla-Bacino-Caviglia misurato: ${metrics.hipAngle}° (scostamento dalla linea retta: ${metrics.deviationFromStraight}°).`,
      `• Inclinazione asse Spalla→Caviglia rispetto all'orizzontale: ${metrics.bodyTiltDeg}°.`,
      `• Rilevamento geometrico: ${metrics.postureStatus}.`,
      notes.trim() ? `• Sensazioni / Note atleta: "${notes.trim()}"` : '',
      `Dammi 2-3 correzioni tecniche mirate su scapole, retroversione del bacino (hollow) e compensi articolari in base a questi angoli.`,
    ]
      .filter(Boolean)
      .join('\n');

    onSendPosturalAnalysisToCoach(prompt);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] bg-[#05070A]/85 backdrop-blur-md flex items-end sm:items-center justify-center p-2.5 sm:p-4 overflow-y-auto">
      <div
        className="w-full max-w-xl rounded-3xl border p-4 sm:p-5 space-y-4 my-auto shadow-2xl"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--accent)',
          color: 'var(--text-main)',
        }}
      >
        {/* Header */}
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Crosshair className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
              <h2 className="text-base font-extrabold">Coach Vision · Controllo Posturale</h2>
            </div>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
              Carica o scatta una foto di profilo e trascina i punti su Spalla, Bacino e Caviglia.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Chiudi Coach Vision"
            className="min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center shrink-0"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-muted)',
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Skill Selector */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div>
            <label className="block text-[11px] font-bold mb-1" style={{ color: 'var(--text-muted)' }}>
              Skill o Esercizio da analizzare
            </label>
            <select
              value={skillName}
              onChange={(e) => setSkillName(e.target.value)}
              className="w-full min-h-[40px] px-3 rounded-xl border text-xs font-bold focus:outline-none"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--border-subtle)',
                color: 'var(--text-main)',
              }}
            >
              {SKILL_OPTIONS.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
              {defaultSkillName && !SKILL_OPTIONS.includes(defaultSkillName) && (
                <option value={defaultSkillName}>{defaultSkillName}</option>
              )}
            </select>
          </div>

          <div className="flex items-end gap-2">
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleLoadImage}
              className="hidden"
            />
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleLoadImage}
              className="hidden"
            />
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              className="flex-1 min-h-[40px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center justify-center gap-1.5"
              style={{
                backgroundColor: 'var(--primary)',
                borderColor: 'var(--accent)',
                color: '#FFFFFF',
              }}
            >
              <Camera className="w-4 h-4 shrink-0" />
              <span>Scatta Foto</span>
            </button>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 min-h-[40px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center justify-center gap-1.5"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--border-subtle)',
                color: 'var(--text-main)',
              }}
            >
              <Upload className="w-4 h-4 shrink-0" />
              <span>Carica</span>
            </button>
          </div>
        </div>

        {/* Interactive Postural Alignment Stage */}
        <div
          ref={stageRef}
          onPointerMove={(e) => updatePinFromPointer(e.clientX, e.clientY)}
          onPointerUp={() => setDraggingId(null)}
          onPointerLeave={() => setDraggingId(null)}
          className="relative w-full h-64 sm:h-72 rounded-2xl border overflow-hidden select-none touch-none flex items-center justify-center"
          style={{
            backgroundColor: '#05070A',
            borderColor: 'var(--border-subtle)',
          }}
        >
          {photoDataUrl ? (
            <img
              src={photoDataUrl}
              alt="Anteprima esercizio per analisi posturale"
              className="w-full h-full object-contain pointer-events-none"
            />
          ) : (
            <div className="text-center px-6 space-y-2 pointer-events-none">
              <Sparkles className="w-8 h-8 mx-auto" style={{ color: 'var(--accent)' }} />
              <p className="text-xs font-bold text-[#FFFFFF]">
                Carica una foto laterale per tracciare la linea Spalle – Bacino – Caviglie
              </p>
              <p className="text-[11px] text-[#94A3B8]">
                Puoi comunque trascinare i 3 punti guida qui sopra per simulare l&apos;angolo.
              </p>
            </div>
          )}

          {/* Geometric Alignment SVG Lines */}
          <svg
            viewBox="0 0 100 100"
            preserveAspectRatio="none"
            className="absolute inset-0 w-full h-full pointer-events-none"
          >
            {/* Ideal Straight Reference Line Shoulder -> Ankle */}
            <line
              x1={pins[0].x}
              y1={pins[0].y}
              x2={pins[2].x}
              y2={pins[2].y}
              stroke="#94A3B8"
              strokeWidth="0.6"
              strokeDasharray="2 2"
            />
            {/* Measured Segment Shoulder -> Hip -> Ankle */}
            <polyline
              points={`${pins[0].x},${pins[0].y} ${pins[1].x},${pins[1].y} ${pins[2].x},${pins[2].y}`}
              fill="none"
              style={{ stroke: 'var(--accent)' }}
              strokeWidth="1.2"
            />
          </svg>

          {/* Draggable Landmark Handles */}
          {pins.map((pin) => (
            <button
              key={pin.id}
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                (e.currentTarget as HTMLElement).releasePointerCapture?.(e.pointerId);
                setDraggingId(pin.id);
              }}
              aria-label={`Sposta punto ${pin.label}`}
              className="absolute -translate-x-1/2 -translate-y-1/2 w-8 h-8 rounded-full border-2 flex items-center justify-center shadow-lg cursor-grab active:cursor-grabbing"
              style={{
                left: `${pin.x}%`,
                top: `${pin.y}%`,
                backgroundColor: draggingId === pin.id ? 'var(--accent)' : 'var(--primary)',
                borderColor: '#FFFFFF',
              }}
            >
              <span className="w-2 h-2 rounded-full bg-white" />
              <span
                className="absolute -bottom-5 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded bg-[#05070A]/90 text-[10px] font-extrabold text-[#FFFFFF] whitespace-nowrap pointer-events-none"
              >
                {pin.label}
              </span>
            </button>
          ))}
        </div>

        {/* Live Geometric Angles Strip */}
        <div
          className="rounded-2xl border p-3 flex flex-wrap items-center justify-between gap-2 text-xs"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div className="space-y-0.5 min-w-0">
            <p className="font-extrabold" style={{ color: 'var(--accent)' }}>
              {metrics.postureStatus}
            </p>
            <p className="text-[11px] font-mono tabular-nums" style={{ color: 'var(--text-secondary)' }}>
              Angolo Bacino: {metrics.hipAngle}° · Inclinazione Asse: {metrics.bodyTiltDeg}°
            </p>
          </div>
          <button
            type="button"
            onClick={() => setPins(DEFAULT_PINS)}
            className="min-h-[34px] px-2.5 rounded-xl border text-[11px] font-bold inline-flex items-center gap-1 shrink-0"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-muted)',
            }}
          >
            <RotateCcw className="w-3 h-3" />
            <span>Reset punti</span>
          </button>
        </div>

        {/* Optional Athlete Notes + Send to Coach AI */}
        <input
          type="text"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Nota opzionale (es. sento tirare i polsi o perdo la hollow)..."
          className="w-full min-h-[42px] rounded-xl border px-3 text-xs focus:outline-none"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        />

        <button
          type="button"
          onClick={handleSendToCoach}
          className="w-full min-h-[48px] rounded-2xl font-extrabold text-sm flex items-center justify-center gap-2 transition"
          style={{
            backgroundColor: 'var(--accent)',
            color: '#05070A',
          }}
        >
          <Send className="w-4 h-4" />
          <span>Invia Analisi &amp; Angoli al Coach AI</span>
        </button>
      </div>
    </div>
  );
};
