import React, { useEffect, useRef, useState } from 'react';
import { Brain, Check, FastForward, Zap } from 'lucide-react';
import { playDoubleDing, playTickBeep, warmUpAudio } from '../utils/audio';

interface CognitiveWarmupModalProps {
  isOpen: boolean;
  onStartWorkout: () => void;
  onClose: () => void;
}

const TOTAL_TARGETS = 5;

function pickNextCell(prev: number): number {
  let next = Math.floor(Math.random() * 9);
  if (next === prev) {
    next = (next + 1 + Math.floor(Math.random() * 7)) % 9;
  }
  return next;
}

export const CognitiveWarmupModal: React.FC<CognitiveWarmupModalProps> = ({
  isOpen,
  onStartWorkout,
  onClose,
}) => {
  const [mode, setMode] = useState<'reflex' | 'math'>('reflex');
  const [hits, setHits] = useState(0);
  const [activeCell, setActiveCell] = useState(4);
  const [reactionTimes, setReactionTimes] = useState<number[]>([]);
  const [completed, setCompleted] = useState(false);

  // Math quick-calc mode state
  const [mathIdx, setMathIdx] = useState(0);
  const [mathQuestion, setMathQuestion] = useState<{ a: number; b: number; options: number[] }>({
    a: 7,
    b: 8,
    options: [13, 15, 16, 14],
  });

  const targetSpawnMsRef = useRef<number>(Date.now());
  const autoStartTimerRef = useRef<number | null>(null);

  const generateMathQuestion = () => {
    const a = 4 + Math.floor(Math.random() * 14);
    const b = 3 + Math.floor(Math.random() * 12);
    const ans = a + b;
    const wrongSet = new Set<number>([ans]);
    while (wrongSet.size < 4) {
      const delta = (Math.random() > 0.5 ? 1 : -1) * (1 + Math.floor(Math.random() * 4));
      if (ans + delta > 0) wrongSet.add(ans + delta);
    }
    const options = Array.from(wrongSet).sort(() => Math.random() - 0.5);
    setMathQuestion({ a, b, options });
    targetSpawnMsRef.current = Date.now();
  };

  useEffect(() => {
    if (!isOpen) {
      if (autoStartTimerRef.current !== null) {
        window.clearTimeout(autoStartTimerRef.current);
        autoStartTimerRef.current = null;
      }
      return;
    }

    setHits(0);
    setMathIdx(0);
    setReactionTimes([]);
    setCompleted(false);
    setActiveCell(Math.floor(Math.random() * 9));
    generateMathQuestion();
    targetSpawnMsRef.current = Date.now();

    return () => {
      if (autoStartTimerRef.current !== null) {
        window.clearTimeout(autoStartTimerRef.current);
        autoStartTimerRef.current = null;
      }
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const finishActivation = (allTimes: number[]) => {
    setReactionTimes(allTimes);
    setCompleted(true);
    playDoubleDing();
    autoStartTimerRef.current = window.setTimeout(() => {
      onStartWorkout();
    }, 1250);
  };

  const handleCellTap = (cellIdx: number) => {
    if (completed || cellIdx !== activeCell) return;
    warmUpAudio();
    playTickBeep(true);

    const rt = Math.max(80, Date.now() - targetSpawnMsRef.current);
    const nextTimes = [...reactionTimes, rt];
    const nextHits = hits + 1;

    setReactionTimes(nextTimes);
    setHits(nextHits);

    if (nextHits >= TOTAL_TARGETS) {
      finishActivation(nextTimes);
    } else {
      setActiveCell((prev) => pickNextCell(prev));
      targetSpawnMsRef.current = Date.now();
    }
  };

  const handleMathTap = (val: number) => {
    if (completed) return;
    if (val !== mathQuestion.a + mathQuestion.b) return;
    warmUpAudio();
    playTickBeep(true);

    const rt = Math.max(120, Date.now() - targetSpawnMsRef.current);
    const nextTimes = [...reactionTimes, rt];
    const nextIdx = mathIdx + 1;
    setReactionTimes(nextTimes);
    setMathIdx(nextIdx);

    if (nextIdx >= 3) {
      finishActivation(nextTimes);
    } else {
      generateMathQuestion();
    }
  };

  const avgMs =
    reactionTimes.length > 0
      ? Math.round(reactionTimes.reduce((acc, v) => acc + v, 0) / reactionTimes.length)
      : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070A]/90 backdrop-blur-md p-4">
      <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-[#2563EB]/70 p-5 shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-[#0B1D36] border border-[#00D2FF]/60 flex items-center justify-center shrink-0">
              <Brain className="w-5 h-5 text-[#00D2FF]" />
            </div>
            <div className="min-w-0">
              <p className="text-[11px] font-bold text-[#38BDF8]">
                Attivazione Cerebrale · 10s
              </p>
              <h3 className="text-base font-extrabold text-[#FFFFFF] truncate">
                Focus &amp; Riflessi Pre-Workout
              </h3>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              warmUpAudio();
              onStartWorkout();
            }}
            className="min-h-[38px] px-3 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#CBD5E1] hover:text-[#FFFFFF] inline-flex items-center gap-1 shrink-0 transition"
          >
            <FastForward className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>Salta</span>
          </button>
        </div>

        {/* Mode Switch */}
        {!completed && (
          <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-[#090D16] border border-[#1E293B]">
            <button
              type="button"
              onClick={() => {
                setMode('reflex');
                setHits(0);
                setReactionTimes([]);
                targetSpawnMsRef.current = Date.now();
              }}
              className={`min-h-[36px] rounded-lg text-xs font-bold transition ${
                mode === 'reflex'
                  ? 'bg-[#2563EB] text-[#FFFFFF]'
                  : 'text-[#94A3B8] hover:text-[#FFFFFF]'
              }`}
            >
              Riflessi Rapidi
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('math');
                setMathIdx(0);
                setReactionTimes([]);
                generateMathQuestion();
              }}
              className={`min-h-[36px] rounded-lg text-xs font-bold transition ${
                mode === 'math'
                  ? 'bg-[#38BDF8] text-[#05070A]'
                  : 'text-[#94A3B8] hover:text-[#FFFFFF]'
              }`}
            >
              3 Calcoli Veloci
            </button>
          </div>
        )}

        {completed ? (
          <div className="rounded-2xl bg-[#0B1D36] border border-[#00D2FF] p-6 text-center space-y-3">
            <div className="w-12 h-12 rounded-2xl bg-[#00D2FF] text-[#05070A] flex items-center justify-center mx-auto">
              <Check className="w-6 h-6 stroke-[3]" />
            </div>
            <div>
              <p className="text-xs font-bold text-[#38BDF8]">Sistema Nervoso Attivo</p>
              <p className="font-mono text-3xl font-extrabold text-[#FFFFFF] mt-1 tabular-nums">
                {avgMs} ms
              </p>
              <p className="text-xs text-[#CBD5E1] mt-1">
                Tempo medio di reazione · Avvio cronometro...
              </p>
            </div>
            <button
              type="button"
              onClick={onStartWorkout}
              className="w-full min-h-[44px] rounded-xl bg-[#2563EB] text-sm font-extrabold text-[#FFFFFF]"
            >
              Parti Subito
            </button>
          </div>
        ) : mode === 'reflex' ? (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-[#94A3B8] tabular-nums">
              <span>Tocca i bersagli azzurri appena si illuminano</span>
              <span className="font-mono font-bold text-[#00D2FF]">
                {hits} / {TOTAL_TARGETS}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2.5 p-3 rounded-2xl bg-[#090D16] border border-[#1E293B]">
              {Array.from({ length: 9 }).map((_, idx) => {
                const isTarget = idx === activeCell;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleCellTap(idx)}
                    aria-label={isTarget ? 'Bersaglio attivo' : 'Cella inattiva'}
                    className={`h-20 rounded-2xl border flex items-center justify-center transition active:scale-95 ${
                      isTarget
                        ? 'bg-[#00D2FF] border-[#7DD3FC] text-[#05070A] shadow-[0_0_20px_rgba(0,210,255,0.45)]'
                        : 'bg-[#131C31] border-[#1E293B] text-[#64748B]'
                    }`}
                  >
                    {isTarget ? <Zap className="w-7 h-7 fill-current" /> : <span className="w-2 h-2 rounded-full bg-[#1E293B]" />}
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between text-xs text-[#94A3B8] tabular-nums">
              <span>Risolvi 3 somme al volo</span>
              <span className="font-mono font-bold text-[#00D2FF]">
                {mathIdx + 1} / 3
              </span>
            </div>

            <div className="rounded-2xl bg-[#090D16] border border-[#1E293B] p-5 text-center space-y-4">
              <p className="font-mono text-4xl font-extrabold text-[#FFFFFF] tabular-nums">
                {mathQuestion.a} + {mathQuestion.b} = ?
              </p>
              <div className="grid grid-cols-2 gap-2.5">
                {mathQuestion.options.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => handleMathTap(opt)}
                    className="min-h-[50px] rounded-xl bg-[#131C31] border border-[#38BDF8]/40 font-mono text-lg font-extrabold text-[#FFFFFF] hover:bg-[#2563EB] active:scale-95 transition tabular-nums"
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <button
          type="button"
          onClick={onClose}
          className="w-full text-center text-xs font-semibold text-[#64748B] hover:text-[#CBD5E1] transition"
        >
          Chiudi senza avviare
        </button>
      </div>
    </div>
  );
};
