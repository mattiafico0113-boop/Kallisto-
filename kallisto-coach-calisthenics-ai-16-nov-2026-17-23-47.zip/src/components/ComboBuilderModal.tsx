import React, { useEffect, useState } from 'react';
import {
  ArrowRight,
  Check,
  Flame,
  Play,
  Plus,
  RotateCcw,
  Trash2,
  X,
} from 'lucide-react';
import { EXERCISE_CATALOG } from '../data/exercises';
import type { ComboFlowPreset, ComboFlowStep } from '../types/calisthenics';
import { playLevelUpFanfare, playSetCompleteTone, playTechClick } from '../utils/audio';
import { speakItalian } from '../utils/voiceCoach';

interface ComboBuilderModalProps {
  isOpen: boolean;
  savedCombos: ComboFlowPreset[];
  onSaveCombo: (combo: ComboFlowPreset) => void;
  onUpdateComboRecord: (comboId: string, durationSec: number) => void;
  onDeleteCombo: (comboId: string) => void;
  onClose: () => void;
}

const DEFAULT_STARTER_STEPS: ComboFlowStep[] = [
  { id: 'st_1', exerciseId: 'muscle_up', name: 'Muscle-up (o Propedeutica)', isIsometric: false, targetValue: 1 },
  { id: 'st_2', exerciseId: 'parallel_dips', name: 'Dip alle Parallele', isIsometric: false, targetValue: 5 },
  { id: 'st_3', exerciseId: 'l_sit', name: 'L-Sit', isIsometric: true, targetValue: 10 },
];

export const ComboBuilderModal: React.FC<ComboBuilderModalProps> = ({
  isOpen,
  savedCombos,
  onSaveCombo,
  onUpdateComboRecord,
  onDeleteCombo,
  onClose,
}) => {
  const [comboName, setComboName] = useState('Flow Sbarra & Core');
  const [steps, setSteps] = useState<ComboFlowStep[]>(DEFAULT_STARTER_STEPS);
  const [selectedExId, setSelectedExId] = useState(EXERCISE_CATALOG[0]?.id ?? 'pullups');
  const [stepTarget, setStepTarget] = useState(5);

  // Live Flow Execution Stopwatch
  const [runningCombo, setRunningCombo] = useState<ComboFlowPreset | null>(null);
  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const [elapsedMs, setElapsedMs] = useState(0);
  const [flowRunning, setFlowRunning] = useState(false);
  const [flowFinishedSec, setFlowFinishedSec] = useState<number | null>(null);

  useEffect(() => {
    if (!isOpen || !flowRunning) return;
    let last = performance.now();
    const id = window.setInterval(() => {
      const now = performance.now();
      const dt = now - last;
      last = now;
      setElapsedMs((p) => p + dt);
    }, 100);
    return () => window.clearInterval(id);
  }, [isOpen, flowRunning]);

  if (!isOpen) return null;

  const handleAddStep = () => {
    if (steps.length >= 5) return;
    const def = EXERCISE_CATALOG.find((e) => e.id === selectedExId);
    if (!def) return;
    playTechClick();
    setSteps((prev) => [
      ...prev,
      {
        id: `cstep_${Date.now()}_${Math.random().toString(36).slice(2, 5)}`,
        exerciseId: def.id,
        name: def.name,
        isIsometric: def.type === 'isometric',
        targetValue: Math.max(1, stepTarget),
      },
    ]);
  };

  const handleSaveAndRun = () => {
    if (steps.length < 2) return;
    const cleanName = comboName.trim() || 'Combo Freestyle';
    const created: ComboFlowPreset = {
      id: `combo_${Date.now()}`,
      name: cleanName,
      steps,
      bestDurationSeconds: null,
      createdAtISO: new Date().toISOString(),
    };
    playSetCompleteTone();
    onSaveCombo(created);
    startFlowExecution(created);
  };

  const startFlowExecution = (combo: ComboFlowPreset) => {
    setRunningCombo(combo);
    setActiveStepIndex(0);
    setElapsedMs(0);
    setFlowFinishedSec(null);
    setFlowRunning(true);
    const first = combo.steps[0];
    if (first) {
      speakItalian(`Via Combo ${combo.name}. Primo passo: ${first.targetValue} ${first.isIsometric ? 'secondi di' : ''} ${first.name}`, {
        rate: 1.05,
      });
    }
  };

  const handleNextFlowStep = () => {
    if (!runningCombo) return;
    if (activeStepIndex < runningCombo.steps.length - 1) {
      playSetCompleteTone();
      const nextIdx = activeStepIndex + 1;
      setActiveStepIndex(nextIdx);
      const st = runningCombo.steps[nextIdx];
      if (st) {
        speakItalian(`Prossimo: ${st.targetValue} ${st.isIsometric ? 'secondi di' : ''} ${st.name}`, {
          rate: 1.08,
        });
      }
    } else {
      setFlowRunning(false);
      const totalSec = Math.max(1, Math.round(elapsedMs / 100) / 10);
      setFlowFinishedSec(totalSec);
      playLevelUpFanfare();
      onUpdateComboRecord(runningCombo.id, totalSec);
      speakItalian(`Combo completata in ${Math.round(totalSec)} secondi!`, { rate: 1.0 });
    }
  };

  const formatFlowTime = (ms: number) => {
    const s = Math.floor(ms / 1000);
    const tenths = Math.floor((ms % 1000) / 100);
    const m = Math.floor(s / 60);
    const remS = s % 60;
    return `${String(m).padStart(2, '0')}:${String(remS).padStart(2, '0')}.${tenths}`;
  };

  return (
    <div className="fixed inset-0 z-[70] bg-[#05070A]/88 backdrop-blur-md flex items-end sm:items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div
        className="w-full max-w-xl rounded-3xl border p-4 sm:p-5 space-y-4 my-auto shadow-2xl"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--accent)',
          color: 'var(--text-main)',
        }}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Flame className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
              <h2 className="text-base font-extrabold">Combo Builder · Flow a Catena</h2>
            </div>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
              Concatena 3–5 esercizi di fila senza scendere dall&apos;attrezzo e cronometra il Flow.
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              setFlowRunning(false);
              setRunningCombo(null);
              onClose();
            }}
            aria-label="Chiudi Combo Builder"
            className="min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center shrink-0"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-muted)',
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {runningCombo ? (
          <div className="space-y-4">
            <div
              className="rounded-2xl border p-5 text-center space-y-3"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--accent)',
              }}
            >
              <p className="text-xs font-extrabold uppercase tracking-wider" style={{ color: 'var(--accent)' }}>
                {runningCombo.name}
              </p>
              <p className="font-mono text-5xl font-black tabular-nums">
                {flowFinishedSec !== null ? `${flowFinishedSec.toFixed(1)}s` : formatFlowTime(elapsedMs)}
              </p>

              {/* Step Chain Pills */}
              <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
                {runningCombo.steps.map((st, idx) => {
                  const done = flowFinishedSec !== null || idx < activeStepIndex;
                  const active = flowFinishedSec === null && idx === activeStepIndex;
                  return (
                    <React.Fragment key={st.id}>
                      <span
                        className="px-2.5 py-1 rounded-xl border text-xs font-extrabold"
                        style={{
                          backgroundColor: active
                            ? 'var(--accent)'
                            : done
                            ? 'var(--primary)'
                            : 'var(--bg-card)',
                          borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                          color: active ? '#05070A' : done ? '#FFFFFF' : 'var(--text-muted)',
                        }}
                      >
                        {st.targetValue}
                        {st.isIsometric ? 's' : '×'} {st.name}
                      </span>
                      {idx < runningCombo.steps.length - 1 && (
                        <ArrowRight className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--text-muted)' }} />
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>

            {flowFinishedSec !== null ? (
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => startFlowExecution(runningCombo)}
                  className="min-h-[48px] rounded-xl font-extrabold text-xs sm:text-sm inline-flex items-center justify-center gap-1.5"
                  style={{
                    backgroundColor: 'var(--accent)',
                    color: '#05070A',
                  }}
                >
                  <RotateCcw className="w-4 h-4" />
                  <span>Ripeti Combo</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setFlowRunning(false);
                    setRunningCombo(null);
                  }}
                  className="min-h-[48px] rounded-xl border font-extrabold text-xs sm:text-sm"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-main)',
                  }}
                >
                  Torna al Builder
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    setFlowRunning(false);
                    setRunningCombo(null);
                  }}
                  className="min-h-[50px] rounded-xl border font-bold text-xs sm:text-sm"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-muted)',
                  }}
                >
                  Annulla
                </button>
                <button
                  type="button"
                  onClick={handleNextFlowStep}
                  className="min-h-[50px] rounded-xl font-black text-sm inline-flex items-center justify-center gap-1.5"
                  style={{
                    backgroundColor: 'var(--accent)',
                    color: '#05070A',
                  }}
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>
                    {activeStepIndex < runningCombo.steps.length - 1
                      ? 'Prossimo Passo →'
                      : 'Fine Combo!'}
                  </span>
                </button>
              </div>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {/* Saved Combos quick launch */}
            {savedCombos.length > 0 && (
              <div className="space-y-1.5">
                <p className="text-[11px] font-extrabold uppercase tracking-wider" style={{ color: 'var(--accent)' }}>
                  Le tue Combo Salvate
                </p>
                <div className="space-y-1.5 max-h-36 overflow-y-auto pr-0.5">
                  {savedCombos.map((c) => (
                    <div
                      key={c.id}
                      className="rounded-xl border p-2.5 flex items-center justify-between gap-2"
                      style={{
                        backgroundColor: 'var(--bg-elevated)',
                        borderColor: 'var(--border-subtle)',
                      }}
                    >
                      <div className="min-w-0">
                        <p className="text-xs font-extrabold truncate">{c.name}</p>
                        <p className="text-[11px] truncate" style={{ color: 'var(--text-muted)' }}>
                          {c.steps.map((s) => `${s.targetValue}${s.isIsometric ? 's' : '×'} ${s.name}`).join(' → ')}
                        </p>
                        {typeof c.bestDurationSeconds === 'number' && (
                          <p className="text-[10px] font-mono font-bold mt-0.5" style={{ color: 'var(--accent)' }}>
                            Miglior tempo: {c.bestDurationSeconds.toFixed(1)}s
                          </p>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() => startFlowExecution(c)}
                          className="min-h-[34px] px-3 rounded-lg font-extrabold text-xs inline-flex items-center gap-1"
                          style={{
                            backgroundColor: 'var(--primary)',
                            color: '#FFFFFF',
                          }}
                        >
                          <Play className="w-3 h-3 fill-current" />
                          <span>Avvia</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteCombo(c.id)}
                          aria-label={`Elimina combo ${c.name}`}
                          className="min-h-[34px] min-w-[34px] rounded-lg border flex items-center justify-center"
                          style={{
                            backgroundColor: 'var(--bg-card)',
                            borderColor: 'var(--border-subtle)',
                            color: 'var(--text-muted)',
                          }}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* New Combo Builder */}
            <div className="space-y-2.5">
              <div>
                <label className="block text-[11px] font-bold mb-1" style={{ color: 'var(--text-muted)' }}>
                  Nome della Combo Flow
                </label>
                <input
                  type="text"
                  value={comboName}
                  onChange={(e) => setComboName(e.target.value)}
                  className="w-full min-h-[40px] rounded-xl border px-3 text-xs font-bold focus:outline-none"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-main)',
                  }}
                />
              </div>

              {/* Chain Preview */}
              <div className="space-y-1.5">
                <p className="text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
                  Sequenza attuale ({steps.length}/5 anelli):
                </p>
                <div className="space-y-1.5">
                  {steps.map((st, idx) => (
                    <div
                      key={st.id}
                      className="rounded-xl border px-3 py-2 flex items-center justify-between gap-2 text-xs"
                      style={{
                        backgroundColor: 'var(--bg-elevated)',
                        borderColor: 'var(--border-subtle)',
                      }}
                    >
                      <span className="font-bold truncate">
                        {idx + 1}. {st.name} —{' '}
                        <strong style={{ color: 'var(--accent)' }}>
                          {st.targetValue}
                          {st.isIsometric ? ' sec' : ' rep'}
                        </strong>
                      </span>
                      <button
                        type="button"
                        onClick={() => setSteps((prev) => prev.filter((s) => s.id !== st.id))}
                        aria-label={`Rimuovi ${st.name}`}
                        style={{ color: 'var(--text-muted)' }}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Add Step Row */}
              {steps.length < 5 && (
                <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                  <select
                    value={selectedExId}
                    onChange={(e) => setSelectedExId(e.target.value)}
                    className="flex-1 min-h-[40px] rounded-xl border px-2.5 text-xs font-semibold focus:outline-none"
                    style={{
                      backgroundColor: 'var(--bg-elevated)',
                      borderColor: 'var(--border-subtle)',
                      color: 'var(--text-main)',
                    }}
                  >
                    {EXERCISE_CATALOG.map((ex) => (
                      <option key={ex.id} value={ex.id}>
                        {ex.name} ({ex.type === 'isometric' ? 'sec' : 'rep'})
                      </option>
                    ))}
                  </select>

                  <input
                    type="number"
                    min={1}
                    max={90}
                    value={stepTarget}
                    onChange={(e) => setStepTarget(Math.max(1, Number(e.target.value) || 1))}
                    aria-label="Ripetizioni o secondi anello combo"
                    className="w-16 min-h-[40px] rounded-xl border px-2 text-center font-mono text-xs font-bold focus:outline-none"
                    style={{
                      backgroundColor: 'var(--bg-elevated)',
                      borderColor: 'var(--border-subtle)',
                      color: 'var(--text-main)',
                    }}
                  />

                  <button
                    type="button"
                    onClick={handleAddStep}
                    className="min-h-[40px] px-3 rounded-xl font-extrabold text-xs inline-flex items-center gap-1 shrink-0"
                    style={{
                      backgroundColor: 'var(--primary)',
                      color: '#FFFFFF',
                    }}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Aggiungi</span>
                  </button>
                </div>
              )}
            </div>

            <button
              type="button"
              disabled={steps.length < 2}
              onClick={handleSaveAndRun}
              className="w-full min-h-[48px] rounded-2xl font-black text-sm flex items-center justify-center gap-2 disabled:opacity-45 transition"
              style={{
                backgroundColor: 'var(--accent)',
                color: '#05070A',
              }}
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Salva &amp; Cronometra Combo Flow</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
