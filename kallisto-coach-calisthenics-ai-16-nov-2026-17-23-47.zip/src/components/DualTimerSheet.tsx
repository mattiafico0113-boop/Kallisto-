import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Check,
  Maximize2,
  Minimize2,
  Pause,
  Play,
  RotateCcw,
  Timer,
  TrendingDown,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import type { ActiveTimerState } from '../types/calisthenics';
import { playTickBeep, playTimerCompleteChime } from '../utils/audio';
import { speakItalian, stopSpeaking } from '../utils/voiceCoach';

interface DualTimerSheetProps {
  timerState: ActiveTimerState | null;
  onClose: () => void;
  onSwitchMode: (mode: 'rest' | 'isometric' | 'negative' | 'transition') => void;
  onApplyIsometricSeconds?: (exerciseInstanceId: string, setId: string, seconds: number) => void;
  onApplyNegativeReps?: (exerciseInstanceId: string, setId: string, reps: number) => void;
  onChangeTransitionDefault?: (seconds: number) => void;
}

export const DualTimerSheet: React.FC<DualTimerSheetProps> = ({
  timerState,
  onClose,
  onSwitchMode,
  onApplyIsometricSeconds,
  onApplyNegativeReps,
  onChangeTransitionDefault,
}) => {
  const mode = timerState?.mode ?? 'rest';
  const target = timerState?.targetSeconds ?? (mode === 'rest' ? 90 : 15);
  const initialNegSec = timerState?.negativeSeconds ?? 5;
  const targetReps = timerState?.targetReps ?? 5;

  const [voiceOn, setVoiceOn] = useState<boolean>(timerState?.voiceEnabled ?? true);
  const [semaforoOpen, setSemaforoOpen] = useState<boolean>(false);

  // Rest timer state (counts down)
  const [restRemaining, setRestRemaining] = useState(target);
  const [restTotal, setRestTotal] = useState(target);
  const [restRunning, setRestRunning] = useState(false);

  // Isometric timer state (3s prep -> holding)
  const [isoPhase, setIsoPhase] = useState<'idle' | 'prep' | 'holding'>('idle');
  const [prepLeft, setPrepLeft] = useState(3);
  const [isoElapsed, setIsoElapsed] = useState(0);
  const [isoTargetReached, setIsoTargetReached] = useState(false);

  // Negative eccentric timer state
  const [descentSeconds, setDescentSeconds] = useState(initialNegSec);
  const [negPhase, setNegPhase] = useState<'idle' | 'prep' | 'descent' | 'up'>('idle');
  const [negCountdown, setNegCountdown] = useState<number | 'scendi'>(initialNegSec);
  const [negPrepLeft, setNegPrepLeft] = useState(2);
  const [negUpLeft, setNegUpLeft] = useState(2);
  const [negRepsDone, setNegRepsDone] = useState(0);

  const chimePlayedRef = useRef(false);
  const lastActionNonceRef = useRef<number>(0);

  const startIsometricFlow = useCallback(
    (withVoice: boolean) => {
      setIsoElapsed(0);
      setIsoTargetReached(false);
      setPrepLeft(3);
      setIsoPhase('prep');
      if (withVoice) {
        speakItalian('Preparati', { rate: 1.05 });
      } else {
        playTickBeep(false);
      }
    },
    []
  );

  const startNegativeFlow = useCallback(
    (withVoice: boolean, sec: number) => {
      setNegRepsDone(0);
      setNegPrepLeft(2);
      setNegCountdown(sec);
      setNegPhase('prep');
      if (withVoice) {
        speakItalian('Preparati per la negativa', { rate: 1.05 });
      } else {
        playTickBeep(false);
      }
    },
    []
  );

  useEffect(() => {
    if (!timerState) {
      stopSpeaking();
      setSemaforoOpen(false);
      return;
    }
    const nextVoice = timerState.voiceEnabled ?? true;
    setVoiceOn(nextVoice);

    if (timerState.mode === 'rest' || timerState.mode === 'transition') {
      setIsoPhase('idle');
      setNegPhase('idle');
      setRestTotal(timerState.targetSeconds);
      setRestRemaining(timerState.targetSeconds);
      setRestRunning(true);
      chimePlayedRef.current = false;
    } else if (timerState.mode === 'isometric') {
      setRestRunning(false);
      setNegPhase('idle');
      if (timerState.autoStart) {
        startIsometricFlow(nextVoice);
      } else {
        setIsoPhase('idle');
        setPrepLeft(3);
        setIsoElapsed(0);
        setIsoTargetReached(false);
      }
    } else {
      setRestRunning(false);
      setIsoPhase('idle');
      const sec = timerState.negativeSeconds ?? 5;
      setDescentSeconds(sec);
      setNegCountdown(sec);
      setNegRepsDone(0);
      if (timerState.autoStart) {
        startNegativeFlow(nextVoice, sec);
      } else {
        setNegPhase('idle');
      }
    }
  }, [timerState, startIsometricFlow, startNegativeFlow]);

  // Handle external Voice Commands ("Via"/"Start" and "Stop"/"Pausa")
  useEffect(() => {
    const ext = timerState?.externalAction;
    if (!ext || ext.nonce === lastActionNonceRef.current) return;
    lastActionNonceRef.current = ext.nonce;

    if (ext.type === 'stop') {
      stopSpeaking();
      if (mode === 'rest' || mode === 'transition') setRestRunning(false);
      if (mode === 'isometric') setIsoPhase('idle');
      if (mode === 'negative') setNegPhase('idle');
    } else if (ext.type === 'start') {
      if (mode === 'rest' || mode === 'transition') {
        if (restRemaining === 0) {
          setRestRemaining(restTotal);
          chimePlayedRef.current = false;
        }
        setRestRunning(true);
      } else if (mode === 'isometric') {
        if (isoPhase === 'idle') {
          startIsometricFlow(voiceOn);
        }
      } else if (mode === 'negative') {
        if (negPhase === 'idle') {
          startNegativeFlow(voiceOn, descentSeconds);
        }
      }
    }
  }, [
    timerState?.externalAction,
    mode,
    restRemaining,
    restTotal,
    isoPhase,
    negPhase,
    voiceOn,
    descentSeconds,
    startIsometricFlow,
    startNegativeFlow,
  ]);

  // Cleanup speech on unmount
  useEffect(() => {
    return () => {
      stopSpeaking();
    };
  }, []);

  // Rest countdown interval
  const handsFreeVoice = Boolean(timerState?.handsFreeVoice);
  useEffect(() => {
    if (!restRunning) return;
    const id = window.setInterval(() => {
      setRestRemaining((prev) => {
        if (prev <= 1) {
          setRestRunning(false);
          if (!chimePlayedRef.current) {
            chimePlayedRef.current = true;
            playTimerCompleteChime();
            if (handsFreeVoice) {
              speakItalian('Tocca a te!', { rate: 1.05 });
            } else if (voiceOn) {
              speakItalian(
                mode === 'transition'
                  ? 'Cambio esercizio finito, si parte!'
                  : 'Recupero finito, si riparte!',
                { rate: 1.0 }
              );
            }
          }
          return 0;
        }
        if (prev <= 4) {
          playTickBeep(false);
          if (handsFreeVoice) {
            speakItalian(String(prev - 1), { rate: 1.15 });
          }
        }
        return prev - 1;
      });
    }, 1000);
    return () => window.clearInterval(id);
  }, [restRunning, voiceOn, handsFreeVoice, mode]);

  // Isometric prep & spoken countdown interval
  useEffect(() => {
    if (isoPhase === 'idle') return;
    const id = window.setInterval(() => {
      if (isoPhase === 'prep') {
        setPrepLeft((prev) => {
          if (prev <= 1) {
            playTickBeep(true);
            setIsoPhase('holding');
            if (voiceOn) {
              speakItalian(String(target), { rate: 1.1 });
            }
            return 0;
          }
          playTickBeep(false);
          return prev - 1;
        });
      } else if (isoPhase === 'holding') {
        setIsoElapsed((prev) => {
          const next = prev + 1;
          const remaining = target - next;

          if (remaining > 0) {
            if (voiceOn) {
              speakItalian(String(remaining), { rate: 1.1 });
            }
          } else if (remaining === 0 && !isoTargetReached) {
            setIsoTargetReached(true);
            playTimerCompleteChime();
            if (voiceOn) {
              speakItalian('Fine!', { rate: 1.0 });
            }
          }
          return next;
        });
      }
    }, 1000);
    return () => window.clearInterval(id);
  }, [isoPhase, target, isoTargetReached, voiceOn]);

  // Negative (eccentric) spoken cadence interval: "Scendi... 5... 4... 3... 2... 1... Su!"
  useEffect(() => {
    if (negPhase === 'idle') return;
    const id = window.setInterval(() => {
      if (negPhase === 'prep') {
        setNegPrepLeft((prev) => {
          if (prev <= 1) {
            setNegPhase('descent');
            setNegCountdown('scendi');
            if (voiceOn) {
              speakItalian('Scendi', { rate: 1.0 });
            } else {
              playTickBeep(true);
            }
            return 0;
          }
          playTickBeep(false);
          return prev - 1;
        });
      } else if (negPhase === 'descent') {
        setNegCountdown((prev) => {
          if (prev === 'scendi') {
            if (voiceOn) {
              speakItalian(String(descentSeconds), { rate: 1.05 });
            } else {
              playTickBeep(false);
            }
            return descentSeconds;
          }
          if (prev <= 1) {
            setNegPhase('up');
            setNegUpLeft(2);
            setNegRepsDone((r) => {
              const nextR = r + 1;
              if (nextR >= targetReps) {
                playTimerCompleteChime();
              } else {
                playTickBeep(true);
              }
              return nextR;
            });
            if (voiceOn) {
              speakItalian('Su!', { rate: 1.05 });
            }
            return 0;
          }
          const nextNum = prev - 1;
          if (voiceOn) {
            speakItalian(String(nextNum), { rate: 1.05 });
          } else {
            playTickBeep(false);
          }
          return nextNum;
        });
      } else if (negPhase === 'up') {
        setNegUpLeft((prev) => {
          if (prev <= 1) {
            if (negRepsDone >= targetReps) {
              setNegPhase('idle');
              if (voiceOn) {
                speakItalian('Serie completata!', { rate: 1.0 });
              }
              return 0;
            }
            setNegPhase('descent');
            setNegCountdown('scendi');
            if (voiceOn) {
              speakItalian('Scendi', { rate: 1.0 });
            }
            return 0;
          }
          return prev - 1;
        });
      }
    }, 1000);
    return () => window.clearInterval(id);
  }, [negPhase, descentSeconds, negRepsDone, targetReps, voiceOn]);

  if (!timerState) return null;

  const formatMMSS = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  const restProgress = restTotal > 0 ? Math.max(0, Math.min(1, restRemaining / restTotal)) : 0;
  const isoRemaining = Math.max(0, target - isoElapsed);
  const isoProgress = target > 0 ? Math.min(1, isoElapsed / target) : 0;
  const negProgress =
    negPhase === 'descent' && typeof negCountdown === 'number' && descentSeconds > 0
      ? Math.max(0, Math.min(1, (descentSeconds - negCountdown + 1) / descentSeconds))
      : negPhase === 'up'
      ? 1
      : 0;

  const radius = 56;
  const circumference = 2 * Math.PI * radius;
  const activeProgress =
    mode === 'rest' || mode === 'transition'
      ? restProgress
      : mode === 'isometric'
      ? isoProgress
      : negProgress;
  const strokeDashoffset = circumference * (1 - activeProgress);

  // Semaforo Gigante visual state calculation (readable from 3+ meters away)
  const getSemaforoState = () => {
    if (mode === 'rest' || mode === 'transition') {
      if (restRemaining === 0) {
        return {
          bg: '#22C55E',
          fg: '#05070A',
          pulse: false,
          phaseLabel: mode === 'transition' ? 'CAMBIO COMPLETATO — VIA!' : 'RECUPERO FINITO — TOCCA A TE!',
          bigValue: 'VIA!',
        };
      }
      if (restRemaining <= 5) {
        return {
          bg: '#FACC15',
          fg: '#05070A',
          pulse: true,
          phaseLabel: 'ULTIMI 5 SECONDI · PREPARATI!',
          bigValue: `${restRemaining}`,
        };
      }
      return {
        bg: '#2563EB',
        fg: '#FFFFFF',
        pulse: false,
        phaseLabel: mode === 'transition' ? 'CAMBIO ESERCIZIO IN CORSO' : 'RECUPERO IN CORSO',
        bigValue: formatMMSS(restRemaining),
      };
    }

    if (mode === 'isometric') {
      if (isoPhase === 'prep') {
        return {
          bg: '#FACC15',
          fg: '#05070A',
          pulse: true,
          phaseLabel: 'PREPARATI ALLA TENUTA',
          bigValue: `${prepLeft}`,
        };
      }
      if (isoPhase === 'holding') {
        if (isoTargetReached) {
          return {
            bg: '#22C55E',
            fg: '#05070A',
            pulse: false,
            phaseLabel: 'TARGET TENUTA RAGGIUNTO!',
            bigValue: `${isoElapsed}s`,
          };
        }
        if (isoRemaining <= 5 && isoRemaining > 0) {
          return {
            bg: '#FACC15',
            fg: '#05070A',
            pulse: true,
            phaseLabel: 'ULTIMI 5 SECONDI DI TENUTA!',
            bigValue: `${isoRemaining}s`,
          };
        }
        return {
          bg: '#00D2FF',
          fg: '#05070A',
          pulse: true,
          phaseLabel: 'SERIE ISOMETRICA ATTIVA · MANTIENI!',
          bigValue: `${isoRemaining}s`,
        };
      }
      return {
        bg: '#0284C7',
        fg: '#FFFFFF',
        pulse: false,
        phaseLabel: 'PRONTO ALLA TENUTA',
        bigValue: `${target}s`,
      };
    }

    // Negative mode
    if (negPhase === 'prep') {
      return {
        bg: '#FACC15',
        fg: '#05070A',
        pulse: true,
        phaseLabel: 'PREPARATI ALLA NEGATIVA',
        bigValue: `${negPrepLeft}`,
      };
    }
    if (negPhase === 'descent' || negPhase === 'up') {
      const isLastSec = typeof negCountdown === 'number' && negCountdown <= 2;
      return {
        bg: isLastSec ? '#FACC15' : '#00D2FF',
        fg: '#05070A',
        pulse: true,
        phaseLabel: `FASE ECCENTRICA · REP ${negRepsDone + 1}/${targetReps}`,
        bigValue:
          negPhase === 'up'
            ? 'SU!'
            : negCountdown === 'scendi'
            ? 'SCENDI'
            : `${negCountdown}s`,
      };
    }
    return {
      bg: '#22C55E',
      fg: '#05070A',
      pulse: false,
      phaseLabel: 'PRONTO',
      bigValue: `${descentSeconds}s`,
    };
  };

  const semaforo = getSemaforoState();

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#05070A]/80 backdrop-blur-sm p-3 sm:p-4">
      <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-[#1E293B] p-5 shadow-2xl">
        {/* Header & Mode Switch + Speaker Toggle */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-1 p-1 rounded-xl bg-[#090D16] border border-[#1E293B] overflow-x-auto no-scrollbar">
            <button
              type="button"
              onClick={() => {
                stopSpeaking();
                onSwitchMode('rest');
              }}
              className={`min-h-[36px] px-2.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                mode === 'rest'
                  ? 'bg-[#2563EB] text-[#FFFFFF]'
                  : 'text-[#94A3B8] hover:text-[#FFFFFF]'
              }`}
            >
              Recupero
            </button>
            <button
              type="button"
              onClick={() => {
                stopSpeaking();
                onSwitchMode('transition');
              }}
              className={`min-h-[36px] px-2.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                mode === 'transition'
                  ? 'bg-[#2563EB] text-[#FFFFFF]'
                  : 'text-[#94A3B8] hover:text-[#FFFFFF]'
              }`}
            >
              Cambio Es.
            </button>
            <button
              type="button"
              onClick={() => {
                stopSpeaking();
                onSwitchMode('isometric');
              }}
              className={`min-h-[36px] px-2.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                mode === 'isometric'
                  ? 'bg-[#38BDF8] text-[#05070A]'
                  : 'text-[#94A3B8] hover:text-[#FFFFFF]'
              }`}
            >
              Isometria
            </button>
            <button
              type="button"
              onClick={() => {
                stopSpeaking();
                onSwitchMode('negative');
              }}
              className={`min-h-[36px] px-2.5 rounded-lg text-xs font-bold transition whitespace-nowrap ${
                mode === 'negative'
                  ? 'bg-[#00D2FF] text-[#05070A]'
                  : 'text-[#94A3B8] hover:text-[#FFFFFF]'
              }`}
            >
              Negativa
            </button>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => setSemaforoOpen(true)}
              aria-label="Espandi Semaforo Gigante a schermo intero"
              title="Semaforo Gigante a schermo intero"
              className="min-h-[42px] px-2.5 flex items-center justify-center gap-1 rounded-xl border text-xs font-extrabold transition"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--accent)',
                color: 'var(--accent)',
              }}
            >
              <Maximize2 className="w-4 h-4" />
              <span className="hidden sm:inline">Semaforo</span>
            </button>

            <button
              type="button"
              onClick={() => {
                const next = !voiceOn;
                setVoiceOn(next);
                if (!next) stopSpeaking();
              }}
              aria-label={voiceOn ? 'Disattiva sintesi vocale' : 'Attiva sintesi vocale'}
              className={`min-h-[42px] min-w-[42px] flex items-center justify-center rounded-xl border transition ${
                voiceOn
                  ? 'bg-[#132347] border-[#38BDF8] text-[#00D2FF]'
                  : 'bg-[#090D16] border-[#1E293B] text-[#94A3B8]'
              }`}
            >
              {voiceOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={() => {
                stopSpeaking();
                onClose();
              }}
              aria-label="Chiudi timer"
              className="min-h-[42px] min-w-[42px] flex items-center justify-center rounded-xl text-[#94A3B8] hover:text-[#FFFFFF] hover:bg-[#131C31] transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {timerState.partnerLabel && (
          <div className="mt-2.5 flex justify-center">
            <span
              className="px-2.5 py-0.5 rounded-lg border text-[11px] font-extrabold uppercase tracking-wider"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--accent)',
                color: 'var(--accent)',
              }}
            >
              {timerState.partnerLabel}
            </span>
          </div>
        )}

        {mode === 'transition' ? (
          <div className="mt-3 text-center space-y-0.5">
            <p className="text-[11px] font-bold text-[#00D2FF] uppercase tracking-wider">
              Timer Cambio Esercizio
            </p>
            {timerState.nextExerciseName && (
              <p className="text-xs font-semibold text-[#FFFFFF] truncate">
                Prossimo: {timerState.nextExerciseName}
              </p>
            )}
          </div>
        ) : (
          timerState.exerciseName && (
            <p className="mt-3 text-center text-xs font-medium text-[#94A3B8] truncate">
              {timerState.exerciseName}
            </p>
          )
        )}

        {/* Circular Timer Ring */}
        <div className="my-5 flex flex-col items-center justify-center">
          <div className="relative w-40 h-40 flex items-center justify-center">
            <svg className="w-40 h-40 -rotate-90" viewBox="0 0 140 140">
              <circle
                cx="70"
                cy="70"
                r={radius}
                fill="none"
                stroke="#1E293B"
                strokeWidth="10"
              />
              <circle
                cx="70"
                cy="70"
                r={radius}
                fill="none"
                stroke={
                  mode === 'rest'
                    ? '#2563EB'
                    : mode === 'transition' || mode === 'negative'
                    ? '#00D2FF'
                    : '#38BDF8'
                }
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-300"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-2">
              {mode === 'rest' || mode === 'transition' ? (
                <>
                  <span className="font-mono text-3xl font-bold text-[#FFFFFF] tabular-nums">
                    {formatMMSS(restRemaining)}
                  </span>
                  <span className="text-xs text-[#94A3B8] mt-1">
                    {restRemaining === 0
                      ? mode === 'transition'
                        ? 'Pronto al prossimo!'
                        : 'Recupero finito!'
                      : `Target ${restTotal}s`}
                  </span>
                </>
              ) : mode === 'isometric' ? (
                isoPhase === 'prep' ? (
                  <>
                    <span className="font-mono text-4xl font-extrabold text-[#00D2FF] tabular-nums">
                      {prepLeft}
                    </span>
                    <span className="text-xs font-semibold text-[#FFFFFF] mt-1">Preparati...</span>
                  </>
                ) : isoPhase === 'holding' ? (
                  <>
                    <span className="font-mono text-3xl font-extrabold text-[#FFFFFF] tabular-nums">
                      {isoTargetReached ? `${isoElapsed}s` : `${isoRemaining}s`}
                    </span>
                    <span className="text-xs text-[#38BDF8] font-semibold mt-1 tabular-nums">
                      {isoTargetReached ? 'Target raggiunto!' : `Tenuta (${isoElapsed}/${target}s)`}
                    </span>
                  </>
                ) : (
                  <>
                    <span className="font-mono text-3xl font-bold text-[#FFFFFF] tabular-nums">
                      {target}s
                    </span>
                    <span className="text-xs text-[#94A3B8] mt-1">
                      {voiceOn ? 'Voce it-IT attiva' : 'Solo audio beep'}
                    </span>
                  </>
                )
              ) : negPhase === 'prep' ? (
                <>
                  <span className="font-mono text-4xl font-extrabold text-[#00D2FF] tabular-nums">
                    {negPrepLeft}
                  </span>
                  <span className="text-xs font-semibold text-[#FFFFFF] mt-1">Preparati...</span>
                </>
              ) : negPhase === 'descent' ? (
                <>
                  <span className="font-mono text-3xl font-extrabold text-[#00D2FF] tabular-nums">
                    {negCountdown === 'scendi' ? 'Scendi' : `${negCountdown}s`}
                  </span>
                  <span className="text-xs text-[#CBD5E1] mt-1 tabular-nums">
                    Rep {negRepsDone + 1} / {targetReps}
                  </span>
                </>
              ) : negPhase === 'up' ? (
                <>
                  <span className="font-mono text-3xl font-extrabold text-[#38BDF8]">Su!</span>
                  <span className="text-xs text-[#CBD5E1] mt-1 tabular-nums">
                    Rep {negRepsDone} / {targetReps}
                  </span>
                </>
              ) : (
                <>
                  <span className="font-mono text-3xl font-bold text-[#FFFFFF] tabular-nums">
                    {descentSeconds}s
                  </span>
                  <span className="text-xs text-[#94A3B8] mt-1 tabular-nums">
                    {negRepsDone > 0 ? `${negRepsDone} rep fatte` : `${targetReps} rep · Eccentrica`}
                  </span>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Mode Controls */}
        {mode === 'rest' || mode === 'transition' ? (
          <div className="space-y-3">
            {mode === 'transition' && (
              <div className="grid grid-cols-4 gap-1.5">
                {[60, 90, 120, 150].map((sec) => (
                  <button
                    key={sec}
                    type="button"
                    onClick={() => {
                      setRestTotal(sec);
                      setRestRemaining(sec);
                      setRestRunning(true);
                      chimePlayedRef.current = false;
                      onChangeTransitionDefault?.(sec);
                    }}
                    className={`min-h-[34px] rounded-lg font-mono text-xs font-bold transition ${
                      restTotal === sec
                        ? 'bg-[#00D2FF] text-[#05070A]'
                        : 'bg-[#131C31] border border-[#1E293B] text-[#CBD5E1] hover:text-[#FFFFFF]'
                    }`}
                  >
                    {sec}s
                  </button>
                ))}
              </div>
            )}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  setRestRemaining((p) => Math.max(0, p - 15));
                }}
                className="min-h-[44px] rounded-xl bg-[#131C31] border border-[#1E293B] font-mono text-sm font-bold text-[#FFFFFF] hover:bg-[#1E293B] transition"
              >
                -15s
              </button>
              <button
                type="button"
                onClick={() => {
                  if (restRemaining === 0) {
                    setRestRemaining(restTotal);
                    chimePlayedRef.current = false;
                  }
                  setRestRunning((r) => !r);
                }}
                className="min-h-[44px] rounded-xl bg-[#2563EB] text-[#FFFFFF] text-sm font-extrabold flex items-center justify-center gap-1.5 hover:bg-[#3B82F6] transition"
              >
                {restRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                <span>{restRunning ? 'Pausa' : restRemaining === 0 ? 'Ripeti' : 'Avvia'}</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setRestRemaining((p) => p + 15);
                  setRestTotal((t) => Math.max(t, restRemaining + 15));
                }}
                className="min-h-[44px] rounded-xl bg-[#131C31] border border-[#1E293B] font-mono text-sm font-bold text-[#FFFFFF] hover:bg-[#1E293B] transition"
              >
                +15s
              </button>
            </div>
            <div className="flex items-center justify-between text-xs text-[#94A3B8] pt-1">
              <button
                type="button"
                onClick={() => {
                  setRestRunning(false);
                  setRestRemaining(restTotal);
                  chimePlayedRef.current = false;
                }}
                className="inline-flex items-center gap-1.5 min-h-[36px] px-2 hover:text-[#FFFFFF] transition"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reimposta {restTotal}s</span>
              </button>
              <span className="inline-flex items-center gap-1">
                <Volume2 className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>{voiceOn ? 'Voce it-IT attiva' : 'Segnale acustico'}</span>
              </span>
            </div>
          </div>
        ) : mode === 'isometric' ? (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              {isoPhase === 'idle' ? (
                <button
                  type="button"
                  onClick={() => startIsometricFlow(voiceOn)}
                  className="col-span-2 min-h-[48px] rounded-xl bg-[#38BDF8] text-[#05070A] text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#7DD3FC] transition"
                >
                  <Timer className="w-4 h-4" />
                  <span>
                    {voiceOn ? 'Avvia Tenuta con Voce (3s prep)' : 'Avvia Tenuta (3s prep)'}
                  </span>
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      stopSpeaking();
                      setIsoPhase('idle');
                    }}
                    className="min-h-[48px] rounded-xl bg-[#131C31] border border-[#1E293B] text-sm font-bold text-[#FFFFFF] flex items-center justify-center gap-1.5 hover:bg-[#1E293B] transition"
                  >
                    <Pause className="w-4 h-4" />
                    <span>Ferma</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => startIsometricFlow(voiceOn)}
                    className="min-h-[48px] rounded-xl bg-[#131C31] border border-[#1E293B] text-sm font-bold text-[#FFFFFF] flex items-center justify-center gap-1.5 hover:bg-[#1E293B] transition"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Riparti</span>
                  </button>
                </>
              )}
            </div>

            {timerState.exerciseInstanceId &&
              timerState.setId &&
              isoElapsed > 0 &&
              onApplyIsometricSeconds && (
                <button
                  type="button"
                  onClick={() => {
                    stopSpeaking();
                    setIsoPhase('idle');
                    onApplyIsometricSeconds(
                      timerState.exerciseInstanceId!,
                      timerState.setId!,
                      isoElapsed
                    );
                    onClose();
                  }}
                  className="w-full min-h-[48px] rounded-xl bg-[#2563EB] text-[#FFFFFF] text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#3B82F6] transition"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Salva {isoElapsed}s nella serie e completa</span>
                </button>
              )}
          </div>
        ) : (
          /* Negative Eccentric Mode Controls */
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-xl bg-[#090D16] border border-[#1E293B] p-2.5">
              <span className="text-xs font-semibold text-[#CBD5E1]">
                Secondi di discesa (eccentrica)
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={negPhase !== 'idle'}
                  onClick={() => setDescentSeconds((s) => Math.max(3, s - 1))}
                  className="min-h-[34px] min-w-[34px] rounded-lg bg-[#131C31] text-sm font-bold text-[#FFFFFF] disabled:opacity-40"
                >
                  -
                </button>
                <span className="font-mono text-sm font-bold text-[#00D2FF] min-w-[36px] text-center tabular-nums">
                  {descentSeconds}s
                </span>
                <button
                  type="button"
                  disabled={negPhase !== 'idle'}
                  onClick={() => setDescentSeconds((s) => Math.min(12, s + 1))}
                  className="min-h-[34px] min-w-[34px] rounded-lg bg-[#131C31] text-sm font-bold text-[#FFFFFF] disabled:opacity-40"
                >
                  +
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              {negPhase === 'idle' ? (
                <button
                  type="button"
                  onClick={() => startNegativeFlow(voiceOn, descentSeconds)}
                  className="col-span-2 min-h-[48px] rounded-xl bg-[#00D2FF] text-[#05070A] text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#38BDF8] transition"
                >
                  <TrendingDown className="w-4 h-4" />
                  <span>
                    Avvia Guida Negativa ({descentSeconds}s discesa)
                  </span>
                </button>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => {
                      stopSpeaking();
                      setNegPhase('idle');
                    }}
                    className="min-h-[48px] rounded-xl bg-[#131C31] border border-[#1E293B] text-sm font-bold text-[#FFFFFF] flex items-center justify-center gap-1.5 hover:bg-[#1E293B] transition"
                  >
                    <Pause className="w-4 h-4" />
                    <span>Ferma</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => startNegativeFlow(voiceOn, descentSeconds)}
                    className="min-h-[48px] rounded-xl bg-[#131C31] border border-[#1E293B] text-sm font-bold text-[#FFFFFF] flex items-center justify-center gap-1.5 hover:bg-[#1E293B] transition"
                  >
                    <RotateCcw className="w-4 h-4" />
                    <span>Riparti</span>
                  </button>
                </>
              )}
            </div>

            {timerState.exerciseInstanceId &&
              timerState.setId &&
              negRepsDone > 0 &&
              onApplyNegativeReps && (
                <button
                  type="button"
                  onClick={() => {
                    stopSpeaking();
                    setNegPhase('idle');
                    onApplyNegativeReps(
                      timerState.exerciseInstanceId!,
                      timerState.setId!,
                      negRepsDone
                    );
                    onClose();
                  }}
                  className="w-full min-h-[48px] rounded-xl bg-[#2563EB] text-[#FFFFFF] text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#3B82F6] transition"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Salva {negRepsDone} rep nella serie e completa</span>
                </button>
              )}
          </div>
        )}
      </div>

      {/* Fullscreen Semaforo Gigante Overlay */}
      {semaforoOpen && (
        <div
          className={`fixed inset-0 z-[90] flex flex-col items-center justify-between p-6 text-center select-none transition-colors duration-300 ${
            semaforo.pulse ? 'semaforo-pulse' : ''
          }`}
          style={{
            backgroundColor: semaforo.bg,
            color: semaforo.fg,
          }}
        >
          <div className="w-full max-w-2xl flex items-center justify-between gap-3">
            <span className="text-xs sm:text-sm font-black uppercase tracking-widest opacity-90 truncate">
              {timerState.exerciseName ?? timerState.nextExerciseName ?? 'Timer CALI PRO'}
            </span>
            <button
              type="button"
              onClick={() => setSemaforoOpen(false)}
              className="min-h-[44px] px-4 rounded-2xl font-black text-xs sm:text-sm inline-flex items-center gap-1.5 border-2"
              style={{
                borderColor: semaforo.fg,
                backgroundColor: 'rgba(0,0,0,0.16)',
                color: semaforo.fg,
              }}
            >
              <Minimize2 className="w-4 h-4" />
              <span>Riduci</span>
            </button>
          </div>

          <div className="my-auto space-y-4">
            <p className="text-base sm:text-2xl font-black uppercase tracking-wider opacity-90">
              {semaforo.phaseLabel}
            </p>
            <p
              className="font-mono font-black tabular-nums leading-none"
              style={{ fontSize: 'clamp(4.5rem, 20vw, 11rem)' }}
            >
              {semaforo.bigValue}
            </p>
          </div>

          <div className="w-full max-w-md flex items-center justify-center gap-3">
            {(mode === 'rest' || mode === 'transition') && (
              <button
                type="button"
                onClick={() => {
                  if (restRemaining === 0) {
                    setRestRemaining(restTotal);
                    chimePlayedRef.current = false;
                  }
                  setRestRunning((r) => !r);
                }}
                className="min-h-[54px] px-8 rounded-2xl font-black text-base border-2"
                style={{
                  borderColor: semaforo.fg,
                  backgroundColor: 'rgba(0,0,0,0.16)',
                  color: semaforo.fg,
                }}
              >
                {restRunning ? 'Pausa' : restRemaining === 0 ? 'Ripeti' : 'Avvia'}
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                stopSpeaking();
                setSemaforoOpen(false);
                onClose();
              }}
              className="min-h-[54px] px-8 rounded-2xl font-black text-base border-2"
              style={{
                borderColor: semaforo.fg,
                backgroundColor: 'rgba(0,0,0,0.16)',
                color: semaforo.fg,
              }}
            >
              Chiudi Timer
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

