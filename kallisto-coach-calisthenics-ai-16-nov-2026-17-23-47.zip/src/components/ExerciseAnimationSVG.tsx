import React, { useEffect, useId, useState } from 'react';
import { AlertTriangle, Camera, Columns2, ExternalLink, Pause, Play } from 'lucide-react';
import { getExerciseById } from '../data/exercises';
import type { AnimationId, ExerciseCategory } from '../types/calisthenics';
import { playTechClick } from '../utils/audio';
import {
  computeBiomechanicalPose,
  getBiomechSpec,
  getVisualCalloutLabels,
  type BiomechanicalPose,
  type MuscleGroupId,
  type Point2D,
  type VisualCalloutLabel,
} from '../utils/biomechanicsEngine';

type PhaseMode = 'auto' | 1 | 2 | 3;
type VisualViewMode = 'auto_anim' | 'side_by_side';

const FREE_EXERCISE_DB_BASE =
  'https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises';

function getFreeExerciseDbFolder(exerciseId: string): string | null {
  switch (exerciseId) {
    case 'pull_up':
    case 'commando_pullup':
    case 'archer_pullup':
    case 'weighted_pullup':
    case 'pullup_negative':
    case 'high_pullup':
      return 'Pullups';
    case 'chin_up':
      return 'Chin-Up';
    case 'australian_pullup_prona':
    case 'australian_pullup_supina':
    case 'ring_row':
      return 'Inverted_Row';
    case 'push_up':
    case 'parallettes_pushup':
    case 'archer_pushup':
    case 'pushup_negative':
      return 'Pushups';
    case 'diamond_pushup':
      return 'Close-Triceps_Pushup';
    case 'dip_parallele':
    case 'ring_dip':
    case 'dip_negative':
      return 'Dips_-_Triceps_Version';
    case 'wall_hspu':
    case 'hspu_negative':
      return 'Handstand_Push-Ups';
    case 'plank':
      return 'Plank';
    case 'side_plank':
      return 'Side_Bridge';
    case 'arch_body_hold':
      return 'Superman';
    case 'crunch':
    case 'bicycle_crunch':
      return 'Crunches';
    case 'sit_up':
      return 'Sit-Up';
    case 'hanging_leg_raises':
    case 'knee_raises':
    case 'toes_to_bar':
      return 'Hanging_Leg_Raise';
    case 'lying_leg_raises':
      return 'Flat_Bench_Lying_Leg_Raise';
    case 'russian_twist':
      return 'Russian_Twist';
    case 'mountain_climbers':
      return 'Mountain_Climbers';
    case 'bodyweight_squat':
      return 'Bodyweight_Squat';
    case 'lunges':
      return 'Bodyweight_Lunges';
    case 'calf_raises':
      return 'Standing_Calf_Raises';
    default:
      return null;
  }
}

interface StageProps {
  pose: BiomechanicalPose;
  activeMuscles: MuscleGroupId[];
  ariaLabel: string;
  compact?: boolean;
  showArrows?: boolean;
  visualLabels?: VisualCalloutLabel[];
}

function unitPerp(a: Point2D, b: Point2D): Point2D {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const len = Math.hypot(dx, dy) || 1;
  return { x: -dy / len, y: dx / len };
}

function offsetSegment(
  a: Point2D,
  b: Point2D,
  offsetStart: number,
  offsetEnd: number
): { p1: Point2D; p2: Point2D } {
  const n = unitPerp(a, b);
  return {
    p1: { x: a.x + n.x * offsetStart, y: a.y + n.y * offsetStart },
    p2: { x: b.x + n.x * offsetEnd, y: b.y + n.y * offsetEnd },
  };
}

function lerpPt(a: Point2D, b: Point2D, t: number): Point2D {
  return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
}

const BiomechanicalStageSVG: React.FC<StageProps> = ({
  pose,
  activeMuscles,
  ariaLabel,
  compact = false,
  showArrows = true,
  visualLabels = [],
}) => {
  const uid = useId().replace(/:/g, '');
  const arrowId = `arrowNeon_${uid}`;
  const glowId = `neonGlow_${uid}`;
  const gridMinorId = `gridMinor_${uid}`;
  const gridMajorId = `gridMajor_${uid}`;

  const hasMuscle = (m: MuscleGroupId) => activeMuscles.includes(m);
  const barY = pose.barY ?? 26;

  const torsoPerp = unitPerp(pose.shoulder, pose.pelvis);
  const chestPt = lerpPt(pose.shoulder, pose.pelvis, 0.28);
  const midBackPt = lerpPt(pose.shoulder, pose.pelvis, 0.56);

  // Ultra-clear high-contrast palette on #0B1120 blueprint grid
  const BG_STAGE = '#0B1120';
  const APPARATUS_METAL = '#94A3B8';
  const APPARATUS_BASE = '#475569';
  const APPARATUS_SPECULAR = '#E2E8F0';
  const TORSO_WHITE = '#FFFFFF';
  const LIMB_PRIMARY = '#E2E8F0';
  const LIMB_FAR = pose.bilateralFront ? '#CBD5E1' : '#94A3B8';
  const NEON = '#38BDF8';
  const NEON_BRIGHT = '#7DD3FC';

  // Thick, clear proportions (~80% frame occupancy via zoomed viewBox 24 4 232 162)
  const armUpperWidth = compact ? 6.4 : 8;
  const forearmWidth = compact ? 6 : 8;
  const thighWidth = compact ? 7 : 8.5;
  const shinWidth = compact ? 6.4 : 8;
  const torsoWidth = compact ? 10 : 12.5;

  // Highlight active limbs subtly in neon #38BDF8 when targeted
  const armsActive =
    hasMuscle('biceps') ||
    hasMuscle('triceps') ||
    hasMuscle('shoulders') ||
    hasMuscle('forearms');
  const legsActive =
    hasMuscle('quads') ||
    hasMuscle('glutesHamstrings') ||
    hasMuscle('calves');

  const latsBand = offsetSegment(lerpPt(pose.shoulder, pose.pelvis, 0.14), midBackPt, -4.5, -3.5);
  const chestBand = offsetSegment(pose.shoulder, chestPt, 5, 4.5);
  const absBand = offsetSegment(chestPt, pose.pelvis, 4.5, 4.2);
  const lowerBackBand = offsetSegment(midBackPt, pose.pelvis, -4.2, -3.8);
  const obliquesBand = offsetSegment(chestPt, pose.pelvis, 1.8, 1.8);

  const bicepsBand = offsetSegment(
    lerpPt(pose.shoulder, pose.elbow, 0.14),
    lerpPt(pose.shoulder, pose.elbow, 0.86),
    2.8,
    2.4
  );
  const tricepsBand = offsetSegment(
    lerpPt(pose.shoulder, pose.elbow, 0.14),
    lerpPt(pose.shoulder, pose.elbow, 0.86),
    -2.8,
    -2.4
  );
  const forearmsBand = offsetSegment(
    lerpPt(pose.elbow, pose.wrist, 0.14),
    lerpPt(pose.elbow, pose.wrist, 0.82),
    1.8,
    1.4
  );

  const quadsBand = offsetSegment(
    lerpPt(pose.pelvis, pose.knee, 0.14),
    lerpPt(pose.pelvis, pose.knee, 0.88),
    3,
    2.4
  );
  const hamstringsBand = offsetSegment(
    lerpPt(pose.pelvis, pose.knee, 0.12),
    lerpPt(pose.pelvis, pose.knee, 0.88),
    -3.4,
    -2.4
  );
  const calvesBand = offsetSegment(
    lerpPt(pose.knee, pose.ankle, 0.16),
    lerpPt(pose.knee, pose.ankle, 0.76),
    -2.8,
    -2
  );

  const renderJointGlow = (pt: Point2D, rBase: number) => (
    <g>
      <circle cx={pt.x} cy={pt.y} r={rBase + 1.8} fill={NEON} opacity="0.22" />
      <circle
        cx={pt.x}
        cy={pt.y}
        r={rBase}
        fill={BG_STAGE}
        stroke={NEON}
        strokeWidth={compact ? 1.8 : 2.2}
      />
    </g>
  );

  return (
    <svg
      viewBox="24 4 232 166"
      className={
        compact
          ? 'w-full h-32 sm:h-36 rounded-lg overflow-hidden'
          : 'w-full h-52 sm:h-60 rounded-xl overflow-hidden'
      }
      style={{ backgroundColor: BG_STAGE }}
      role="img"
      aria-label={ariaLabel}
    >
      <defs>
        {/* Fine millimeter reference grid */}
        <pattern id={gridMinorId} width="10" height="10" patternUnits="userSpaceOnUse">
          <path
            d="M 10 0 L 0 0 0 10"
            fill="none"
            stroke="#94A3B8"
            strokeWidth="0.45"
            opacity="0.13"
          />
        </pattern>
        <pattern id={gridMajorId} width="50" height="50" patternUnits="userSpaceOnUse">
          <rect width="50" height="50" fill={`url(#${gridMinorId})`} />
          <path
            d="M 50 0 L 0 0 0 50"
            fill="none"
            stroke="#38BDF8"
            strokeWidth="0.7"
            opacity="0.16"
          />
        </pattern>

        <marker
          id={arrowId}
          markerWidth="7"
          markerHeight="7"
          refX="5"
          refY="3.5"
          orient="auto"
        >
          <polygon points="0 0, 7 3.5, 0 7" fill={NEON} />
        </marker>

        <filter id={glowId} x="-40%" y="-40%" width="180%" height="180%">
          <feGaussianBlur stdDeviation="2.4" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      {/* Background #0B1120 + Millimeter Reference Grid */}
      <rect x="24" y="4" width="232" height="166" fill={BG_STAGE} />
      <rect x="24" y="4" width="232" height="166" fill={`url(#${gridMajorId})`} />

      {/* ============================================================
          THICK METALLIC APPARATUS (strokeWidth="6", #94A3B8)
         ============================================================ */}
      {(pose.apparatus === 'high_bar' || pose.apparatus === 'mid_bar') && (
        <g>
          {/* Side support uprights & grounded bases */}
          <line x1="48" y1={barY} x2="48" y2="160" stroke={APPARATUS_BASE} strokeWidth="6" strokeLinecap="round" />
          <line x1="232" y1={barY} x2="232" y2="160" stroke={APPARATUS_BASE} strokeWidth="6" strokeLinecap="round" />
          <line x1="36" y1="160" x2="60" y2="160" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <line x1="220" y1="160" x2="244" y2="160" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          {/* Main horizontal bar */}
          <line x1="38" y1={barY} x2="242" y2={barY} stroke={APPARATUS_METAL} strokeWidth="6.5" strokeLinecap="round" />
          <line x1="40" y1={barY - 1.5} x2="240" y2={barY - 1.5} stroke={APPARATUS_SPECULAR} strokeWidth="1.6" strokeLinecap="round" opacity="0.65" />
        </g>
      )}

      {pose.apparatus === 'mid_bar_behind' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <line x1={(pose.barX ?? 120) - 24} y1="153" x2={(pose.barX ?? 120) - 24} y2={barY} stroke={APPARATUS_BASE} strokeWidth="6" strokeLinecap="round" />
          <line x1={(pose.barX ?? 120) - 28} y1={barY} x2={(pose.barX ?? 120) + 18} y2={barY} stroke={APPARATUS_METAL} strokeWidth="6.5" strokeLinecap="round" />
        </g>
      )}

      {pose.apparatus === 'low_bar' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <line x1={pose.barX ?? 176} y1={barY} x2={pose.barX ?? 176} y2="153" stroke={APPARATUS_BASE} strokeWidth="6" strokeLinecap="round" />
          <line x1={(pose.barX ?? 176) - 24} y1={barY} x2={(pose.barX ?? 176) + 24} y2={barY} stroke={APPARATUS_METAL} strokeWidth="6.5" strokeLinecap="round" />
          <line x1={(pose.barX ?? 176) - 22} y1={barY - 1.5} x2={(pose.barX ?? 176) + 22} y2={barY - 1.5} stroke={APPARATUS_SPECULAR} strokeWidth="1.4" strokeLinecap="round" opacity="0.65" />
        </g>
      )}

      {(pose.apparatus === 'rings_low' || pose.apparatus === 'rings_high') && pose.ringAnchors && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <line x1="60" y1="12" x2="220" y2="12" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          {/* Left strap & ring */}
          <line x1={pose.ringAnchors.left.x} y1="12" x2={pose.ringAnchors.left.x} y2={pose.ringAnchors.left.y - 6} stroke={APPARATUS_SPECULAR} strokeWidth="3" />
          <circle cx={pose.ringAnchors.left.x} cy={pose.ringAnchors.left.y} r="7" fill="none" stroke={NEON} strokeWidth="3.2" />
          {/* Right strap & ring */}
          <line x1={pose.ringAnchors.right.x} y1="12" x2={pose.ringAnchors.right.x} y2={pose.ringAnchors.right.y - 6} stroke={APPARATUS_SPECULAR} strokeWidth="3" />
          <circle cx={pose.ringAnchors.right.x} cy={pose.ringAnchors.right.y} r="7" fill="none" stroke={NEON} strokeWidth="3.2" />
        </g>
      )}

      {pose.apparatus === 'parallel_bars' && (
        <g>
          <line x1="32" y1="153" x2="248" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <line x1="106" y1={barY - 4} x2="106" y2="153" stroke={APPARATUS_BASE} strokeWidth="5.5" strokeLinecap="round" />
          <line x1="202" y1={barY - 4} x2="202" y2="153" stroke={APPARATUS_BASE} strokeWidth="5.5" strokeLinecap="round" />
          <line x1="92" y1={barY - 4} x2="214" y2={barY - 4} stroke={APPARATUS_BASE} strokeWidth="6" strokeLinecap="round" />
          <line x1="92" y1={barY} x2="92" y2="153" stroke={APPARATUS_METAL} strokeWidth="5.5" strokeLinecap="round" />
          <line x1="188" y1={barY} x2="188" y2="153" stroke={APPARATUS_METAL} strokeWidth="5.5" strokeLinecap="round" />
          <line x1="78" y1={barY} x2="200" y2={barY} stroke={APPARATUS_METAL} strokeWidth="6.5" strokeLinecap="round" />
        </g>
      )}

      {pose.apparatus === 'parallettes' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <line x1="102" y1={barY - 4} x2="166" y2={barY - 4} stroke={APPARATUS_BASE} strokeWidth="5.5" strokeLinecap="round" />
          <line x1="96" y1={barY} x2="96" y2="153" stroke={APPARATUS_METAL} strokeWidth="5" strokeLinecap="round" />
          <line x1="146" y1={barY} x2="146" y2="153" stroke={APPARATUS_METAL} strokeWidth="5" strokeLinecap="round" />
          <line x1="86" y1={barY} x2="156" y2={barY} stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
        </g>
      )}

      {pose.apparatus === 'floor' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <line x1="28" y1="151" x2="252" y2="151" stroke={APPARATUS_SPECULAR} strokeWidth="1.2" opacity="0.45" />
        </g>
      )}

      {pose.diamondHandPos && (
        <polygon
          points={`${pose.diamondHandPos.x},${pose.diamondHandPos.y - 7} ${pose.diamondHandPos.x + 9},${pose.diamondHandPos.y} ${pose.diamondHandPos.x},${pose.diamondHandPos.y + 7} ${pose.diamondHandPos.x - 9},${pose.diamondHandPos.y}`}
          fill="#0B1120"
          stroke={NEON}
          strokeWidth="2.2"
        />
      )}

      {pose.apparatus === 'floor_bench_back' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <rect x="202" y="122" width="12" height="30" rx="3" fill={APPARATUS_BASE} stroke={APPARATUS_METAL} strokeWidth="2.5" />
        </g>
      )}

      {pose.apparatus === 'elevated_box_rear' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <rect x="44" y="116" width="46" height="35" rx="4" fill="#1E293B" stroke={APPARATUS_METAL} strokeWidth="3.5" />
        </g>
      )}

      {pose.apparatus === 'wall_floor' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <rect x={pose.wallX ? pose.wallX - 12 : 98} y="10" width="12" height="143" rx="2" fill="#1E293B" stroke={APPARATUS_METAL} strokeWidth="3" />
        </g>
      )}

      {pose.apparatus === 'ankle_anchor' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <rect x="52" y="135" width="24" height="16" rx="4" fill="#1E293B" stroke={NEON} strokeWidth="2.5" />
        </g>
      )}

      {pose.apparatus === 'step' && (
        <g>
          <line x1="26" y1="153" x2="254" y2="153" stroke={APPARATUS_METAL} strokeWidth="6" strokeLinecap="round" />
          <rect x="114" y="136" width="54" height="16" rx="3" fill="#1E293B" stroke={APPARATUS_METAL} strokeWidth="3" />
        </g>
      )}

      {/* Alignment Reference Line */}
      {pose.guideLine && (
        <line
          x1={pose.guideLine.p1.x}
          y1={pose.guideLine.p1.y}
          x2={pose.guideLine.p2.x}
          y2={pose.guideLine.p2.y}
          stroke={NEON}
          strokeWidth="1.6"
          strokeDasharray="4 4"
          opacity="0.72"
        />
      )}

      {/* ============================================================
          FAR / BILATERAL LIMBS
         ============================================================ */}
      {pose.shoulderFar && pose.elbowFar && pose.wristFar && (
        <g opacity={pose.bilateralFront ? '1' : '0.8'}>
          <line
            x1={pose.shoulderFar.x}
            y1={pose.shoulderFar.y}
            x2={pose.elbowFar.x}
            y2={pose.elbowFar.y}
            stroke={armsActive && pose.bilateralFront ? NEON_BRIGHT : LIMB_FAR}
            strokeWidth={armUpperWidth}
            strokeLinecap="round"
          />
          <line
            x1={pose.elbowFar.x}
            y1={pose.elbowFar.y}
            x2={pose.wristFar.x}
            y2={pose.wristFar.y}
            stroke={armsActive && pose.bilateralFront ? NEON_BRIGHT : LIMB_FAR}
            strokeWidth={forearmWidth}
            strokeLinecap="round"
          />
          {pose.bilateralFront && !compact && (
            <>
              {renderJointGlow(pose.elbowFar, 3.6)}
              {renderJointGlow(pose.wristFar, 3.6)}
            </>
          )}
        </g>
      )}

      {pose.kneeFar && pose.ankleFar && (
        <g opacity={pose.bilateralFront ? '1' : '0.8'}>
          <line
            x1={pose.pelvis.x}
            y1={pose.pelvis.y}
            x2={pose.kneeFar.x}
            y2={pose.kneeFar.y}
            stroke={legsActive && pose.bilateralFront ? NEON_BRIGHT : LIMB_FAR}
            strokeWidth={thighWidth}
            strokeLinecap="round"
          />
          <line
            x1={pose.kneeFar.x}
            y1={pose.kneeFar.y}
            x2={pose.ankleFar.x}
            y2={pose.ankleFar.y}
            stroke={legsActive && pose.bilateralFront ? NEON_BRIGHT : LIMB_FAR}
            strokeWidth={shinWidth}
            strokeLinecap="round"
          />
          {pose.footTipFar && (
            <line
              x1={pose.ankleFar.x}
              y1={pose.ankleFar.y}
              x2={pose.footTipFar.x}
              y2={pose.footTipFar.y}
              stroke={LIMB_FAR}
              strokeWidth={5}
              strokeLinecap="round"
            />
          )}
        </g>
      )}

      {/* ============================================================
          PRIMARY ATHLETE BODY (Bright White Torso #FFFFFF + 8px Rounded Limbs)
         ============================================================ */}
      <g>
        {/* Neck & Head */}
        <line
          x1={pose.shoulder.x}
          y1={pose.shoulder.y}
          x2={pose.neck.x}
          y2={pose.neck.y}
          stroke={TORSO_WHITE}
          strokeWidth={compact ? 5.5 : 6.5}
          strokeLinecap="round"
        />
        <circle
          cx={pose.head.x}
          cy={pose.head.y}
          r={compact ? 8.5 : 10.2}
          fill="#E2E8F0"
          stroke={TORSO_WHITE}
          strokeWidth="2.4"
        />
        {/* Torso in Brilliant White #FFFFFF */}
        <line
          x1={pose.shoulder.x}
          y1={pose.shoulder.y}
          x2={pose.pelvis.x}
          y2={pose.pelvis.y}
          stroke={TORSO_WHITE}
          strokeWidth={torsoWidth}
          strokeLinecap="round"
        />

        {/* Primary Leg (strokeWidth=8) */}
        <line
          x1={pose.pelvis.x}
          y1={pose.pelvis.y}
          x2={pose.knee.x}
          y2={pose.knee.y}
          stroke={legsActive ? NEON_BRIGHT : LIMB_PRIMARY}
          strokeWidth={thighWidth}
          strokeLinecap="round"
        />
        <line
          x1={pose.knee.x}
          y1={pose.knee.y}
          x2={pose.ankle.x}
          y2={pose.ankle.y}
          stroke={legsActive ? NEON_BRIGHT : LIMB_PRIMARY}
          strokeWidth={shinWidth}
          strokeLinecap="round"
        />
        <line
          x1={pose.ankle.x}
          y1={pose.ankle.y}
          x2={pose.footTip.x}
          y2={pose.footTip.y}
          stroke={LIMB_PRIMARY}
          strokeWidth={compact ? 4.8 : 5.8}
          strokeLinecap="round"
        />

        {/* Primary Arm (strokeWidth=8) */}
        <line
          x1={pose.shoulder.x}
          y1={pose.shoulder.y}
          x2={pose.elbow.x}
          y2={pose.elbow.y}
          stroke={armsActive ? NEON_BRIGHT : LIMB_PRIMARY}
          strokeWidth={armUpperWidth}
          strokeLinecap="round"
        />
        <line
          x1={pose.elbow.x}
          y1={pose.elbow.y}
          x2={pose.wrist.x}
          y2={pose.wrist.y}
          stroke={armsActive ? NEON_BRIGHT : LIMB_PRIMARY}
          strokeWidth={forearmWidth}
          strokeLinecap="round"
        />
      </g>

      {/* ============================================================
          NEON CYAN ACTIVE MUSCLES (#38BDF8) WITH GLOW
         ============================================================ */}
      <g filter={compact ? undefined : `url(#${glowId})`}>
        {hasMuscle('lats') && (
          <line x1={latsBand.p1.x} y1={latsBand.p1.y} x2={latsBand.p2.x} y2={latsBand.p2.y} stroke={NEON} strokeWidth={compact ? 5 : 6} strokeLinecap="round" />
        )}
        {hasMuscle('chest') && (
          <line x1={chestBand.p1.x} y1={chestBand.p1.y} x2={chestBand.p2.x} y2={chestBand.p2.y} stroke={NEON} strokeWidth={compact ? 5 : 6} strokeLinecap="round" />
        )}
        {hasMuscle('abs') && (
          <line x1={absBand.p1.x} y1={absBand.p1.y} x2={absBand.p2.x} y2={absBand.p2.y} stroke={NEON} strokeWidth={compact ? 4.8 : 5.6} strokeLinecap="round" />
        )}
        {hasMuscle('obliques') && (
          <line x1={obliquesBand.p1.x} y1={obliquesBand.p1.y} x2={obliquesBand.p2.x} y2={obliquesBand.p2.y} stroke={NEON} strokeWidth={compact ? 4.8 : 5.6} strokeLinecap="round" />
        )}
        {hasMuscle('lowerBack') && (
          <line x1={lowerBackBand.p1.x} y1={lowerBackBand.p1.y} x2={lowerBackBand.p2.x} y2={lowerBackBand.p2.y} stroke={NEON} strokeWidth={compact ? 4.5 : 5.2} strokeLinecap="round" />
        )}
        {hasMuscle('shoulders') && (
          <>
            <circle cx={pose.shoulder.x + torsoPerp.x * 1} cy={pose.shoulder.y + torsoPerp.y * 1} r={compact ? 5.6 : 6.8} fill={NEON} />
            {pose.shoulderFar && pose.bilateralFront && (
              <circle cx={pose.shoulderFar.x} cy={pose.shoulderFar.y} r={compact ? 5.2 : 6} fill={NEON} />
            )}
          </>
        )}
        {hasMuscle('biceps') && (
          <line x1={bicepsBand.p1.x} y1={bicepsBand.p1.y} x2={bicepsBand.p2.x} y2={bicepsBand.p2.y} stroke={NEON} strokeWidth={compact ? 4.4 : 5.2} strokeLinecap="round" />
        )}
        {hasMuscle('triceps') && (
          <line x1={tricepsBand.p1.x} y1={tricepsBand.p1.y} x2={tricepsBand.p2.x} y2={tricepsBand.p2.y} stroke={NEON} strokeWidth={compact ? 4.4 : 5.2} strokeLinecap="round" />
        )}
        {hasMuscle('forearms') && (
          <line x1={forearmsBand.p1.x} y1={forearmsBand.p1.y} x2={forearmsBand.p2.x} y2={forearmsBand.p2.y} stroke={NEON} strokeWidth={compact ? 3.8 : 4.6} strokeLinecap="round" />
        )}
        {hasMuscle('quads') && (
          <line x1={quadsBand.p1.x} y1={quadsBand.p1.y} x2={quadsBand.p2.x} y2={quadsBand.p2.y} stroke={NEON} strokeWidth={compact ? 4.8 : 5.8} strokeLinecap="round" />
        )}
        {hasMuscle('glutesHamstrings') && (
          <>
            <circle cx={pose.pelvis.x - 1.5} cy={pose.pelvis.y} r={compact ? 5.2 : 6.2} fill={NEON} />
            <line x1={hamstringsBand.p1.x} y1={hamstringsBand.p1.y} x2={hamstringsBand.p2.x} y2={hamstringsBand.p2.y} stroke={NEON} strokeWidth={compact ? 4.6 : 5.4} strokeLinecap="round" />
          </>
        )}
        {hasMuscle('calves') && (
          <line x1={calvesBand.p1.x} y1={calvesBand.p1.y} x2={calvesBand.p2.x} y2={calvesBand.p2.y} stroke={NEON} strokeWidth={compact ? 4.4 : 5.2} strokeLinecap="round" />
        )}
      </g>

      {/* ============================================================
          LUMINOUS JOINT RINGS (Shoulders, Elbows, Wrists, Hips, Knees, Ankles)
         ============================================================ */}
      {renderJointGlow(pose.wrist, compact ? 3 : 3.8)}
      {renderJointGlow(pose.elbow, compact ? 3 : 3.8)}
      {renderJointGlow(pose.shoulder, compact ? 3.4 : 4.4)}
      {renderJointGlow(pose.pelvis, compact ? 3.4 : 4.4)}
      {renderJointGlow(pose.knee, compact ? 3 : 3.8)}
      {renderJointGlow(pose.ankle, compact ? 2.6 : 3.4)}

      {/* ============================================================
          MOVEMENT DIRECTION ARROWS (#38BDF8)
         ============================================================ */}
      {showArrows &&
        pose.arrows.map((arr, idx) =>
          arr.curved && arr.ctrl ? (
            <path
              key={idx}
              d={`M ${arr.from.x} ${arr.from.y} Q ${arr.ctrl.x} ${arr.ctrl.y} ${arr.to.x} ${arr.to.y}`}
              fill="none"
              stroke={NEON}
              strokeWidth={compact ? 2.1 : 2.6}
              strokeDasharray="4 3"
              markerEnd={`url(#${arrowId})`}
            />
          ) : (
            <line
              key={idx}
              x1={arr.from.x}
              y1={arr.from.y}
              x2={arr.to.x}
              y2={arr.to.y}
              stroke={NEON}
              strokeWidth={compact ? 2.1 : 2.6}
              markerEnd={`url(#${arrowId})`}
            />
          )
        )}

      {/* ============================================================
          1-2 HIGH-CONTRAST IN-CANVAS TECHNIQUE LABELS
         ============================================================ */}
      {!compact &&
        visualLabels.slice(0, 2).map((lbl, idx) => {
          const textWidth = Math.min(138, Math.max(58, lbl.text.length * 4.7 + 12));
          const rectX =
            lbl.anchor === 'end' ? lbl.x - textWidth : lbl.x;
          const textX = rectX + textWidth / 2;
          return (
            <g key={idx}>
              <rect
                x={rectX}
                y={lbl.y - 11}
                width={textWidth}
                height={15}
                rx="4"
                fill="#05070A"
                fillOpacity="0.88"
                stroke={NEON}
                strokeWidth="0.9"
              />
              <text
                x={textX}
                y={lbl.y - 1}
                fill="#FFFFFF"
                fontSize="7.4"
                fontWeight="800"
                textAnchor="middle"
                fontFamily="ui-sans-serif, system-ui, -apple-system, sans-serif"
              >
                {lbl.text}
              </text>
            </g>
          );
        })}
    </svg>
  );
};

interface ExerciseAnimationSVGProps {
  exerciseId: string;
  animationId?: AnimationId;
  exerciseName: string;
  category: ExerciseCategory;
  cues: string[];
}

export const ExerciseAnimationSVG: React.FC<ExerciseAnimationSVGProps> = ({
  exerciseId,
  animationId,
  exerciseName,
  category,
  cues,
}) => {
  const resolvedAnimationId = animationId ?? getExerciseById(exerciseId)?.animationId;
  const dbFolder = getFreeExerciseDbFolder(exerciseId);
  const [photoFailed, setPhotoFailed] = useState(false);
  const [showPhotoMode, setShowPhotoMode] = useState(false);
  const [viewMode, setViewMode] = useState<VisualViewMode>('auto_anim');
  const [photoFrame, setPhotoFrame] = useState<0 | 1>(0);

  const [phaseMode, setPhaseMode] = useState<PhaseMode>('auto');
  const [animProgress, setAnimProgress] = useState<number>(0);

  const spec = getBiomechSpec(
    exerciseId,
    exerciseName,
    category,
    cues,
    resolvedAnimationId
  );

  useEffect(() => {
    setPhotoFailed(false);
    setShowPhotoMode(false);
    setPhotoFrame(0);
    setPhaseMode('auto');
  }, [exerciseId]);

  const showRealPhotos = Boolean(dbFolder) && !photoFailed && showPhotoMode;
  const img0Url = dbFolder ? `${FREE_EXERCISE_DB_BASE}/${dbFolder}/0.jpg` : '';
  const img1Url = dbFolder ? `${FREE_EXERCISE_DB_BASE}/${dbFolder}/1.jpg` : '';

  useEffect(() => {
    if (!showRealPhotos || viewMode !== 'auto_anim') return;
    const id = window.setInterval(() => {
      setPhotoFrame((f) => (f === 0 ? 1 : 0));
    }, 1250);
    return () => window.clearInterval(id);
  }, [showRealPhotos, viewMode]);

  useEffect(() => {
    if (showRealPhotos) return;
    if (phaseMode !== 'auto') {
      setAnimProgress(
        phaseMode === 1
          ? spec.phase1Progress
          : phaseMode === 2
          ? spec.phase2Progress
          : spec.phase3Progress
      );
      return;
    }

    let rafId = 0;
    const startTs = performance.now();
    const cycleMs = spec.isIsometric ? 3000 : 3800;

    const tick = (now: number) => {
      const elapsed = (now - startTs) % cycleMs;
      const u = elapsed / cycleMs;
      let raw: number;
      if (u < 0.12) {
        raw = 0;
      } else if (u < 0.45) {
        raw = (u - 0.12) / 0.33;
      } else if (u < 0.62) {
        raw = 1;
      } else if (u < 0.94) {
        raw = 1 - (u - 0.62) / 0.32;
      } else {
        raw = 0;
      }
      const eased = 0.5 - 0.5 * Math.cos(raw * Math.PI);
      setAnimProgress(eased);
      rafId = window.requestAnimationFrame(tick);
    };

    rafId = window.requestAnimationFrame(tick);
    return () => window.cancelAnimationFrame(rafId);
  }, [
    showRealPhotos,
    phaseMode,
    spec.key,
    spec.isIsometric,
    spec.phase1Progress,
    spec.phase2Progress,
    spec.phase3Progress,
  ]);

  const currentPose = computeBiomechanicalPose(spec.key, animProgress, exerciseId);
  const startPose = computeBiomechanicalPose(spec.key, spec.phase1Progress, exerciseId);
  const peakPose = computeBiomechanicalPose(spec.key, spec.phase2Progress, exerciseId);
  const visualLabels = getVisualCalloutLabels(spec.key, exerciseId);

  const youtubeSearchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(
    `${exerciseName} calisthenics`
  )}`;

  const handleSelectPhase = (next: PhaseMode) => {
    playTechClick();
    setPhaseMode(next);
  };

  return (
    <div className="mt-2.5 rounded-xl bg-[var(--bg-card-elevated)] border border-[var(--border-subtle)] p-3.5 space-y-3">
      {/* Header + Photo / Confronto Switch */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <span className="text-[11px] font-extrabold text-[#38BDF8] uppercase tracking-wider">
          Focus muscolare: {spec.muscleSummaryLabel}
        </span>

        <div className="flex items-center gap-1.5">
          {dbFolder && !photoFailed && (
            <button
              type="button"
              onClick={() => {
                playTechClick();
                setShowPhotoMode((v) => !v);
              }}
              className="px-2 py-1 rounded-lg bg-[var(--bg-main)] border border-[var(--border-subtle)] text-[10px] font-bold text-[var(--text-muted)] hover:text-[var(--text-main)] inline-flex items-center gap-1 transition"
            >
              <Camera className="w-3 h-3" />
              <span>{showPhotoMode ? 'Biomeccanica 1-a-1' : 'Foto Reali'}</span>
            </button>
          )}
          <button
            type="button"
            onClick={() => {
              playTechClick();
              setViewMode((m) => (m === 'auto_anim' ? 'side_by_side' : 'auto_anim'));
            }}
            className="px-2.5 py-1 rounded-lg bg-[var(--bg-card)] border border-[#38BDF8]/50 text-[10px] font-extrabold text-[#38BDF8] inline-flex items-center gap-1 hover:border-[#38BDF8] transition"
          >
            {viewMode === 'auto_anim' ? (
              <>
                <Columns2 className="w-3 h-3" />
                <span>Confronto Affiancato</span>
              </>
            ) : (
              <>
                <Play className="w-3 h-3" />
                <span>Animazione Auto</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Optional Real Photos View */}
      {showRealPhotos ? (
        viewMode === 'auto_anim' ? (
          <div className="rounded-xl bg-[#0B1120] border border-[var(--border-subtle)] p-2.5 space-y-2">
            <div className="flex items-center justify-between text-[11px] font-bold px-1">
              <span className="text-[#38BDF8]">
                {photoFrame === 0 ? spec.phase1Label : spec.phase2Label}
              </span>
              <span className="text-[var(--text-muted)]">Sequenza fotografica reale</span>
            </div>

            <div className="relative rounded-xl overflow-hidden bg-[#FFFFFF]/5 aspect-[16/10] max-h-56 mx-auto flex items-center justify-center">
              <img
                src={photoFrame === 0 ? img0Url : img1Url}
                alt={`${exerciseName} - ${photoFrame === 0 ? 'Posizione iniziale' : 'Massima contrazione'}`}
                onError={() => setPhotoFailed(true)}
                className="w-full h-full object-contain bg-[#FFFFFF] rounded-lg"
                loading="lazy"
              />
              <img
                src={photoFrame === 0 ? img1Url : img0Url}
                alt=""
                onError={() => setPhotoFailed(true)}
                className="hidden"
              />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-xl bg-[#0B1120] border border-[var(--border-subtle)] p-2 space-y-1.5">
              <p className="text-[11px] font-extrabold text-[#38BDF8] truncate">
                {spec.phase1Label}
              </p>
              <div className="rounded-lg overflow-hidden aspect-[4/3] bg-[#FFFFFF]">
                <img
                  src={img0Url}
                  alt={`${exerciseName} - Posizione iniziale`}
                  onError={() => setPhotoFailed(true)}
                  className="w-full h-full object-contain"
                  loading="lazy"
                />
              </div>
            </div>

            <div className="rounded-xl bg-[#0B1120] border border-[#38BDF8]/60 p-2 space-y-1.5">
              <p className="text-[11px] font-extrabold text-[#38BDF8] truncate">
                {spec.phase2Label}
              </p>
              <div className="rounded-lg overflow-hidden aspect-[4/3] bg-[#FFFFFF]">
                <img
                  src={img1Url}
                  alt={`${exerciseName} - Massima contrazione`}
                  onError={() => setPhotoFailed(true)}
                  className="w-full h-full object-contain"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        )
      ) : (
        /* PRIMARY ULTRA-CLEAR 1-TO-1 BIOMECHANICAL BLUEPRINT STAGE */
        <>
          {viewMode === 'auto_anim' && (
            <div className="rounded-xl bg-[#0B1120] border border-[#1E293B] p-2.5 flex flex-col items-center justify-center space-y-2">
              <div className="w-full flex items-center justify-between text-[10px] font-bold px-1">
                <span className="text-[#38BDF8] flex items-center gap-1.5">
                  <span className="inline-block w-2 h-2 rounded-full bg-[#38BDF8] shadow-[0_0_6px_#38BDF8]" />
                  Muscoli &amp; arti attivi in azzurro neon
                </span>
                <span className="text-[#94A3B8]">
                  {spec.apparatusLabel} ·{' '}
                  {phaseMode === 'auto'
                    ? 'Live'
                    : phaseMode === 1
                    ? 'Partenza'
                    : phaseMode === 2
                    ? 'Massimo Sforzo'
                    : 'Chiusura'}
                </span>
              </div>

              <BiomechanicalStageSVG
                pose={currentPose}
                activeMuscles={spec.activeMuscles}
                ariaLabel={`Simulazione biomeccanica dedicata per ${exerciseName}`}
                showArrows
                visualLabels={visualLabels}
              />

              {/* Interactive 3-Phase Buttons + Auto */}
              <div className="w-full grid grid-cols-2 sm:grid-cols-4 gap-1.5 pt-2 border-t border-[#1E293B]">
                <button
                  type="button"
                  onClick={() => handleSelectPhase('auto')}
                  className={`min-h-[36px] px-2 rounded-lg border text-[11px] font-bold inline-flex items-center justify-center gap-1 transition ${
                    phaseMode === 'auto'
                      ? 'bg-[#38BDF8] border-[#38BDF8] text-[#05070A]'
                      : 'bg-[#0F172A] border-[#1E293B] text-[#E2E8F0] hover:border-[#38BDF8]'
                  }`}
                >
                  {phaseMode === 'auto' ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
                  <span>Auto</span>
                </button>

                {(
                  [
                    { phase: 1, label: 'Fase 1: Partenza' },
                    { phase: 2, label: 'Fase 2: Massimo Sforzo' },
                    { phase: 3, label: 'Fase 3: Chiusura' },
                  ] as const
                ).map((btn) => {
                  const active = phaseMode === btn.phase;
                  return (
                    <button
                      key={btn.phase}
                      type="button"
                      onClick={() => handleSelectPhase(btn.phase)}
                      className={`min-h-[36px] px-2 rounded-lg border text-[11px] font-bold transition truncate ${
                        active
                          ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]'
                          : 'bg-[#0F172A] border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF] hover:border-[#38BDF8]/50'
                      }`}
                    >
                      {btn.label}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Side-by-Side Keyframes */}
          <div className="grid grid-cols-2 gap-2">
            <div className="rounded-xl bg-[#0B1120] border border-[#1E293B] p-2 space-y-1">
              <p className="text-[11px] font-extrabold text-[#94A3B8] truncate">
                {spec.phase1Label}
              </p>
              <div className="flex items-center justify-center">
                <BiomechanicalStageSVG
                  pose={startPose}
                  activeMuscles={spec.activeMuscles}
                  ariaLabel={`${exerciseName} - Fase 1 Partenza`}
                  compact
                  showArrows={false}
                />
              </div>
            </div>

            <div className="rounded-xl bg-[#0B1120] border border-[#38BDF8]/60 p-2 space-y-1">
              <p className="text-[11px] font-extrabold text-[#38BDF8] truncate">
                {spec.phase2Label}
              </p>
              <div className="flex items-center justify-center">
                <BiomechanicalStageSVG
                  pose={peakPose}
                  activeMuscles={spec.activeMuscles}
                  ariaLabel={`${exerciseName} - Fase 2 Massimo Sforzo`}
                  compact
                  showArrows
                />
              </div>
            </div>
          </div>
        </>
      )}

      {/* YouTube Real Video Button */}
      <a
        href={youtubeSearchUrl}
        target="_blank"
        rel="noopener noreferrer"
        onClick={() => playTechClick()}
        className="w-full min-h-[42px] px-3.5 rounded-xl bg-[#38BDF8] text-[#05070A] text-xs font-extrabold flex items-center justify-center gap-2 hover:bg-[#7DD3FC] active:scale-[0.99] transition"
      >
        <ExternalLink className="w-4 h-4 shrink-0" />
        <span>Guarda Video Esecuzione Reale (YouTube)</span>
      </a>

      {/* Step-by-Step Text Cues & Mistake Callout */}
      <div className="space-y-1.5">
        <div className="rounded-lg p-2.5 border bg-[var(--bg-main)] border-[var(--border-subtle)]">
          <p className="text-xs text-[var(--text-main)] leading-snug">
            <strong className="text-[#38BDF8]">Fase 1 · Partenza: </strong>
            {spec.phase1Detail}
          </p>
        </div>

        <div className="rounded-lg p-2.5 border bg-[var(--bg-main)] border-[var(--border-subtle)]">
          <p className="text-xs text-[var(--text-main)] leading-snug">
            <strong className="text-[#38BDF8]">Fase 2 · Massimo Sforzo: </strong>
            {spec.phase2Detail}
          </p>
        </div>

        <div className="rounded-lg p-2.5 border bg-[var(--bg-main)] border-[var(--border-subtle)]">
          <p className="text-xs text-[var(--text-main)] leading-snug">
            <strong className="text-[#FFFFFF]">
              Fase 3 · Chiusura:{' '}
            </strong>
            {spec.phase3Detail}
          </p>
        </div>

        <div className="rounded-lg bg-[var(--bg-card)] border border-[#38BDF8]/50 p-2.5 flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-[#38BDF8] shrink-0 mt-0.5" />
          <p className="text-xs text-[var(--text-main)] leading-snug">
            <strong className="text-[#38BDF8]">Attenzione: errore comune da evitare — </strong>
            {spec.commonMistake}
          </p>
        </div>
      </div>
    </div>
  );
};
