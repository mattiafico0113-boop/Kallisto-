import React, { useMemo, useState } from 'react';
import {
  Award,
  BarChart3,
  Calendar as CalendarIcon,
  Camera,
  ChevronLeft,
  ChevronRight,
  Clock,
  ShieldCheck,
  TrendingUp,
  Trophy,
} from 'lucide-react';
import { SKILL_NODE_MAP } from '../data/skills';
import type {
  AthleteProfile,
  BodyWeightEntry,
  ManualWorkoutIntensity,
  MorningCheckinRecord,
  UnlockedSkillRecord,
  WorkoutSessionLog,
} from '../types/calisthenics';
import { formatMorningCheckinSummary } from '../utils/athletePillars';
import { playTechClick } from '../utils/audio';
import { formatDurationShort } from '../utils/voiceCoach';
import { BodyWeightStrengthCard } from './BodyWeightStrengthCard';
import { MonthlyDisciplineChart } from './MonthlyDisciplineChart';
import { PhotoDiarySection } from './PhotoDiarySection';
import { RadarStatsChart } from './RadarStatsChart';

interface HistoryViewProps {
  history: WorkoutSessionLog[];
  profile?: AthleteProfile | null;
  morningCheckins?: MorningCheckinRecord[];
  manualWorkoutDays?: Record<string, ManualWorkoutIntensity>;
  onSetManualWorkoutDay?: (dateKey: string, intensity: ManualWorkoutIntensity | null) => void;
  weightLog?: BodyWeightEntry[];
  onAddWeightEntry?: (entry: { dateISO: string; weightKg: number }) => void;
  onDeleteWeightEntry?: (id: string) => void;
  unlockedSkills?: UnlockedSkillRecord[];
  accountId?: string;
  currentWeightKg?: number;
}

const WEEKDAYS = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];

function getSessionSeconds(s: WorkoutSessionLog): number {
  if (typeof s.durationSeconds === 'number' && s.durationSeconds > 0) {
    return s.durationSeconds;
  }
  return Math.max(60, Math.round((s.durationMinutes || 0) * 60));
}

function findPreviousSession(
  session: WorkoutSessionLog,
  history: WorkoutSessionLog[]
): WorkoutSessionLog | null {
  const idx = history.findIndex((s) => s.id === session.id);
  if (idx < 0 || idx >= history.length - 1) return null;
  const earlier = history.slice(idx + 1);
  const sameSplit = earlier.find(
    (s) => s.dayPlanId === session.dayPlanId || s.dayTitle === session.dayTitle
  );
  return sameSplit ?? earlier[0] ?? null;
}

function buildDurationComparison(
  current: WorkoutSessionLog,
  prev: WorkoutSessionLog | null
): { text: string; isFaster: boolean | null } {
  const curSec = getSessionSeconds(current);
  const curLabel = formatDurationShort(curSec);
  if (!prev) {
    return { text: `Durata: ${curLabel}`, isFaster: null };
  }
  const prevSec = getSessionSeconds(prev);
  const diffSec = prevSec - curSec;
  if (Math.abs(diffSec) < 20) {
    return {
      text: `Durata: ${curLabel} — stessa durata rispetto all'ultima volta`,
      isFaster: null,
    };
  }
  const absDiff = Math.abs(diffSec);
  const diffLabel = absDiff >= 60 ? `${Math.round(absDiff / 60)} min` : `${absDiff}s`;
  if (diffSec > 0) {
    return {
      text: `Durata: ${curLabel} — ${diffLabel} più veloce rispetto all'ultima volta!`,
      isFaster: true,
    };
  }
  return {
    text: `Durata: ${curLabel} — ${diffLabel} in più rispetto all'ultima volta`,
    isFaster: false,
  };
}

export const HistoryView: React.FC<HistoryViewProps> = ({
  history,
  profile = null,
  morningCheckins = [],
  manualWorkoutDays = {},
  onSetManualWorkoutDay,
  weightLog = [],
  onAddWeightEntry,
  onDeleteWeightEntry,
  unlockedSkills = [],
  accountId = 'guest',
  currentWeightKg,
}) => {
  const [subTab, setSubTab] = useState<'stats' | 'photos'>('stats');
  const [monthOffset, setMonthOffset] = useState(0);
  const [selectedSessionId, setSelectedSessionId] = useState<string | null>(
    history[0]?.id ?? null
  );

  // Unique exercises recorded across history for progression charts
  const trackedExercises = useMemo(() => {
    const map = new Map<string, { id: string; name: string; isIsometric: boolean; count: number }>();
    for (const s of history) {
      for (const ex of s.exercises) {
        const prev = map.get(ex.exerciseId);
        map.set(ex.exerciseId, {
          id: ex.exerciseId,
          name: ex.exerciseName,
          isIsometric: ex.isIsometric,
          count: (prev?.count ?? 0) + 1,
        });
      }
    }
    return Array.from(map.values()).sort((a, b) => b.count - a.count);
  }, [history]);

  const [selectedChartExId, setSelectedChartExId] = useState<string>('');
  const activeChartExId =
    selectedChartExId && trackedExercises.some((e) => e.id === selectedChartExId)
      ? selectedChartExId
      : trackedExercises[0]?.id ?? '';

  const activeChartEx = trackedExercises.find((e) => e.id === activeChartExId);

  const chartPoints = useMemo(() => {
    if (!activeChartExId) return [];
    const pts: { dateLabel: string; bestValue: number; avgRpe: number }[] = [];
    // Oldest to newest
    for (let i = history.length - 1; i >= 0; i--) {
      const s = history[i];
      const rec = s.exercises.find((e) => e.exerciseId === activeChartExId);
      if (rec) {
        pts.push({
          dateLabel: new Date(s.dateISO).toLocaleDateString('it-IT', {
            day: '2-digit',
            month: '2-digit',
          }),
          bestValue: rec.bestValue,
          avgRpe: rec.avgRpe,
        });
      }
    }
    return pts;
  }, [history, activeChartExId]);

  // Calendar computation
  const today = new Date();
  const displayDate = new Date(today.getFullYear(), today.getMonth() + monthOffset, 1);
  const year = displayDate.getFullYear();
  const month = displayDate.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayMondayIndex = (displayDate.getDay() + 6) % 7;

  const sessionsByDayKey = useMemo(() => {
    const map = new Map<string, WorkoutSessionLog[]>();
    for (const s of history) {
      const d = new Date(s.dateISO);
      const key = `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
      const list = map.get(key) ?? [];
      list.push(s);
      map.set(key, list);
    }
    return map;
  }, [history]);

  const selectedSession =
    history.find((s) => s.id === selectedSessionId) ?? history[0] ?? null;

  const totalSessions = history.length;
  const avgOverallRpe =
    history.length > 0
      ? (history.reduce((acc, s) => acc + s.avgRpe, 0) / history.length).toFixed(1)
      : '—';

  // Revisione Mensile (current calendar month vs previous month)
  const monthlyReview = useMemo(() => {
    const now = new Date();
    const curYear = now.getFullYear();
    const curMonth = now.getMonth();
    const prevRef = new Date(curYear, curMonth - 1, 1);
    const prevYear = prevRef.getFullYear();
    const prevMonth = prevRef.getMonth();

    const monthName = now.toLocaleDateString('it-IT', { month: 'long', year: 'numeric' });

    const curSessions = history
      .filter((s) => {
        const d = new Date(s.dateISO);
        return d.getFullYear() === curYear && d.getMonth() === curMonth;
      })
      .sort((a, b) => new Date(a.dateISO).getTime() - new Date(b.dateISO).getTime());

    const prevSessions = history.filter((s) => {
      const d = new Date(s.dateISO);
      return d.getFullYear() === prevYear && d.getMonth() === prevMonth;
    });

    const totalSec = curSessions.reduce((acc, s) => acc + getSessionSeconds(s), 0);
    const prevTotalSec = prevSessions.reduce((acc, s) => acc + getSessionSeconds(s), 0);

    const techRatings = curSessions.flatMap((s) =>
      s.exercises
        .map((e) => e.technicalScore)
        .filter((v): v is 1 | 2 | 3 => v === 1 || v === 2 || v === 3)
    );
    const avgTech =
      techRatings.length > 0
        ? (techRatings.reduce((a, b) => a + b, 0) / techRatings.length).toFixed(2)
        : null;

    const prevTechRatings = prevSessions.flatMap((s) =>
      s.exercises
        .map((e) => e.technicalScore)
        .filter((v): v is 1 | 2 | 3 => v === 1 || v === 2 || v === 3)
    );
    const prevAvgTech =
      prevTechRatings.length > 0
        ? prevTechRatings.reduce((a, b) => a + b, 0) / prevTechRatings.length
        : null;

    const curAvgRpe =
      curSessions.length > 0
        ? curSessions.reduce((acc, s) => acc + s.avgRpe, 0) / curSessions.length
        : null;
    const prevAvgRpe =
      prevSessions.length > 0
        ? prevSessions.reduce((acc, s) => acc + s.avgRpe, 0) / prevSessions.length
        : null;

    const rpePoints = curSessions.map((s) => ({
      label: new Date(s.dateISO).toLocaleDateString('it-IT', {
        day: '2-digit',
        month: '2-digit',
      }),
      rpe: Number(s.avgRpe.toFixed(1)),
    }));

    // Total volume improvements across matching exercises
    const bestByExCur = new Map<string, { name: string; best: number; iso: boolean }>();
    const bestByExPrev = new Map<string, number>();

    for (const s of prevSessions) {
      for (const ex of s.exercises) {
        const cur = bestByExPrev.get(ex.exerciseId) ?? 0;
        if (ex.bestValue > cur) bestByExPrev.set(ex.exerciseId, ex.bestValue);
      }
    }
    for (const s of curSessions) {
      for (const ex of s.exercises) {
        const cur = bestByExCur.get(ex.exerciseId);
        if (!cur || ex.bestValue > cur.best) {
          bestByExCur.set(ex.exerciseId, {
            name: ex.exerciseName,
            best: ex.bestValue,
            iso: ex.isIsometric,
          });
        }
      }
    }

    const improvements: string[] = [];
    const sessDelta = curSessions.length - prevSessions.length;
    if (curSessions.length === 0) {
      improvements.push('Completa il primo allenamento del mese per generare il confronto mensile.');
    } else {
      if (prevSessions.length > 0) {
        if (sessDelta > 0) {
          improvements.push(`+${sessDelta} sedute completate rispetto al mese scorso.`);
        } else if (sessDelta === 0) {
          improvements.push(`Frequenza stabile (${curSessions.length} sedute come il mese scorso).`);
        } else {
          improvements.push(
            `${curSessions.length} sedute questo mese (mese scorso: ${prevSessions.length}).`
          );
        }

        const timeDeltaMin = Math.round((totalSec - prevTotalSec) / 60);
        if (timeDeltaMin > 0) {
          improvements.push(`+${timeDeltaMin} minuti di volume allenante rispetto al mese precedente.`);
        }
      } else {
        improvements.push(`${curSessions.length} sedute registrate finora in questo mese.`);
      }

      if (avgTech !== null && prevAvgTech !== null) {
        const techDiff = Number(avgTech) - prevAvgTech;
        if (techDiff >= 0.1) {
          improvements.push(
            `Qualità tecnica migliorata (+${techDiff.toFixed(2)} punti su scala 1–3).`
          );
        }
      } else if (avgTech !== null) {
        improvements.push(`Qualità tecnica media del mese: ${avgTech}/3.`);
      }

      if (curAvgRpe !== null && prevAvgRpe !== null) {
        const rpeDiff = curAvgRpe - prevAvgRpe;
        improvements.push(
          `Intensità media RPE ${curAvgRpe.toFixed(1)} (${
            rpeDiff >= 0 ? `+${rpeDiff.toFixed(1)}` : rpeDiff.toFixed(1)
          } vs mese scorso).`
        );
      }

      let prCount = 0;
      bestByExCur.forEach((val, id) => {
        const prevBest = bestByExPrev.get(id);
        if (prevBest !== undefined && val.best > prevBest && prCount < 2) {
          prCount++;
          improvements.push(
            `${val.name}: migliorato da ${prevBest}${val.iso ? 's' : ' rep'} a ${val.best}${
              val.iso ? 's' : ' rep'
            }.`
          );
        }
      });
    }

    const totalHours = Math.floor(totalSec / 3600);
    const totalRemMins = Math.round((totalSec % 3600) / 60);
    const totalTimeLabel =
      totalSec === 0
        ? '0 min'
        : totalHours > 0
        ? `${totalHours}h ${totalRemMins}m`
        : `${Math.max(1, Math.round(totalSec / 60))} min`;

    return {
      monthName,
      sessionCount: curSessions.length,
      totalTimeLabel,
      avgTech,
      curAvgRpe: curAvgRpe !== null ? curAvgRpe.toFixed(1) : '—',
      rpePoints,
      improvements,
    };
  }, [history]);

  return (
    <div className="space-y-4 pb-8">
      {/* Sub-navigation between Stats/Radar and Photo Diary */}
      <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-[#0F172A] border border-[#1E293B]">
        <button
          type="button"
          onClick={() => {
            playTechClick();
            setSubTab('stats');
          }}
          className={`min-h-[42px] rounded-xl text-xs font-extrabold inline-flex items-center justify-center gap-1.5 transition ${
            subTab === 'stats'
              ? 'bg-[#2563EB] text-[#FFFFFF] shadow-[0_0_16px_rgba(37,99,235,0.3)]'
              : 'text-[#94A3B8] hover:text-[#FFFFFF]'
          }`}
        >
          <BarChart3 className="w-4 h-4" />
          <span>Statistiche &amp; Radar</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playTechClick();
            setSubTab('photos');
          }}
          className={`min-h-[42px] rounded-xl text-xs font-extrabold inline-flex items-center justify-center gap-1.5 transition ${
            subTab === 'photos'
              ? 'bg-[#00D2FF] text-[#05070A] shadow-[0_0_16px_rgba(0,210,255,0.28)]'
              : 'text-[#94A3B8] hover:text-[#FFFFFF]'
          }`}
        >
          <Camera className="w-4 h-4" />
          <span>Diario Fotografico</span>
        </button>
      </div>

      {subTab === 'photos' ? (
        <PhotoDiarySection accountId={accountId} currentWeightKg={currentWeightKg} />
      ) : (
        <>
      {/* Interactive Monthly Discipline Chart (Settembre 2026 - Dicembre 2030) */}
      <MonthlyDisciplineChart
        history={history}
        manualWorkoutDays={manualWorkoutDays}
        onSetManualWorkoutDay={(dateKey, intensity) => {
          onSetManualWorkoutDay?.(dateKey, intensity);
        }}
      />

      {/* Body Weight Chart & Relative Strength Index */}
      {onAddWeightEntry && onDeleteWeightEntry && (
        <BodyWeightStrengthCard
          profile={profile}
          history={history}
          weightLog={weightLog}
          onAddWeightEntry={onAddWeightEntry}
          onDeleteWeightEntry={onDeleteWeightEntry}
        />
      )}

      {/* Recent Morning Check-ins Log */}
      {morningCheckins.length > 0 && (
        <section
          className="rounded-2xl border p-4 sm:p-5 space-y-2.5"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        >
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-sm sm:text-base font-extrabold">Check-in Mattutini Recenti</h2>
            <span className="font-mono text-xs font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
              {morningCheckins.length} registrati
            </span>
          </div>
          <div className="space-y-1.5">
            {morningCheckins.slice(0, 5).map((c) => (
              <div
                key={c.id}
                className="rounded-xl border px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: c.jointStatus !== 'ok' ? '#F59E0B' : 'var(--border-subtle)',
                }}
              >
                <span className="font-mono font-bold" style={{ color: 'var(--accent)' }}>
                  {new Date(c.timestampISO).toLocaleDateString('it-IT', {
                    day: '2-digit',
                    month: 'short',
                  })}
                </span>
                <span className="flex-1 min-w-0 truncate" style={{ color: 'var(--text-secondary)' }}>
                  {formatMorningCheckinSummary(c)}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Revisione Mensile Section */}
      <section className="rounded-2xl bg-[#0B1D36] border border-[#2563EB]/60 p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#00D2FF]" />
            <h2 className="text-base font-extrabold text-[#FFFFFF] capitalize">
              Revisione Mensile · {monthlyReview.monthName}
            </h2>
          </div>
          <span className="font-mono text-xs font-bold text-[#38BDF8] tabular-nums">
            RPE medio {monthlyReview.curAvgRpe}
          </span>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3">
            <p className="text-[11px] text-[#94A3B8]">Sessioni mese</p>
            <p className="font-mono text-xl sm:text-2xl font-extrabold text-[#FFFFFF] mt-0.5 tabular-nums">
              {monthlyReview.sessionCount}
            </p>
          </div>
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3">
            <p className="text-[11px] text-[#94A3B8]">Tempo totale</p>
            <p className="font-mono text-xl sm:text-2xl font-extrabold text-[#38BDF8] mt-0.5 tabular-nums">
              {monthlyReview.totalTimeLabel}
            </p>
          </div>
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3">
            <p className="text-[11px] text-[#94A3B8]">Voto tecnica (1–3)</p>
            <p className="font-mono text-xl sm:text-2xl font-extrabold text-[#00D2FF] mt-0.5 tabular-nums">
              {monthlyReview.avgTech ?? '—'}
            </p>
          </div>
        </div>

        {/* Monthly RPE / Intensity SVG Chart */}
        {monthlyReview.rpePoints.length > 0 && (
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3 space-y-1.5">
            <p className="text-[11px] font-semibold text-[#94A3B8]">
              Andamento intensità / RPE nel mese
            </p>
            {(() => {
              const pts = monthlyReview.rpePoints;
              const w = 340;
              const h = 92;
              const padX = 20;
              const padY = 16;
              const coords = pts.map((pt, idx) => {
                const x =
                  pts.length === 1 ? w / 2 : padX + (idx / (pts.length - 1)) * (w - padX * 2);
                const clampedRpe = Math.max(5, Math.min(10, pt.rpe));
                const y = h - padY - ((clampedRpe - 5) / 5) * (h - padY * 2);
                return { ...pt, x, y };
              });
              const poly = coords.map((c) => `${c.x},${c.y}`).join(' ');
              return (
                <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-24 overflow-visible">
                  <line x1={padX} y1={h - padY} x2={w - padX} y2={h - padY} stroke="var(--border-subtle)" />
                  <line
                    x1={padX}
                    y1={padY}
                    x2={w - padX}
                    y2={padY}
                    stroke="var(--border-subtle)"
                    strokeDasharray="3 3"
                  />
                  {coords.length > 1 && (
                    <polyline
                      fill="none"
                      stroke="var(--accent)"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      points={poly}
                    />
                  )}
                  {coords.map((c, idx) => (
                    <g key={idx}>
                      <circle
                        cx={c.x}
                        cy={c.y}
                        r="4"
                        fill="var(--bg-main)"
                        stroke="var(--accent-soft)"
                        strokeWidth="2.5"
                      />
                      <text
                        x={c.x}
                        y={c.y - 8}
                        textAnchor="middle"
                        fill="var(--text-main)"
                        fontSize="9"
                        fontFamily="JetBrains Mono, monospace"
                        fontWeight="700"
                      >
                        {c.rpe}
                      </text>
                      <text x={c.x} y={h - 2} textAnchor="middle" fill="var(--text-muted)" fontSize="8">
                        {c.label}
                      </text>
                    </g>
                  ))}
                </svg>
              );
            })()}
          </div>
        )}

        {/* Key Monthly Improvements */}
        <div className="space-y-1">
          <p className="text-[11px] font-bold text-[#38BDF8] uppercase tracking-wider">
            Confronto &amp; Miglioramenti vs mese precedente
          </p>
          <ul className="space-y-1 text-xs text-[#CBD5E1]">
            {monthlyReview.improvements.map((line, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-[#00D2FF] font-bold">•</span>
                <span>{line}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* Videogame-style 5-Vertex Radar Spider Chart */}
      <RadarStatsChart history={history} unlockedSkills={unlockedSkills} />

      {/* Top KPI Summary Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <div className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4">
          <p className="text-xs text-[#94A3B8]">Sedute completate</p>
          <p className="font-mono text-2xl font-extrabold text-[#FFFFFF] mt-1 tabular-nums">
            {totalSessions}
          </p>
        </div>
        <div className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4">
          <p className="text-xs text-[#94A3B8]">RPE medio storico</p>
          <p className="font-mono text-2xl font-extrabold text-[#38BDF8] mt-1 tabular-nums">
            {avgOverallRpe}
          </p>
        </div>
        <div className="col-span-2 sm:col-span-1 rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4">
          <p className="text-xs text-[#94A3B8]">Esercizi tracciati</p>
          <p className="font-mono text-2xl font-extrabold text-[#00D2FF] mt-1 tabular-nums">
            {trackedExercises.length}
          </p>
        </div>
      </div>

      {/* Progression Chart */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-[#38BDF8]" />
            <h2 className="text-base font-bold text-[#FFFFFF]">Grafico Progressione</h2>
          </div>
          {activeChartEx && (
            <span className="text-xs text-[#94A3B8]">
              {activeChartEx.isIsometric ? 'Secondi di tenuta max' : 'Ripetizioni max / serie'}
            </span>
          )}
        </div>

        {trackedExercises.length > 0 ? (
          <>
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-1">
              {trackedExercises.slice(0, 8).map((ex) => (
                <button
                  key={ex.id}
                  type="button"
                  onClick={() => setSelectedChartExId(ex.id)}
                  className={`min-h-[36px] px-3 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition ${
                    ex.id === activeChartExId
                      ? 'bg-[#2563EB] text-[#FFFFFF] font-bold'
                      : 'bg-[#131C31] text-[#CBD5E1] hover:text-[#FFFFFF]'
                  }`}
                >
                  {ex.name}
                </button>
              ))}
            </div>

            {chartPoints.length > 0 && (
              <div className="pt-2">
                {(() => {
                  const maxVal = Math.max(...chartPoints.map((p) => p.bestValue), 5);
                  const minVal = Math.max(0, Math.min(...chartPoints.map((p) => p.bestValue)) - 2);
                  const range = Math.max(1, maxVal - minVal);
                  const w = 360;
                  const h = 140;
                  const padX = 24;
                  const padY = 18;

                  const coords = chartPoints.map((pt, idx) => {
                    const x =
                      chartPoints.length === 1
                        ? w / 2
                        : padX + (idx / (chartPoints.length - 1)) * (w - padX * 2);
                    const y = h - padY - ((pt.bestValue - minVal) / range) * (h - padY * 2);
                    return { ...pt, x, y };
                  });

                  const polyPoints = coords.map((c) => `${c.x},${c.y}`).join(' ');

                  return (
                    <div className="w-full overflow-hidden">
                      <svg
                        viewBox={`0 0 ${w} ${h}`}
                        className="w-full h-40 overflow-visible"
                        role="img"
                        aria-label={`Progressione ${activeChartEx?.name}`}
                      >
                        <line
                          x1={padX}
                          y1={h - padY}
                          x2={w - padX}
                          y2={h - padY}
                          stroke="var(--border-subtle)"
                        />
                        <line
                          x1={padX}
                          y1={padY}
                          x2={w - padX}
                          y2={padY}
                          stroke="var(--border-subtle)"
                          strokeDasharray="3 3"
                        />
                        {coords.length > 1 && (
                          <polyline
                            fill="none"
                            stroke={activeChartEx?.isIsometric ? 'var(--accent)' : 'var(--accent-soft)'}
                            strokeWidth="3"
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            points={polyPoints}
                          />
                        )}
                        {coords.map((c, idx) => (
                          <g key={idx}>
                            <circle
                              cx={c.x}
                              cy={c.y}
                              r="5"
                              fill="var(--bg-elevated)"
                              stroke={activeChartEx?.isIsometric ? 'var(--accent)' : 'var(--accent-soft)'}
                              strokeWidth="3"
                            />
                            <text
                              x={c.x}
                              y={c.y - 10}
                              textAnchor="middle"
                              fill="var(--text-main)"
                              fontSize="10"
                              fontFamily="JetBrains Mono, monospace"
                              fontWeight="700"
                            >
                              {c.bestValue}
                              {activeChartEx?.isIsometric ? 's' : ''}
                            </text>
                            <text
                              x={c.x}
                              y={h - 2}
                              textAnchor="middle"
                              fill="var(--text-muted)"
                              fontSize="9"
                            >
                              {c.dateLabel}
                            </text>
                          </g>
                        ))}
                      </svg>
                    </div>
                  );
                })()}
              </div>
            )}
          </>
        ) : (
          <p className="text-xs text-[#94A3B8]">
            Completa almeno un allenamento nella sezione Scheda per sbloccare i grafici di progressione.
          </p>
        )}
      </section>

      {/* Calendar + Selected Session Details */}
      <div className="grid grid-cols-1 gap-4 items-start">
        <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <CalendarIcon className="w-4 h-4 text-[#38BDF8]" />
              <h2 className="text-base font-bold text-[#FFFFFF] capitalize">
                {displayDate.toLocaleDateString('it-IT', { month: 'long', year: 'numeric' })}
              </h2>
            </div>
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => setMonthOffset((m) => m - 1)}
                aria-label="Mese precedente"
                className="min-h-[38px] min-w-[38px] rounded-xl bg-[#131C31] flex items-center justify-center text-[#CBD5E1] hover:text-[#FFFFFF]"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setMonthOffset((m) => m + 1)}
                aria-label="Mese successivo"
                className="min-h-[38px] min-w-[38px] rounded-xl bg-[#131C31] flex items-center justify-center text-[#CBD5E1] hover:text-[#FFFFFF]"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-semibold text-[#94A3B8] mb-2">
            {WEEKDAYS.map((wd) => (
              <div key={wd}>{wd}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-1.5">
            {Array.from({ length: firstDayMondayIndex }).map((_, i) => (
              <div key={`empty_${i}`} className="h-10" />
            ))}
            {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((dayNum) => {
              const key = `${year}-${month}-${dayNum}`;
              const daySessions = sessionsByDayKey.get(key) ?? [];
              const hasWorkout = daySessions.length > 0;
              const isSelected =
                hasWorkout && daySessions.some((s) => s.id === selectedSession?.id);
              return (
                <button
                  key={dayNum}
                  type="button"
                  disabled={!hasWorkout}
                  onClick={() => {
                    if (daySessions[0]) setSelectedSessionId(daySessions[0].id);
                  }}
                  className={`h-10 rounded-xl font-mono text-xs font-bold tabular-nums flex items-center justify-center transition ${
                    isSelected
                      ? 'bg-[#2563EB] text-[#FFFFFF] border border-[#38BDF8]'
                      : hasWorkout
                      ? 'bg-[#132347] border border-[#38BDF8]/50 text-[#38BDF8] hover:bg-[#1E3A6E]'
                      : 'bg-[#090D16] text-[#64748B] cursor-default'
                  }`}
                >
                  {dayNum}
                </button>
              );
            })}
          </div>
        </section>

        {/* Session Log Detail */}
        <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-4">
          <h2 className="text-base font-bold text-[#FFFFFF]">Dettaglio Sessione</h2>
          {selectedSession ? (
            <div className="space-y-3">
              <div className="pb-3 border-b border-[#1E293B] space-y-2">
                <p className="text-xs text-[#94A3B8]">
                  {new Date(selectedSession.dateISO).toLocaleDateString('it-IT', {
                    weekday: 'long',
                    day: '2-digit',
                    month: 'long',
                  })}{' '}
                  · {formatDurationShort(getSessionSeconds(selectedSession))} · RPE medio{' '}
                  {selectedSession.avgRpe.toFixed(1)}
                </p>
                <p className="text-lg font-extrabold text-[#FFFFFF]">
                  {selectedSession.dayTitle}
                </p>

                {(() => {
                  const prev = findPreviousSession(selectedSession, history);
                  const cmp = buildDurationComparison(selectedSession, prev);
                  return (
                    <div
                      className={`rounded-xl px-3 py-2 border flex items-center gap-2 text-xs font-semibold ${
                        cmp.isFaster
                          ? 'bg-[#0B1D36] border-[#00D2FF]/60 text-[#00D2FF]'
                          : 'bg-[#131C31] border-[#1E293B] text-[#CBD5E1]'
                      }`}
                    >
                      <Clock className="w-3.5 h-3.5 text-[#38BDF8] shrink-0" />
                      <span>{cmp.text}</span>
                    </div>
                  );
                })()}
              </div>

              <div className="space-y-2.5">
                {selectedSession.exercises.map((ex) => (
                  <div
                    key={ex.exerciseId}
                    className="p-3 rounded-xl bg-[#090D16] border border-[#1E293B] flex items-center justify-between gap-3"
                  >
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-[#FFFFFF] truncate">
                        {ex.exerciseName}
                      </p>
                      <p className="text-xs text-[#94A3B8] tabular-nums">
                        {ex.sets.filter((s) => s.completed).length}/{ex.sets.length} serie · RPE{' '}
                        {ex.avgRpe ? ex.avgRpe.toFixed(1) : '-'}
                        {ex.maxAddedWeightKg > 0 ? ` · +${ex.maxAddedWeightKg}kg` : ''}
                        {ex.technicalScore
                          ? ` · Tecnica ${ex.technicalScore}/3`
                          : ''}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="font-mono text-sm font-bold text-[#38BDF8] tabular-nums">
                        Best {ex.bestValue}
                        {ex.isIsometric ? 's' : ' rep'}
                      </p>
                      {ex.technicalScore && (
                        <p className="inline-flex items-center gap-1 text-[11px] font-bold text-[#00D2FF] tabular-nums">
                          <ShieldCheck className="w-3 h-3" />
                          <span>
                            {ex.technicalScore === 3
                              ? 'Pulita'
                              : ex.technicalScore === 2
                              ? 'Al limite'
                              : 'Sporca'}
                          </span>
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {selectedSession.coachFeedback && (
                <div className="p-3.5 rounded-xl bg-[#131C31] border border-[#1E293B]">
                  <p className="text-xs font-bold text-[#38BDF8] mb-1">Nota del Coach AI</p>
                  <p className="text-xs text-[#CBD5E1] leading-relaxed">
                    {selectedSession.coachFeedback}
                  </p>
                </div>
              )}

              {history.length > 0 && (
                <div className="pt-2">
                  <p className="text-xs font-semibold text-[#94A3B8] mb-2">Ultime sessioni</p>
                  <div className="space-y-1.5">
                    {history.slice(0, 8).map((s) => {
                      const prevS = findPreviousSession(s, history);
                      const cmp = buildDurationComparison(s, prevS);
                      return (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => setSelectedSessionId(s.id)}
                          className={`w-full text-left px-3 py-2.5 rounded-xl text-xs transition ${
                            s.id === selectedSession.id
                              ? 'bg-[#132347] border border-[#2563EB] text-[#FFFFFF] font-bold'
                              : 'bg-[#090D16] text-[#CBD5E1] hover:bg-[#131C31]'
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="truncate">{s.dayTitle}</span>
                            <span className="font-mono tabular-nums shrink-0 text-[#38BDF8]">
                              {formatDurationShort(getSessionSeconds(s))} ·{' '}
                              {new Date(s.dateISO).toLocaleDateString('it-IT', {
                                day: '2-digit',
                                month: '2-digit',
                              })}
                            </span>
                          </div>
                          {prevS && (
                            <p
                              className={`text-[11px] mt-0.5 ${
                                cmp.isFaster ? 'text-[#00D2FF]' : 'text-[#94A3B8]'
                              }`}
                            >
                              {cmp.text}
                            </p>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <p className="text-xs text-[#94A3B8]">
              Nessuna sessione registrata finora. Completa il tuo primo allenamento nella scheda!
            </p>
          )}
        </section>
      </div>

      {/* Certified Skill Milestones */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-[#00D2FF]" />
            <h2 className="text-base font-bold text-[#FFFFFF]">Skill Sbloccate e Certificate</h2>
          </div>
          <span className="font-mono text-xs font-bold text-[#38BDF8] tabular-nums">
            {unlockedSkills.length} traguardi
          </span>
        </div>

        {unlockedSkills.length === 0 ? (
          <p className="text-xs text-[#94A3B8]">
            I badge delle Skill sbloccate con la fotocamera appariranno qui con data e prestazione certificata.
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {unlockedSkills.map((rec) => {
              const def = SKILL_NODE_MAP[rec.skillId];
              if (!def) return null;
              return (
                <div
                  key={rec.skillId}
                  className="rounded-xl bg-[#090D16] border border-[#38BDF8]/40 p-3 flex items-center justify-between gap-2.5"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-[#132347] border border-[#38BDF8]/50 text-[#00D2FF] flex items-center justify-center shrink-0">
                      <Award className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-[#FFFFFF] truncate">{def.name}</p>
                      <p className="text-[11px] text-[#94A3B8]">
                        {new Date(rec.unlockedAtISO).toLocaleDateString('it-IT', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                  <span className="font-mono text-xs font-bold text-[#38BDF8] tabular-nums shrink-0">
                    {rec.achievedValue}
                    {def.mode === 'isometric' ? 's' : ' rep'}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </section>
        </>
      )}
    </div>
  );
};
