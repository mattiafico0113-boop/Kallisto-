import React, { useMemo, useState } from 'react';
import { CalendarDays, Check, ChevronLeft, ChevronRight, Flame, Trash2 } from 'lucide-react';
import type {
  ManualWorkoutIntensity,
  WorkoutSessionLog,
} from '../types/calisthenics';
import { playSetCompleteTone, playTechClick } from '../utils/audio';

interface MonthlyDisciplineChartProps {
  history: WorkoutSessionLog[];
  manualWorkoutDays: Record<string, ManualWorkoutIntensity>;
  onSetManualWorkoutDay: (dateKey: string, intensity: ManualWorkoutIntensity | null) => void;
}

const MONTH_NAMES = [
  'Gennaio',
  'Febbraio',
  'Marzo',
  'Aprile',
  'Maggio',
  'Giugno',
  'Luglio',
  'Agosto',
  'Settembre',
  'Ottobre',
  'Novembre',
  'Dicembre',
];

const WEEKDAY_SHORT = ['Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab', 'Dom'];

// Allowed range: Settembre 2026 (2026 * 12 + 8) -> Dicembre 2030 (2030 * 12 + 11)
const MIN_MONTH_INDEX = 2026 * 12 + 8; // Sept 2026
const MAX_MONTH_INDEX = 2030 * 12 + 11; // Dec 2030

const ALL_SELECTABLE_MONTHS: { index: number; year: number; month: number; label: string }[] = [];
for (let idx = MIN_MONTH_INDEX; idx <= MAX_MONTH_INDEX; idx++) {
  const year = Math.floor(idx / 12);
  const month = idx % 12;
  ALL_SELECTABLE_MONTHS.push({
    index: idx,
    year,
    month,
    label: `${MONTH_NAMES[month]} ${year}`,
  });
}

function getInitialMonthIndex(): number {
  const now = new Date();
  const idx = now.getFullYear() * 12 + now.getMonth();
  return Math.max(MIN_MONTH_INDEX, Math.min(MAX_MONTH_INDEX, idx));
}

function toDateKey(year: number, monthZeroBased: number, day: number): string {
  return `${year}-${String(monthZeroBased + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export const MonthlyDisciplineChart: React.FC<MonthlyDisciplineChartProps> = ({
  history,
  manualWorkoutDays,
  onSetManualWorkoutDay,
}) => {
  const [monthIndex, setMonthIndex] = useState<number>(() => getInitialMonthIndex());
  const [selectedDateKey, setSelectedDateKey] = useState<string | null>(null);

  const currentYear = Math.floor(monthIndex / 12);
  const currentMonth = monthIndex % 12;
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();

  // Offset so Monday = 0 .. Sunday = 6
  const firstWeekdayMon = (new Date(currentYear, currentMonth, 1).getDay() + 6) % 7;

  // Map logged workout sessions by YYYY-MM-DD local date
  const autoSessionsByDate = useMemo(() => {
    const map = new Map<string, { intensity: ManualWorkoutIntensity; count: number; title: string }>();
    for (const sess of history) {
      const d = new Date(sess.dateISO);
      if (!Number.isFinite(d.getTime())) continue;
      const key = toDateKey(d.getFullYear(), d.getMonth(), d.getDate());
      const intensity: ManualWorkoutIntensity =
        sess.avgRpe >= 8.5 ? 'alta' : sess.avgRpe >= 7 ? 'media' : 'leggera';
      const prev = map.get(key);
      map.set(key, {
        intensity: prev && prev.intensity === 'alta' ? 'alta' : intensity,
        count: (prev?.count ?? 0) + 1,
        title: sess.dayTitle,
      });
    }
    return map;
  }, [history]);

  const monthDays = useMemo(() => {
    return Array.from({ length: daysInMonth }, (_, i) => {
      const day = i + 1;
      const dateKey = toDateKey(currentYear, currentMonth, day);
      const auto = autoSessionsByDate.get(dateKey);
      const manual = manualWorkoutDays[dateKey];
      const effectiveIntensity: ManualWorkoutIntensity | null =
        manual ?? auto?.intensity ?? null;

      return {
        day,
        dateKey,
        auto,
        manual,
        effectiveIntensity,
        trained: Boolean(effectiveIntensity),
      };
    });
  }, [daysInMonth, currentYear, currentMonth, autoSessionsByDate, manualWorkoutDays]);

  const trainedDaysCount = monthDays.filter((d) => d.trained).length;
  const disciplinePct = daysInMonth > 0 ? Math.round((trainedDaysCount / daysInMonth) * 100) : 0;

  const selectedDayInfo = selectedDateKey
    ? monthDays.find((d) => d.dateKey === selectedDateKey) ?? null
    : null;

  const barHeightFor = (intensity: ManualWorkoutIntensity | null): number => {
    if (!intensity) return 14;
    if (intensity === 'leggera') return 46;
    if (intensity === 'media') return 74;
    return 100;
  };

  return (
    <section
      aria-label="Grafico Disciplina Mensile"
      className="rounded-2xl border p-4 sm:p-5 space-y-4"
      style={{
        backgroundColor: 'var(--bg-card)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-main)',
      }}
    >
      {/* Header & Month/Year Selector (Settembre 2026 - Dicembre 2030) */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <CalendarDays className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            <h2 className="text-sm sm:text-base font-extrabold">
              Grafico Disciplina Mensile
            </h2>
          </div>
          <p className="text-xs mt-0.5 tabular-nums" style={{ color: 'var(--text-secondary)' }}>
            <strong style={{ color: 'var(--accent)' }}>
              {trainedDaysCount} giorni su {daysInMonth}
            </strong>{' '}
            — Disciplina {disciplinePct}%
          </p>
        </div>

        {/* Navigation: Prev Arrow + Dropdown + Next Arrow */}
        <div className="flex items-center gap-1.5">
          <button
            type="button"
            disabled={monthIndex <= MIN_MONTH_INDEX}
            onClick={() => {
              playTechClick();
              setMonthIndex((m) => Math.max(MIN_MONTH_INDEX, m - 1));
              setSelectedDateKey(null);
            }}
            aria-label="Mese precedente"
            className="min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center disabled:opacity-40 transition"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <select
            aria-label="Seleziona mese e anno"
            value={monthIndex}
            onChange={(e) => {
              playTechClick();
              setMonthIndex(Number(e.target.value));
              setSelectedDateKey(null);
            }}
            className="min-h-[38px] px-2.5 rounded-xl border text-xs font-extrabold focus:outline-none"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--accent)',
              color: 'var(--text-main)',
            }}
          >
            {ALL_SELECTABLE_MONTHS.map((m) => (
              <option key={m.index} value={m.index}>
                {m.label}
              </option>
            ))}
          </select>

          <button
            type="button"
            disabled={monthIndex >= MAX_MONTH_INDEX}
            onClick={() => {
              playTechClick();
              setMonthIndex((m) => Math.min(MAX_MONTH_INDEX, m + 1));
              setSelectedDateKey(null);
            }}
            aria-label="Mese successivo"
            className="min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center disabled:opacity-40 transition"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Discipline Bar / Peak Chart across all days 1..N */}
      <div
        className="rounded-xl border p-3 space-y-2"
        style={{
          backgroundColor: 'var(--bg-elevated)',
          borderColor: 'var(--border-subtle)',
        }}
      >
        <div className="flex items-center justify-between text-[11px]">
          <span className="font-bold" style={{ color: 'var(--text-muted)' }}>
            Picchi di Disciplina Giornalieri (1–{daysInMonth})
          </span>
          <span className="font-mono font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
            {disciplinePct}% completamento
          </span>
        </div>

        <div
          className="flex items-end gap-[3px] h-20 pt-2"
          role="img"
          aria-label={`Grafico a barre disciplina ${MONTH_NAMES[currentMonth]} ${currentYear}`}
        >
          {monthDays.map((d) => {
            const heightPct = barHeightFor(d.effectiveIntensity);
            const isSelected = selectedDateKey === d.dateKey;
            const bgColor =
              d.effectiveIntensity === 'alta'
                ? 'var(--accent)'
                : d.effectiveIntensity === 'media'
                ? 'var(--primary)'
                : d.effectiveIntensity === 'leggera'
                ? 'var(--accent-soft)'
                : 'var(--border-subtle)';
            return (
              <button
                key={d.dateKey}
                type="button"
                onClick={() => {
                  playTechClick();
                  setSelectedDateKey((cur) => (cur === d.dateKey ? null : d.dateKey));
                }}
                title={`${d.day} ${MONTH_NAMES[currentMonth]} · ${
                  d.effectiveIntensity ? `Intensità ${d.effectiveIntensity}` : 'Riposo / Tocca per segnare'
                }`}
                className="flex-1 h-full flex flex-col justify-end items-center group"
              >
                <div
                  className="w-full rounded-t-sm transition-all"
                  style={{
                    height: `${heightPct}%`,
                    backgroundColor: bgColor,
                    opacity: d.trained ? 1 : 0.4,
                    outline: isSelected ? '2px solid #FFFFFF' : 'none',
                  }}
                />
              </button>
            );
          })}
        </div>
      </div>

      {/* Interactive Monthly Calendar Grid (Tap any day to mark/edit manually) */}
      <div className="space-y-2">
        <div className="grid grid-cols-7 gap-1 text-center">
          {WEEKDAY_SHORT.map((w) => (
            <span
              key={w}
              className="text-[10px] font-bold py-0.5"
              style={{ color: 'var(--text-muted)' }}
            >
              {w}
            </span>
          ))}
        </div>

        <div className="grid grid-cols-7 gap-1.5">
          {Array.from({ length: firstWeekdayMon }).map((_, idx) => (
            <div key={`empty_${idx}`} className="h-10" aria-hidden="true" />
          ))}

          {monthDays.map((d) => {
            const isSelected = selectedDateKey === d.dateKey;
            const intensity = d.effectiveIntensity;
            const bg =
              intensity === 'alta'
                ? 'var(--accent)'
                : intensity === 'media'
                ? 'var(--primary)'
                : intensity === 'leggera'
                ? 'var(--bg-card-alt)'
                : 'var(--bg-elevated)';
            const textColor =
              intensity === 'alta'
                ? '#05070A'
                : intensity === 'media'
                ? '#FFFFFF'
                : intensity === 'leggera'
                ? 'var(--accent)'
                : 'var(--text-secondary)';
            const border = isSelected
              ? '#FFFFFF'
              : d.trained
              ? 'var(--accent)'
              : 'var(--border-subtle)';

            return (
              <button
                key={d.dateKey}
                type="button"
                onClick={() => {
                  playTechClick();
                  setSelectedDateKey((cur) => (cur === d.dateKey ? null : d.dateKey));
                }}
                className="h-10 rounded-xl border flex flex-col items-center justify-center transition active:scale-95 tabular-nums relative"
                style={{
                  backgroundColor: bg,
                  borderColor: border,
                  color: textColor,
                }}
              >
                <span className="font-mono text-xs font-extrabold leading-none">{d.day}</span>
                {d.trained && (
                  <span className="text-[9px] font-bold leading-none mt-0.5 uppercase">
                    {intensity === 'alta' ? 'ALT' : intensity === 'media' ? 'MED' : 'LEG'}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Inline Day Editor for Retroactive / Manual Logging */}
      {selectedDayInfo ? (
        <div
          className="rounded-xl border p-3.5 space-y-2.5"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--accent)',
          }}
        >
          <div className="flex items-center justify-between gap-2">
            <div className="min-w-0">
              <p className="text-xs font-extrabold" style={{ color: 'var(--accent)' }}>
                {selectedDayInfo.day} {MONTH_NAMES[currentMonth]} {currentYear}
              </p>
              <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
                {selectedDayInfo.auto
                  ? `Seduta app registrata: ${selectedDayInfo.auto.title} (puoi comunque regolare l'intensità)`
                  : selectedDayInfo.manual
                  ? `Allenamento manuale segnato: intensità ${selectedDayInfo.manual}`
                  : 'Segna manualmente questo giorno come Allenamento Svolto:'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5">
            {(
              [
                { id: 'leggera', label: 'Leggera' },
                { id: 'media', label: 'Media' },
                { id: 'alta', label: 'Alta' },
              ] as const
            ).map((opt) => {
              const active = selectedDayInfo.manual === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    playSetCompleteTone();
                    onSetManualWorkoutDay(selectedDayInfo.dateKey, opt.id);
                  }}
                  className="min-h-[38px] px-2 rounded-xl border text-xs font-extrabold inline-flex items-center justify-center gap-1 transition"
                  style={{
                    backgroundColor: active ? 'var(--primary)' : 'var(--bg-card)',
                    borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                    color: active ? '#FFFFFF' : 'var(--text-main)',
                  }}
                >
                  {active && <Check className="w-3.5 h-3.5 shrink-0" />}
                  <span>{opt.label}</span>
                </button>
              );
            })}

            {selectedDayInfo.manual && (
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  onSetManualWorkoutDay(selectedDayInfo.dateKey, null);
                }}
                className="min-h-[38px] px-2 rounded-xl border text-xs font-bold inline-flex items-center justify-center gap-1 transition col-span-3 sm:col-span-1"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-muted)',
                }}
              >
                <Trash2 className="w-3.5 h-3.5 shrink-0" />
                <span>Rimuovi</span>
              </button>
            )}
          </div>
        </div>
      ) : (
        <div
          className="flex flex-wrap items-center justify-between gap-2 text-[11px] pt-1"
          style={{ color: 'var(--text-muted)' }}
        >
          <span>
            Tocca qualsiasi giorno dal Settembre 2026 per registrare manualmente gli allenamenti svolti.
          </span>
          <div className="flex items-center gap-2 font-semibold">
            <span className="inline-flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: 'var(--accent-soft)' }} />
              Leggera
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: 'var(--primary)' }} />
              Media
            </span>
            <span className="inline-flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: 'var(--accent)' }} />
              Alta
            </span>
          </div>
        </div>
      )}
    </section>
  );
};

export { Flame };
