import React, { useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Battery,
  BatteryCharging,
  BatteryLow,
  Check,
  Moon,
  ShieldAlert,
  Sparkles,
  Sun,
  X,
  Zap,
} from 'lucide-react';
import type {
  EnergyLevel,
  MorningCheckinRecord,
  MorningJointStatus,
  SleepQuality,
} from '../types/calisthenics';
import { playSetCompleteTone, playTechClick } from '../utils/audio';

interface MorningCheckinCardProps {
  todayCheckin: MorningCheckinRecord | null;
  isOpen: boolean;
  hasJointRiskExercises: boolean;
  onSaveCheckin: (values: {
    sleepQuality: SleepQuality;
    energyLevel: EnergyLevel;
    jointStatus: MorningJointStatus;
  }) => void;
  onAdaptVolumeMinusOne: () => void;
  onProtectJointAndPrehab: (joint: MorningJointStatus) => void;
  onClose: () => void;
}

const SLEEP_OPTIONS: { id: SleepQuality; label: string; sub: string; Icon: React.ElementType }[] = [
  { id: 'scarso', label: 'Scarso', sub: '<6h', Icon: Moon },
  { id: 'medio', label: 'Nella media', sub: '6-7h', Icon: Activity },
  { id: 'ottimo', label: 'Ottimo', sub: '8h+', Icon: Sun },
];

const ENERGY_OPTIONS: { id: EnergyLevel; label: string; Icon: React.ElementType }[] = [
  { id: 'bassa', label: 'Bassa', Icon: BatteryLow },
  { id: 'media', label: 'Media', Icon: Battery },
  { id: 'alta', label: 'Alta', Icon: BatteryCharging },
];

const JOINT_OPTIONS: { id: MorningJointStatus; label: string }[] = [
  { id: 'ok', label: 'Tutto OK' },
  { id: 'polsi', label: 'Fastidio Polsi' },
  { id: 'gomiti', label: 'Fastidio Gomiti' },
  { id: 'spalle', label: 'Fastidio Spalle' },
  { id: 'lombare', label: 'Zona Lombare' },
];

export const MorningCheckinCard: React.FC<MorningCheckinCardProps> = ({
  todayCheckin,
  isOpen,
  hasJointRiskExercises,
  onSaveCheckin,
  onAdaptVolumeMinusOne,
  onProtectJointAndPrehab,
  onClose,
}) => {
  const [sleepQuality, setSleepQuality] = useState<SleepQuality>(
    todayCheckin?.sleepQuality ?? 'medio'
  );
  const [energyLevel, setEnergyLevel] = useState<EnergyLevel>(
    todayCheckin?.energyLevel ?? 'media'
  );
  const [jointStatus, setJointStatus] = useState<MorningJointStatus>(
    todayCheckin?.jointStatus ?? 'ok'
  );

  if (!isOpen) return null;

  const currentSleep = todayCheckin ? todayCheckin.sleepQuality : sleepQuality;
  const currentEnergy = todayCheckin ? todayCheckin.energyLevel : energyLevel;
  const currentJoint = todayCheckin ? todayCheckin.jointStatus : jointStatus;

  const isLowReadiness = currentSleep === 'scarso' || currentEnergy === 'bassa';
  const hasJointAlert = currentJoint !== 'ok';

  const handleSelectSleep = (val: SleepQuality) => {
    playTechClick();
    setSleepQuality(val);
    if (todayCheckin) {
      onSaveCheckin({
        sleepQuality: val,
        energyLevel: currentEnergy,
        jointStatus: currentJoint,
      });
    }
  };

  const handleSelectEnergy = (val: EnergyLevel) => {
    playTechClick();
    setEnergyLevel(val);
    if (todayCheckin) {
      onSaveCheckin({
        sleepQuality: currentSleep,
        energyLevel: val,
        jointStatus: currentJoint,
      });
    }
  };

  const handleSelectJoint = (val: MorningJointStatus) => {
    playTechClick();
    setJointStatus(val);
    if (todayCheckin) {
      onSaveCheckin({
        sleepQuality: currentSleep,
        energyLevel: currentEnergy,
        jointStatus: val,
      });
    }
  };

  const handleConfirm = () => {
    playSetCompleteTone();
    onSaveCheckin({
      sleepQuality: currentSleep,
      energyLevel: currentEnergy,
      jointStatus: currentJoint,
    });
  };

  return (
    <section
      aria-label="Check-in Mattutino Pre-Workout"
      className="rounded-2xl border p-4 space-y-3.5 shadow-lg"
      style={{
        backgroundColor: 'var(--bg-card)',
        borderColor: 'var(--accent)',
        color: 'var(--text-main)',
      }}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            <h2 className="text-sm sm:text-base font-extrabold leading-snug">
              Come ti senti oggi prima di allenarti?
            </h2>
          </div>
          <p className="text-[11px] mt-0.5" style={{ color: 'var(--text-muted)' }}>
            Check-in rapido di 5 secondi · Salvato nello Storico e condiviso con il Coach AI
          </p>
        </div>

        <button
          type="button"
          onClick={onClose}
          aria-label="Chiudi check-in mattutino"
          className="min-h-[36px] min-w-[36px] rounded-xl border flex items-center justify-center shrink-0 transition"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-muted)',
          }}
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* 1. Sleep Quality */}
      <div className="space-y-1.5">
        <p className="text-xs font-bold" style={{ color: 'var(--text-secondary)' }}>
          1. Qualità del Sonno
        </p>
        <div className="grid grid-cols-3 gap-2">
          {SLEEP_OPTIONS.map(({ id, label, sub, Icon }) => {
            const active = currentSleep === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => handleSelectSleep(id)}
                className="min-h-[58px] px-2 py-2 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition active:scale-[0.98]"
                style={{
                  backgroundColor: active ? 'var(--primary)' : 'var(--bg-elevated)',
                  borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                  color: active ? '#FFFFFF' : 'var(--text-secondary)',
                }}
              >
                <Icon
                  className="w-4 h-4 shrink-0"
                  style={{ color: active ? '#FFFFFF' : 'var(--accent)' }}
                />
                <span className="text-xs font-extrabold leading-tight">{label}</span>
                <span
                  className="text-[10px] font-mono leading-none"
                  style={{ color: active ? '#E2E8F0' : 'var(--text-muted)' }}
                >
                  {sub}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 2. Physical Energy */}
      <div className="space-y-1.5">
        <p className="text-xs font-bold" style={{ color: 'var(--text-secondary)' }}>
          2. Energia Fisica
        </p>
        <div className="grid grid-cols-3 gap-2">
          {ENERGY_OPTIONS.map(({ id, label, Icon }) => {
            const active = currentEnergy === id;
            return (
              <button
                key={id}
                type="button"
                onClick={() => handleSelectEnergy(id)}
                className="min-h-[52px] px-2 py-2 rounded-xl border flex flex-col items-center justify-center gap-1 text-center transition active:scale-[0.98]"
                style={{
                  backgroundColor: active ? 'var(--primary)' : 'var(--bg-elevated)',
                  borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                  color: active ? '#FFFFFF' : 'var(--text-secondary)',
                }}
              >
                <Icon
                  className="w-4 h-4 shrink-0"
                  style={{ color: active ? '#FFFFFF' : 'var(--accent)' }}
                />
                <span className="text-xs font-extrabold leading-tight">{label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 3. Joints & Tendons */}
      <div className="space-y-1.5">
        <p className="text-xs font-bold" style={{ color: 'var(--text-secondary)' }}>
          3. Stato Articolazioni e Tendini
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
          {JOINT_OPTIONS.map((opt) => {
            const active = currentJoint === opt.id;
            const isWarningChoice = opt.id !== 'ok';
            return (
              <button
                key={opt.id}
                type="button"
                onClick={() => handleSelectJoint(opt.id)}
                className="min-h-[42px] px-2.5 py-1.5 rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 text-center transition active:scale-[0.98]"
                style={{
                  backgroundColor: active
                    ? isWarningChoice
                      ? '#B45309'
                      : 'var(--primary)'
                    : 'var(--bg-elevated)',
                  borderColor: active
                    ? isWarningChoice
                      ? '#F59E0B'
                      : 'var(--accent)'
                    : 'var(--border-subtle)',
                  color: active ? '#FFFFFF' : 'var(--text-secondary)',
                }}
              >
                {isWarningChoice && (
                  <AlertTriangle
                    className="w-3.5 h-3.5 shrink-0"
                    style={{ color: active ? '#FDE68A' : '#F59E0B' }}
                  />
                )}
                <span className="truncate">{opt.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Save / Status Row */}
      {!todayCheckin && (
        <button
          type="button"
          onClick={handleConfirm}
          className="w-full min-h-[44px] rounded-xl font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 transition"
          style={{
            backgroundColor: 'var(--primary)',
            color: '#FFFFFF',
          }}
        >
          <Check className="w-4 h-4 stroke-[2.75]" />
          <span>Salva Check-in di Oggi</span>
        </button>
      )}

      {/* Intelligent Smart Recommendations */}
      {isLowReadiness && (
        <div
          className="rounded-xl border p-3 space-y-2"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--accent)',
          }}
        >
          <p className="text-xs font-bold leading-snug" style={{ color: 'var(--text-main)' }}>
            Rilevato recupero non ottimale: riduci leggermente il volume per mantenere alta la qualità tecnica.
          </p>
          <button
            type="button"
            disabled={Boolean(todayCheckin?.volumeAdapted)}
            onClick={() => {
              if (!todayCheckin) {
                onSaveCheckin({
                  sleepQuality: currentSleep,
                  energyLevel: currentEnergy,
                  jointStatus: currentJoint,
                });
              }
              onAdaptVolumeMinusOne();
            }}
            className="w-full min-h-[42px] px-3 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 transition disabled:opacity-60"
            style={{
              backgroundColor: 'var(--accent)',
              color: '#05070A',
            }}
          >
            <Sparkles className="w-4 h-4 shrink-0" />
            <span>
              {todayCheckin?.volumeAdapted
                ? 'Volume odierno già ridotto (-1 Serie applicato)'
                : 'Adatta la Scheda di Oggi (-1 Serie per esercizio)'}
            </span>
          </button>
        </div>
      )}

      {hasJointAlert && (
        <div
          className="rounded-xl border p-3 space-y-2"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: '#F59E0B',
          }}
        >
          <p className="text-xs font-bold leading-snug" style={{ color: 'var(--text-main)' }}>
            {hasJointRiskExercises
              ? 'Alcuni esercizi in scheda oggi caricano questa articolazione e sono evidenziati con bordo di avviso.'
              : 'Fastidio registrato: puoi avviare subito il protocollo protettivo Prehab.'}
          </p>
          <button
            type="button"
            onClick={() => {
              if (!todayCheckin) {
                onSaveCheckin({
                  sleepQuality: currentSleep,
                  energyLevel: currentEnergy,
                  jointStatus: currentJoint,
                });
              }
              onProtectJointAndPrehab(currentJoint);
            }}
            className="w-full min-h-[42px] px-3 rounded-xl font-extrabold text-xs flex items-center justify-center gap-1.5 transition"
            style={{
              backgroundColor: '#F59E0B',
              color: '#05070A',
            }}
          >
            <ShieldAlert className="w-4 h-4 shrink-0" />
            <span>Proteggi Articolazione: Sostituisci e Avvia Prehab</span>
          </button>
        </div>
      )}
    </section>
  );
};
