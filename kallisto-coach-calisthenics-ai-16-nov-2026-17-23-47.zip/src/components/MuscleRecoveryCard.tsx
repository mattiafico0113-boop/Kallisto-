import React, { useMemo } from 'react';
import { Activity } from 'lucide-react';
import type { WorkoutSessionLog } from '../types/calisthenics';
import { computeMuscleRecovery } from '../utils/recoveryAndMissions';

interface MuscleRecoveryCardProps {
  history: WorkoutSessionLog[];
  compact?: boolean;
}

export const MuscleRecoveryCard: React.FC<MuscleRecoveryCardProps> = ({
  history,
  compact = false,
}) => {
  const zones = useMemo(() => computeMuscleRecovery(history), [history]);

  return (
    <section
      className={`rounded-2xl border ${compact ? 'p-3.5' : 'p-4 sm:p-5'} space-y-3`}
      style={{
        backgroundColor: 'var(--bg-card)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-main)',
      }}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
          <h3 className="text-sm font-extrabold">Stato Recupero Muscolare &amp; Tendini</h3>
        </div>
        <span className="text-[11px] font-semibold" style={{ color: 'var(--text-muted)' }}>
          Live da storico
        </span>
      </div>

      <div className="space-y-2.5">
        {zones.map((z) => {
          const barColor =
            z.statusTone === 'recovering'
              ? '#F97316'
              : z.statusTone === 'moderate'
              ? 'var(--primary)'
              : '#10B981';

          const badgeColor =
            z.statusTone === 'recovering'
              ? '#FB923C'
              : z.statusTone === 'moderate'
              ? 'var(--accent)'
              : '#34D399';

          return (
            <div key={z.id} className="space-y-1">
              <div className="flex items-center justify-between gap-2 text-xs">
                <span className="font-bold truncate">{z.label}</span>
                <div className="flex items-center gap-2 shrink-0 tabular-nums">
                  <span className="text-[11px] font-bold" style={{ color: badgeColor }}>
                    {z.statusLabel}
                  </span>
                  <span className="font-mono font-extrabold w-9 text-right">
                    {z.percent}%
                  </span>
                </div>
              </div>
              <div
                className="h-2 w-full rounded-full border overflow-hidden"
                style={{
                  backgroundColor: 'var(--bg-main)',
                  borderColor: 'var(--border-subtle)',
                }}
              >
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${z.percent}%`,
                    backgroundColor: barColor,
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
