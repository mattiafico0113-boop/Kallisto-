import React, { useMemo } from 'react';
import { Check, Droplets, Flame, Pill, RotateCcw, Utensils } from 'lucide-react';
import type { AthleteProfile, DailyNutritionLog } from '../types/calisthenics';
import { playSetCompleteTone, playTechClick } from '../utils/audio';
import {
  computeCreatineConsistencyDays,
  computeNutritionTargets,
  getLocalDateKey,
} from '../utils/athletePillars';

interface NutritionHydrationWidgetProps {
  profile: AthleteProfile | null;
  nutritionLogs: DailyNutritionLog[];
  compact?: boolean;
  onUpdateTodayNutrition: (updater: (cur: DailyNutritionLog) => DailyNutritionLog) => void;
}

export const NutritionHydrationWidget: React.FC<NutritionHydrationWidgetProps> = ({
  profile,
  nutritionLogs,
  compact = false,
  onUpdateTodayNutrition,
}) => {
  const todayKey = getLocalDateKey();
  const todayLog: DailyNutritionLog = useMemo(() => {
    return (
      nutritionLogs.find((l) => l.dateKey === todayKey) ?? {
        dateKey: todayKey,
        waterMl: 0,
        proteinMeals: 0,
        creatineTaken: false,
      }
    );
  }, [nutritionLogs, todayKey]);

  const targets = useMemo(() => computeNutritionTargets(profile), [profile]);
  const creatineStreakDays = useMemo(
    () => computeCreatineConsistencyDays(nutritionLogs),
    [nutritionLogs]
  );

  const waterPct = Math.min(100, Math.round((todayLog.waterMl / targets.waterTargetMl) * 100));
  const proteinPct = Math.min(
    100,
    Math.round((todayLog.proteinMeals / targets.proteinMealsTarget) * 100)
  );

  const waterLitersNow = (todayLog.waterMl / 1000).toFixed(2);
  const waterLitersTarget = (targets.waterTargetMl / 1000).toFixed(2);

  return (
    <section
      aria-label="Nutrizione e Energia"
      className="rounded-2xl border p-3.5 sm:p-4 space-y-3"
      style={{
        backgroundColor: 'var(--bg-card)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-main)',
      }}
    >
      {/* Header + Auto Targets */}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Utensils className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
          <div className="min-w-0">
            <h3 className="text-sm font-extrabold leading-tight">Nutrizione &amp; Energia</h3>
            {!compact && (
              <p className="text-[11px] truncate" style={{ color: 'var(--text-muted)' }}>
                {targets.caloriesLabel}
                {targets.usingDefaultMetrics ? ' · Completa peso/altezza nel Profilo per stima esatta' : ''}
              </p>
            )}
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono font-bold tabular-nums">
          <span className="inline-flex items-center gap-1" style={{ color: 'var(--accent)' }}>
            <Flame className="w-3.5 h-3.5" />
            {targets.caloriesKcal} kcal
          </span>
          <span style={{ color: 'var(--text-secondary)' }}>{targets.proteinGrams}g prot</span>
        </div>
      </div>

      {/* 3 One-Tap Trackers */}
      <div className="grid grid-cols-1 gap-2.5">
        {/* 1. Daily Water Tracker (+250 ml) */}
        <div
          className="rounded-xl border p-2.5 space-y-2"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div className="flex items-center justify-between gap-1">
            <span className="text-[11px] font-bold" style={{ color: 'var(--text-secondary)' }}>
              Acqua Giornaliera
            </span>
            <span
              className="font-mono text-xs font-extrabold tabular-nums"
              style={{ color: 'var(--accent)' }}
            >
              {waterLitersNow} / {waterLitersTarget} L
            </span>
          </div>

          <div
            className="h-1.5 w-full rounded-full overflow-hidden border"
            style={{
              backgroundColor: 'var(--bg-main)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div
              className="h-full transition-all duration-200"
              style={{
                width: `${waterPct}%`,
                backgroundColor: 'var(--accent)',
              }}
            />
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                playTechClick();
                onUpdateTodayNutrition((cur) => ({
                  ...cur,
                  waterMl: cur.waterMl + 250,
                }));
              }}
              className="flex-1 min-h-[38px] px-2.5 rounded-xl font-extrabold text-xs inline-flex items-center justify-center gap-1 transition active:scale-[0.98]"
              style={{
                backgroundColor: 'var(--primary)',
                color: '#FFFFFF',
              }}
            >
              <Droplets className="w-3.5 h-3.5 shrink-0" />
              <span>+250 ml</span>
            </button>

            {todayLog.waterMl >= 250 && (
              <button
                type="button"
                aria-label="Sottrai 250 ml"
                onClick={() =>
                  onUpdateTodayNutrition((cur) => ({
                    ...cur,
                    waterMl: Math.max(0, cur.waterMl - 250),
                  }))
                }
                className="min-h-[38px] min-w-[34px] rounded-xl border flex items-center justify-center transition"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-muted)',
                }}
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* 2. Protein Meals Tracker (+1 Pasto Proteico) */}
        <div
          className="rounded-xl border p-2.5 space-y-2"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div className="flex items-center justify-between gap-1">
            <span className="text-[11px] font-bold" style={{ color: 'var(--text-secondary)' }}>
              Pasti Proteici
            </span>
            <span
              className="font-mono text-xs font-extrabold tabular-nums"
              style={{ color: 'var(--accent)' }}
            >
              {todayLog.proteinMeals} / {targets.proteinMealsTarget} pasti
            </span>
          </div>

          <div
            className="h-1.5 w-full rounded-full overflow-hidden border"
            style={{
              backgroundColor: 'var(--bg-main)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div
              className="h-full transition-all duration-200"
              style={{
                width: `${proteinPct}%`,
                backgroundColor: 'var(--primary)',
              }}
            />
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                playTechClick();
                onUpdateTodayNutrition((cur) => ({
                  ...cur,
                  proteinMeals: cur.proteinMeals + 1,
                }));
              }}
              className="flex-1 min-h-[38px] px-2.5 rounded-xl font-extrabold text-xs inline-flex items-center justify-center gap-1 transition active:scale-[0.98]"
              style={{
                backgroundColor: 'var(--primary)',
                color: '#FFFFFF',
              }}
            >
              <Utensils className="w-3.5 h-3.5 shrink-0" />
              <span>+1 Pasto Proteico</span>
            </button>

            {todayLog.proteinMeals > 0 && (
              <button
                type="button"
                aria-label="Rimuovi un pasto proteico"
                onClick={() =>
                  onUpdateTodayNutrition((cur) => ({
                    ...cur,
                    proteinMeals: Math.max(0, cur.proteinMeals - 1),
                  }))
                }
                className="min-h-[38px] min-w-[34px] rounded-xl border flex items-center justify-center transition"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-muted)',
                }}
              >
                <RotateCcw className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* 3. Creatine / Supplements Daily Toggle */}
        <div
          className="rounded-xl border p-2.5 flex flex-col justify-between gap-2"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: todayLog.creatineTaken ? 'var(--accent)' : 'var(--border-subtle)',
          }}
        >
          <div className="flex items-center justify-between gap-1">
            <span className="text-[11px] font-bold" style={{ color: 'var(--text-secondary)' }}>
              Integratori / Creatina
            </span>
            <span
              className="font-mono text-xs font-extrabold tabular-nums"
              style={{ color: 'var(--accent)' }}
            >
              {creatineStreakDays}g costanza
            </span>
          </div>

          <button
            type="button"
            onClick={() => {
              const next = !todayLog.creatineTaken;
              if (next) playSetCompleteTone();
              else playTechClick();
              onUpdateTodayNutrition((cur) => ({
                ...cur,
                creatineTaken: !cur.creatineTaken,
              }));
            }}
            aria-pressed={todayLog.creatineTaken}
            className="w-full min-h-[42px] px-2.5 rounded-xl border font-extrabold text-xs flex items-center justify-center gap-1.5 transition active:scale-[0.98]"
            style={{
              backgroundColor: todayLog.creatineTaken ? 'var(--accent)' : 'var(--bg-card)',
              borderColor: todayLog.creatineTaken ? 'var(--accent)' : 'var(--border-subtle)',
              color: todayLog.creatineTaken ? '#05070A' : 'var(--text-main)',
            }}
          >
            {todayLog.creatineTaken ? (
              <Check className="w-4 h-4 stroke-[2.75] shrink-0" />
            ) : (
              <Pill className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--accent)' }} />
            )}
            <span className="truncate">
              {todayLog.creatineTaken
                ? 'Presi oggi (Completato)'
                : 'Segna Creatina / Integratori'}
            </span>
          </button>
        </div>
      </div>
    </section>
  );
};
