import React, { useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  Check,
  Clock,
  Dumbbell,
  ShieldAlert,
  Sparkles,
  Target,
} from 'lucide-react';
import { EQUIPMENT_OPTIONS, JOINT_OPTIONS } from '../data/exercises';
import type {
  AthleteBaselines,
  AthleteProfile,
  EquipmentId,
  GoalType,
  JointId,
  SkillTarget,
  WeekdayId,
} from '../types/calisthenics';
import {
  requestNotificationPermission,
  sendWorkoutNotification,
  WEEKDAY_ORDER,
} from '../utils/notifications';

interface OnboardingWizardProps {
  initialProfile?: AthleteProfile | null;
  onComplete: (profile: AthleteProfile) => void;
  onCreateCustomSchedule?: (profile: AthleteProfile) => void;
  onCancel?: () => void;
}

const GOAL_OPTIONS: { id: GoalType; title: string; subtitle: string }[] = [
  {
    id: 'forza',
    title: 'Forza nei fondamentali',
    subtitle: 'Trazioni, dip, piegamenti e progressioni zavorrate ad alta intensità.',
  },
  {
    id: 'ipertrofia',
    title: 'Ipertrofia a corpo libero',
    subtitle: 'Volume allenante, controllo eccentrico e densità muscolare.',
  },
  {
    id: 'skill',
    title: 'Sblocco Skill',
    subtitle: 'Muscle-up, Planche, Front Lever, Verticale o Human Flag.',
  },
  {
    id: 'ricomposizione',
    title: 'Ricomposizione corporea',
    subtitle: 'Alta densità metabolica, tenuta tecnica e consumo energetico.',
  },
];

const SKILL_TARGETS: { id: SkillTarget; label: string }[] = [
  { id: 'muscle_up', label: 'Muscle-up' },
  { id: 'planche', label: 'Planche' },
  { id: 'front_lever', label: 'Front Lever' },
  { id: 'handstand', label: 'Verticale (Handstand)' },
  { id: 'human_flag', label: 'Human Flag' },
];

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({
  initialProfile,
  onComplete,
  onCreateCustomSchedule,
  onCancel,
}) => {
  const [step, setStep] = useState(1);
  const [name, setName] = useState(initialProfile?.name ?? 'Atleta');
  const [goal, setGoal] = useState<GoalType>(initialProfile?.goal ?? 'forza');
  const [targetSkill, setTargetSkill] = useState<SkillTarget>(
    initialProfile?.targetSkill ?? 'front_lever'
  );
  const [equipment, setEquipment] = useState<EquipmentId[]>(
    initialProfile?.equipment ?? ['sbarra', 'parallele', 'pavimento']
  );
  const [baselines, setBaselines] = useState<AthleteBaselines>(
    initialProfile?.baselines ?? {
      pullups: 6,
      dips: 8,
      pushups: 15,
      legRaises: 8,
    }
  );
  const [trainingDays, setTrainingDays] = useState<WeekdayId[]>(
    initialProfile?.trainingDays ?? ['lun', 'mer', 'ven', 'sab']
  );
  const [reminderEnabled, setReminderEnabled] = useState<boolean>(
    initialProfile?.reminderEnabled ?? false
  );
  const [reminderTime, setReminderTime] = useState<string>(
    initialProfile?.reminderTime ?? '18:00'
  );
  const [notifFeedback, setNotifFeedback] = useState<string | null>(null);
  const [injuries, setInjuries] = useState<JointId[]>(initialProfile?.injuries ?? []);

  const toggleEquipment = (id: EquipmentId) => {
    setEquipment((prev) => {
      if (id === 'pavimento') {
        return prev.includes('pavimento') && prev.length > 1
          ? prev.filter((x) => x !== 'pavimento')
          : prev.includes('pavimento')
          ? prev
          : [...prev, 'pavimento'];
      }
      const next = prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id];
      return next.length === 0 ? ['pavimento'] : next;
    });
  };

  const toggleTrainingDay = (dayId: WeekdayId) => {
    setTrainingDays((prev) => {
      if (prev.includes(dayId)) {
        if (prev.length === 1) return prev; // Almeno 1 giorno
        return prev.filter((d) => d !== dayId);
      }
      const combined = [...prev, dayId];
      // Ordina sempre da Lunedì a Domenica
      return WEEKDAY_ORDER.map((w) => w.id).filter((id) => combined.includes(id));
    });
  };

  const toggleInjury = (id: JointId) => {
    setInjuries((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  };

  const updateBaseline = (key: keyof AthleteBaselines, delta: number) => {
    setBaselines((prev) => ({
      ...prev,
      [key]: Math.max(0, Math.min(60, prev[key] + delta)),
    }));
  };

  const handleToggleReminder = async () => {
    const next = !reminderEnabled;
    if (!next) {
      setReminderEnabled(false);
      setNotifFeedback(null);
      return;
    }

    const perm = await requestNotificationPermission();
    if (perm === 'granted') {
      setReminderEnabled(true);
      setNotifFeedback('Notifiche attive! Riceverai il promemoria nei giorni selezionati.');
    } else if (perm === 'unsupported') {
      setReminderEnabled(false);
      setNotifFeedback('Questo browser non supporta le notifiche Web.');
    } else {
      setReminderEnabled(false);
      setNotifFeedback(
        'Permesso notifiche non concesso. Abilita le notifiche dalle impostazioni del browser.'
      );
    }
  };

  const handleTestNotification = async () => {
    const res = await sendWorkoutNotification(
      'Kallisto Calisthenics',
      "È l'ora del tuo allenamento di Calisthenics! Oggi ti aspettano Trazioni alla sbarra e Dip alle parallele."
    );
    if (res.ok) {
      setNotifFeedback('Notifica di prova inviata!');
    } else {
      setNotifFeedback(res.reason ?? 'Impossibile inviare la notifica di prova.');
    }
  };

  const buildProfilePayload = (): AthleteProfile => {
    const now = new Date().toISOString();
    return {
      name: name.trim() || 'Atleta',
      goal,
      targetSkill: goal === 'skill' ? targetSkill : undefined,
      equipment: equipment.length > 0 ? equipment : ['pavimento'],
      baselines,
      daysPerWeek: trainingDays.length,
      trainingDays,
      reminderEnabled,
      reminderTime,
      injuries,
      onboardingCompleted: true,
      createdAt: initialProfile?.createdAt ?? now,
      updatedAt: now,
    };
  };

  const handleFinish = () => {
    onComplete(buildProfilePayload());
  };

  return (
    <div className="min-h-screen bg-[#05070A] text-[#FFFFFF] flex flex-col">
      {/* Top progress header */}
      <header className="sticky top-0 z-20 bg-[#090D16]/90 backdrop-blur-md border-b border-[#1E293B] px-4 py-3">
        <div className="max-w-2xl mx-auto flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {step > 1 ? (
              <button
                type="button"
                onClick={() => setStep((s) => s - 1)}
                aria-label="Passaggio precedente"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-[#0F172A] border border-[#1E293B] text-[#FFFFFF] hover:bg-[#131C31] transition"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            ) : onCancel ? (
              <button
                type="button"
                onClick={onCancel}
                className="min-h-[44px] px-3 rounded-xl bg-[#0F172A] border border-[#1E293B] text-sm font-medium text-[#94A3B8] hover:text-[#FFFFFF] transition"
              >
                Annulla
              </button>
            ) : (
              <img src="/icon.svg" alt="Kallisto Logo" className="w-9 h-9 rounded-xl shrink-0" />
            )}
            <div>
              <p className="text-xs font-medium text-[#94A3B8] tabular-nums">
                Configurazione atleta · Passaggio {step} di 4
              </p>
              <h1 className="text-base font-bold text-[#FFFFFF] tracking-tight">Kallisto Calisthenics</h1>
            </div>
          </div>

          <div className="flex items-center gap-1.5" aria-hidden="true">
            {[1, 2, 3, 4].map((n) => (
              <span
                key={n}
                className={`h-1.5 rounded-full transition-all ${
                  n <= step ? 'w-6 bg-[#38BDF8]' : 'w-3 bg-[#1E293B]'
                }`}
              />
            ))}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-4 py-6 pb-36 max-w-2xl w-full mx-auto">
        {step === 1 && (
          <section className="space-y-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#FFFFFF]">
                Qual è il tuo obiettivo principale?
              </h2>
              <p className="mt-2 text-sm text-[#94A3B8] leading-relaxed">
                Calibreremo split settimanale, recuperi, ripetizioni e progressioni sulle tue priorità.
              </p>
            </div>

            <div>
              <label htmlFor="athlete-name" className="block text-xs font-semibold text-[#94A3B8] mb-2">
                Il tuo nome (opzionale)
              </label>
              <input
                id="athlete-name"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Es. Marco"
                className="w-full min-h-[48px] rounded-2xl bg-[#0F172A] border border-[#1E293B] px-4 text-base text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {GOAL_OPTIONS.map((opt) => {
                const active = goal === opt.id;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => setGoal(opt.id)}
                    className={`text-left p-4 rounded-2xl border transition min-h-[104px] flex flex-col justify-between ${
                      active
                        ? 'bg-[#132347] border-[#2563EB] text-[#FFFFFF]'
                        : 'bg-[#0F172A] border-[#1E293B] text-[#FFFFFF] hover:border-[#38BDF8]/40'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-base font-bold leading-snug">{opt.title}</span>
                      <span
                        className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 border ${
                          active
                            ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]'
                            : 'border-[#1E293B] text-transparent'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    </div>
                    <p className="mt-2 text-xs text-[#94A3B8] leading-relaxed">{opt.subtitle}</p>
                  </button>
                );
              })}
            </div>

            {goal === 'skill' && (
              <div className="pt-2 space-y-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#FFFFFF]">
                  <Target className="w-4 h-4 text-[#38BDF8]" />
                  <span>Skill prioritaria da sbloccare</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {SKILL_TARGETS.map((sk) => {
                    const active = targetSkill === sk.id;
                    return (
                      <button
                        key={sk.id}
                        type="button"
                        onClick={() => setTargetSkill(sk.id)}
                        className={`min-h-[44px] px-4 py-2 rounded-xl text-sm font-semibold border transition whitespace-nowrap ${
                          active
                            ? 'bg-[#2563EB] text-[#FFFFFF] border-[#38BDF8]/60'
                            : 'bg-[#0F172A] text-[#CBD5E1] border-[#1E293B] hover:border-[#38BDF8]/40'
                        }`}
                      >
                        {sk.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </section>
        )}

        {step === 2 && (
          <section className="space-y-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#FFFFFF]">
                Attrezzatura disponibile
              </h2>
              <p className="mt-2 text-sm text-[#94A3B8] leading-relaxed">
                Seleziona tutto ciò che hai in palestra, al parco o a casa. La scheda userà solo questi strumenti.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {EQUIPMENT_OPTIONS.map((item) => {
                const active = equipment.includes(item.id);
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => toggleEquipment(item.id)}
                    className={`text-left p-4 rounded-2xl border transition min-h-[76px] flex items-center justify-between gap-3 ${
                      active
                        ? 'bg-[#132347] border-[#2563EB]'
                        : 'bg-[#0F172A] border-[#1E293B] hover:border-[#38BDF8]/40'
                    }`}
                  >
                    <div>
                      <p className="text-sm font-bold text-[#FFFFFF]">{item.label}</p>
                      <p className="text-xs text-[#94A3B8] mt-0.5">{item.detail}</p>
                    </div>
                    <span
                      className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 border ${
                        active
                          ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]'
                          : 'border-[#1E293B] text-transparent'
                      }`}
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                    </span>
                  </button>
                );
              })}
            </div>
          </section>
        )}

        {step === 3 && (
          <section className="space-y-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#FFFFFF]">
                Test del livello attuale
              </h2>
              <p className="mt-2 text-sm text-[#94A3B8] leading-relaxed">
                Inserisci quante ripetizioni pulite (senza slanci) riesci a completare oggi in una serie massimale.
              </p>
            </div>

            <div className="space-y-3">
              {(
                [
                  {
                    key: 'pullups',
                    label: 'Trazioni alla sbarra (Pull-up)',
                    hint: '0 se non ne chiudi ancora una completa',
                  },
                  {
                    key: 'dips',
                    label: 'Dip alle parallele',
                    hint: 'Discesa fino a omero parallelo al suolo',
                  },
                  {
                    key: 'pushups',
                    label: 'Piegamenti (Push-up)',
                    hint: 'Petto a sfiorare il suolo, core rigido',
                  },
                  {
                    key: 'legRaises',
                    label: 'Leg Raises alla sbarra',
                    hint: 'Alzate gambe controllate senza dondolare',
                  },
                ] as { key: keyof AthleteBaselines; label: string; hint: string }[]
              ).map((item) => (
                <div
                  key={item.key}
                  className="p-4 rounded-2xl bg-[#0F172A] border border-[#1E293B] flex items-center justify-between gap-4"
                >
                  <div className="min-w-0">
                    <p className="text-sm font-bold text-[#FFFFFF]">{item.label}</p>
                    <p className="text-xs text-[#94A3B8] mt-0.5">{item.hint}</p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => updateBaseline(item.key, -1)}
                      aria-label={`Diminuisci ${item.label}`}
                      className="min-h-[44px] min-w-[44px] rounded-xl bg-[#131C31] border border-[#1E293B] text-lg font-bold text-[#FFFFFF] hover:bg-[#1E293B] active:scale-95 transition"
                    >
                      -
                    </button>
                    <input
                      type="number"
                      min={0}
                      max={60}
                      value={baselines[item.key]}
                      onChange={(e) => {
                        const val = Math.max(0, Math.min(60, Number(e.target.value) || 0));
                        setBaselines((p) => ({ ...p, [item.key]: val }));
                      }}
                      aria-label={item.label}
                      className="w-14 min-h-[44px] rounded-xl bg-[#090D16] border border-[#1E293B] text-center font-mono text-base font-bold text-[#38BDF8] tabular-nums focus:outline-none focus:border-[#38BDF8]"
                    />
                    <button
                      type="button"
                      onClick={() => updateBaseline(item.key, 1)}
                      aria-label={`Aumenta ${item.label}`}
                      className="min-h-[44px] min-w-[44px] rounded-xl bg-[#131C31] border border-[#1E293B] text-lg font-bold text-[#FFFFFF] hover:bg-[#1E293B] active:scale-95 transition"
                    >
                      +
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {step === 4 && (
          <section className="space-y-6">
            <div>
              <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#FFFFFF]">
                Giorni, promemoria e sicurezza
              </h2>
              <p className="mt-2 text-sm text-[#94A3B8] leading-relaxed">
                Scegli i giorni esatti in cui ti alleni, l’orario delle notifiche e segnala eventuali articolazioni da proteggere.
              </p>
            </div>

            {/* Visual Weekday Selector */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-sm font-semibold text-[#FFFFFF]">
                  <Dumbbell className="w-4 h-4 text-[#38BDF8]" />
                  <span>Giorni della settimana ({trainingDays.length})</span>
                </div>
                <span className="text-xs text-[#94A3B8]">
                  {trainingDays.length <= 3
                    ? 'Full Body'
                    : trainingDays.length === 4
                    ? 'Upper / Lower'
                    : 'Push / Pull / Legs'}
                </span>
              </div>

              <div className="grid grid-cols-7 gap-1.5">
                {WEEKDAY_ORDER.map((wd) => {
                  const active = trainingDays.includes(wd.id);
                  return (
                    <button
                      key={wd.id}
                      type="button"
                      onClick={() => toggleTrainingDay(wd.id)}
                      aria-pressed={active}
                      aria-label={wd.label}
                      className={`min-h-[54px] rounded-2xl border font-bold text-xs flex flex-col items-center justify-center gap-1 transition ${
                        active
                          ? 'bg-[#2563EB] text-[#FFFFFF] border-[#38BDF8]/70'
                          : 'bg-[#0F172A] text-[#94A3B8] border-[#1E293B] hover:text-[#FFFFFF] hover:border-[#38BDF8]/40'
                      }`}
                    >
                      <span>{wd.short}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Reminder Time & Notification Switch */}
            <div className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Bell className="w-4 h-4 text-[#38BDF8] shrink-0" />
                  <div>
                    <p className="text-sm font-bold text-[#FFFFFF]">Attiva Notifiche</p>
                    <p className="text-xs text-[#94A3B8]">
                      Promemoria automatico nei giorni scelti
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={reminderEnabled}
                  onClick={handleToggleReminder}
                  className={`w-12 h-7 rounded-full p-1 transition-colors shrink-0 ${
                    reminderEnabled ? 'bg-[#2563EB]' : 'bg-[#1E293B]'
                  }`}
                >
                  <span
                    className={`block w-5 h-5 rounded-full bg-[#FFFFFF] transition-transform ${
                      reminderEnabled ? 'translate-x-5' : 'translate-x-0'
                    }`}
                  />
                </button>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-[#1E293B]">
                <label
                  htmlFor="onb-reminder-time"
                  className="flex items-center gap-2 text-xs font-semibold text-[#CBD5E1]"
                >
                  <Clock className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Orario promemoria</span>
                </label>
                <input
                  id="onb-reminder-time"
                  type="time"
                  value={reminderTime}
                  onChange={(e) => setReminderTime(e.target.value || '18:00')}
                  className="min-h-[42px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 font-mono text-sm font-bold text-[#FFFFFF] focus:outline-none focus:border-[#38BDF8]"
                />
              </div>

              <button
                type="button"
                onClick={handleTestNotification}
                className="w-full min-h-[44px] rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#FFFFFF] hover:bg-[#1E293B] transition"
              >
                Invia notifica di prova ora
              </button>

              {notifFeedback && (
                <p className="text-xs text-[#38BDF8] leading-relaxed">{notifFeedback}</p>
              )}
            </div>

            {/* Injuries */}
            <div className="space-y-3 pt-1">
              <div className="flex items-center gap-2 text-sm font-semibold text-[#FFFFFF]">
                <ShieldAlert className="w-4 h-4 text-[#00D2FF]" />
                <span>Fastidi o infortuni pregressi da proteggere</span>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => setInjuries([])}
                  className={`w-full text-left p-3.5 rounded-2xl border transition flex items-center justify-between ${
                    injuries.length === 0
                      ? 'bg-[#132347] border-[#2563EB]'
                      : 'bg-[#0F172A] border-[#1E293B]'
                  }`}
                >
                  <span className="text-sm font-bold text-[#FFFFFF]">Nessun fastidio attuale</span>
                  {injuries.length === 0 && <Check className="w-4 h-4 text-[#38BDF8]" />}
                </button>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {JOINT_OPTIONS.map((j) => {
                    const active = injuries.includes(j.id);
                    return (
                      <button
                        key={j.id}
                        type="button"
                        onClick={() => toggleInjury(j.id)}
                        className={`text-left p-3.5 rounded-2xl border transition flex items-center justify-between gap-2 ${
                          active
                            ? 'bg-[#0B1D36] border-[#38BDF8]'
                            : 'bg-[#0F172A] border-[#1E293B] hover:border-[#38BDF8]/40'
                        }`}
                      >
                        <div>
                          <p className="text-sm font-bold text-[#FFFFFF]">{j.label}</p>
                          <p className="text-xs text-[#94A3B8] mt-0.5">{j.detail}</p>
                        </div>
                        <span
                          className={`w-5 h-5 rounded-md flex items-center justify-center shrink-0 border ${
                            active
                              ? 'bg-[#38BDF8] border-[#38BDF8] text-[#05070A]'
                              : 'border-[#1E293B] text-transparent'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </section>
        )}
      </main>

      {/* Fixed Bottom CTA Bar */}
      <footer className="fixed bottom-0 left-0 right-0 z-30 bg-gradient-to-t from-[#05070A] via-[#05070A] to-transparent pt-6 pb-safe px-4">
        <div className="max-w-2xl mx-auto">
          {step < 4 ? (
            <button
              type="button"
              onClick={() => setStep((s) => s + 1)}
              className="w-full min-h-[52px] rounded-2xl bg-[#2563EB] text-[#FFFFFF] text-base font-extrabold flex items-center justify-center gap-2 hover:bg-[#3B82F6] active:scale-[0.98] transition shadow-lg shadow-[#05070A]/70"
            >
              <span>Continua</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          ) : (
            <div className="space-y-2">
              <button
                type="button"
                onClick={handleFinish}
                className="w-full min-h-[52px] rounded-2xl bg-[#2563EB] text-[#FFFFFF] text-base font-extrabold flex items-center justify-center gap-2 hover:bg-[#3B82F6] active:scale-[0.98] transition shadow-lg shadow-[#05070A]/70"
              >
                <Sparkles className="w-5 h-5" />
                <span>Genera la mia scheda</span>
              </button>
              {onCreateCustomSchedule && (
                <button
                  type="button"
                  onClick={() => onCreateCustomSchedule(buildProfilePayload())}
                  className="w-full min-h-[44px] rounded-2xl bg-[#0F172A] border border-[#1E293B] text-xs font-bold text-[#FFFFFF] hover:bg-[#131C31] transition"
                >
                  Oppure crea tu la tua scheda da zero
                </button>
              )}
            </div>
          )}
        </div>
      </footer>
    </div>
  );
};
