import React, { useMemo, useState } from 'react';
import { Calculator, Dumbbell, X } from 'lucide-react';
import { calculateCalisthenics1RM } from '../utils/recoveryAndMissions';
import { playTechClick } from '../utils/audio';

interface OneRMCalculatorCardProps {
  defaultWeightKg?: number;
  compact?: boolean;
}

export const OneRMCalculatorCard: React.FC<OneRMCalculatorCardProps> = ({
  defaultWeightKg,
  compact = false,
}) => {
  const [exercise, setExercise] = useState<'pullup' | 'dip'>('pullup');
  const [bodyWeightStr, setBodyWeightStr] = useState<string>(
    defaultWeightKg && defaultWeightKg > 0 ? String(defaultWeightKg) : '72'
  );
  const [addedKgStr, setAddedKgStr] = useState<string>('15');
  const [repsStr, setRepsStr] = useState<string>('5');

  const bodyWeightKg = Math.max(30, Number(bodyWeightStr) || 70);
  const addedWeightKg = Math.max(0, Number(addedKgStr) || 0);
  const reps = Math.max(1, Math.min(20, Number(repsStr) || 1));

  const result = useMemo(
    () =>
      calculateCalisthenics1RM({
        bodyWeightKg,
        addedWeightKg,
        reps,
      }),
    [bodyWeightKg, addedWeightKg, reps]
  );

  const formatBeltRange = (minKg: number, maxKg: number): string => {
    if (maxKg <= 0) return 'Corpo libero (nessuna zavorra)';
    const low = Math.max(0, minKg);
    const high = Math.max(0, maxKg);
    if (low === 0) return `0 – +${high} kg`;
    return `+${low} – +${high} kg`;
  };

  return (
    <section
      className={`rounded-2xl border ${compact ? 'p-3.5' : 'p-4 sm:p-5'} space-y-3.5`}
      style={{
        backgroundColor: 'var(--bg-card)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-main)',
      }}
    >
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Calculator className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
          <div>
            <h3 className="text-sm font-extrabold">
              Calcolatore Zavorre &amp; Massimali (1RM)
            </h3>
            <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
              Calcola il massimale reale (peso corporeo + cintura) e le zavorre target
            </p>
          </div>
        </div>
      </div>

      {/* Exercise Switcher */}
      <div className="grid grid-cols-2 gap-2">
        {(
          [
            { id: 'pullup', label: 'Trazioni alla sbarra' },
            { id: 'dip', label: 'Dip alle parallele' },
          ] as const
        ).map((opt) => {
          const active = exercise === opt.id;
          return (
            <button
              key={opt.id}
              type="button"
              onClick={() => {
                playTechClick();
                setExercise(opt.id);
              }}
              className="min-h-[40px] px-3 rounded-xl border text-xs font-extrabold transition flex items-center justify-center gap-1.5"
              style={{
                backgroundColor: active ? 'var(--primary)' : 'var(--bg-main)',
                borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                color: active ? '#FFFFFF' : 'var(--text-secondary)',
              }}
            >
              <Dumbbell className="w-3.5 h-3.5 shrink-0" />
              <span className="truncate">{opt.label}</span>
            </button>
          );
        })}
      </div>

      {/* 3 Numeric Inputs */}
      <div className="grid grid-cols-3 gap-2.5">
        <div>
          <label
            htmlFor="onerm-bw"
            className="block text-[11px] font-semibold mb-1"
            style={{ color: 'var(--text-muted)' }}
          >
            Peso Corp. (kg)
          </label>
          <input
            id="onerm-bw"
            type="number"
            min={35}
            max={180}
            step="0.5"
            inputMode="decimal"
            value={bodyWeightStr}
            onChange={(e) => setBodyWeightStr(e.target.value)}
            className="w-full min-h-[42px] rounded-xl border px-2.5 font-mono text-sm font-bold tabular-nums focus:outline-none"
            style={{
              backgroundColor: 'var(--bg-main)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          />
        </div>

        <div>
          <label
            htmlFor="onerm-added"
            className="block text-[11px] font-semibold mb-1"
            style={{ color: 'var(--text-muted)' }}
          >
            Zavorra (kg)
          </label>
          <input
            id="onerm-added"
            type="number"
            min={0}
            max={140}
            step="1.25"
            inputMode="decimal"
            value={addedKgStr}
            onChange={(e) => setAddedKgStr(e.target.value)}
            className="w-full min-h-[42px] rounded-xl border px-2.5 font-mono text-sm font-bold tabular-nums focus:outline-none"
            style={{
              backgroundColor: 'var(--bg-main)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          />
        </div>

        <div>
          <label
            htmlFor="onerm-reps"
            className="block text-[11px] font-semibold mb-1"
            style={{ color: 'var(--text-muted)' }}
          >
            Rep pulite (1–20)
          </label>
          <input
            id="onerm-reps"
            type="number"
            min={1}
            max={20}
            inputMode="numeric"
            value={repsStr}
            onChange={(e) => setRepsStr(e.target.value)}
            className="w-full min-h-[42px] rounded-xl border px-2.5 font-mono text-sm font-bold tabular-nums focus:outline-none"
            style={{
              backgroundColor: 'var(--bg-main)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          />
        </div>
      </div>

      {/* 1RM Summary Hero */}
      <div
        className="rounded-xl border p-3 flex flex-wrap items-center justify-between gap-2"
        style={{
          backgroundColor: 'var(--bg-elevated)',
          borderColor: 'var(--accent)',
        }}
      >
        <div>
          <p className="text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
            1RM Stimato ({exercise === 'pullup' ? 'Trazioni' : 'Dip'})
          </p>
          <p className="font-mono text-xl font-black tabular-nums" style={{ color: 'var(--accent)' }}>
            {result.oneRmAddedKg >= 0 ? `+${result.oneRmAddedKg} kg` : `${result.oneRmAddedKg} kg`} alla cintura
          </p>
        </div>
        <div className="text-right">
          <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
            Carico Totale (BW + Zavorra)
          </p>
          <p className="font-mono text-base font-extrabold tabular-nums">
            {result.oneRmTotalKg} kg
          </p>
        </div>
      </div>

      {/* Target Zones Table */}
      <div className="space-y-2">
        <p className="text-[11px] font-bold uppercase tracking-wider" style={{ color: 'var(--text-muted)' }}>
          Peso esatto da appendere alla cintura
        </p>
        <div className="space-y-1.5">
          {result.zones.map((zone) => (
            <div
              key={zone.id}
              className="rounded-xl border px-3 py-2.5 flex items-center justify-between gap-2"
              style={{
                backgroundColor: 'var(--bg-main)',
                borderColor: 'var(--border-subtle)',
              }}
            >
              <div className="min-w-0">
                <p className="text-xs font-extrabold truncate">{zone.title}</p>
                <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
                  {zone.repsRange} · {zone.pctLabel}
                </p>
              </div>
              <div className="text-right shrink-0">
                <p className="font-mono text-xs sm:text-sm font-extrabold tabular-nums" style={{ color: 'var(--accent)' }}>
                  {formatBeltRange(zone.minAddedKg, zone.maxAddedKg)}
                </p>
                <p className="font-mono text-[10px] tabular-nums" style={{ color: 'var(--text-muted)' }}>
                  Tot {zone.minTotalKg}–{zone.maxTotalKg} kg
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

interface OneRMCalculatorModalProps {
  isOpen: boolean;
  defaultWeightKg?: number;
  onClose: () => void;
}

export const OneRMCalculatorModal: React.FC<OneRMCalculatorModalProps> = ({
  isOpen,
  defaultWeightKg,
  onClose,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Calcolatore Zavorre e Massimali 1RM"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#05070A]/85 backdrop-blur-md p-3 sm:p-4"
    >
      <div className="w-full max-w-md space-y-2 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-end">
          <button
            type="button"
            onClick={onClose}
            aria-label="Chiudi calcolatore"
            className="w-9 h-9 rounded-xl border flex items-center justify-center transition"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>
        <OneRMCalculatorCard defaultWeightKg={defaultWeightKg} compact />
      </div>
    </div>
  );
};
