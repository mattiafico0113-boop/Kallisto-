import React, { useState } from 'react';
import { Download, Share, X } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallButtonProps {
  compact?: boolean;
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ compact = false }) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (isInstalled) {
    return null;
  }

  if (isInstallable) {
    return (
      <button
        type="button"
        onClick={install}
        className={
          compact
            ? 'w-9 h-9 rounded-xl bg-[#2563EB] border border-[#38BDF8]/60 text-[#FFFFFF] inline-flex items-center justify-center hover:bg-[#3B82F6] active:scale-[0.98] transition shrink-0'
            : 'w-full min-h-[48px] flex items-center justify-center gap-2 rounded-2xl bg-[#2563EB] text-[#FFFFFF] px-4 py-3 text-sm font-bold hover:bg-[#3B82F6] active:scale-[0.98] transition whitespace-nowrap'
        }
        aria-label="Installa App CALI PRO"
        title="Installa App CALI PRO"
      >
        <Download className="w-4 h-4 shrink-0" />
        {!compact && <span>Installa App</span>}
      </button>
    );
  }

  if (isIOS) {
    return (
      <>
        <button
          type="button"
          onClick={() => setShowIOSGuide(true)}
          aria-label="Installa CALI PRO su iPhone"
          title="Installa CALI PRO su iPhone"
          className={
            compact
              ? 'w-9 h-9 rounded-xl border border-[#1E293B] bg-[#0F172A] text-[#38BDF8] inline-flex items-center justify-center hover:bg-[#131C31] transition shrink-0'
              : 'w-full min-h-[48px] flex items-center justify-center gap-2 rounded-2xl border border-[#1E293B] bg-[#0F172A] text-[#FFFFFF] px-4 py-3 text-sm font-semibold hover:bg-[#131C31] transition whitespace-nowrap'
          }
        >
          <Share className="w-4 h-4 shrink-0 text-[#38BDF8]" />
          {!compact && <span>Installa su iPhone</span>}
        </button>

        {showIOSGuide && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#05070A]/80 backdrop-blur-sm p-4">
            <div className="w-full max-w-sm rounded-3xl bg-[#0F172A] border border-[#1E293B] p-6 shadow-2xl">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-bold text-[#FFFFFF]">Installa CALI PRO su iOS</h3>
                <button
                  type="button"
                  onClick={() => setShowIOSGuide(false)}
                  aria-label="Chiudi guida installazione"
                  className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-[#94A3B8] hover:text-[#FFFFFF]"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <ol className="mt-4 space-y-3 text-sm text-[#CBD5E1]">
                <li>
                  1. Tocca il pulsante <strong className="text-[#FFFFFF]">Condividi</strong> nella barra di Safari.
                </li>
                <li>
                  2. Scorri verso il basso e seleziona{' '}
                  <strong className="text-[#38BDF8]">Aggiungi alla schermata Home</strong>.
                </li>
                <li>3. Conferma toccando <strong className="text-[#FFFFFF]">Aggiungi</strong> in alto a destra.</li>
              </ol>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                className="mt-6 w-full min-h-[44px] rounded-xl bg-[#2563EB] text-[#FFFFFF] text-sm font-bold hover:bg-[#3B82F6] transition"
              >
                Ho capito
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return null;
};
