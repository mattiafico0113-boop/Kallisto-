import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  Columns,
  ImagePlus,
  Loader2,
  SlidersHorizontal,
  Trash2,
} from 'lucide-react';
import { playSetCompleteTone, playTechClick } from '../utils/audio';
import {
  compressProgressImage,
  deleteProgressPhoto,
  loadProgressPhotos,
  saveProgressPhoto,
  type ProgressPhotoEntry,
} from '../utils/photoDiaryDB';

interface PhotoDiarySectionProps {
  accountId: string;
  currentWeightKg?: number;
}

export const PhotoDiarySection: React.FC<PhotoDiarySectionProps> = ({
  accountId,
  currentWeightKg,
}) => {
  const [photos, setPhotos] = useState<ProgressPhotoEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [noteInput, setNoteInput] = useState('');

  // Before / After Comparison state
  const [compareMode, setCompareMode] = useState<'slider' | 'side'>('slider');
  const [sliderPct, setSliderPct] = useState(50);
  const [beforeId, setBeforeId] = useState<string>('');
  const [afterId, setAfterId] = useState<string>('');

  const cameraInputRef = useRef<HTMLInputElement | null>(null);
  const galleryInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    loadProgressPhotos(accountId).then((list) => {
      if (!active) return;
      setPhotos(list);
      if (list.length >= 2) {
        setBeforeId(list[list.length - 1].id); // oldest
        setAfterId(list[0].id); // newest
      } else if (list.length === 1) {
        setBeforeId(list[0].id);
        setAfterId(list[0].id);
      }
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, [accountId]);

  const handleSelectedFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setSaving(true);
    setErrorMsg(null);
    try {
      const compressedDataUrl = await compressProgressImage(file);
      const entry: ProgressPhotoEntry = {
        id: `photo_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        accountId,
        dateISO: new Date().toISOString(),
        weightKg:
          typeof currentWeightKg === 'number' && currentWeightKg > 0
            ? currentWeightKg
            : null,
        note: noteInput.trim() || undefined,
        dataUrl: compressedDataUrl,
      };
      await saveProgressPhoto(entry);
      const next = [entry, ...photos];
      setPhotos(next);
      setAfterId(entry.id);
      if (next.length === 1) {
        setBeforeId(entry.id);
      } else if (!beforeId) {
        setBeforeId(next[next.length - 1].id);
      }
      setNoteInput('');
      playSetCompleteTone();
    } catch (err) {
      setErrorMsg(
        err instanceof Error
          ? err.message
          : 'Impossibile comprimere o salvare la foto.'
      );
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    playTechClick();
    await deleteProgressPhoto(id);
    const next = photos.filter((p) => p.id !== id);
    setPhotos(next);
    if (next.length >= 2) {
      if (beforeId === id) setBeforeId(next[next.length - 1].id);
      if (afterId === id) setAfterId(next[0].id);
    } else if (next.length === 1) {
      setBeforeId(next[0].id);
      setAfterId(next[0].id);
    }
  };

  const beforePhoto = photos.find((p) => p.id === beforeId) ?? photos[photos.length - 1];
  const afterPhoto = photos.find((p) => p.id === afterId) ?? photos[0];

  const weightDiff =
    beforePhoto?.weightKg != null && afterPhoto?.weightKg != null
      ? Number((afterPhoto.weightKg - beforePhoto.weightKg).toFixed(1))
      : null;

  return (
    <div className="space-y-4">
      {/* Capture / Upload Controls */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-3.5">
        <div>
          <h2 className="text-base font-extrabold text-[#FFFFFF]">
            Diario Fotografico Progressi
          </h2>
          <p className="text-xs text-[#94A3B8] mt-0.5">
            Ogni foto viene compressa automaticamente e associata a data odierna
            {typeof currentWeightKg === 'number' && currentWeightKg > 0
              ? ` e peso attuale (${currentWeightKg} kg)`
              : ''}
            .
          </p>
        </div>

        <input
          type="text"
          value={noteInput}
          onChange={(e) => setNoteInput(e.target.value)}
          placeholder="Nota facoltativa (es. Post workout upper, luci fredde...)"
          className="w-full min-h-[42px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 text-xs text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#00D2FF]"
        />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <button
            type="button"
            disabled={saving}
            onClick={() => {
              playTechClick();
              cameraInputRef.current?.click();
            }}
            className="min-h-[46px] rounded-xl bg-[#2563EB] text-[#FFFFFF] text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#3B82F6] disabled:opacity-60 transition"
          >
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Camera className="w-4 h-4" />
            )}
            <span>Scatta Foto con Fotocamera</span>
          </button>

          <button
            type="button"
            disabled={saving}
            onClick={() => {
              playTechClick();
              galleryInputRef.current?.click();
            }}
            className="min-h-[46px] rounded-xl bg-[#00D2FF] text-[#05070A] text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#38BDF8] disabled:opacity-60 transition"
          >
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <ImagePlus className="w-4 h-4" />
            )}
            <span>Carica da Galleria</span>
          </button>

          <input
            ref={cameraInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handleSelectedFile}
            className="hidden"
          />
          <input
            ref={galleryInputRef}
            type="file"
            accept="image/*"
            onChange={handleSelectedFile}
            className="hidden"
          />
        </div>

        {errorMsg && <p className="text-xs font-semibold text-[#38BDF8]">{errorMsg}</p>}
      </section>

      {/* Before / After Comparison Module */}
      {photos.length >= 2 && beforePhoto && afterPhoto && (
        <section className="rounded-2xl bg-[#0B1D36] border border-[#2563EB]/70 p-4 sm:p-5 space-y-3.5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h3 className="text-sm sm:text-base font-extrabold text-[#FFFFFF]">
                Confronta Prima e Dopo
              </h3>
              <p className="text-xs text-[#94A3B8]">
                {weightDiff !== null
                  ? `Variazione peso: ${weightDiff > 0 ? `+${weightDiff}` : weightDiff} kg`
                  : 'Seleziona due scatti da confrontare'}
              </p>
            </div>

            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#090D16] border border-[#1E293B]">
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  setCompareMode('slider');
                }}
                className={`min-h-[34px] px-2.5 rounded-lg text-xs font-bold inline-flex items-center gap-1 transition ${
                  compareMode === 'slider'
                    ? 'bg-[#2563EB] text-[#FFFFFF]'
                    : 'text-[#94A3B8] hover:text-[#FFFFFF]'
                }`}
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Cursore</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  setCompareMode('side');
                }}
                className={`min-h-[34px] px-2.5 rounded-lg text-xs font-bold inline-flex items-center gap-1 transition ${
                  compareMode === 'side'
                    ? 'bg-[#2563EB] text-[#FFFFFF]'
                    : 'text-[#94A3B8] hover:text-[#FFFFFF]'
                }`}
              >
                <Columns className="w-3.5 h-3.5" />
                <span>Affiancate</span>
              </button>
            </div>
          </div>

          {/* Photo Pickers */}
          <div className="grid grid-cols-2 gap-2.5">
            <div>
              <label
                htmlFor="photo-before-select"
                className="block text-[11px] font-bold text-[#94A3B8] mb-1"
              >
                Foto Prima
              </label>
              <select
                id="photo-before-select"
                value={beforePhoto.id}
                onChange={(e) => setBeforeId(e.target.value)}
                className="w-full min-h-[40px] rounded-xl bg-[#090D16] border border-[#1E293B] px-2.5 text-xs font-semibold text-[#FFFFFF] focus:outline-none focus:border-[#00D2FF]"
              >
                {photos.map((p) => (
                  <option key={p.id} value={p.id}>
                    {new Date(p.dateISO).toLocaleDateString('it-IT', {
                      day: '2-digit',
                      month: 'short',
                      year: '2-digit',
                    })}
                    {p.weightKg != null ? ` · ${p.weightKg}kg` : ''}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="photo-after-select"
                className="block text-[11px] font-bold text-[#00D2FF] mb-1"
              >
                Foto Dopo
              </label>
              <select
                id="photo-after-select"
                value={afterPhoto.id}
                onChange={(e) => setAfterId(e.target.value)}
                className="w-full min-h-[40px] rounded-xl bg-[#090D16] border border-[#38BDF8]/50 px-2.5 text-xs font-semibold text-[#FFFFFF] focus:outline-none focus:border-[#00D2FF]"
              >
                {photos.map((p) => (
                  <option key={p.id} value={p.id}>
                    {new Date(p.dateISO).toLocaleDateString('it-IT', {
                      day: '2-digit',
                      month: 'short',
                      year: '2-digit',
                    })}
                    {p.weightKg != null ? ` · ${p.weightKg}kg` : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {compareMode === 'slider' ? (
            <div className="space-y-2.5">
              <div className="relative w-full aspect-[3/4] max-h-[430px] rounded-2xl overflow-hidden bg-[#05070A] border border-[#1E293B] select-none">
                {/* Base Layer: AFTER photo */}
                <img
                  src={afterPhoto.dataUrl}
                  alt="Foto Dopo"
                  className="absolute inset-0 w-full h-full object-cover"
                />

                {/* Clipped Overlay: BEFORE photo */}
                <div
                  className="absolute inset-0 overflow-hidden"
                  style={{ clipPath: `inset(0 ${100 - sliderPct}% 0 0)` }}
                >
                  <img
                    src={beforePhoto.dataUrl}
                    alt="Foto Prima"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Vertical Cyan Divider Handle */}
                <div
                  className="absolute top-0 bottom-0 w-0.5 bg-[#00D2FF] shadow-[0_0_12px_rgba(0,210,255,0.9)] pointer-events-none"
                  style={{ left: `${sliderPct}%` }}
                >
                  <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-[#00D2FF] text-[#05070A] font-black text-xs flex items-center justify-center shadow-lg">
                    ⇄
                  </div>
                </div>

                {/* Corner Labels */}
                <span className="absolute top-2.5 left-2.5 rounded-lg bg-[#05070A]/85 border border-[#1E293B] px-2 py-1 text-[10px] font-bold text-[#CBD5E1]">
                  PRIMA ·{' '}
                  {new Date(beforePhoto.dateISO).toLocaleDateString('it-IT', {
                    day: '2-digit',
                    month: 'short',
                  })}
                  {beforePhoto.weightKg != null ? ` (${beforePhoto.weightKg}kg)` : ''}
                </span>
                <span className="absolute top-2.5 right-2.5 rounded-lg bg-[#05070A]/85 border border-[#00D2FF]/60 px-2 py-1 text-[10px] font-bold text-[#00D2FF]">
                  DOPO ·{' '}
                  {new Date(afterPhoto.dateISO).toLocaleDateString('it-IT', {
                    day: '2-digit',
                    month: 'short',
                  })}
                  {afterPhoto.weightKg != null ? ` (${afterPhoto.weightKg}kg)` : ''}
                </span>
              </div>

              <input
                type="range"
                min={0}
                max={100}
                value={sliderPct}
                onChange={(e) => setSliderPct(Number(e.target.value))}
                aria-label="Cursore confronto Prima e Dopo"
                className="w-full accent-[#00D2FF] cursor-pointer"
              />
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-2.5">
              <div className="rounded-2xl overflow-hidden bg-[#05070A] border border-[#1E293B]">
                <img
                  src={beforePhoto.dataUrl}
                  alt="Foto Prima"
                  className="w-full aspect-[3/4] object-cover"
                />
                <div className="p-2 text-center bg-[#090D16] border-t border-[#1E293B]">
                  <p className="text-[11px] font-bold text-[#CBD5E1]">
                    PRIMA ·{' '}
                    {new Date(beforePhoto.dateISO).toLocaleDateString('it-IT', {
                      day: '2-digit',
                      month: 'short',
                    })}
                  </p>
                  {beforePhoto.weightKg != null && (
                    <p className="font-mono text-xs font-bold text-[#94A3B8] tabular-nums">
                      {beforePhoto.weightKg} kg
                    </p>
                  )}
                </div>
              </div>

              <div className="rounded-2xl overflow-hidden bg-[#05070A] border border-[#00D2FF]/70">
                <img
                  src={afterPhoto.dataUrl}
                  alt="Foto Dopo"
                  className="w-full aspect-[3/4] object-cover"
                />
                <div className="p-2 text-center bg-[#090D16] border-t border-[#1E293B]">
                  <p className="text-[11px] font-bold text-[#00D2FF]">
                    DOPO ·{' '}
                    {new Date(afterPhoto.dateISO).toLocaleDateString('it-IT', {
                      day: '2-digit',
                      month: 'short',
                    })}
                  </p>
                  {afterPhoto.weightKg != null && (
                    <p className="font-mono text-xs font-bold text-[#FFFFFF] tabular-nums">
                      {afterPhoto.weightKg} kg
                    </p>
                  )}
                </div>
              </div>
            </div>
          )}
        </section>
      )}

      {/* Photo Timeline Archive */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-sm font-bold text-[#FFFFFF]">Archivio Scatti</h3>
          <span className="font-mono text-xs font-bold text-[#38BDF8] tabular-nums">
            {photos.length} foto
          </span>
        </div>

        {loading ? (
          <p className="text-xs text-[#94A3B8]">Caricamento diario fotografico...</p>
        ) : photos.length === 0 ? (
          <p className="text-xs text-[#94A3B8] leading-relaxed">
            Nessuna foto salvata finora. Scatta o carica il tuo primo check fisico per sbloccare il confronto Prima e Dopo!
          </p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {photos.map((p) => (
              <article
                key={p.id}
                className="rounded-xl overflow-hidden bg-[#090D16] border border-[#1E293B] flex flex-col"
              >
                <div className="relative">
                  <img
                    src={p.dataUrl}
                    alt={`Check ${new Date(p.dateISO).toLocaleDateString('it-IT')}`}
                    className="w-full aspect-[3/4] object-cover"
                  />
                  <button
                    type="button"
                    onClick={() => handleDelete(p.id)}
                    aria-label="Elimina foto"
                    className="absolute top-2 right-2 w-8 h-8 rounded-lg bg-[#05070A]/85 border border-[#1E293B] text-[#94A3B8] hover:text-[#38BDF8] flex items-center justify-center transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="p-2.5 space-y-0.5">
                  <div className="flex items-center justify-between gap-1 text-[11px] font-bold">
                    <span className="text-[#FFFFFF]">
                      {new Date(p.dateISO).toLocaleDateString('it-IT', {
                        day: '2-digit',
                        month: 'short',
                        year: '2-digit',
                      })}
                    </span>
                    {p.weightKg != null && (
                      <span className="font-mono text-[#00D2FF] tabular-nums">
                        {p.weightKg} kg
                      </span>
                    )}
                  </div>
                  {p.note && (
                    <p className="text-[10px] text-[#94A3B8] truncate">{p.note}</p>
                  )}
                </div>
              </article>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
