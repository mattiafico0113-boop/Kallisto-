import React, { useState } from 'react';
import { Award, Download, Flame, MessageSquare, ShieldCheck, Timer, Zap } from 'lucide-react';
import type { PostWorkoutSummaryData } from '../utils/athletePillars';
import { playTechClick } from '../utils/audio';
import { CaliProLogo } from './CaliProLogo';

interface PostWorkoutSummaryModalProps {
  summary: PostWorkoutSummaryData | null;
  athleteName: string;
  onContinueToCoach: () => void;
}

function drawShareCardCanvas(
  summary: PostWorkoutSummaryData,
  athleteName: string
): string | null {
  const canvas = document.createElement('canvas');
  canvas.width = 1080;
  canvas.height = 1350;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const computed = getComputedStyle(document.documentElement);
  const bgMain = computed.getPropertyValue('--bg-main').trim() || '#05070A';
  const bgCard = computed.getPropertyValue('--bg-card').trim() || '#0F172A';
  const primary = computed.getPropertyValue('--primary').trim() || '#2563EB';
  const accent = computed.getPropertyValue('--accent').trim() || '#00D2FF';
  const textMain = computed.getPropertyValue('--text-main').trim() || '#FFFFFF';
  const textMuted = computed.getPropertyValue('--text-muted').trim() || '#94A3B8';

  // Background & Radial Glow
  ctx.fillStyle = bgMain;
  ctx.fillRect(0, 0, 1080, 1350);

  const grad = ctx.createRadialGradient(540, 260, 40, 540, 480, 740);
  grad.addColorStop(0, `${primary}44`);
  grad.addColorStop(0.55, `${accent}1A`);
  grad.addColorStop(1, 'transparent');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 1080, 1350);

  // Outer Glowing Card Frame
  ctx.strokeStyle = accent;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.roundRect(48, 48, 984, 1254, 42);
  ctx.stroke();

  // Hexagon Emblem
  ctx.save();
  ctx.translate(96, 98);
  ctx.fillStyle = bgCard;
  ctx.strokeStyle = accent;
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(46, 0);
  ctx.lineTo(88, 24);
  ctx.lineTo(88, 72);
  ctx.lineTo(46, 96);
  ctx.lineTo(4, 72);
  ctx.lineTo(4, 24);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.strokeStyle = textMain;
  ctx.lineWidth = 6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(22, 48);
  ctx.lineTo(66, 48);
  ctx.moveTo(52, 48);
  ctx.lineTo(58, 72);
  ctx.stroke();
  ctx.restore();

  // Brand Title
  ctx.fillStyle = textMain;
  ctx.font = '800 42px Outfit, sans-serif';
  ctx.fillText('CALI', 208, 146);
  ctx.fillStyle = accent;
  ctx.fillText('PRO', 208 + ctx.measureText('CALI ').width, 146);

  ctx.fillStyle = textMuted;
  ctx.font = '600 24px Plus Jakarta Sans, sans-serif';
  ctx.fillText(`RIEPILOGO ALLENAMENTO · ${athleteName.toUpperCase()}`, 208, 184);

  // Workout Title & Date
  ctx.fillStyle = textMain;
  ctx.font = '800 54px Outfit, sans-serif';
  ctx.fillText(summary.session.dayTitle.slice(0, 30), 96, 300);

  ctx.fillStyle = accent;
  ctx.font = '600 28px Plus Jakarta Sans, sans-serif';
  ctx.fillText(summary.dateFormatted, 96, 348);

  // 4 Key Metric Tiles
  const tiles = [
    { label: 'DURATA TOTALE', value: summary.durationFormatted },
    {
      label: 'VOLUME SVOLTO',
      value: `${summary.totalReps} rep${summary.totalIsoSeconds > 0 ? ` + ${summary.totalIsoSeconds}s` : ''}`,
    },
    {
      label: 'MEDIA VOTO TECNICO',
      value:
        summary.avgTechScore !== null
          ? `${summary.avgTechScore.toFixed(1)} / 3.0`
          : 'Non valutato',
      sub: summary.avgTechScore !== null ? summary.techVerdictLabel : '',
    },
    { label: 'PUNTI XP GUADAGNATI', value: `+${summary.xpEarned} XP` },
  ];

  tiles.forEach((tile, idx) => {
    const col = idx % 2;
    const row = Math.floor(idx / 2);
    const x = 96 + col * 456;
    const y = 410 + row * 224;
    ctx.fillStyle = bgCard;
    ctx.strokeStyle = idx === 3 ? accent : primary;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.roundRect(x, y, 432, 196, 28);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = textMuted;
    ctx.font = '700 22px Plus Jakarta Sans, sans-serif';
    ctx.fillText(tile.label, x + 28, y + 52);

    ctx.fillStyle = idx === 3 ? accent : textMain;
    ctx.font = '800 42px JetBrains Mono, monospace';
    ctx.fillText(tile.value, x + 28, y + 124);

    if (tile.sub) {
      ctx.fillStyle = accent;
      ctx.font = '700 22px Plus Jakarta Sans, sans-serif';
      ctx.fillText(tile.sub, x + 28, y + 166);
    }
  });

  // Broken Records Section
  ctx.fillStyle = bgCard;
  ctx.strokeStyle = summary.brokenRecords.length > 0 ? accent : `${textMuted}55`;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.roundRect(96, 874, 888, 280, 28);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = accent;
  ctx.font = '800 26px Outfit, sans-serif';
  ctx.fillText(
    summary.brokenRecords.length > 0
      ? `NUOVI RECORD BATTUTI (${summary.brokenRecords.length})`
      : 'ESERCIZI COMPLETATI',
    128,
    926
  );

  const lines =
    summary.brokenRecords.length > 0
      ? summary.brokenRecords.slice(0, 4).map((r) => `• ${r.exerciseName}: ${r.valueLabel}`)
      : summary.session.exercises
          .slice(0, 4)
          .map(
            (ex) =>
              `• ${ex.exerciseName}: Best ${ex.bestValue}${ex.isIsometric ? 's' : ' rep'}`
          );

  ctx.fillStyle = textMain;
  ctx.font = '600 28px Plus Jakarta Sans, sans-serif';
  lines.forEach((line, i) => {
    ctx.fillText(line.slice(0, 46), 128, 984 + i * 44);
  });

  // Footer
  ctx.fillStyle = textMuted;
  ctx.font = '600 22px Plus Jakarta Sans, sans-serif';
  ctx.fillText('Allenato con Kallisto Calisthenics', 96, 1244);

  return canvas.toDataURL('image/png');
}

export const PostWorkoutSummaryModal: React.FC<PostWorkoutSummaryModalProps> = ({
  summary,
  athleteName,
  onContinueToCoach,
}) => {
  const [savedNotice, setSavedNotice] = useState(false);

  if (!summary) return null;

  const handleDownloadPng = () => {
    playTechClick();
    const dataUrl = drawShareCardCanvas(summary, athleteName);
    if (!dataUrl) return;
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `calipro-allenamento-${new Date(summary.session.dateISO).toISOString().slice(0, 10)}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setSavedNotice(true);
    window.setTimeout(() => setSavedNotice(false), 3000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Riepilogo post-allenamento condivisibile"
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#05070A]/90 backdrop-blur-md p-3 sm:p-4 overflow-y-auto"
    >
      <div
        className="w-full max-w-md rounded-3xl border p-5 space-y-4 shadow-2xl my-auto"
        style={{
          backgroundColor: 'var(--bg-main)',
          borderColor: 'var(--accent)',
          boxShadow: '0 0 36px color-mix(in srgb, var(--accent) 26%, transparent)',
          color: 'var(--text-main)',
        }}
      >
        {/* Top App Logo */}
        <div className="flex items-center justify-between gap-2">
          <CaliProLogo size="sm" />
          <span
            className="font-mono text-xs font-extrabold uppercase tracking-wider"
            style={{ color: 'var(--accent)' }}
          >
            Sessione Chiusa
          </span>
        </div>

        {/* Workout Title & Date */}
        <div
          className="rounded-2xl border p-4 space-y-1"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--primary)',
          }}
        >
          <p className="text-xs font-semibold capitalize" style={{ color: 'var(--accent)' }}>
            {summary.dateFormatted}
          </p>
          <h2 className="text-xl font-extrabold leading-tight">{summary.session.dayTitle}</h2>
          <p className="text-xs" style={{ color: 'var(--text-muted)' }}>
            Atleta: <strong style={{ color: 'var(--text-main)' }}>{athleteName}</strong> ·{' '}
            {summary.completedSetsCount} serie completate
          </p>
        </div>

        {/* High-Impact Numbers Grid */}
        <div className="grid grid-cols-2 gap-2.5">
          <div
            className="rounded-2xl border p-3.5 space-y-1"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div className="flex items-center gap-1.5 text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
              <Timer className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} />
              <span>Durata Totale</span>
            </div>
            <p className="font-mono text-lg font-extrabold tabular-nums">
              {summary.durationFormatted}
            </p>
          </div>

          <div
            className="rounded-2xl border p-3.5 space-y-1"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div className="flex items-center gap-1.5 text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
              <Zap className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} />
              <span>Volume Totale</span>
            </div>
            <p className="font-mono text-lg font-extrabold tabular-nums">
              {summary.totalReps} rep
              {summary.totalIsoSeconds > 0 ? ` · ${summary.totalIsoSeconds}s` : ''}
            </p>
          </div>

          <div
            className="rounded-2xl border p-3.5 space-y-1"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div className="flex items-center gap-1.5 text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
              <ShieldCheck className="w-3.5 h-3.5" style={{ color: 'var(--accent)' }} />
              <span>Media Voto Tecnico</span>
            </div>
            <p className="font-mono text-lg font-extrabold tabular-nums">
              {summary.avgTechScore !== null ? `${summary.avgTechScore.toFixed(1)} / 3.0` : '—'}
            </p>
            <p className="text-[11px] font-semibold" style={{ color: 'var(--accent)' }}>
              {summary.techVerdictLabel}
            </p>
          </div>

          <div
            className="rounded-2xl border p-3.5 space-y-1"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--accent)',
            }}
          >
            <div className="flex items-center gap-1.5 text-[11px] font-bold" style={{ color: 'var(--accent)' }}>
              <Award className="w-3.5 h-3.5" />
              <span>XP Guadagnati</span>
            </div>
            <p
              className="font-mono text-2xl font-black tabular-nums"
              style={{ color: 'var(--accent)' }}
            >
              +{summary.xpEarned} XP
            </p>
          </div>
        </div>

        {/* Broken Records Highlight */}
        <div
          className="rounded-2xl border p-3.5 space-y-1.5"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: summary.brokenRecords.length > 0 ? 'var(--accent)' : 'var(--border-subtle)',
          }}
        >
          <div className="flex items-center gap-1.5 text-xs font-extrabold">
            <Flame className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            <span>
              {summary.brokenRecords.length > 0
                ? `Nuovi Record Battuti (${summary.brokenRecords.length})`
                : 'Prestazioni Principali'}
            </span>
          </div>

          {summary.brokenRecords.length > 0 ? (
            <ul className="space-y-1 text-xs">
              {summary.brokenRecords.map((rec, i) => (
                <li key={i} className="flex items-center justify-between gap-2">
                  <span className="truncate font-semibold">{rec.exerciseName}</span>
                  <span className="font-mono font-extrabold shrink-0" style={{ color: 'var(--accent)' }}>
                    {rec.valueLabel}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <ul className="space-y-1 text-xs">
              {summary.session.exercises.slice(0, 3).map((ex) => (
                <li key={ex.exerciseId} className="flex items-center justify-between gap-2">
                  <span className="truncate" style={{ color: 'var(--text-secondary)' }}>
                    {ex.exerciseName}
                  </span>
                  <span className="font-mono font-bold shrink-0" style={{ color: 'var(--accent)' }}>
                    Best {ex.bestValue}
                    {ex.isIsometric ? 's' : ' rep'}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* 2 Clear Bottom CTAs */}
        <div className="space-y-2.5 pt-1">
          <button
            type="button"
            onClick={handleDownloadPng}
            className="w-full min-h-[48px] px-4 rounded-2xl border text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 transition"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--accent)',
              color: 'var(--accent)',
            }}
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>
              {savedNotice
                ? 'Immagine PNG salvata!'
                : 'Salva Riepilogo come Immagine (PNG)'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => {
              playTechClick();
              onContinueToCoach();
            }}
            className="w-full min-h-[50px] px-4 rounded-2xl text-sm font-extrabold flex items-center justify-center gap-2 transition"
            style={{
              backgroundColor: 'var(--primary)',
              color: '#FFFFFF',
            }}
          >
            <MessageSquare className="w-4 h-4 shrink-0" />
            <span>Continua e Parla con il Coach AI →</span>
          </button>
        </div>
      </div>
    </div>
  );
};
