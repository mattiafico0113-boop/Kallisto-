import React, { useEffect, useState } from 'react';
import { CheckCircle2, Pause, Play, RotateCcw, ShieldCheck, SkipForward, X } from 'lucide-react';
import { playDoubleDing, playSetCompleteTone, playTechClick, playTimerCompleteChime } from '../utils/audio';

interface PrehabStep {
  id: string;
  title: string;
  durationSec: number;
  instruction: string;
}

const PREHAB_STEPS: PrehabStep[] = [
  {
    id: 'step_1',
    title: '1. Rotazioni e flesso-estensioni polsi',
    durationSec: 45,
    instruction:
      'In quadrupedia o a mani unite, esegui cerchi ampi e lenti in entrambi i sensi, poi sposta piano le spalle avanti oltre le dita senza dolore.',
  },
  {
    id: 'step_2',
    title: '2. Stretching estensori dell’avambraccio',
    durationSec: 45,
    instruction:
      'Braccio teso avanti: piega il polso verso il basso e accompagna dolcemente il dorso della mano con l’altra mano (22s per lato).',
  },
  {
    id: 'step_3',
    title: '3. Pronazione e supinazione controllata',
    durationSec: 45,
    instruction:
      'Gomiti stretti ai fianchi piegati a 90°: ruota lentamente gli avambracci portando i palmi su e poi giù fino a fine corsa articolare.',
  },
  {
    id: 'step_4',
    title: '4. Decompressione scapole e gomiti',
    durationSec: 45,
    instruction:
      'Braccia distese sopra la testa o in appoggio morbido: eleva e deprimi le scapole con respiro lento e piega/stendi fluido i gomiti.',
  },
];

interface PrehabModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCompleted?: () => void;
}

export const PrehabModal: React.FC<PrehabModalProps> = ({ isOpen, onClose, onCompleted }) => {
  const [stepIndex, setStepIndex] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState(PREHAB_STEPS[0].durationSec);
  const [running, setRunning] = useState(false);
  const [completed, setCompleted] = useState(false);
  const completedFiredRef = React.useRef(false);

  useEffect(() => {
    if (!isOpen) {
      setRunning(false);
    }
  }, [isOpen]);

  useEffect(() => {
    if (!isOpen || !running || completed) return;

    const timerId = window.setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev > 1) return prev - 1;
        if (stepIndex < PREHAB_STEPS.length - 1) {
          const nextIdx = stepIndex + 1;
          playDoubleDing();
          setStepIndex(nextIdx);
          return PREHAB_STEPS[nextIdx].durationSec;
        }
        playTimerCompleteChime();
        setRunning(false);
        setCompleted(true);
        if (!completedFiredRef.current) {
          completedFiredRef.current = true;
          onCompleted?.();
        }
        return 0;
      });
    }, 1000);

    return () => window.clearInterval(timerId);
  }, [isOpen, running, completed, stepIndex, onCompleted]);

  if (!isOpen) return null;

  const activeStep = PREHAB_STEPS[stepIndex] ?? PREHAB_STEPS[0];
  const elapsedBefore = PREHAB_STEPS.slice(0, stepIndex).reduce((a, s) => a + s.durationSec, 0);
  const elapsedInCurrent = activeStep.durationSec - secondsLeft;
  const totalSec = PREHAB_STEPS.reduce((a, s) => a + s.durationSec, 0);
  const remainingTotal = Math.max(0, totalSec - (elapsedBefore + elapsedInCurrent));
  const totalPct = Math.min(100, Math.round(((totalSec - remainingTotal) / totalSec) * 100));

  const formatMMSS = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const handleReset = () => {
    playTechClick();
    completedFiredRef.current = false;
    setStepIndex(0);
    setSecondsLeft(PREHAB_STEPS[0].durationSec);
    setRunning(false);
    setCompleted(false);
  };

  const handleNextStep = () => {
    playTechClick();
    if (stepIndex < PREHAB_STEPS.length - 1) {
      const next = stepIndex + 1;
      setStepIndex(next);
      setSecondsLeft(PREHAB_STEPS[next].durationSec);
      setCompleted(false);
    } else {
      playSetCompleteTone();
      setRunning(false);
      setCompleted(true);
      setSecondsLeft(0);
      if (!completedFiredRef.current) {
        completedFiredRef.current = true;
        onCompleted?.();
      }
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Prehab Polsi e Gomiti — Routine 3 Minuti"
      className="fixed inset-0 z-50 bg-[#05070A]/85 backdrop-blur-md flex items-end sm:items-center justify-center p-3 sm:p-4"
    >
      <div className="w-full max-w-lg rounded-3xl bg-[#0F172A] border border-[#38BDF8]/60 p-4 sm:p-5 space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#132347] border border-[#00D2FF]/60 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-5 h-5 text-[#00D2FF]" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-[#FFFFFF]">
                Prehab Polsi &amp; Gomiti (3 Min)
              </h3>
              <p className="text-xs text-[#94A3B8]">
                Routine protettiva articolare · 4 step da 45 secondi
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Chiudi Prehab"
            className="w-9 h-9 rounded-xl bg-[#131C31] border border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF] flex items-center justify-center shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Active Step Timer Hero */}
        <div className="rounded-2xl bg-[#090D16] border border-[#1E293B] p-4 space-y-3 text-center">
          {completed ? (
            <div className="py-3 space-y-2">
              <CheckCircle2 className="w-10 h-10 text-[#00D2FF] mx-auto" />
              <p className="text-base font-extrabold text-[#FFFFFF]">
                Prehab Completato! Articolazioni pronte.
              </p>
              <p className="text-xs text-[#CBD5E1]">
                Polsi, estensori e gomiti sono lubrificati per spinta, trazione e verticali.
              </p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between text-[11px] font-bold">
                <span className="text-[#00D2FF]">
                  STEP {stepIndex + 1} DI {PREHAB_STEPS.length}
                </span>
                <span className="font-mono text-[#94A3B8] tabular-nums">
                  Totale rimanente: {formatMMSS(remainingTotal)}
                </span>
              </div>

              <p className="font-mono text-5xl font-extrabold text-[#FFFFFF] tabular-nums leading-none">
                {formatMMSS(secondsLeft)}
              </p>

              <p className="text-sm font-extrabold text-[#38BDF8]">{activeStep.title}</p>
              <p className="text-xs text-[#CBD5E1] leading-relaxed">{activeStep.instruction}</p>
            </>
          )}

          {/* Progress Bar */}
          <div className="h-2 rounded-full bg-[#05070A] border border-[#1E293B] overflow-hidden">
            <div
              className="h-full bg-[#00D2FF] transition-all duration-300"
              style={{ width: `${completed ? 100 : totalPct}%` }}
            />
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-2 pt-1">
            {!completed && (
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  setRunning((r) => !r);
                }}
                className="flex-1 min-h-[44px] rounded-xl bg-[#2563EB] text-[#FFFFFF] text-xs font-extrabold flex items-center justify-center gap-1.5 hover:bg-[#3B82F6] transition"
              >
                {running ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current" />}
                <span>{running ? 'Pausa' : 'Avvia Timer'}</span>
              </button>
            )}

            {!completed && (
              <button
                type="button"
                onClick={handleNextStep}
                className="min-h-[44px] px-3.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#38BDF8] flex items-center gap-1 hover:border-[#38BDF8]/60 transition"
              >
                <SkipForward className="w-4 h-4" />
                <span>Avanti</span>
              </button>
            )}

            <button
              type="button"
              onClick={handleReset}
              aria-label="Ricomincia Prehab"
              className="min-h-[44px] px-3.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#CBD5E1] flex items-center gap-1 hover:text-[#FFFFFF] transition"
            >
              <RotateCcw className="w-4 h-4" />
              <span>Reset</span>
            </button>
          </div>
        </div>

        {/* Interactive 4-Step Overview */}
        <div className="space-y-1.5">
          {PREHAB_STEPS.map((st, idx) => {
            const isCurrent = !completed && idx === stepIndex;
            const isDone = completed || idx < stepIndex;
            return (
              <button
                key={st.id}
                type="button"
                onClick={() => {
                  playTechClick();
                  setStepIndex(idx);
                  setSecondsLeft(st.durationSec);
                  setCompleted(false);
                }}
                className={`w-full text-left px-3 py-2.5 rounded-xl border text-xs flex items-center justify-between gap-2 transition ${
                  isCurrent
                    ? 'bg-[#132347] border-[#00D2FF] text-[#FFFFFF] font-bold'
                    : isDone
                    ? 'bg-[#090D16] border-[#2563EB]/50 text-[#38BDF8]'
                    : 'bg-[#090D16] border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF]'
                }`}
              >
                <span className="truncate">{st.title}</span>
                <span className="font-mono text-[11px] font-bold shrink-0 tabular-nums">
                  {isDone ? 'OK' : `${st.durationSec}s`}
                </span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
