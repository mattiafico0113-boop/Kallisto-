import React, { useMemo, useRef, useState } from 'react';
import {
  Award,
  Bell,
  Check,
  Clock,
  CreditCard,
  Download,
  HardDrive,
  Loader2,
  Lock,
  LogOut,
  Palette,
  RefreshCw,
  Ruler,
  ShieldAlert,
  Sliders,
  Sparkles,
  Target,
  Trash2,
  Trophy,
  Upload,
} from 'lucide-react';
import { EQUIPMENT_OPTIONS, JOINT_OPTIONS } from '../data/exercises';
import { SKILL_NODE_MAP, SKILL_TREE_NODES } from '../data/skills';
import type {
  AthleteProfile,
  AuthSession,
  BodyWeightEntry,
  DailyNutritionLog,
  GoalType,
  SkillTarget,
  UnlockedSkillRecord,
  WeekdayId,
  WorkoutDayPlan,
  WorkoutSessionLog,
} from '../types/calisthenics';
import {
  buildWorkoutNotificationBody,
  requestNotificationPermission,
  sendWorkoutNotification,
  WEEKDAY_ORDER,
} from '../utils/notifications';
import { playTechClick } from '../utils/audio';
import { computeTrophies } from '../utils/recoveryAndMissions';
import { measureLocalStorageUsage } from '../utils/storage';
import { THEME_PRESETS, type ThemePresetId } from '../utils/themeManager';
import { AthleteAvatarCard } from './AthleteAvatarCard';
import { AthleteCardModal } from './AthleteCardModal';
import { BodyWeightStrengthCard } from './BodyWeightStrengthCard';
import { NutritionHydrationWidget } from './NutritionHydrationWidget';
import { OneRMCalculatorCard } from './OneRMCalculatorModal';
import { PWAInstallButton } from './PWAInstallButton';

interface ProfileViewProps {
  profile: AthleteProfile;
  session: AuthSession;
  weeklyPlan: WorkoutDayPlan[];
  unlockedSkills?: UnlockedSkillRecord[];
  history?: WorkoutSessionLog[];
  prehabCompletedDates?: string[];
  bonusMissionXp?: number;
  nutritionLogs?: DailyNutritionLog[];
  weightLog?: BodyWeightEntry[];
  onUpdateTodayNutrition?: (updater: (cur: DailyNutritionLog) => DailyNutritionLog) => void;
  onAddWeightEntry?: (entry: { dateISO: string; weightKg: number }) => void;
  onDeleteWeightEntry?: (id: string) => void;
  themeId: ThemePresetId;
  onChangeTheme: (id: ThemePresetId) => void;
  isGeneratingAiPlan?: boolean;
  onGenerateAiPlan?: () => Promise<void>;
  onUpdateProfile: (next: AthleteProfile) => void;
  onEditOnboarding: () => void;
  onRegeneratePlan: () => void;
  onExportBackup: () => void;
  onImportBackup: (jsonText: string) => void;
  onLogout: () => void;
  onResetAll: () => void;
}

const GOAL_LABELS: Record<GoalType, string> = {
  forza: 'Forza nei fondamentali',
  ipertrofia: 'Ipertrofia a corpo libero',
  skill: 'Sblocco Skill',
  ricomposizione: 'Ricomposizione corporea',
};

const SKILL_TARGET_OPTIONS: { id: SkillTarget; label: string }[] = [
  { id: 'muscle_up', label: 'Muscle-up' },
  { id: 'planche', label: 'Planche' },
  { id: 'front_lever', label: 'Front Lever' },
  { id: 'handstand', label: 'Handstand / Verticale' },
  { id: 'human_flag', label: 'Human Flag' },
  { id: 'pistol_squat', label: 'Pistol Squat' },
];

export const ProfileView: React.FC<ProfileViewProps> = ({
  profile,
  session,
  weeklyPlan,
  unlockedSkills = [],
  history = [],
  prehabCompletedDates = [],
  bonusMissionXp = 0,
  nutritionLogs = [],
  weightLog = [],
  onUpdateTodayNutrition,
  onAddWeightEntry,
  onDeleteWeightEntry,
  themeId,
  onChangeTheme,
  isGeneratingAiPlan = false,
  onGenerateAiPlan,
  onUpdateProfile,
  onEditOnboarding,
  onRegeneratePlan,
  onExportBackup,
  onImportBackup,
  onLogout,
  onResetAll,
}) => {
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [notifFeedback, setNotifFeedback] = useState<string | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);
  const [cardModalOpen, setCardModalOpen] = useState(false);

  const trophies = useMemo(
    () =>
      computeTrophies({
        history,
        unlockedSkills,
        conqueredParksCount: 0,
        prehabCompletedDates,
      }),
    [history, unlockedSkills, prehabCompletedDates]
  );

  const storageStats = useMemo(
    () => measureLocalStorageUsage(),
    // Recompute when persisted profile/history/skills change
    [profile, weeklyPlan, history, unlockedSkills]
  );

  const equipmentLabels = profile.equipment
    .map((id) => EQUIPMENT_OPTIONS.find((o) => o.id === id)?.label ?? id)
    .join(' · ');

  const injuryLabels =
    profile.injuries.length > 0
      ? profile.injuries
          .map((id) => JOINT_OPTIONS.find((o) => o.id === id)?.label ?? id)
          .join(' · ')
      : 'Nessun fastidio segnalato';

  const toggleWeekday = (dayId: WeekdayId) => {
    const current = profile.trainingDays ?? [];
    let next: WeekdayId[];
    if (current.includes(dayId)) {
      if (current.length <= 1) return;
      next = current.filter((d) => d !== dayId);
    } else {
      const combined = [...current, dayId];
      next = WEEKDAY_ORDER.map((w) => w.id).filter((id) => combined.includes(id));
    }
    onUpdateProfile({
      ...profile,
      trainingDays: next,
      daysPerWeek: next.length,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleToggleNotifications = async () => {
    const next = !profile.reminderEnabled;
    if (!next) {
      onUpdateProfile({
        ...profile,
        reminderEnabled: false,
        updatedAt: new Date().toISOString(),
      });
      setNotifFeedback('Notifiche promemoria disattivate.');
      return;
    }

    const perm = await requestNotificationPermission();
    if (perm === 'granted') {
      onUpdateProfile({
        ...profile,
        reminderEnabled: true,
        updatedAt: new Date().toISOString(),
      });
      setNotifFeedback(
        `Promemoria attivo alle ${profile.reminderTime} nei giorni selezionati.`
      );
    } else if (perm === 'unsupported') {
      setNotifFeedback('Il browser attuale non supporta le notifiche Web.');
    } else {
      setNotifFeedback(
        'Permesso notifiche negato o bloccato. Consenti le notifiche nelle impostazioni del browser.'
      );
    }
  };

  const handleTestNotification = async () => {
    const body = buildWorkoutNotificationBody(profile, weeklyPlan);
    const res = await sendWorkoutNotification('CALI PRO', body);
    if (res.ok) {
      setNotifFeedback('Notifica di prova inviata!');
    } else {
      setNotifFeedback(res.reason ?? 'Impossibile inviare la notifica di prova.');
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        onImportBackup(reader.result);
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const hasPhysicalRatio =
    typeof profile.weightKg === 'number' &&
    profile.weightKg > 0 &&
    typeof profile.heightCm === 'number' &&
    profile.heightCm > 0;

  const weightHeightRatio = hasPhysicalRatio
    ? (profile.weightKg! / profile.heightCm!).toFixed(2)
    : null;
  const bmiValue = hasPhysicalRatio
    ? (profile.weightKg! / ((profile.heightCm! / 100) ** 2)).toFixed(1)
    : null;

  const handlePhysicalNumberChange = (
    field: 'ageYears' | 'heightCm' | 'weightKg',
    rawVal: string
  ) => {
    const trimmed = rawVal.trim();
    if (!trimmed) {
      onUpdateProfile({
        ...profile,
        [field]: undefined,
        updatedAt: new Date().toISOString(),
      });
      return;
    }
    const num = Number(trimmed);
    if (!Number.isFinite(num) || num < 0) return;
    onUpdateProfile({
      ...profile,
      [field]: num,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleTriggerAiPlan = async () => {
    if (!onGenerateAiPlan) return;
    setAiError(null);
    try {
      await onGenerateAiPlan();
    } catch (err) {
      setAiError(
        err instanceof Error
          ? err.message
          : 'Impossibile generare la scheda AI in questo momento.'
      );
    }
  };

  return (
    <div className="space-y-4 pb-8 max-w-3xl mx-auto">
      {/* Top RPG Athlete Avatar & Skill Tree Progression */}
      <AthleteAvatarCard
        athleteName={profile.name}
        avatar={profile.avatar}
        unlockedSkills={unlockedSkills}
        history={history}
        bonusMissionXp={bonusMissionXp}
        onChangeAvatar={(nextAvatar) =>
          onUpdateProfile({
            ...profile,
            avatar: nextAvatar,
            updatedAt: new Date().toISOString(),
          })
        }
      />

      {/* Video Game Style Athlete Card Modal Launcher */}
      <button
        type="button"
        onClick={() => {
          playTechClick();
          setCardModalOpen(true);
        }}
        className="w-full min-h-[48px] px-4 rounded-2xl bg-[#0B1D36] border border-[#00D2FF]/70 text-sm font-extrabold text-[#FFFFFF] flex items-center justify-center gap-2 hover:bg-[#132347] hover:border-[#00D2FF] transition shadow-[0_0_20px_rgba(0,210,255,0.16)]"
      >
        <CreditCard className="w-4 h-4 text-[#00D2FF]" />
        <span>Genera la mia Card Atleta</span>
      </button>

      {/* Dynamic App Color Theme Selector */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Palette className="w-4 h-4 text-[#00D2FF]" />
            <h3 className="text-sm font-extrabold text-[#FFFFFF]">Tema Colore App</h3>
          </div>
          <span className="text-[11px] font-bold text-[#38BDF8]">
            {THEME_PRESETS.find((p) => p.id === themeId)?.name ?? 'Cyber Blue'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {THEME_PRESETS.map((preset) => {
            const active = preset.id === themeId;
            return (
              <button
                key={preset.id}
                type="button"
                onClick={() => onChangeTheme(preset.id)}
                className={`p-3 rounded-xl border text-left transition flex items-start justify-between gap-2.5 ${
                  active
                    ? 'bg-[#132347] border-[#00D2FF] shadow-[0_0_16px_rgba(0,210,255,0.18)]'
                    : 'bg-[#090D16] border-[#1E293B] hover:border-[#38BDF8]/50'
                }`}
              >
                <div className="min-w-0 space-y-1">
                  <div className="flex items-center gap-2">
                    <span
                      className="inline-flex items-center gap-1 p-1 rounded-lg border border-white/15 shrink-0"
                      style={{ backgroundColor: preset.swatchBg }}
                    >
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: preset.swatchPrimary }}
                      />
                      <span
                        className="w-2.5 h-2.5 rounded-full"
                        style={{ backgroundColor: preset.swatchAccent }}
                      />
                    </span>
                    <span className="text-xs font-extrabold text-[#FFFFFF] truncate">
                      {preset.name}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#94A3B8] leading-snug">
                    {preset.description}
                  </p>
                </div>
                {active && <Check className="w-4 h-4 text-[#00D2FF] shrink-0 mt-0.5" />}
              </button>
            );
          })}
        </div>
      </section>

      {/* Account Summary & Baselines */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <p className="text-xs text-[#94A3B8]">
              {session.isGuest
                ? 'Account Ospite (locale)'
                : `Account connesso · ${session.email}`}
            </p>
            <p className="text-xs text-[#38BDF8] font-semibold mt-1">
              {GOAL_LABELS[profile.goal]}
              {profile.targetSkill ? ` · Focus: ${profile.targetSkill.replace('_', ' ')}` : ''} ·{' '}
              {profile.trainingDays.length} giorni/settimana
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onEditOnboarding}
              className="min-h-[42px] px-3.5 rounded-xl bg-[#2563EB] text-[#FFFFFF] text-xs font-extrabold inline-flex items-center gap-1.5 hover:bg-[#3B82F6] transition"
            >
              <Sliders className="w-4 h-4" />
              <span>Modifica dati / Test</span>
            </button>

            <button
              type="button"
              onClick={onLogout}
              aria-label="Esci o cambia account"
              className="min-h-[42px] px-3 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#FFFFFF] inline-flex items-center gap-1.5 hover:bg-[#1E293B] transition"
            >
              <LogOut className="w-4 h-4 text-[#38BDF8]" />
              <span>Cambia account</span>
            </button>
          </div>
        </div>

        {/* Baselines Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3">
            <p className="text-[11px] text-[#94A3B8]">Trazioni max</p>
            <p className="font-mono text-xl font-bold text-[#FFFFFF] mt-0.5 tabular-nums">
              {profile.baselines.pullups}
            </p>
          </div>
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3">
            <p className="text-[11px] text-[#94A3B8]">Dip max</p>
            <p className="font-mono text-xl font-bold text-[#FFFFFF] mt-0.5 tabular-nums">
              {profile.baselines.dips}
            </p>
          </div>
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3">
            <p className="text-[11px] text-[#94A3B8]">Push-up max</p>
            <p className="font-mono text-xl font-bold text-[#FFFFFF] mt-0.5 tabular-nums">
              {profile.baselines.pushups}
            </p>
          </div>
          <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-3">
            <p className="text-[11px] text-[#94A3B8]">Leg Raises max</p>
            <p className="font-mono text-xl font-bold text-[#FFFFFF] mt-0.5 tabular-nums">
              {profile.baselines.legRaises}
            </p>
          </div>
        </div>
      </section>

      {/* Physical Data (Age, Height, Weight + Ratio) & Target Skill + Generate with AI */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Ruler className="w-4 h-4 text-[#00D2FF]" />
            <h3 className="text-sm font-extrabold text-[#FFFFFF]">
              Dati Fisici &amp; Skill Obiettivo
            </h3>
          </div>
          <span className="text-[11px] text-[#94A3B8]">Salvati in automatico</span>
        </div>

        <div className="grid grid-cols-3 gap-2.5">
          <div>
            <label
              htmlFor="profile-age"
              className="block text-[11px] font-semibold text-[#94A3B8] mb-1"
            >
              Età (anni)
            </label>
            <input
              id="profile-age"
              type="number"
              min={12}
              max={99}
              inputMode="numeric"
              value={profile.ageYears ?? ''}
              onChange={(e) => handlePhysicalNumberChange('ageYears', e.target.value)}
              placeholder="Es. 25"
              className="w-full min-h-[44px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 font-mono text-sm font-bold text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#00D2FF] tabular-nums"
            />
          </div>

          <div>
            <label
              htmlFor="profile-height"
              className="block text-[11px] font-semibold text-[#94A3B8] mb-1"
            >
              Altezza (cm)
            </label>
            <input
              id="profile-height"
              type="number"
              min={120}
              max={230}
              inputMode="numeric"
              value={profile.heightCm ?? ''}
              onChange={(e) => handlePhysicalNumberChange('heightCm', e.target.value)}
              placeholder="Es. 176"
              className="w-full min-h-[44px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 font-mono text-sm font-bold text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#00D2FF] tabular-nums"
            />
          </div>

          <div>
            <label
              htmlFor="profile-weight"
              className="block text-[11px] font-semibold text-[#94A3B8] mb-1"
            >
              Peso (kg)
            </label>
            <input
              id="profile-weight"
              type="number"
              min={35}
              max={180}
              step="0.5"
              inputMode="decimal"
              value={profile.weightKg ?? ''}
              onChange={(e) => handlePhysicalNumberChange('weightKg', e.target.value)}
              placeholder="Es. 72"
              className="w-full min-h-[44px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 font-mono text-sm font-bold text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#00D2FF] tabular-nums"
            />
          </div>
        </div>

        {/* Discrete Automatic Weight/Height Ratio Calculation */}
        <div className="rounded-xl bg-[#090D16] border border-[#1E293B] px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs">
          <span className="text-[#94A3B8]">Rapporto Peso / Altezza</span>
          {weightHeightRatio && bmiValue ? (
            <span className="font-mono font-bold text-[#38BDF8] tabular-nums">
              {weightHeightRatio} kg/cm · IMC {bmiValue} (
              {Number(bmiValue) <= 22.5
                ? 'Leva favorevole per skill'
                : Number(bmiValue) <= 25.5
                ? 'Ottimo equilibrio forza/peso'
                : 'Focus su forza relativa'}
              )
            </span>
          ) : (
            <span className="text-[#64748B]">
              Inserisci altezza e peso per il calcolo automatico
            </span>
          )}
        </div>

        {/* Target Skill Selector */}
        <div className="space-y-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#CBD5E1]">
            <Target className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>Skill Obiettivo Principale</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
            {SKILL_TARGET_OPTIONS.map((opt) => {
              const active = profile.targetSkill === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() =>
                    onUpdateProfile({
                      ...profile,
                      targetSkill: opt.id,
                      updatedAt: new Date().toISOString(),
                    })
                  }
                  className={`min-h-[42px] px-3 rounded-xl border text-xs font-bold text-left transition ${
                    active
                      ? 'bg-[#2563EB] border-[#00D2FF] text-[#FFFFFF]'
                      : 'bg-[#090D16] border-[#1E293B] text-[#CBD5E1] hover:border-[#38BDF8]/50'
                  }`}
                >
                  {opt.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Bright Cyan AI Schedule Generation CTA */}
        {onGenerateAiPlan && (
          <div className="pt-1 space-y-2">
            <button
              type="button"
              disabled={isGeneratingAiPlan}
              onClick={handleTriggerAiPlan}
              className="w-full min-h-[48px] px-4 rounded-2xl bg-[#00D2FF] text-[#05070A] text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#38BDF8] disabled:opacity-60 transition shadow-[0_0_20px_rgba(0,210,255,0.28)]"
            >
              {isGeneratingAiPlan ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Generazione scheda su misura con AI in corso...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Genera la mia Scheda con AI</span>
                </>
              )}
            </button>
            {aiError && (
              <p className="text-xs font-semibold text-[#38BDF8] leading-relaxed">{aiError}</p>
            )}
          </div>
        )}
      </section>

      {/* Training Days & Notification Reminders */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-5 space-y-4">
        <div>
          <h3 className="text-sm font-bold text-[#FFFFFF]">
            Giorni della settimana ({profile.trainingDays.length})
          </h3>
          <p className="text-xs text-[#94A3B8] mt-0.5">
            Tocca i giorni esatti in cui vuoi allenarti. Poi premi "Rigenera scheda" se vuoi adattare gli split.
          </p>
          <div className="grid grid-cols-7 gap-1.5 mt-3">
            {WEEKDAY_ORDER.map((wd) => {
              const active = profile.trainingDays.includes(wd.id);
              return (
                <button
                  key={wd.id}
                  type="button"
                  onClick={() => toggleWeekday(wd.id)}
                  aria-pressed={active}
                  aria-label={wd.label}
                  className={`min-h-[48px] rounded-xl border text-xs font-bold transition ${
                    active
                      ? 'bg-[#2563EB] text-[#FFFFFF] border-[#38BDF8]/70'
                      : 'bg-[#090D16] text-[#94A3B8] border-[#1E293B] hover:text-[#FFFFFF]'
                  }`}
                >
                  {wd.short}
                </button>
              );
            })}
          </div>
        </div>

        {/* Notifications Block */}
        <div className="pt-4 border-t border-[#1E293B] space-y-3.5">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Bell className="w-4 h-4 text-[#38BDF8] shrink-0" />
              <div>
                <p className="text-sm font-bold text-[#FFFFFF]">Attiva Notifiche</p>
                <p className="text-xs text-[#94A3B8]">
                  Promemoria nei giorni selezionati
                </p>
              </div>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={profile.reminderEnabled}
              onClick={handleToggleNotifications}
              className={`w-12 h-7 rounded-full p-1 transition-colors shrink-0 ${
                profile.reminderEnabled ? 'bg-[#2563EB]' : 'bg-[#1E293B]'
              }`}
            >
              <span
                className={`block w-5 h-5 rounded-full bg-[#FFFFFF] transition-transform ${
                  profile.reminderEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <label
              htmlFor="profile-reminder-time"
              className="flex items-center gap-2 text-xs font-semibold text-[#CBD5E1]"
            >
              <Clock className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>Orario promemoria</span>
            </label>
            <input
              id="profile-reminder-time"
              type="time"
              value={profile.reminderTime}
              onChange={(e) =>
                onUpdateProfile({
                  ...profile,
                  reminderTime: e.target.value || '18:00',
                  updatedAt: new Date().toISOString(),
                })
              }
              className="min-h-[42px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 font-mono text-sm font-bold text-[#FFFFFF] focus:outline-none focus:border-[#38BDF8]"
            />
          </div>

          <button
            type="button"
            onClick={handleTestNotification}
            className="w-full min-h-[44px] rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#FFFFFF] hover:bg-[#1E293B] transition"
          >
            Invia notifica di prova ora
          </button>

          {notifFeedback && (
            <p className="text-xs text-[#38BDF8] leading-relaxed">{notifFeedback}</p>
          )}
        </div>
      </section>

      {/* Equipment & Joint Protection */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-5 space-y-4">
        <div>
          <p className="text-xs font-semibold text-[#94A3B8]">Attrezzatura configurata</p>
          <p className="text-sm text-[#FFFFFF] mt-1 leading-relaxed">{equipmentLabels}</p>
        </div>

        <div className="pt-3 border-t border-[#1E293B]">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#00D2FF]">
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>Protezione articolare attiva</span>
          </div>
          <p className="text-sm text-[#FFFFFF] mt-1 leading-relaxed">{injuryLabels}</p>
        </div>
      </section>

      {/* Certified Skills & Milestones */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 text-[#00D2FF]" />
            <h3 className="text-sm font-bold text-[#FFFFFF]">Skill Sbloccate e Certificate</h3>
          </div>
          <span className="font-mono text-xs font-bold text-[#38BDF8] tabular-nums">
            {unlockedSkills.length}/{SKILL_TREE_NODES.length}
          </span>
        </div>

        {unlockedSkills.length === 0 ? (
          <p className="text-xs text-[#94A3B8] leading-relaxed">
            Nessuna skill ancora certificata. Apri la scheda <strong className="text-[#FFFFFF]">Skill</strong> in basso e supera il primo test con la fotocamera!
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {unlockedSkills.map((rec) => {
              const def = SKILL_NODE_MAP[rec.skillId];
              if (!def) return null;
              return (
                <div
                  key={rec.skillId}
                  className="rounded-xl bg-[#132347] border border-[#38BDF8]/50 p-3 flex items-center justify-between gap-2.5"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-[#38BDF8] text-[#05070A] flex items-center justify-center shrink-0">
                      <Award className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-extrabold text-[#FFFFFF] truncate">{def.name}</p>
                      <p className="text-[11px] text-[#94A3B8]">
                        {new Date(rec.unlockedAtISO).toLocaleDateString('it-IT', {
                          day: '2-digit',
                          month: 'short',
                          year: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>
                  <span className="font-mono text-xs font-extrabold text-[#00D2FF] tabular-nums shrink-0">
                    {rec.achievedValue}
                    {def.mode === 'isometric' ? 's' : ' rep'}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Nutrition, Protein & Daily Hydration Tracker */}
      {onUpdateTodayNutrition && (
        <NutritionHydrationWidget
          profile={profile}
          nutritionLogs={nutritionLogs}
          onUpdateTodayNutrition={onUpdateTodayNutrition}
        />
      )}

      {/* Body Weight Chart & Relative Strength Index */}
      {onAddWeightEntry && onDeleteWeightEntry && (
        <BodyWeightStrengthCard
          profile={profile}
          history={history}
          weightLog={weightLog}
          onAddWeightEntry={onAddWeightEntry}
          onDeleteWeightEntry={onDeleteWeightEntry}
        />
      )}

      {/* Weighted Calisthenics 1RM Calculator */}
      <OneRMCalculatorCard defaultWeightKg={profile.weightKg} />

      {/* Unlockable Trophies Board */}
      <section
        className="rounded-2xl border p-4 sm:p-5 space-y-3"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-subtle)',
          color: 'var(--text-main)',
        }}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Trophy className="w-4 h-4 shrink-0" style={{ color: '#FACC15' }} />
            <h3 className="text-sm font-extrabold">Bacheca Trofei Sbloccabili</h3>
          </div>
          <span
            className="font-mono text-xs font-bold tabular-nums"
            style={{ color: 'var(--accent)' }}
          >
            {trophies.filter((t) => t.unlocked).length}/{trophies.length} sbloccati
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {trophies.map((tr) => (
            <div
              key={tr.id}
              className="rounded-xl border p-3 flex items-start gap-2.5 transition"
              style={{
                backgroundColor: tr.unlocked ? 'var(--bg-elevated)' : 'var(--bg-main)',
                borderColor: tr.unlocked ? '#FACC15' : 'var(--border-subtle)',
                opacity: tr.unlocked ? 1 : 0.78,
              }}
            >
              <div
                className="w-9 h-9 rounded-xl border flex items-center justify-center shrink-0"
                style={{
                  backgroundColor: tr.unlocked ? '#FACC15' : 'var(--bg-card)',
                  borderColor: tr.unlocked ? '#FACC15' : 'var(--border-subtle)',
                  color: tr.unlocked ? '#05070A' : 'var(--text-muted)',
                }}
              >
                {tr.unlocked ? <Trophy className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="text-xs font-extrabold truncate">{tr.title}</p>
                  <span
                    className="font-mono text-[10px] font-bold shrink-0 tabular-nums"
                    style={{ color: tr.unlocked ? '#FACC15' : 'var(--text-muted)' }}
                  >
                    {tr.progressLabel}
                  </span>
                </div>
                <p className="text-[11px] leading-snug mt-0.5" style={{ color: 'var(--text-muted)' }}>
                  {tr.description}
                </p>
              </div>
            </div>
          ))}
        </div>
        <p className="text-[11px]" style={{ color: 'var(--text-muted)' }}>
          I trofei sbloccati vengono mostrati automaticamente anche sulla tua <strong style={{ color: 'var(--text-main)' }}>Card Atleta</strong>.
        </p>
      </section>

      {/* Memory Management & Full Backup (.json) */}
      <section
        className="rounded-2xl border p-5 space-y-3.5"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-subtle)',
          color: 'var(--text-main)',
        }}
      >
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <HardDrive className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            <h3 className="text-sm font-extrabold">Gestione Memoria &amp; Backup Completo</h3>
          </div>
          <span
            className="font-mono text-xs font-bold tabular-nums"
            style={{ color: 'var(--accent)' }}
          >
            {storageStats.usedMB.toFixed(2)} MB ({storageStats.percentUsed}%)
          </span>
        </div>

        {/* LocalStorage Usage Bar */}
        <div
          className="rounded-xl border p-3 space-y-1.5"
          style={{
            backgroundColor: 'var(--bg-main)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <div className="flex items-center justify-between text-[11px]">
            <span style={{ color: 'var(--text-muted)' }}>
              Spazio locale utilizzato (quota browser ~{storageStats.quotaMB} MB)
            </span>
            <span className="font-mono font-bold tabular-nums">
              {storageStats.usedMB.toFixed(2)} / {storageStats.quotaMB} MB
            </span>
          </div>
          <div
            className="h-2 w-full rounded-full border overflow-hidden"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div
              className="h-full rounded-full transition-all duration-300"
              style={{
                width: `${storageStats.percentUsed}%`,
                backgroundColor:
                  storageStats.percentUsed >= 80 ? '#F97316' : 'var(--accent)',
              }}
            />
          </div>
        </div>

        <PWAInstallButton />

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <button
            type="button"
            onClick={onExportBackup}
            className="min-h-[48px] px-3 rounded-2xl border text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 transition"
            style={{
              backgroundColor: 'var(--primary)',
              borderColor: 'var(--accent)',
              color: '#FFFFFF',
            }}
          >
            <Download className="w-4 h-4 shrink-0" />
            <span>Esporta Backup Completo (.json)</span>
          </button>

          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="min-h-[48px] px-3 rounded-2xl border text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 transition"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--accent)',
              color: 'var(--accent)',
            }}
          >
            <Upload className="w-4 h-4 shrink-0" />
            <span>Ripristina da File Backup</span>
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json,application/json"
            onChange={handleFileChange}
            className="hidden"
          />
        </div>

        <button
          type="button"
          onClick={onRegeneratePlan}
          className="w-full min-h-[48px] rounded-2xl border text-sm font-bold flex items-center justify-center gap-2 transition"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        >
          <RefreshCw className="w-4 h-4" style={{ color: 'var(--accent)' }} />
          <span>Rigenera scheda dai parametri attuali</span>
        </button>

        <button
          type="button"
          onClick={onResetAll}
          className="w-full min-h-[48px] rounded-2xl border text-sm font-semibold flex items-center justify-center gap-2 transition"
          style={{
            backgroundColor: 'var(--bg-main)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-muted)',
          }}
        >
          <Trash2 className="w-4 h-4" />
          <span>Azzera dati di questo account</span>
        </button>
      </section>

      <AthleteCardModal
        isOpen={cardModalOpen}
        profile={profile}
        unlockedSkills={unlockedSkills}
        history={history}
        bonusMissionXp={bonusMissionXp}
        unlockedTrophies={trophies}
        onClose={() => setCardModalOpen(false)}
      />
    </div>
  );
};
