import React, { useMemo } from 'react';
import { CalendarCheck2, Droplets, Flame, ShieldCheck } from 'lucide-react';
import type { WorkoutDayPlan, WorkoutExerciseItem, WorkoutSessionLog } from '../types/calisthenics';

interface QuickWidgetsGridProps {
  currentDay: WorkoutDayPlan | undefined;
  activeExercises: WorkoutExerciseItem[];
  history: WorkoutSessionLog[];
  waterSipsCount: number;
  onAddWaterSip: () => void;
  onOpenHistory: () => void;
  onNextDay: () => void;
}

function computeConsecutiveStreak(history: WorkoutSessionLog[]): number {
  if (history.length === 0) return 0;
  const uniqueDays = Array.from(
    new Set(
      history.map((s) => {
        const d = new Date(s.dateISO);
        return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
      })
    )
  ).sort((a, b) => b - a);

  if (uniqueDays.length === 0) return 0;

  const now = new Date();
  const todayMs = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const oneDayMs = 86400000;

  if (todayMs - uniqueDays[0] > oneDayMs) {
    return 0;
  }

  let streak = 1;
  for (let i = 1; i < uniqueDays.length; i++) {
    if (uniqueDays[i - 1] - uniqueDays[i] === oneDayMs) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}

function getTechLabel(score: 1 | 2 | 3 | null | undefined): string {
  if (score === 3) return '3/3 · Pulita';
  if (score === 2) return '2/3 · Al limite';
  if (score === 1) return '1/3 · Sporca';
  return 'Da valutare';
}

export const QuickWidgetsGrid: React.FC<QuickWidgetsGridProps> = ({
  currentDay,
  activeExercises,
  history,
  waterSipsCount,
  onAddWaterSip,
  onOpenHistory,
  onNextDay,
}) => {
  const streakDays = useMemo(() => computeConsecutiveStreak(history), [history]);

  const latestTech = useMemo(() => {
    for (let i = activeExercises.length - 1; i >= 0; i--) {
      if (activeExercises[i].technicalScore) {
        return {
          score: activeExercises[i].technicalScore,
          label: getTechLabel(activeExercises[i].technicalScore),
        };
      }
    }
    for (const s of history) {
      for (const ex of s.exercises) {
        if (ex.technicalScore) {
          return {
            score: ex.technicalScore,
            label: getTechLabel(ex.technicalScore),
          };
        }
      }
    }
    return { score: null, label: 'Nessun voto' };
  }, [activeExercises, history]);

  const waterTarget = 8;
  const waterPct = Math.min(100, Math.round((waterSipsCount / waterTarget) * 100));

  return (
    <section aria-label="Riepilogo rapido" className="grid grid-cols-2 gap-2.5">
      {/* Widget 1: Prossimo Allenamento */}
      <button
        type="button"
        onClick={onNextDay}
        className="rounded-2xl bg-[#0F172A] border border-[#1E293B] hover:border-[#38BDF8]/60 p-3 text-left transition active:scale-[0.98] flex flex-col justify-between min-h-[82px]"
      >
        <div className="flex items-center justify-between gap-1.5">
          <span className="text-[11px] font-bold text-[#94A3B8]">Prossimo Workout</span>
          <CalendarCheck2 className="w-4 h-4 text-[#38BDF8] shrink-0" />
        </div>
        <div className="mt-1.5 min-w-0">
          <p className="text-xs font-extrabold text-[#FFFFFF] truncate">
            {currentDay?.splitLabel ?? 'Scheda'}
          </p>
          <p className="text-[11px] font-semibold text-[#38BDF8] truncate">
            {currentDay?.title ?? 'Tocca per cambiare'}
          </p>
        </div>
      </button>

      {/* Widget 2: Streak Giorni Consecutivi */}
      <button
        type="button"
        onClick={onOpenHistory}
        className="rounded-2xl bg-[#0F172A] border border-[#1E293B] hover:border-[#38BDF8]/60 p-3 text-left transition active:scale-[0.98] flex flex-col justify-between min-h-[82px]"
      >
        <div className="flex items-center justify-between gap-1.5">
          <span className="text-[11px] font-bold text-[#94A3B8]">Streak Attiva</span>
          <Flame className="w-4 h-4 text-[#00D2FF] shrink-0" />
        </div>
        <div className="mt-1.5">
          <p className="font-mono text-lg font-extrabold text-[#FFFFFF] leading-none tabular-nums">
            {streakDays} {streakDays === 1 ? 'giorno' : 'giorni'}
          </p>
          <p className="text-[11px] text-[#94A3B8] mt-1">
            {history.length} sedute totali
          </p>
        </div>
      </button>

      {/* Widget 3: Obiettivo Acqua (tap to log +1 sip) */}
      <button
        type="button"
        onClick={onAddWaterSip}
        className="rounded-2xl bg-[#0B1D36] border border-[#2563EB]/60 hover:border-[#00D2FF] p-3 text-left transition active:scale-[0.98] flex flex-col justify-between min-h-[82px]"
      >
        <div className="flex items-center justify-between gap-1.5">
          <span className="text-[11px] font-bold text-[#7DD3FC]">Obiettivo Acqua</span>
          <Droplets className="w-4 h-4 text-[#00D2FF] shrink-0" />
        </div>
        <div className="mt-1.5 space-y-1.5">
          <p className="font-mono text-lg font-extrabold text-[#FFFFFF] leading-none tabular-nums">
            {waterSipsCount}/{waterTarget}{' '}
            <span className="text-[11px] font-semibold text-[#38BDF8]">+1</span>
          </p>
          <div className="h-1.5 w-full rounded-full bg-[#090D16] overflow-hidden">
            <div
              className="h-full bg-[#00D2FF] transition-all duration-200"
              style={{ width: `${waterPct}%` }}
            />
          </div>
        </div>
      </button>

      {/* Widget 4: Ultimo Voto Tecnico */}
      <button
        type="button"
        onClick={onOpenHistory}
        className="rounded-2xl bg-[#0F172A] border border-[#1E293B] hover:border-[#38BDF8]/60 p-3 text-left transition active:scale-[0.98] flex flex-col justify-between min-h-[82px]"
      >
        <div className="flex items-center justify-between gap-1.5">
          <span className="text-[11px] font-bold text-[#94A3B8]">Qualità Tecnica</span>
          <ShieldCheck className="w-4 h-4 text-[#38BDF8] shrink-0" />
        </div>
        <div className="mt-1.5">
          <p
            className={`font-mono text-base font-extrabold leading-tight tabular-nums ${
              latestTech.score === 3
                ? 'text-[#00D2FF]'
                : latestTech.score === 2
                ? 'text-[#38BDF8]'
                : 'text-[#FFFFFF]'
            }`}
          >
            {latestTech.label}
          </p>
          <p className="text-[11px] text-[#94A3B8] mt-0.5">Ultimo voto 1–3</p>
        </div>
      </button>
    </section>
  );
};
