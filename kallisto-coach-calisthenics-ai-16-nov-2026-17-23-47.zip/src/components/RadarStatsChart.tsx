import React, { useMemo, useState } from 'react';
import { Crosshair, Radar } from 'lucide-react';
import type { UnlockedSkillRecord, WorkoutSessionLog } from '../types/calisthenics';
import { computeAthleteRadarMetrics, type RadarVertexStat } from '../utils/rpgProgression';

interface RadarStatsChartProps {
  history: WorkoutSessionLog[];
  unlockedSkills: UnlockedSkillRecord[];
}

export const RadarStatsChart: React.FC<RadarStatsChartProps> = ({
  history,
  unlockedSkills,
}) => {
  const vertices = useMemo(
    () => computeAthleteRadarMetrics(history, unlockedSkills),
    [history, unlockedSkills]
  );

  const [selectedKey, setSelectedKey] = useState<RadarVertexStat['key']>('Skill');
  const activeStat = vertices.find((v) => v.key === selectedKey) ?? vertices[0];

  const cx = 180;
  const cy = 152;
  const maxR = 96;
  const ringLevels = [20, 40, 60, 80, 100];

  const getPoint = (idx: number, valuePct: number, radiusScale = 1) => {
    // Start straight up (-90 deg) and move clockwise across 5 vertices
    const angle = -Math.PI / 2 + (idx * 2 * Math.PI) / 5;
    const r = ((Math.max(4, valuePct) / 100) * maxR) * radiusScale;
    return {
      x: cx + r * Math.cos(angle),
      y: cy + r * Math.sin(angle),
      labelX: cx + (maxR + 30) * Math.cos(angle),
      labelY: cy + (maxR + 28) * Math.sin(angle),
    };
  };

  const dataPolygonPoints = vertices
    .map((v, idx) => {
      const p = getPoint(idx, v.score);
      return `${p.x.toFixed(1)},${p.y.toFixed(1)}`;
    })
    .join(' ');

  const overallPower = Math.round(
    vertices.reduce((acc, v) => acc + v.score, 0) / Math.max(1, vertices.length)
  );

  return (
    <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Radar className="w-4 h-4 text-[#00D2FF]" />
          <h2 className="text-base font-extrabold text-[#FFFFFF]">
            Radar Parametri Atleta
          </h2>
        </div>
        <span className="font-mono text-xs font-extrabold text-[#38BDF8] tabular-nums">
          Indice globale: {overallPower}/100
        </span>
      </div>

      <div className="grid grid-cols-1 gap-4 items-center">
        {/* Interactive Videogame Spider Chart */}
        <div className="rounded-2xl bg-[#090D16] border border-[#1E293B] p-3 flex flex-col items-center">
          <svg
            viewBox="0 0 360 305"
            className="w-full max-w-[360px] h-auto overflow-visible select-none"
            role="img"
            aria-label="Grafico a rete dei 5 parametri dell'atleta"
          >
            <defs>
              <radialGradient id="radarField" cx="50%" cy="50%" r="50%">
                <stop offset="0%" style={{ stopColor: 'var(--accent)' }} stopOpacity="0.16" />
                <stop offset="100%" style={{ stopColor: 'var(--bg-main)' }} stopOpacity="0.9" />
              </radialGradient>
              <linearGradient id="radarFill" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" style={{ stopColor: 'var(--accent)' }} stopOpacity="0.42" />
                <stop offset="100%" style={{ stopColor: 'var(--primary)' }} stopOpacity="0.28" />
              </linearGradient>
            </defs>

            {/* Ambient Night-Blue Disc */}
            <circle cx={cx} cy={cy} r={maxR + 4} fill="url(#radarField)" />

            {/* Concentric Grid Pentagons */}
            {ringLevels.map((lvl) => {
              const ringPts = vertices
                .map((_, idx) => {
                  const p = getPoint(idx, lvl);
                  return `${p.x.toFixed(1)},${p.y.toFixed(1)}`;
                })
                .join(' ');
              return (
                <polygon
                  key={lvl}
                  points={ringPts}
                  fill="none"
                  stroke={lvl === 100 ? 'var(--primary)' : 'var(--border-subtle)'}
                  strokeWidth={lvl === 100 ? 1.5 : 1}
                  strokeDasharray={lvl === 100 ? undefined : '3 3'}
                />
              );
            })}

            {/* Radial Axis Spokes */}
            {vertices.map((_, idx) => {
              const p = getPoint(idx, 100);
              return (
                <line
                  key={idx}
                  x1={cx}
                  y1={cy}
                  x2={p.x}
                  y2={p.y}
                  stroke="var(--border-subtle)"
                  strokeWidth="1.2"
                />
              );
            })}

            {/* Ring Scale Indicators */}
            <text x={cx + 4} y={cy - maxR * 0.4 + 3} fill="var(--text-muted)" fontSize="8.5" fontFamily="JetBrains Mono, monospace">
              40
            </text>
            <text x={cx + 4} y={cy - maxR * 0.8 + 3} fill="var(--text-muted)" fontSize="8.5" fontFamily="JetBrains Mono, monospace">
              80
            </text>

            {/* Filled Athlete Area Polygon */}
            <polygon
              points={dataPolygonPoints}
              fill="url(#radarFill)"
              stroke="var(--accent)"
              strokeWidth="2.5"
              strokeLinejoin="round"
            />

            {/* Interactive Vertex Nodes & Labels */}
            {vertices.map((v, idx) => {
              const pt = getPoint(idx, v.score);
              const outerPt = getPoint(idx, 100);
              const isSelected = v.key === activeStat.key;
              const anchor =
                Math.abs(outerPt.labelX - cx) < 12
                  ? 'middle'
                  : outerPt.labelX > cx
                  ? 'start'
                  : 'end';

              return (
                <g
                  key={v.key}
                  className="cursor-pointer"
                  onMouseEnter={() => setSelectedKey(v.key)}
                  onFocus={() => setSelectedKey(v.key)}
                  onClick={() => setSelectedKey(v.key)}
                >
                  {/* Highlight beam if selected */}
                  {isSelected && (
                    <line
                      x1={cx}
                      y1={cy}
                      x2={outerPt.x}
                      y2={outerPt.y}
                      stroke="var(--accent)"
                      strokeWidth="2"
                      strokeOpacity="0.65"
                    />
                  )}

                  {/* Outer interactive touch target */}
                  <circle cx={pt.x} cy={pt.y} r="20" fill="transparent" />
                  <circle cx={outerPt.labelX} cy={outerPt.labelY} r="22" fill="transparent" />

                  {/* Vertex dot */}
                  <circle
                    cx={pt.x}
                    cy={pt.y}
                    r={isSelected ? 6.5 : 4.5}
                    fill={isSelected ? 'var(--accent)' : 'var(--bg-main)'}
                    stroke={isSelected ? 'var(--text-main)' : 'var(--accent-soft)'}
                    strokeWidth="2.5"
                  />

                  {/* Axis Title */}
                  <text
                    x={outerPt.labelX}
                    y={outerPt.labelY - 3}
                    textAnchor={anchor}
                    fill={isSelected ? 'var(--accent)' : 'var(--text-secondary)'}
                    fontSize="11"
                    fontWeight="800"
                  >
                    {v.shortLabel}
                  </text>
                  <text
                    x={outerPt.labelX}
                    y={outerPt.labelY + 11}
                    textAnchor={anchor}
                    fill={isSelected ? 'var(--text-main)' : 'var(--accent-soft)'}
                    fontSize="10.5"
                    fontFamily="JetBrains Mono, monospace"
                    fontWeight="800"
                  >
                    {v.score}/100
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected Area Detail Panel + Touch Selector Buttons */}
        <div className="space-y-3">
          {/* Touch-friendly Vertex Selector Buttons */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 gap-1.5">
            {vertices.map((v) => {
              const active = v.key === activeStat.key;
              return (
                <button
                  key={v.key}
                  type="button"
                  onClick={() => setSelectedKey(v.key)}
                  className={`min-h-[42px] px-2.5 py-1.5 rounded-xl border text-left transition flex items-center justify-between gap-2 ${
                    active
                      ? 'bg-[#132347] border-[#00D2FF] text-[#FFFFFF]'
                      : 'bg-[#090D16] border-[#1E293B] text-[#CBD5E1] hover:border-[#38BDF8]/50'
                  }`}
                >
                  <span className="text-[11px] font-bold truncate">{v.shortLabel}</span>
                  <span className="font-mono text-xs font-extrabold text-[#00D2FF] tabular-nums shrink-0">
                    {v.score}
                  </span>
                </button>
              );
            })}
          </div>

          {/* Active Area Breakdown Card */}
          <div className="rounded-xl bg-[#0B1D36] border border-[#2563EB]/60 p-3.5 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 min-w-0">
                <Crosshair className="w-4 h-4 text-[#00D2FF] shrink-0" />
                <h3 className="text-sm font-extrabold text-[#FFFFFF] truncate">
                  {activeStat.label}
                </h3>
              </div>
              <span className="font-mono text-lg font-extrabold text-[#00D2FF] tabular-nums shrink-0">
                {activeStat.score}/100
              </span>
            </div>

            <div className="h-1.5 w-full rounded-full bg-[#05070A] border border-[#1E293B] overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-[#2563EB] to-[#00D2FF] transition-all duration-300"
                style={{ width: `${activeStat.score}%` }}
              />
            </div>

            <div className="grid grid-cols-3 gap-2 pt-1 text-center">
              <div className="rounded-lg bg-[#090D16] border border-[#1E293B] p-2">
                <p className="text-[10px] text-[#94A3B8]">Serie fatte</p>
                <p className="font-mono text-sm font-extrabold text-[#FFFFFF] tabular-nums">
                  {activeStat.completedSets}
                </p>
              </div>
              <div className="rounded-lg bg-[#090D16] border border-[#1E293B] p-2">
                <p className="text-[10px] text-[#94A3B8]">Tecnica</p>
                <p className="font-mono text-sm font-extrabold text-[#38BDF8] tabular-nums">
                  {activeStat.avgTech !== null ? `${activeStat.avgTech.toFixed(1)}/3` : '—'}
                </p>
              </div>
              <div className="rounded-lg bg-[#090D16] border border-[#1E293B] p-2">
                <p className="text-[10px] text-[#94A3B8]">Skill cert.</p>
                <p className="font-mono text-sm font-extrabold text-[#00D2FF] tabular-nums">
                  {activeStat.unlockedCount}
                </p>
              </div>
            </div>

            <p className="text-xs text-[#CBD5E1] leading-relaxed">{activeStat.insight}</p>
          </div>
        </div>
      </div>
    </section>
  );
};
