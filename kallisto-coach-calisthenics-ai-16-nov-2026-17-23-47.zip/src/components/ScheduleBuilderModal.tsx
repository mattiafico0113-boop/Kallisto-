import React, { useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Check,
  FilePlus2,
  Plus,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import { EXERCISE_CATALOG, getExerciseById } from '../data/exercises';
import { generateStretchingForDay, generateWarmupForDay } from '../utils/programGenerator';
import type {
  ExerciseCategory,
  WorkoutDayPlan,
  WorkoutExerciseItem,
} from '../types/calisthenics';

interface ScheduleBuilderModalProps {
  initialPlan: WorkoutDayPlan[];
  initialDayIndex?: number;
  startBlank?: boolean;
  onSave: (newPlan: WorkoutDayPlan[]) => void;
  onClose: () => void;
}

const MUSCLE_CATEGORY_LABELS: Record<ExerciseCategory, string> = {
  Spinta: 'Petto (Spinta)',
  Tirata: 'Schiena (Tirata)',
  Core: 'Addome (Core)',
  Gambe: 'Gambe',
  Skill: 'Skill',
};

const CATEGORIES: { id: 'Tutte' | ExerciseCategory; label: string }[] = [
  { id: 'Tutte', label: 'Tutte' },
  { id: 'Spinta', label: 'Petto (Spinta)' },
  { id: 'Tirata', label: 'Schiena (Tirata)' },
  { id: 'Core', label: 'Addome (Core)' },
  { id: 'Gambe', label: 'Gambe' },
  { id: 'Skill', label: 'Skill' },
];

const PICKER_GROUP_ORDER: ExerciseCategory[] = ['Spinta', 'Tirata', 'Core', 'Gambe', 'Skill'];

function uid(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

function createEmptyDay(dayNumber: number): WorkoutDayPlan {
  return {
    id: uid('day'),
    dayNumber,
    title: `Giorno ${dayNumber} — Personalizzato`,
    splitLabel: `Giorno ${dayNumber}`,
    focus: 'Scheda personalizzata',
    warmup: generateWarmupForDay('Personalizzato'),
    stretch: generateStretchingForDay('Personalizzato'),
    exercises: [],
  };
}

function clonePlan(plan: WorkoutDayPlan[]): WorkoutDayPlan[] {
  return plan.map((d) => ({
    ...d,
    warmup: d.warmup ? d.warmup.map((w) => ({ ...w })) : generateWarmupForDay(d.title),
    stretch: d.stretch ? d.stretch.map((s) => ({ ...s })) : generateStretchingForDay(d.title),
    exercises: d.exercises.map((ex) => ({
      ...ex,
      sets: ex.sets.map((s) => ({ ...s })),
    })),
  }));
}

export const ScheduleBuilderModal: React.FC<ScheduleBuilderModalProps> = ({
  initialPlan,
  initialDayIndex = 0,
  startBlank = false,
  onSave,
  onClose,
}) => {
  const [draftPlan, setDraftPlan] = useState<WorkoutDayPlan[]>(() =>
    startBlank || initialPlan.length === 0 ? [createEmptyDay(1)] : clonePlan(initialPlan)
  );
  const [activeDayIdx, setActiveDayIdx] = useState(() =>
    startBlank ? 0 : Math.min(initialDayIndex, Math.max(0, initialPlan.length - 1))
  );
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickerCat, setPickerCat] = useState<'Tutte' | ExerciseCategory>('Tutte');
  const [pickerQuery, setPickerQuery] = useState('');

  // Custom exercise quick-create state inside picker
  const [customOpen, setCustomOpen] = useState(false);
  const [customName, setCustomName] = useState('');
  const [customCategory, setCustomCategory] = useState<ExerciseCategory>('Tirata');
  const [customIsIso, setCustomIsIso] = useState(false);

  const activeDay = draftPlan[activeDayIdx] ?? draftPlan[0];

  const updateActiveDay = (updater: (d: WorkoutDayPlan) => WorkoutDayPlan) => {
    setDraftPlan((prev) =>
      prev.map((d, i) => (i === activeDayIdx ? updater(d) : d))
    );
  };

  const handleAddDay = () => {
    if (draftPlan.length >= 7) return;
    const nextNum = draftPlan.length + 1;
    setDraftPlan((prev) => [...prev, createEmptyDay(nextNum)]);
    setActiveDayIdx(draftPlan.length);
  };

  const handleRemoveDay = (idx: number) => {
    if (draftPlan.length <= 1) return;
    const filtered = draftPlan
      .filter((_, i) => i !== idx)
      .map((d, i) => ({ ...d, dayNumber: i + 1 }));
    setDraftPlan(filtered);
    setActiveDayIdx((cur) => Math.max(0, Math.min(cur, filtered.length - 1)));
  };

  const handleStartBlank = () => {
    setDraftPlan([createEmptyDay(1)]);
    setActiveDayIdx(0);
  };

  const handleAddCatalogExercise = (exId: string) => {
    const def = getExerciseById(exId);
    if (!def) return;
    const defaultTarget = def.type === 'isometric' ? 15 : 8;
    const newItem: WorkoutExerciseItem = {
      instanceId: uid('ex'),
      exerciseId: def.id,
      variantNote: def.variantHint,
      isIsometric: def.type === 'isometric',
      isNegative: def.isNegative,
      negativeSeconds: def.negativeSeconds,
      restSeconds: def.defaultRestSec,
      sets: Array.from({ length: 3 }, () => ({
        id: uid('set'),
        targetValue: defaultTarget,
        actualValue: defaultTarget,
        addedWeightKg: 0,
        rpe: null,
        completed: false,
      })),
    };
    updateActiveDay((d) => ({ ...d, exercises: [...d.exercises, newItem] }));
    setPickerOpen(false);
    setPickerQuery('');
  };

  const handleAddCustomExercise = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = customName.trim();
    if (!cleanName) return;
    const defaultTarget = customIsIso ? 20 : 8;
    const newItem: WorkoutExerciseItem = {
      instanceId: uid('ex'),
      exerciseId: `custom_${Date.now()}`,
      customName: cleanName,
      customCategory,
      variantNote: 'Esercizio personalizzato',
      isIsometric: customIsIso,
      restSeconds: 90,
      sets: Array.from({ length: 3 }, () => ({
        id: uid('set'),
        targetValue: defaultTarget,
        actualValue: defaultTarget,
        addedWeightKg: 0,
        rpe: null,
        completed: false,
      })),
    };
    updateActiveDay((d) => ({ ...d, exercises: [...d.exercises, newItem] }));
    setCustomName('');
    setCustomOpen(false);
    setPickerOpen(false);
  };

  const updateExerciseSetsCount = (instanceId: string, delta: number) => {
    updateActiveDay((d) => ({
      ...d,
      exercises: d.exercises.map((ex) => {
        if (ex.instanceId !== instanceId) return ex;
        const nextCount = Math.max(1, Math.min(10, ex.sets.length + delta));
        if (nextCount === ex.sets.length) return ex;
        if (nextCount < ex.sets.length) {
          return { ...ex, sets: ex.sets.slice(0, nextCount) };
        }
        const template = ex.sets[0];
        const extra = Array.from({ length: nextCount - ex.sets.length }, () => ({
          id: uid('set'),
          targetValue: template?.targetValue ?? (ex.isIsometric ? 15 : 8),
          actualValue: template?.targetValue ?? (ex.isIsometric ? 15 : 8),
          addedWeightKg: template?.addedWeightKg ?? 0,
          rpe: null,
          completed: false,
        }));
        return { ...ex, sets: [...ex.sets, ...extra] };
      }),
    }));
  };

  const updateExerciseTarget = (instanceId: string, delta: number) => {
    updateActiveDay((d) => ({
      ...d,
      exercises: d.exercises.map((ex) => {
        if (ex.instanceId !== instanceId) return ex;
        const cur = ex.sets[0]?.targetValue ?? 8;
        const next = Math.max(1, Math.min(120, cur + delta));
        return {
          ...ex,
          sets: ex.sets.map((s) => ({ ...s, targetValue: next, actualValue: next })),
        };
      }),
    }));
  };

  const updateExerciseWeight = (instanceId: string, delta: number) => {
    updateActiveDay((d) => ({
      ...d,
      exercises: d.exercises.map((ex) => {
        if (ex.instanceId !== instanceId) return ex;
        const cur = ex.sets[0]?.addedWeightKg ?? 0;
        const next = Math.max(0, Math.min(100, cur + delta));
        return {
          ...ex,
          sets: ex.sets.map((s) => ({ ...s, addedWeightKg: next })),
        };
      }),
    }));
  };

  const updateExerciseRest = (instanceId: string, delta: number) => {
    updateActiveDay((d) => ({
      ...d,
      exercises: d.exercises.map((ex) =>
        ex.instanceId === instanceId
          ? { ...ex, restSeconds: Math.max(30, Math.min(300, ex.restSeconds + delta)) }
          : ex
      ),
    }));
  };

  const moveExercise = (idx: number, dir: -1 | 1) => {
    updateActiveDay((d) => {
      const target = idx + dir;
      if (target < 0 || target >= d.exercises.length) return d;
      const copy = [...d.exercises];
      const [item] = copy.splice(idx, 1);
      copy.splice(target, 0, item);
      return { ...d, exercises: copy };
    });
  };

  const removeExercise = (instanceId: string) => {
    updateActiveDay((d) => ({
      ...d,
      exercises: d.exercises.filter((ex) => ex.instanceId !== instanceId),
    }));
  };

  const filteredCatalog = EXERCISE_CATALOG.filter((ex) => {
    const matchCat = pickerCat === 'Tutte' || ex.category === pickerCat;
    const matchQ =
      !pickerQuery.trim() ||
      ex.name.toLowerCase().includes(pickerQuery.toLowerCase()) ||
      ex.variantHint.toLowerCase().includes(pickerQuery.toLowerCase());
    return matchCat && matchQ;
  });

  const canSave = draftPlan.some((d) => d.exercises.length > 0);

  return (
    <div className="fixed inset-0 z-50 bg-[#05070A] flex flex-col">
      {/* Header */}
      <header className="h-14 border-b border-[#1E293B] px-4 flex items-center justify-between gap-3 shrink-0 bg-[#090D16]">
        <div className="min-w-0">
          <h2 className="text-base font-extrabold text-[#FFFFFF] truncate">
            Crea e Personalizza Scheda
          </h2>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={handleStartBlank}
            className="min-h-[38px] px-3 rounded-xl bg-[#0F172A] border border-[#1E293B] text-xs font-semibold text-[#CBD5E1] hover:text-[#FFFFFF] inline-flex items-center gap-1.5"
          >
            <FilePlus2 className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>Da zero</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            aria-label="Chiudi editor scheda"
            className="min-h-[40px] min-w-[40px] rounded-xl bg-[#0F172A] border border-[#1E293B] flex items-center justify-center text-[#94A3B8] hover:text-[#FFFFFF]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Scrollable Body */}
      <div className="flex-1 overflow-y-auto px-4 py-4 pb-28 max-w-3xl w-full mx-auto space-y-5">
        {/* Days Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
          {draftPlan.map((d, i) => (
            <button
              key={d.id}
              type="button"
              onClick={() => setActiveDayIdx(i)}
              className={`min-h-[42px] px-3.5 rounded-xl border text-xs font-bold whitespace-nowrap shrink-0 transition ${
                i === activeDayIdx
                  ? 'bg-[#2563EB] text-[#FFFFFF] border-[#38BDF8]/70'
                  : 'bg-[#0F172A] text-[#CBD5E1] border-[#1E293B] hover:border-[#38BDF8]/40'
              }`}
            >
              G{d.dayNumber} · {d.splitLabel || `Giorno ${d.dayNumber}`}
            </button>
          ))}

          {draftPlan.length < 7 && (
            <button
              type="button"
              onClick={handleAddDay}
              className="min-h-[42px] px-3.5 rounded-xl border border-dashed border-[#38BDF8]/50 text-xs font-bold text-[#38BDF8] inline-flex items-center gap-1 whitespace-nowrap shrink-0 hover:bg-[#0F172A]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Aggiungi giorno</span>
            </button>
          )}
        </div>

        {/* Active Day Metadata */}
        {activeDay && (
          <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold text-[#94A3B8]">
                Impostazioni Giorno {activeDay.dayNumber}
              </span>
              {draftPlan.length > 1 && (
                <button
                  type="button"
                  onClick={() => handleRemoveDay(activeDayIdx)}
                  className="text-xs font-semibold text-[#38BDF8] hover:text-[#00D2FF] inline-flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Elimina giorno</span>
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-[#94A3B8] mb-1">
                  Nome sessione
                </label>
                <input
                  type="text"
                  value={activeDay.title}
                  onChange={(e) =>
                    updateActiveDay((d) => ({
                      ...d,
                      title: e.target.value,
                      splitLabel: e.target.value.split('—')[0].trim().slice(0, 14) || `G${d.dayNumber}`,
                    }))
                  }
                  placeholder="Es. Push & Verticale"
                  className="w-full min-h-[42px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 text-sm text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-[#94A3B8] mb-1">
                  Focus / Note
                </label>
                <input
                  type="text"
                  value={activeDay.focus}
                  onChange={(e) => updateActiveDay((d) => ({ ...d, focus: e.target.value }))}
                  placeholder="Es. Dip, Pike Push-up e Core"
                  className="w-full min-h-[42px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 text-sm text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                />
              </div>
            </div>
          </section>
        )}

        {/* Exercises List in Active Day */}
        <div className="space-y-3">
          {activeDay?.exercises.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-[#1E293B] bg-[#0F172A]/70 p-8 text-center space-y-3">
              <p className="text-sm font-bold text-[#FFFFFF]">
                Nessun esercizio in questo giorno
              </p>
              <p className="text-xs text-[#94A3B8]">
                Aggiungi esercizi dal catalogo Calisthenics o crea un esercizio personalizzato.
              </p>
              <button
                type="button"
                onClick={() => setPickerOpen(true)}
                className="min-h-[44px] px-5 rounded-xl bg-[#2563EB] text-[#FFFFFF] text-xs font-extrabold inline-flex items-center gap-1.5 hover:bg-[#3B82F6] transition"
              >
                <Plus className="w-4 h-4" />
                <span>Aggiungi il primo esercizio</span>
              </button>
            </div>
          ) : (
            activeDay?.exercises.map((item, idx) => {
              const def = getExerciseById(item.exerciseId);
              const displayName = item.customName ?? def?.name ?? item.exerciseId;
              const rawCat = item.customCategory ?? def?.category;
              const displayCat = rawCat ? MUSCLE_CATEGORY_LABELS[rawCat] : 'Personalizzato';
              const targetVal = item.sets[0]?.targetValue ?? 8;
              const weightVal = item.sets[0]?.addedWeightKg ?? 0;

              return (
                <div
                  key={item.instanceId}
                  className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 space-y-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="text-[11px] text-[#94A3B8]">
                        #{idx + 1} · {displayCat} ·{' '}
                        {item.isIsometric ? 'Isometria (s)' : 'Ripetizioni'}
                      </p>
                      <h4 className="text-sm font-bold text-[#FFFFFF] truncate">{displayName}</h4>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => moveExercise(idx, -1)}
                        disabled={idx === 0}
                        aria-label="Sposta su"
                        className="min-h-[36px] min-w-[36px] rounded-lg bg-[#131C31] flex items-center justify-center text-[#CBD5E1] hover:text-[#FFFFFF] disabled:opacity-30"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => moveExercise(idx, 1)}
                        disabled={idx === activeDay.exercises.length - 1}
                        aria-label="Sposta giù"
                        className="min-h-[36px] min-w-[36px] rounded-lg bg-[#131C31] flex items-center justify-center text-[#CBD5E1] hover:text-[#FFFFFF] disabled:opacity-30"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeExercise(item.instanceId)}
                        aria-label="Rimuovi esercizio"
                        className="min-h-[36px] min-w-[36px] rounded-lg bg-[#131C31] border border-[#1E293B] flex items-center justify-center text-[#38BDF8] hover:text-[#00D2FF]"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Steppers Grid */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-2">
                      <p className="text-[10px] text-[#94A3B8] text-center mb-1">Serie</p>
                      <div className="flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => updateExerciseSetsCount(item.instanceId, -1)}
                          className="w-8 h-8 rounded-lg bg-[#131C31] text-[#FFFFFF] font-bold text-sm hover:bg-[#1E293B]"
                        >
                          -
                        </button>
                        <span className="font-mono text-sm font-bold text-[#FFFFFF] tabular-nums">
                          {item.sets.length}
                        </span>
                        <button
                          type="button"
                          onClick={() => updateExerciseSetsCount(item.instanceId, 1)}
                          className="w-8 h-8 rounded-lg bg-[#131C31] text-[#FFFFFF] font-bold text-sm hover:bg-[#1E293B]"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-2">
                      <p className="text-[10px] text-[#94A3B8] text-center mb-1">
                        {item.isIsometric ? 'Secondi' : 'Ripetizioni'}
                      </p>
                      <div className="flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() =>
                            updateExerciseTarget(item.instanceId, item.isIsometric ? -5 : -1)
                          }
                          className="w-8 h-8 rounded-lg bg-[#131C31] text-[#FFFFFF] font-bold text-sm hover:bg-[#1E293B]"
                        >
                          -
                        </button>
                        <span className="font-mono text-sm font-bold text-[#38BDF8] tabular-nums">
                          {targetVal}
                          {item.isIsometric ? 's' : ''}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            updateExerciseTarget(item.instanceId, item.isIsometric ? 5 : 1)
                          }
                          className="w-8 h-8 rounded-lg bg-[#131C31] text-[#FFFFFF] font-bold text-sm hover:bg-[#1E293B]"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-2">
                      <p className="text-[10px] text-[#94A3B8] text-center mb-1">Zavorra</p>
                      <div className="flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => updateExerciseWeight(item.instanceId, -2.5)}
                          className="w-8 h-8 rounded-lg bg-[#131C31] text-[#FFFFFF] font-bold text-sm hover:bg-[#1E293B]"
                        >
                          -
                        </button>
                        <span className="font-mono text-xs font-bold text-[#FFFFFF] tabular-nums">
                          +{weightVal}kg
                        </span>
                        <button
                          type="button"
                          onClick={() => updateExerciseWeight(item.instanceId, 2.5)}
                          className="w-8 h-8 rounded-lg bg-[#131C31] text-[#FFFFFF] font-bold text-sm hover:bg-[#1E293B]"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    <div className="rounded-xl bg-[#090D16] border border-[#1E293B] p-2">
                      <p className="text-[10px] text-[#94A3B8] text-center mb-1">Recupero</p>
                      <div className="flex items-center justify-between">
                        <button
                          type="button"
                          onClick={() => updateExerciseRest(item.instanceId, -15)}
                          className="w-8 h-8 rounded-lg bg-[#131C31] text-[#FFFFFF] font-bold text-sm hover:bg-[#1E293B]"
                        >
                          -
                        </button>
                        <span className="font-mono text-xs font-bold text-[#FFFFFF] tabular-nums">
                          {item.restSeconds}s
                        </span>
                        <button
                          type="button"
                          onClick={() => updateExerciseRest(item.instanceId, 15)}
                          className="w-8 h-8 rounded-lg bg-[#131C31] text-[#FFFFFF] font-bold text-sm hover:bg-[#1E293B]"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Custom Note */}
                  <input
                    type="text"
                    value={item.variantNote}
                    onChange={(e) =>
                      updateActiveDay((d) => ({
                        ...d,
                        exercises: d.exercises.map((ex) =>
                          ex.instanceId === item.instanceId
                            ? { ...ex, variantNote: e.target.value }
                            : ex
                        ),
                      }))
                    }
                    placeholder="Nota tecnica o propedeutica..."
                    className="w-full min-h-[38px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 text-xs text-[#CBD5E1] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                  />
                </div>
              );
            })
          )}

          {activeDay && activeDay.exercises.length > 0 && (
            <button
              type="button"
              onClick={() => setPickerOpen(true)}
              className="w-full min-h-[48px] rounded-2xl border border-dashed border-[#38BDF8]/50 bg-[#0B1D36] text-sm font-bold text-[#38BDF8] flex items-center justify-center gap-2 hover:bg-[#132347] transition"
            >
              <Plus className="w-4 h-4" />
              <span>Aggiungi esercizio a questo giorno</span>
            </button>
          )}
        </div>
      </div>

      {/* Bottom Save Bar */}
      <footer className="fixed bottom-0 left-0 right-0 z-30 bg-[#090D16]/95 backdrop-blur-md border-t border-[#1E293B] p-4 pb-safe">
        <div className="max-w-3xl mx-auto flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[48px] px-5 rounded-2xl bg-[#0F172A] border border-[#1E293B] text-sm font-bold text-[#CBD5E1] hover:text-[#FFFFFF]"
          >
            Annulla
          </button>
          <button
            type="button"
            disabled={!canSave}
            onClick={() => onSave(draftPlan.filter((d) => d.exercises.length > 0))}
            className="flex-1 min-h-[48px] rounded-2xl bg-[#2563EB] text-[#FFFFFF] text-sm font-extrabold flex items-center justify-center gap-2 disabled:opacity-40 hover:bg-[#3B82F6] transition"
          >
            <Check className="w-4 h-4 stroke-[3]" />
            <span>Salva la mia scheda</span>
          </button>
        </div>
      </footer>

      {/* Exercise Picker Overlay */}
      {pickerOpen && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#05070A]/80 backdrop-blur-sm p-3 sm:p-4">
          <div className="w-full max-w-lg max-h-[88vh] rounded-3xl bg-[#0F172A] border border-[#1E293B] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-[#1E293B] flex items-center justify-between">
              <h3 className="text-base font-bold text-[#FFFFFF]">
                {customOpen ? 'Nuovo Esercizio Personalizzato' : 'Scegli Esercizio'}
              </h3>
              <button
                type="button"
                onClick={() => {
                  setPickerOpen(false);
                  setCustomOpen(false);
                }}
                className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-[#94A3B8] hover:text-[#FFFFFF]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {customOpen ? (
              <form onSubmit={handleAddCustomExercise} className="p-4 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-[#94A3B8] mb-1.5">
                    Nome esercizio
                  </label>
                  <input
                    type="text"
                    required
                    value={customName}
                    onChange={(e) => setCustomName(e.target.value)}
                    placeholder="Es. Muscle-up con elastico, Human Flag Tuck..."
                    className="w-full min-h-[44px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 text-sm text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#94A3B8] mb-1.5">
                    Gruppo Muscolare / Categoria
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {PICKER_GROUP_ORDER.map((cat) => (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setCustomCategory(cat)}
                        className={`min-h-[36px] px-3 rounded-lg text-xs font-bold ${
                          customCategory === cat
                            ? 'bg-[#2563EB] text-[#FFFFFF]'
                            : 'bg-[#131C31] text-[#CBD5E1]'
                        }`}
                      >
                        {MUSCLE_CATEGORY_LABELS[cat]}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#94A3B8] mb-1.5">
                    Modalità di misurazione
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setCustomIsIso(false)}
                      className={`min-h-[42px] rounded-xl text-xs font-bold border ${
                        !customIsIso
                          ? 'bg-[#2563EB] text-[#FFFFFF] border-[#38BDF8]'
                          : 'bg-[#131C31] text-[#CBD5E1] border-[#1E293B]'
                      }`}
                    >
                      A ripetizioni
                    </button>
                    <button
                      type="button"
                      onClick={() => setCustomIsIso(true)}
                      className={`min-h-[42px] rounded-xl text-xs font-bold border ${
                        customIsIso
                          ? 'bg-[#38BDF8] text-[#05070A] border-[#00D2FF]'
                          : 'bg-[#131C31] text-[#CBD5E1] border-[#1E293B]'
                      }`}
                    >
                      Isometria (secondi)
                    </button>
                  </div>
                </div>

                <div className="flex items-center gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setCustomOpen(false)}
                    className="min-h-[44px] px-4 rounded-xl bg-[#131C31] text-xs font-bold text-[#CBD5E1]"
                  >
                    Indietro
                  </button>
                  <button
                    type="submit"
                    className="flex-1 min-h-[44px] rounded-xl bg-[#2563EB] text-[#FFFFFF] text-xs font-extrabold hover:bg-[#3B82F6] transition"
                  >
                    Aggiungi alla scheda
                  </button>
                </div>
              </form>
            ) : (
              <>
                <div className="p-4 space-y-3 border-b border-[#1E293B]">
                  <div className="flex items-center gap-2">
                    <div className="relative flex-1">
                      <Search className="w-4 h-4 text-[#94A3B8] absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={pickerQuery}
                        onChange={(e) => setPickerQuery(e.target.value)}
                        placeholder="Cerca nel catalogo..."
                        className="w-full min-h-[42px] pl-9 pr-3 rounded-xl bg-[#090D16] border border-[#1E293B] text-sm text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() => setCustomOpen(true)}
                      className="min-h-[42px] px-3 rounded-xl bg-[#131C31] border border-[#38BDF8]/40 text-xs font-bold text-[#38BDF8] whitespace-nowrap"
                    >
                      + Custom
                    </button>
                  </div>

                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                    {CATEGORIES.map((cat) => (
                      <button
                        key={cat.id}
                        type="button"
                        onClick={() => setPickerCat(cat.id)}
                        className={`min-h-[34px] px-3 rounded-lg text-xs font-bold whitespace-nowrap ${
                          pickerCat === cat.id
                            ? 'bg-[#2563EB] text-[#FFFFFF]'
                            : 'bg-[#131C31] text-[#94A3B8]'
                        }`}
                      >
                        {cat.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto">
                  {(pickerCat === 'Tutte' ? PICKER_GROUP_ORDER : [pickerCat]).map((cat) => {
                    const groupItems = filteredCatalog.filter((ex) => ex.category === cat);
                    if (groupItems.length === 0) return null;
                    return (
                      <div key={cat}>
                        <div className="sticky top-0 z-10 px-4 py-2 bg-[#0B1D36] border-y border-[#1E293B] flex items-center justify-between">
                          <span className="text-xs font-extrabold text-[#38BDF8] uppercase tracking-wider">
                            {MUSCLE_CATEGORY_LABELS[cat]}
                          </span>
                          <span className="font-mono text-[11px] text-[#94A3B8] tabular-nums">
                            {groupItems.length}
                          </span>
                        </div>
                        <div className="divide-y divide-[#1E293B]">
                          {groupItems.map((ex) => (
                            <button
                              key={ex.id}
                              type="button"
                              onClick={() => handleAddCatalogExercise(ex.id)}
                              className="w-full text-left p-4 hover:bg-[#131C31] transition flex items-center justify-between gap-3"
                            >
                              <div>
                                <p className="text-sm font-bold text-[#FFFFFF]">{ex.name}</p>
                                <p className="text-xs text-[#94A3B8] mt-0.5">
                                  {MUSCLE_CATEGORY_LABELS[ex.category]} ·{' '}
                                  {ex.type === 'isometric'
                                    ? 'Isometria'
                                    : ex.isNegative
                                    ? `Negativa (${ex.negativeSeconds ?? 6}s discesa)`
                                    : 'Ripetizioni'}
                                </p>
                              </div>
                              <span className="text-xs font-bold text-[#38BDF8] shrink-0">
                                + Aggiungi
                              </span>
                            </button>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
