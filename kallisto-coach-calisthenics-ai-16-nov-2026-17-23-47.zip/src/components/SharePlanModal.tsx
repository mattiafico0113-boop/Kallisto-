import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Check, Copy, Download, Link2, QrCode, Share2, Upload, X } from 'lucide-react';
import { getExerciseById } from '../data/exercises';
import type { WorkoutDayPlan } from '../types/calisthenics';
import { playSetCompleteTone, playTechClick } from '../utils/audio';
import {
  decodeWorkoutPlanFromCode,
  encodeWorkoutPlanToCode,
  generateQrMatrix,
} from '../utils/qrCodeGenerator';

interface SharePlanModalProps {
  isOpen: boolean;
  weeklyPlan: WorkoutDayPlan[];
  onImportPlan: (plan: WorkoutDayPlan[]) => void;
  onClose: () => void;
}

export const SharePlanModal: React.FC<SharePlanModalProps> = ({
  isOpen,
  weeklyPlan,
  onImportPlan,
  onClose,
}) => {
  const [tab, setTab] = useState<'share' | 'import'>('share');
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [importInput, setImportInput] = useState('');
  const [importError, setImportError] = useState<string | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const shareCode = useMemo(() => encodeWorkoutPlanToCode(weeklyPlan), [weeklyPlan]);

  const shareLink = useMemo(() => {
    if (typeof window === 'undefined') return `?importPlan=${encodeURIComponent(shareCode)}`;
    const base = `${window.location.origin}${window.location.pathname}`;
    return `${base}?importPlan=${encodeURIComponent(shareCode)}`;
  }, [shareCode]);

  const qrMatrix = useMemo(() => generateQrMatrix(shareCode), [shareCode]);

  const previewImportedPlan = useMemo(
    () => (importInput.trim() ? decodeWorkoutPlanFromCode(importInput) : null),
    [importInput]
  );

  // Render crisp QR onto Canvas for crisp display & PNG download
  useEffect(() => {
    if (!isOpen || tab !== 'share' || !qrMatrix || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const size = qrMatrix.length;
    const quiet = 3;
    const cell = 6;
    const totalPx = (size + quiet * 2) * cell;
    canvas.width = totalPx;
    canvas.height = totalPx;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, totalPx, totalPx);

    ctx.fillStyle = '#05070A';
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        if (qrMatrix[r][c]) {
          ctx.fillRect((c + quiet) * cell, (r + quiet) * cell, cell, cell);
        }
      }
    }
  }, [isOpen, tab, qrMatrix]);

  if (!isOpen) return null;

  const handleCopy = async (text: string, type: 'code' | 'link') => {
    playTechClick();
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Fallback ignored if clipboard blocked
    }
    if (type === 'code') {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2200);
    } else {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2200);
    }
  };

  const handleDownloadQr = () => {
    if (!canvasRef.current) return;
    playTechClick();
    const url = canvasRef.current.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = 'calipro-scheda-qr.png';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const handleConfirmImport = () => {
    const decoded = decodeWorkoutPlanFromCode(importInput);
    if (!decoded) {
      setImportError('Codice o link non valido. Controlla che inizi con CALIPRO1: o contenga importPlan=');
      return;
    }
    playSetCompleteTone();
    onImportPlan(decoded);
    setImportInput('');
    setImportError(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[70] bg-[#05070A]/85 backdrop-blur-md flex items-end sm:items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div
        className="w-full max-w-lg rounded-3xl border p-4 sm:p-5 space-y-4 my-auto shadow-2xl"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--accent)',
          color: 'var(--text-main)',
        }}
      >
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <Share2 className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
              <h2 className="text-base font-extrabold">Condividi &amp; Importa Scheda</h2>
            </div>
            <p className="text-xs mt-0.5" style={{ color: 'var(--text-muted)' }}>
              Invia la tua scheda con Codice QR o Link rapido, oppure carica quella di un amico.
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Chiudi condivisione scheda"
            className="min-h-[38px] min-w-[38px] rounded-xl border flex items-center justify-center shrink-0"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-muted)',
            }}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tabs */}
        <div
          className="grid grid-cols-2 gap-1 p-1 rounded-2xl border"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--border-subtle)',
          }}
        >
          <button
            type="button"
            onClick={() => {
              playTechClick();
              setTab('share');
            }}
            className="min-h-[40px] rounded-xl text-xs font-extrabold inline-flex items-center justify-center gap-1.5 transition"
            style={{
              backgroundColor: tab === 'share' ? 'var(--primary)' : 'transparent',
              color: tab === 'share' ? '#FFFFFF' : 'var(--text-muted)',
            }}
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Condividi Scheda</span>
          </button>
          <button
            type="button"
            onClick={() => {
              playTechClick();
              setTab('import');
            }}
            className="min-h-[40px] rounded-xl text-xs font-extrabold inline-flex items-center justify-center gap-1.5 transition"
            style={{
              backgroundColor: tab === 'import' ? 'var(--accent)' : 'transparent',
              color: tab === 'import' ? '#05070A' : 'var(--text-muted)',
            }}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>Importa da Codice</span>
          </button>
        </div>

        {tab === 'share' ? (
          <div className="space-y-3.5">
            {qrMatrix ? (
              <div className="flex flex-col items-center gap-2.5">
                <div className="p-3 rounded-2xl bg-white border-2 border-[#38BDF8] shadow-lg">
                  <canvas
                    ref={canvasRef}
                    className="w-44 h-44 sm:w-48 sm:h-48 block"
                    aria-label="Codice QR della scheda"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleDownloadQr}
                  className="min-h-[36px] px-3 rounded-xl border text-xs font-bold inline-flex items-center gap-1.5"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--accent)',
                  }}
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Salva QR (PNG)</span>
                </button>
              </div>
            ) : (
              <p className="text-xs text-center" style={{ color: 'var(--text-muted)' }}>
                Scheda molto lunga per il QR: usa il codice compatto o il link rapido qui sotto.
              </p>
            )}

            <div className="space-y-1.5">
              <p className="text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
                Codice Compatto Scheda
              </p>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={shareCode}
                  onFocus={(e) => e.currentTarget.select()}
                  className="flex-1 min-h-[40px] rounded-xl border px-3 font-mono text-[11px] focus:outline-none"
                  style={{
                    backgroundColor: 'var(--bg-elevated)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-secondary)',
                  }}
                />
                <button
                  type="button"
                  onClick={() => handleCopy(shareCode, 'code')}
                  className="min-h-[40px] px-3.5 rounded-xl font-extrabold text-xs inline-flex items-center gap-1.5 shrink-0"
                  style={{
                    backgroundColor: 'var(--primary)',
                    color: '#FFFFFF',
                  }}
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copiato!' : 'Copia Codice'}</span>
                </button>
              </div>
            </div>

            <button
              type="button"
              onClick={() => handleCopy(shareLink, 'link')}
              className="w-full min-h-[44px] rounded-xl border text-xs font-extrabold flex items-center justify-center gap-1.5 transition"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--accent)',
                color: 'var(--accent)',
              }}
            >
              {copiedLink ? <Check className="w-4 h-4" /> : <Link2 className="w-4 h-4" />}
              <span>{copiedLink ? 'Link rapido copiato negli appunti!' : 'Copia Link Rapido Condivisibile'}</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-bold mb-1.5" style={{ color: 'var(--text-secondary)' }}>
                Incolla qui il Codice (`CALIPRO1:...`) o il Link dell&apos;amico
              </label>
              <textarea
                rows={3}
                value={importInput}
                onChange={(e) => {
                  setImportInput(e.target.value);
                  setImportError(null);
                }}
                placeholder="CALIPRO1:eyJ2Ijox..."
                className="w-full rounded-xl border p-3 font-mono text-xs focus:outline-none"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-main)',
                }}
              />
            </div>

            {importError && (
              <p className="text-xs font-bold text-[#F59E0B]">{importError}</p>
            )}

            {previewImportedPlan && (
              <div
                className="rounded-xl border p-3 space-y-1.5"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: 'var(--accent)',
                }}
              >
                <p className="text-xs font-extrabold" style={{ color: 'var(--accent)' }}>
                  Anteprima trovata: {previewImportedPlan.length} giorni di allenamento
                </p>
                <div className="space-y-1 max-h-32 overflow-y-auto text-[11px]" style={{ color: 'var(--text-secondary)' }}>
                  {previewImportedPlan.map((d) => (
                    <p key={d.id} className="truncate">
                      • <strong>{d.title}</strong>:{' '}
                      {d.exercises
                        .map((ex) => ex.customName ?? getExerciseById(ex.exerciseId)?.name ?? ex.exerciseId)
                        .join(', ')}
                    </p>
                  ))}
                </div>
              </div>
            )}

            <button
              type="button"
              disabled={!importInput.trim()}
              onClick={handleConfirmImport}
              className="w-full min-h-[46px] rounded-xl font-extrabold text-xs sm:text-sm flex items-center justify-center gap-1.5 disabled:opacity-45 transition"
              style={{
                backgroundColor: 'var(--accent)',
                color: '#05070A',
              }}
            >
              <Upload className="w-4 h-4" />
              <span>Importa e Sostituisci Scheda Attuale</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
