import React, { useMemo, useState } from 'react';
import { Award, Camera, CheckCircle2, Clock, Crosshair, Lock, Sparkles, Trophy } from 'lucide-react';
import { SKILL_BRANCHES, SKILL_TREE_NODES } from '../data/skills';
import type {
  AthleteProfile,
  ManualWorkoutIntensity,
  SkillBranchId,
  SkillNodeDefinition,
  UnlockedSkillRecord,
  WorkoutSessionLog,
} from '../types/calisthenics';
import { estimateSkillUnlockDays } from '../utils/athletePillars';
import { playTechClick } from '../utils/audio';
import { CoachVisionModal } from './CoachVisionModal';
import { SkillChallengeModal } from './SkillChallengeModal';

interface SkillTreeViewProps {
  unlockedSkills: UnlockedSkillRecord[];
  history?: WorkoutSessionLog[];
  manualWorkoutDays?: Record<string, ManualWorkoutIntensity>;
  profile?: AthleteProfile | null;
  onUnlockSkill: (record: UnlockedSkillRecord) => void;
  onSendVisionToCoach?: (analysisText: string) => void;
}

export const SkillTreeView: React.FC<SkillTreeViewProps> = ({
  unlockedSkills,
  history = [],
  manualWorkoutDays = {},
  profile = null,
  onUnlockSkill,
  onSendVisionToCoach,
}) => {
  const [selectedBranch, setSelectedBranch] = useState<'tutte' | SkillBranchId>('tutte');
  const [activeChallengeSkill, setActiveChallengeSkill] = useState<SkillNodeDefinition | null>(
    null
  );
  const [visionOpen, setVisionOpen] = useState(false);
  const [lockedHint, setLockedHint] = useState<string | null>(null);

  const unlockedMap = useMemo(() => {
    const map = new Map<string, UnlockedSkillRecord>();
    for (const rec of unlockedSkills) {
      map.set(rec.skillId, rec);
    }
    return map;
  }, [unlockedSkills]);

  const totalSkills = SKILL_TREE_NODES.length;
  const unlockedCount = unlockedMap.size;
  const pct = totalSkills > 0 ? Math.round((unlockedCount / totalSkills) * 100) : 0;

  const visibleBranches =
    selectedBranch === 'tutte'
      ? SKILL_BRANCHES
      : SKILL_BRANCHES.filter((b) => b.id === selectedBranch);

  const handleNodeClick = (node: SkillNodeDefinition, isAvailable: boolean) => {
    if (!isAvailable) {
      const prereq = SKILL_TREE_NODES.find((n) => n.id === node.prerequisiteId);
      setLockedHint(
        prereq
          ? `Skill bloccata: completa e certifica prima "${prereq.name}".`
          : 'Skill attualmente bloccata.'
      );
      return;
    }
    setLockedHint(null);
    setActiveChallengeSkill(node);
  };

  return (
    <div className="space-y-5 pb-8">
      {/* Summary Header Card */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-semibold text-[#38BDF8]">
              Percorso di padronanza Calisthenics
            </p>
            <h2 className="text-xl sm:text-2xl font-extrabold text-[#FFFFFF] mt-0.5 tracking-tight">
              Albero delle Skill
            </h2>
          </div>

          <div className="flex items-center gap-2.5 rounded-2xl bg-[#090D16] border border-[#1E293B] px-3.5 py-2">
            <Trophy className="w-5 h-5 text-[#00D2FF] shrink-0" />
            <div className="tabular-nums">
              <p className="font-mono text-base font-extrabold text-[#FFFFFF]">
                {unlockedCount} / {totalSkills}
              </p>
              <p className="text-[11px] text-[#94A3B8]">Skill certificate</p>
            </div>
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1.5 tabular-nums">
            <span>Progresso globale albero</span>
            <span className="font-mono font-bold text-[#38BDF8]">{pct}%</span>
          </div>
          <div className="h-2 w-full rounded-full bg-[#090D16] border border-[#1E293B] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#2563EB] to-[#00D2FF] transition-all duration-300"
              style={{ width: `${pct}%` }}
            />
          </div>
        </div>

        {/* Coach Vision Launcher */}
        {onSendVisionToCoach && (
          <button
            type="button"
            onClick={() => {
              playTechClick();
              setVisionOpen(true);
            }}
            className="w-full min-h-[42px] px-3.5 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-2 transition"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--accent)',
              color: 'var(--accent)',
            }}
          >
            <Crosshair className="w-4 h-4 shrink-0" />
            <span>Controlla la mia Forma (Foto) · Coach Vision</span>
          </button>
        )}

        {/* Branch Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
          <button
            type="button"
            onClick={() => setSelectedBranch('tutte')}
            className={`min-h-[40px] px-3.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition ${
              selectedBranch === 'tutte'
                ? 'bg-[#2563EB] text-[#FFFFFF]'
                : 'bg-[#131C31] text-[#CBD5E1] hover:text-[#FFFFFF]'
            }`}
          >
            Tutti i rami
          </button>
          {SKILL_BRANCHES.map((branch) => (
            <button
              key={branch.id}
              type="button"
              onClick={() => setSelectedBranch(branch.id)}
              className={`min-h-[40px] px-3.5 rounded-xl text-xs font-bold whitespace-nowrap shrink-0 transition ${
                selectedBranch === branch.id
                  ? 'bg-[#2563EB] text-[#FFFFFF]'
                  : 'bg-[#131C31] text-[#CBD5E1] hover:text-[#FFFFFF]'
              }`}
            >
              {branch.title}
            </button>
          ))}
        </div>
      </section>

      {lockedHint && (
        <div
          role="status"
          className="rounded-2xl bg-[#0B1D36] border border-[#38BDF8]/60 px-4 py-3 text-xs font-semibold text-[#FFFFFF] flex items-center gap-2.5"
        >
          <Lock className="w-4 h-4 text-[#38BDF8] shrink-0" />
          <span>{lockedHint}</span>
        </div>
      )}

      {/* Skill Branches Grid */}
      <div className="grid grid-cols-1 gap-4 items-start">
        {visibleBranches.map((branch) => {
          const nodes = SKILL_TREE_NODES.filter((n) => n.branchId === branch.id).sort(
            (a, b) => a.order - b.order
          );
          const branchUnlockedCount = nodes.filter((n) => unlockedMap.has(n.id)).length;

          return (
            <section
              key={branch.id}
              className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-4 sm:p-5 space-y-4"
            >
              <div className="flex items-start justify-between gap-3 pb-3 border-b border-[#1E293B]">
                <div>
                  <h3 className="text-base font-extrabold text-[#FFFFFF]">{branch.title}</h3>
                  <p className="text-xs text-[#94A3B8] mt-0.5">{branch.subtitle}</p>
                </div>
                <span className="font-mono text-xs font-bold text-[#38BDF8] tabular-nums shrink-0">
                  {branchUnlockedCount}/{nodes.length}
                </span>
              </div>

              {/* Connected Progressive Tree */}
              <div className="flex flex-col">
                {nodes.map((node, idx) => {
                  const unlockedRecord = unlockedMap.get(node.id);
                  const isCertified = Boolean(unlockedRecord);
                  const prereqMet =
                    !node.prerequisiteId || unlockedMap.has(node.prerequisiteId);
                  const isAvailable = prereqMet;
                  const nextNode = nodes[idx + 1];
                  const nextLit = Boolean(isCertified && nextNode);
                  const unlockEstimate = !isCertified
                    ? estimateSkillUnlockDays({
                        skill: node,
                        allNodes: SKILL_TREE_NODES,
                        unlockedSkills,
                        history,
                        manualWorkoutDays,
                        profile,
                      })
                    : null;

                  return (
                    <React.Fragment key={node.id}>
                      <button
                        type="button"
                        onClick={() => handleNodeClick(node, isAvailable)}
                        className={`w-full text-left rounded-2xl p-4 border transition flex items-center justify-between gap-3 min-h-[76px] ${
                          isCertified
                            ? 'bg-[#132347] border-[#38BDF8] shadow-[0_0_18px_rgba(56,189,248,0.18)]'
                            : isAvailable
                            ? 'bg-[#0B1D36] border-[#2563EB] hover:border-[#38BDF8]'
                            : 'bg-[#090D16] border-[#1E293B] opacity-80 hover:opacity-100'
                        }`}
                      >
                        <div className="flex items-center gap-3 min-w-0 flex-1">
                          <div
                            className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 border ${
                              isCertified
                                ? 'bg-[#38BDF8] border-[#00D2FF] text-[#05070A]'
                                : isAvailable
                                ? 'bg-[#2563EB] border-[#38BDF8]/60 text-[#FFFFFF]'
                                : 'bg-[#131C31] border-[#1E293B] text-[#64748B]'
                            }`}
                          >
                            {isCertified ? (
                              <CheckCircle2 className="w-5 h-5 stroke-[2.5]" />
                            ) : isAvailable ? (
                              <Camera className="w-5 h-5" />
                            ) : (
                              <Lock className="w-4 h-4" />
                            )}
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-[11px] font-bold text-[#38BDF8] tabular-nums">
                                0{node.order}
                              </span>
                              <h4 className="text-sm font-extrabold text-[#FFFFFF] truncate">
                                {node.name}
                              </h4>
                            </div>
                            <p className="text-xs text-[#94A3B8] mt-0.5 truncate">
                              {node.requirementLabel}
                            </p>
                            {unlockedRecord ? (
                              <p className="text-[11px] font-semibold text-[#00D2FF] mt-1 flex items-center gap-1">
                                <Award className="w-3.5 h-3.5 shrink-0" />
                                <span>
                                  Skill Sbloccata ·{' '}
                                  {new Date(unlockedRecord.unlockedAtISO).toLocaleDateString(
                                    'it-IT',
                                    { day: '2-digit', month: 'short', year: 'numeric' }
                                  )}
                                </span>
                              </p>
                            ) : unlockEstimate ? (
                              <div className="mt-1.5 space-y-1">
                                <p className="text-[11px] font-semibold flex items-center gap-1 text-[#7DD3FC]">
                                  <Clock className="w-3 h-3 shrink-0 text-[#00D2FF]" />
                                  <span className="truncate">{unlockEstimate.label}</span>
                                </p>
                                <div className="h-1.5 w-full max-w-[230px] rounded-full bg-[#05070A] border border-[#1E293B] overflow-hidden">
                                  <div
                                    className="h-full rounded-full transition-all duration-300"
                                    style={{
                                      width: `${unlockEstimate.readinessPct}%`,
                                      backgroundColor: isAvailable ? 'var(--accent)' : 'var(--primary)',
                                    }}
                                  />
                                </div>
                              </div>
                            ) : null}
                          </div>
                        </div>

                        <div className="shrink-0 text-right">
                          {isCertified ? (
                            <span className="text-xs font-bold text-[#38BDF8]">Certificata</span>
                          ) : isAvailable ? (
                            <span className="inline-flex items-center gap-1 text-xs font-bold text-[#FFFFFF] bg-[#2563EB] px-3 py-1.5 rounded-xl">
                              <Sparkles className="w-3.5 h-3.5" />
                              <span>Sfida</span>
                            </span>
                          ) : (
                            <span className="text-xs font-semibold text-[#64748B]">Bloccata</span>
                          )}
                        </div>
                      </button>

                      {/* Glowing Connector Line to next node in branch */}
                      {idx < nodes.length - 1 && (
                        <div className="flex justify-center py-0.5" aria-hidden="true">
                          <div className="flex flex-col items-center">
                            <div
                              className={`w-1 h-6 rounded-full transition-all ${
                                nextLit
                                  ? 'bg-gradient-to-b from-[#00D2FF] to-[#2563EB] shadow-[0_0_12px_rgba(0,210,255,0.85)]'
                                  : 'bg-[#1E293B]'
                              }`}
                            />
                            <div
                              className={`w-2 h-2 rounded-full -mt-1 ${
                                nextLit
                                  ? 'bg-[#00D2FF] shadow-[0_0_8px_rgba(0,210,255,0.9)]'
                                  : 'bg-[#1E293B]'
                              }`}
                            />
                          </div>
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </section>
          );
        })}
      </div>

      {/* Camera Verification Challenge Modal */}
      {activeChallengeSkill && (
        <SkillChallengeModal
          skill={activeChallengeSkill}
          existingUnlock={unlockedMap.get(activeChallengeSkill.id)}
          onCertified={onUnlockSkill}
          onClose={() => setActiveChallengeSkill(null)}
        />
      )}

      {/* Coach Vision Postural Check Modal */}
      {onSendVisionToCoach && (
        <CoachVisionModal
          isOpen={visionOpen}
          onSendPosturalAnalysisToCoach={(analysisText) => {
            onSendVisionToCoach(analysisText);
          }}
          onClose={() => setVisionOpen(false)}
        />
      )}
    </div>
  );
};
