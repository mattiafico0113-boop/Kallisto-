import React, { useCallback, useEffect, useRef, useState } from 'react';
import { Check, Mic, MicOff, X } from 'lucide-react';
import { playDoubleDing } from '../utils/audio';
import { parseVoiceSetEvent } from '../utils/voiceCoach';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionErrorEventLike {
  error: string;
}

interface SpeechRecognitionInstanceLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

type SpeechRecognitionConstructorLike = new () => SpeechRecognitionInstanceLike;

function getSpeechRecognitionCtor(): SpeechRecognitionConstructorLike | null {
  if (typeof window === 'undefined') return null;
  const win = window as unknown as {
    SpeechRecognition?: SpeechRecognitionConstructorLike;
    webkitSpeechRecognition?: SpeechRecognitionConstructorLike;
  };
  return win.SpeechRecognition || win.webkitSpeechRecognition || null;
}

interface VoiceSetModalProps {
  isOpen: boolean;
  exerciseName: string;
  setNumber: number;
  totalSets?: number;
  targetReps: number;
  partnerLabel?: string;
  onComplete: (finalReps: number) => void;
  onCancel: () => void;
}

export const VoiceSetModal: React.FC<VoiceSetModalProps> = ({
  isOpen,
  exerciseName,
  setNumber,
  totalSets,
  targetReps,
  partnerLabel,
  onComplete,
  onCancel,
}) => {
  const [reps, setReps] = useState(0);
  const [listening, setListening] = useState(false);
  const [lastTranscript, setLastTranscript] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const repsRef = useRef(0);
  repsRef.current = reps;

  const finishedRef = useRef(false);
  const activeSessionRef = useRef(false);
  const recognitionRef = useRef<SpeechRecognitionInstanceLike | null>(null);
  const restartTimerRef = useRef<number | null>(null);
  const lastRepFiredRef = useRef<{ val: number; ts: number }>({ val: -1, ts: 0 });
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  const stopRecognition = useCallback(() => {
    if (restartTimerRef.current !== null) {
      window.clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onend = null;
        recognitionRef.current.onresult = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.stop();
      } catch {
        // Ignore stop errors
      }
      recognitionRef.current = null;
    }
    setListening(false);
  }, []);

  const finishSet = useCallback(
    (finalValue: number) => {
      if (finishedRef.current) return;
      finishedRef.current = true;
      activeSessionRef.current = false;
      stopRecognition();
      playDoubleDing();
      onCompleteRef.current(Math.max(0, finalValue));
    },
    [stopRecognition]
  );

  const startRecognition = useCallback(() => {
    if (!activeSessionRef.current || finishedRef.current) return;

    const Ctor = getSpeechRecognitionCtor();
    if (!Ctor) {
      setErrorMsg(
        'Riconoscimento vocale non supportato in questo browser. Puoi usare i pulsanti + / - qui sotto.'
      );
      setListening(false);
      return;
    }

    stopRecognition();

    try {
      const rec = new Ctor();
      rec.lang = 'it-IT';
      rec.continuous = true;
      rec.interimResults = true;
      rec.maxAlternatives = 1;

      rec.onresult = (event) => {
        if (finishedRef.current) return;
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const res = event.results[i];
          const alt = res[0];
          if (!alt?.transcript) continue;

          const transcript = alt.transcript.trim();
          setLastTranscript(transcript);

          const parsed = parseVoiceSetEvent(transcript);
          if (!parsed) continue;

          if (parsed.type === 'finish') {
            finishSet(repsRef.current);
            return;
          }

          if (parsed.type === 'rep') {
            const now = Date.now();
            if (
              lastRepFiredRef.current.val === parsed.value &&
              now - lastRepFiredRef.current.ts < 650
            ) {
              continue;
            }
            lastRepFiredRef.current = { val: parsed.value, ts: now };
            repsRef.current = parsed.value;
            setReps(parsed.value);

            if (parsed.value >= targetReps) {
              finishSet(parsed.value);
              return;
            }
          }
        }
      };

      rec.onerror = (ev) => {
        if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') {
          setErrorMsg('Permesso microfono negato. Consenti il microfono nelle impostazioni del browser.');
          activeSessionRef.current = false;
          stopRecognition();
        } else if (ev.error !== 'no-speech' && ev.error !== 'aborted') {
          setErrorMsg(`Avviso microfono: ${ev.error}`);
        }
      };

      rec.onend = () => {
        if (activeSessionRef.current && !finishedRef.current) {
          restartTimerRef.current = window.setTimeout(() => {
            if (activeSessionRef.current && !finishedRef.current) {
              startRecognition();
            }
          }, 180);
        } else {
          setListening(false);
        }
      };

      recognitionRef.current = rec;
      rec.start();
      setListening(true);
      setErrorMsg(null);
    } catch {
      setErrorMsg('Impossibile avviare il microfono. Usa i controlli manuali qui sotto.');
      setListening(false);
    }
  }, [finishSet, stopRecognition, targetReps]);

  useEffect(() => {
    if (!isOpen) {
      activeSessionRef.current = false;
      stopRecognition();
      return;
    }

    finishedRef.current = false;
    activeSessionRef.current = true;
    repsRef.current = 0;
    lastRepFiredRef.current = { val: -1, ts: 0 };
    setReps(0);
    setLastTranscript('');
    setErrorMsg(null);
    startRecognition();

    return () => {
      activeSessionRef.current = false;
      stopRecognition();
    };
  }, [isOpen, startRecognition, stopRecognition]);

  if (!isOpen) return null;

  const progressPct = targetReps > 0 ? Math.min(100, Math.round((reps / targetReps) * 100)) : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#05070A]/85 backdrop-blur-sm p-3 sm:p-4">
      <div className="w-full max-w-md rounded-3xl bg-[#0F172A] border border-[#00D2FF]/60 p-5 shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs font-semibold text-[#38BDF8] tabular-nums">
              {partnerLabel ? `${partnerLabel} · ` : ''}Serie {setNumber}
              {totalSets ? ` di ${totalSets}` : ''} · Conteggio Vocale
            </p>
            <h3 className="text-lg font-extrabold text-[#FFFFFF] mt-0.5 truncate">
              {exerciseName}
            </h3>
          </div>

          <button
            type="button"
            onClick={() => {
              activeSessionRef.current = false;
              stopRecognition();
              onCancel();
            }}
            aria-label="Annulla serie vocale"
            className="min-h-[44px] min-w-[44px] rounded-xl bg-[#131C31] border border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF] flex items-center justify-center shrink-0 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Bright Cyan Listening Indicator */}
        <div
          role="status"
          className={`rounded-2xl border px-4 py-3 flex items-center gap-3 transition ${
            listening
              ? 'bg-[#0B1D36] border-[#00D2FF] shadow-[0_0_24px_rgba(0,210,255,0.22)]'
              : 'bg-[#131C31] border-[#1E293B]'
          }`}
        >
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
              listening
                ? 'bg-[#00D2FF] text-[#05070A]'
                : 'bg-[#090D16] border border-[#1E293B] text-[#38BDF8]'
            }`}
          >
            {listening ? <Mic className="w-5 h-5 stroke-[2.5]" /> : <MicOff className="w-5 h-5" />}
          </div>
          <div className="min-w-0">
            <p className="text-xs font-extrabold text-[#00D2FF] leading-snug">
              {listening
                ? 'In ascolto... Pronuncia i numeri (1, 2, 3...)'
                : 'Microfono non attivo'}
            </p>
            <p className="text-[11px] text-[#CBD5E1] mt-0.5 truncate">
              {errorMsg
                ? errorMsg
                : lastTranscript
                ? `Rilevato: "${lastTranscript}"`
                : 'Di\u2019 "Fine" o "Stop" per chiudere in anticipo'}
            </p>
          </div>
        </div>

        {/* Large Centered Rep Counter */}
        <div className="rounded-2xl bg-[#090D16] border border-[#1E293B] p-6 text-center space-y-3">
          <p className="font-mono text-5xl sm:text-6xl font-extrabold tabular-nums tracking-tight">
            <span className="text-[#00D2FF]">{reps}</span>
            <span className="text-[#64748B] mx-2 text-4xl">/</span>
            <span className="text-[#FFFFFF] text-4xl sm:text-5xl">{targetReps}</span>
          </p>
          <p className="text-xs font-semibold text-[#94A3B8]">
            ripetizioni contate rispetto al target
          </p>

          <div className="h-2.5 w-full rounded-full bg-[#131C31] border border-[#1E293B] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#2563EB] to-[#00D2FF] transition-all duration-150"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        {/* Manual Stepper + Finish / Cancel Actions */}
        <div className="space-y-2.5">
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                const next = Math.max(0, repsRef.current - 1);
                repsRef.current = next;
                setReps(next);
              }}
              className="min-h-[46px] rounded-xl bg-[#131C31] border border-[#1E293B] text-base font-bold text-[#FFFFFF] hover:bg-[#1E293B] transition"
            >
              -1 Rep
            </button>
            <button
              type="button"
              onClick={() => {
                const next = repsRef.current + 1;
                repsRef.current = next;
                setReps(next);
                if (next >= targetReps) {
                  finishSet(next);
                }
              }}
              className="min-h-[46px] rounded-xl bg-[#132347] border border-[#38BDF8]/50 text-base font-bold text-[#38BDF8] hover:bg-[#1E3A6E] transition"
            >
              +1 Rep
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => {
                activeSessionRef.current = false;
                stopRecognition();
                onCancel();
              }}
              className="min-h-[48px] rounded-xl bg-[#131C31] border border-[#1E293B] text-sm font-bold text-[#CBD5E1] hover:text-[#FFFFFF] transition"
            >
              Annulla
            </button>
            <button
              type="button"
              onClick={() => finishSet(repsRef.current)}
              className="min-h-[48px] rounded-xl bg-[#2563EB] text-sm font-extrabold text-[#FFFFFF] inline-flex items-center justify-center gap-1.5 hover:bg-[#3B82F6] transition"
            >
              <Check className="w-4 h-4 stroke-[3]" />
              <span>Fine Serie</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
