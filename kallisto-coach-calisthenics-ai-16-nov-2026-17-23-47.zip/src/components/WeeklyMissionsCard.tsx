import React from 'react';
import { CheckCircle2, Target } from 'lucide-react';
import type { WeeklyMissionItem } from '../utils/recoveryAndMissions';

interface WeeklyMissionsCardProps {
  missions: WeeklyMissionItem[];
}

export const WeeklyMissionsCard: React.FC<WeeklyMissionsCardProps> = ({ missions }) => {
  const completedCount = missions.filter((m) => m.completed).length;

  return (
    <section
      className="rounded-2xl border p-3.5 space-y-2.5"
      style={{
        backgroundColor: 'var(--bg-card)',
        borderColor: 'var(--border-subtle)',
        color: 'var(--text-main)',
      }}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <Target className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
          <h3 className="text-xs sm:text-sm font-extrabold truncate">
            Missioni Settimanali Automatiche
          </h3>
        </div>
        <span
          className="font-mono text-[11px] font-extrabold px-2 py-0.5 rounded-lg border shrink-0 tabular-nums"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--accent)',
            color: 'var(--accent)',
          }}
        >
          {completedCount}/{missions.length} · +150 XP
        </span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
        {missions.map((m) => {
          const pct = Math.min(100, Math.round((m.current / Math.max(1, m.target)) * 100));
          return (
            <div
              key={m.id}
              className="rounded-xl border p-2.5 space-y-1.5 transition"
              style={{
                backgroundColor: m.completed ? 'var(--bg-elevated)' : 'var(--bg-main)',
                borderColor: m.completed ? 'var(--accent)' : 'var(--border-subtle)',
              }}
            >
              <div className="flex items-start justify-between gap-1.5">
                <p className="text-[11px] font-bold leading-snug">{m.title}</p>
                {m.completed && (
                  <CheckCircle2
                    className="w-4 h-4 shrink-0 mt-0.5"
                    style={{ color: 'var(--accent)' }}
                  />
                )}
              </div>

              <div className="flex items-center justify-between text-[10px] font-mono font-bold tabular-nums">
                <span style={{ color: m.completed ? 'var(--accent)' : 'var(--text-muted)' }}>
                  {Math.min(m.current, m.target)}/{m.target}
                </span>
                <span style={{ color: m.completed ? '#10B981' : 'var(--text-muted)' }}>
                  {m.completed ? `+${m.xpBonus} XP` : `+${m.xpBonus} XP`}
                </span>
              </div>

              <div
                className="h-1.5 w-full rounded-full border overflow-hidden"
                style={{
                  backgroundColor: 'var(--bg-card)',
                  borderColor: 'var(--border-subtle)',
                }}
              >
                <div
                  className="h-full rounded-full transition-all duration-300"
                  style={{
                    width: `${pct}%`,
                    backgroundColor: m.completed ? 'var(--accent)' : 'var(--primary)',
                  }}
                />
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
