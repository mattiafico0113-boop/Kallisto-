import React, { useMemo, useState } from 'react';
import {
  Activity,
  ArrowRight,
  Check,
  Download,
  Droplets,
  HeartPulse,
  Shield,
  ShieldAlert,
  Sparkles,
  Trophy,
  Zap,
} from 'lucide-react';
import { SKILL_TREE_NODES } from '../data/skills';
import type {
  AthleteProfile,
  DailyNutritionLog,
  EnergyLevel,
  ManualWorkoutIntensity,
  MorningCheckinRecord,
  MorningJointStatus,
  SleepQuality,
  UnlockedSkillRecord,
  WorkoutSessionLog,
} from '../types/calisthenics';
import {
  analyzeTendonHealthAlerts,
  computeNutritionTargets,
  estimateSkillUnlockDays,
  formatMorningCheckinSummary,
  getLocalDateKey,
} from '../utils/athletePillars';
import { playSetCompleteTone, playTechClick } from '../utils/audio';
import { computeMuscleRecovery } from '../utils/recoveryAndMissions';
import { computeRpgProgress } from '../utils/rpgProgression';
import { MorningCheckinCard } from './MorningCheckinCard';
import { MuscleRecoveryCard } from './MuscleRecoveryCard';
import { NutritionHydrationWidget } from './NutritionHydrationWidget';
import { PrehabModal } from './PrehabModal';

interface WellnessViewProps {
  profile: AthleteProfile;
  todayCheckin: MorningCheckinRecord | null;
  morningCheckins: MorningCheckinRecord[];
  hasJointRiskExercises: boolean;
  nutritionLogs: DailyNutritionLog[];
  history: WorkoutSessionLog[];
  unlockedSkills?: UnlockedSkillRecord[];
  bonusMissionXp?: number;
  manualWorkoutDays?: Record<string, ManualWorkoutIntensity>;
  onSaveMorningCheckin: (values: {
    sleepQuality: SleepQuality;
    energyLevel: EnergyLevel;
    jointStatus: MorningJointStatus;
  }) => void;
  onAdaptVolumeMinusOne: () => void;
  onProtectJointExercises: (joint: MorningJointStatus) => number;
  onUpdateTodayNutrition: (updater: (cur: DailyNutritionLog) => DailyNutritionLog) => void;
  onPrehabCompleted: () => void;
  onGoToWorkout: () => void;
  onGoToSkills?: () => void;
}

function drawRoundedRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}

export const WellnessView: React.FC<WellnessViewProps> = ({
  profile,
  todayCheckin,
  morningCheckins,
  hasJointRiskExercises,
  nutritionLogs,
  history,
  unlockedSkills = [],
  bonusMissionXp = 0,
  manualWorkoutDays = {},
  onSaveMorningCheckin,
  onAdaptVolumeMinusOne,
  onProtectJointExercises,
  onUpdateTodayNutrition,
  onPrehabCompleted,
  onGoToWorkout,
  onGoToSkills,
}) => {
  const [checkinEditorOpen, setCheckinEditorOpen] = useState<boolean>(!todayCheckin);
  const [prehabOpen, setPrehabOpen] = useState(false);
  const [lockscreenSaved, setLockscreenSaved] = useState(false);

  const tendonAlerts = useMemo(
    () => analyzeTendonHealthAlerts(morningCheckins),
    [morningCheckins]
  );

  // 4 Mini-Widgets Live Data
  const todayKey = getLocalDateKey();
  const todayNutrition = useMemo(
    () =>
      nutritionLogs.find((l) => l.dateKey === todayKey) ?? {
        dateKey: todayKey,
        waterMl: 0,
        proteinMeals: 0,
        creatineTaken: false,
      },
    [nutritionLogs, todayKey]
  );
  const nutritionTargets = useMemo(() => computeNutritionTargets(profile), [profile]);
  const waterPct = Math.min(
    100,
    Math.round((todayNutrition.waterMl / Math.max(1, nutritionTargets.waterTargetMl)) * 100)
  );

  const recoveryZones = useMemo(() => computeMuscleRecovery(history), [history]);
  const avgRecoveryPct = useMemo(() => {
    if (recoveryZones.length === 0) return 100;
    const sum = recoveryZones.reduce((acc, z) => acc + z.percent, 0);
    return Math.round(sum / recoveryZones.length);
  }, [recoveryZones]);

  const rpg = useMemo(
    () => computeRpgProgress(unlockedSkills, history, bonusMissionXp),
    [unlockedSkills, history, bonusMissionXp]
  );

  const nextSkillInfo = useMemo(() => {
    const unlockedSet = new Set(unlockedSkills.map((u) => u.skillId));
    // Prefer an unlocked-prereq node first, else lowest-order uncertified node
    const uncertified = SKILL_TREE_NODES.filter((n) => !unlockedSet.has(n.id)).sort(
      (a, b) => a.order - b.order
    );
    if (uncertified.length === 0) {
      return null;
    }
    const readyCandidate =
      uncertified.find((n) => !n.prerequisiteId || unlockedSet.has(n.prerequisiteId)) ??
      uncertified[0];
    const estimate = estimateSkillUnlockDays({
      skill: readyCandidate,
      allNodes: SKILL_TREE_NODES,
      unlockedSkills,
      history,
      manualWorkoutDays,
      profile,
    });
    return {
      name: readyCandidate.name,
      estimatedDays: estimate.estimatedDays,
      readinessPct: estimate.readinessPct,
    };
  }, [unlockedSkills, history, manualWorkoutDays, profile]);

  const handleSaveLockscreenWallpaper = () => {
    playTechClick();
    const width = 1080;
    const height = 1920;
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background #05070A + radial cyber aura centered in the lockscreen safe zone
    ctx.fillStyle = '#05070A';
    ctx.fillRect(0, 0, width, height);

    const grad = ctx.createRadialGradient(width / 2, height * 0.54, 40, width / 2, height * 0.54, 620);
    grad.addColorStop(0, 'rgba(37, 99, 235, 0.28)');
    grad.addColorStop(0.55, 'rgba(0, 210, 255, 0.08)');
    grad.addColorStop(1, 'rgba(5, 7, 10, 0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Subtle HUD corner brackets in central safe zone (y: 520..1440)
    const padX = 76;
    const cardTop = 530;
    const cardHeight = 900;
    ctx.strokeStyle = 'rgba(56, 189, 248, 0.45)';
    ctx.lineWidth = 4;
    // Top-left bracket
    ctx.beginPath();
    ctx.moveTo(padX, cardTop + 36);
    ctx.lineTo(padX, cardTop);
    ctx.lineTo(padX + 36, cardTop);
    ctx.stroke();
    // Top-right bracket
    ctx.beginPath();
    ctx.moveTo(width - padX - 36, cardTop);
    ctx.lineTo(width - padX, cardTop);
    ctx.lineTo(width - padX, cardTop + 36);
    ctx.stroke();
    // Bottom-left bracket
    ctx.beginPath();
    ctx.moveTo(padX, cardTop + cardHeight - 36);
    ctx.lineTo(padX, cardTop + cardHeight);
    ctx.lineTo(padX + 36, cardTop + cardHeight);
    ctx.stroke();
    // Bottom-right bracket
    ctx.beginPath();
    ctx.moveTo(width - padX - 36, cardTop + cardHeight);
    ctx.lineTo(width - padX, cardTop + cardHeight);
    ctx.lineTo(width - padX, cardTop + cardHeight - 36);
    ctx.stroke();

    // Header inside safe zone (leaves top 520px clear for phone clock & date)
    ctx.textAlign = 'center';
    ctx.fillStyle = '#38BDF8';
    ctx.font = '800 32px sans-serif';
    ctx.fillText('CALI PRO · DASHBOARD ATLETA', width / 2, 600);

    const formattedDate = new Date().toLocaleDateString('it-IT', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
    });
    ctx.fillStyle = '#94A3B8';
    ctx.font = '600 26px sans-serif';
    ctx.fillText(
      `${profile.name ? `${profile.name.toUpperCase()} · ` : ''}${formattedDate.toUpperCase()}`,
      width / 2,
      648
    );

    const cards = [
      {
        title: 'ACQUA OGGI',
        value: `${todayNutrition.waterMl} ml`,
        sub: `Obiettivo: ${nutritionTargets.waterTargetMl} ml (${waterPct}%)`,
        accent: '#00D2FF',
      },
      {
        title: 'RECUPERO MUSCOLARE',
        value: `${avgRecoveryPct}%`,
        sub: avgRecoveryPct >= 80 ? 'Pronto ad alta intensità' : 'Monitora carico & tendini',
        accent: avgRecoveryPct >= 80 ? '#34D399' : '#38BDF8',
      },
      {
        title: 'PROSSIMA SKILL',
        value: nextSkillInfo ? nextSkillInfo.name : 'Albero Completo',
        sub: nextSkillInfo ? `Stima sblocco: ~${nextSkillInfo.estimatedDays} giorni` : '100% Skill Certificate',
        accent: '#38BDF8',
      },
      {
        title: 'LIVELLO AVATAR',
        value: `Livello ${rpg.level}`,
        sub: `${rpg.rankTitle} · ${rpg.totalXp} XP`,
        accent: '#60A5FA',
      },
    ];

    const colGap = 28;
    const rowGap = 28;
    const boxW = (width - padX * 2 - colGap) / 2;
    const boxH = 270;
    const startY = 710;

    cards.forEach((c, idx) => {
      const col = idx % 2;
      const row = Math.floor(idx / 2);
      const bx = padX + col * (boxW + colGap);
      const by = startY + row * (boxH + rowGap);

      drawRoundedRect(ctx, bx, by, boxW, boxH, 32);
      ctx.fillStyle = '#0F172A';
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(37, 99, 235, 0.55)';
      ctx.stroke();

      ctx.textAlign = 'left';
      ctx.fillStyle = '#94A3B8';
      ctx.font = '700 22px sans-serif';
      ctx.fillText(c.title, bx + 30, by + 56);

      ctx.fillStyle = c.accent;
      const fontSize = c.value.length > 14 ? 36 : 52;
      ctx.font = `800 ${fontSize}px sans-serif`;
      const displayVal = c.value.length > 18 ? `${c.value.slice(0, 17)}…` : c.value;
      ctx.fillText(displayVal, bx + 30, by + 150);

      ctx.fillStyle = '#CBD5E1';
      ctx.font = '600 22px sans-serif';
      const displaySub = c.sub.length > 30 ? `${c.sub.slice(0, 29)}…` : c.sub;
      ctx.fillText(displaySub, bx + 30, by + 216);
    });

    // Bottom safe footer inside card
    ctx.textAlign = 'center';
    ctx.fillStyle = '#64748B';
    ctx.font = '600 24px sans-serif';
    ctx.fillText('COSTANZA · TECNICA · RECUPERO', width / 2, 1365);

    const dataUrl = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = dataUrl;
    a.download = `calipro-lockscreen-widget-${todayKey}.png`;
    document.body.appendChild(a);
    a.click();
    a.remove();

    playSetCompleteTone();
    setLockscreenSaved(true);
    window.setTimeout(() => setLockscreenSaved(false), 3500);
  };

  return (
    <div className="space-y-4 pb-6">
      {/* Reparto Header */}
      <section
        className="rounded-2xl border p-4 flex flex-wrap items-center justify-between gap-3"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-subtle)',
          color: 'var(--text-main)',
        }}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div
            className="w-10 h-10 rounded-2xl border flex items-center justify-center shrink-0"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--accent)',
              color: 'var(--accent)',
            }}
          >
            <HeartPulse className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h1 className="text-base sm:text-lg font-extrabold tracking-tight leading-tight">
              Benessere &amp; Recupero
            </h1>
            <p className="text-xs mt-0.5 leading-snug" style={{ color: 'var(--text-muted)' }}>
              Check-in, idratazione, recupero muscolare e tendini
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => {
            playTechClick();
            onGoToWorkout();
          }}
          className="min-h-[38px] px-3.5 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition shrink-0"
          style={{
            backgroundColor: 'var(--primary)',
            borderColor: 'var(--accent)',
            color: '#FFFFFF',
          }}
        >
          <span>Scheda di Oggi</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </section>

      {/* 4 MINI-WIDGETS PINNABILI + LOCKSCREEN WALLPAPER GENERATOR */}
      <section
        aria-label="Mini-widget riepilogo atleta"
        className="rounded-2xl border p-3.5 space-y-3"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: 'var(--border-subtle)',
          color: 'var(--text-main)',
        }}
      >
        <div className="grid grid-cols-2 gap-2.5">
          {/* Widget 1: Acqua Oggi (+250ml rapido) */}
          <button
            type="button"
            onClick={() => {
              playTechClick();
              onUpdateTodayNutrition((cur) => ({
                ...cur,
                waterMl: cur.waterMl + 250,
              }));
            }}
            className="rounded-xl border p-3 text-left transition active:scale-[0.98] flex flex-col justify-between min-h-[90px]"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: waterPct >= 100 ? 'var(--accent)' : 'var(--border-subtle)',
            }}
          >
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
                Acqua Oggi
              </span>
              <Droplets className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            </div>
            <div className="mt-1.5 space-y-1">
              <p className="font-mono text-base font-extrabold leading-none tabular-nums">
                {todayNutrition.waterMl}{' '}
                <span className="text-[11px] font-semibold" style={{ color: 'var(--text-muted)' }}>
                  / {nutritionTargets.waterTargetMl} ml
                </span>
              </p>
              <p className="text-[11px] font-bold" style={{ color: 'var(--accent)' }}>
                +250ml tap rapido · {waterPct}%
              </p>
            </div>
          </button>

          {/* Widget 2: Recupero Muscolare % */}
          <div
            className="rounded-xl border p-3 flex flex-col justify-between min-h-[90px]"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
                Recupero Musc.
              </span>
              <Activity className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            </div>
            <div className="mt-1.5 space-y-1">
              <p className="font-mono text-lg font-extrabold leading-none tabular-nums">
                {avgRecoveryPct}%
              </p>
              <p
                className="text-[11px] font-semibold truncate"
                style={{ color: avgRecoveryPct >= 80 ? '#34D399' : 'var(--accent)' }}
              >
                {avgRecoveryPct >= 85
                  ? 'Pronto al 100%'
                  : avgRecoveryPct >= 60
                  ? 'Recupero buono'
                  : 'Scarico consigliato'}
              </p>
            </div>
          </div>

          {/* Widget 3: Prossima Skill */}
          <button
            type="button"
            onClick={() => {
              playTechClick();
              onGoToSkills?.();
            }}
            className="rounded-xl border p-3 text-left transition active:scale-[0.98] flex flex-col justify-between min-h-[90px]"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
                Prossima Skill
              </span>
              <Trophy className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            </div>
            <div className="mt-1.5 min-w-0 space-y-1">
              <p className="text-xs font-extrabold leading-tight truncate">
                {nextSkillInfo ? nextSkillInfo.name : 'Tutte Certificate!'}
              </p>
              <p className="font-mono text-[11px] font-bold" style={{ color: 'var(--accent)' }}>
                {nextSkillInfo
                  ? `Stima ~${nextSkillInfo.estimatedDays}g (${nextSkillInfo.readinessPct}%)`
                  : `${unlockedSkills.length}/${SKILL_TREE_NODES.length} Skill`}
              </p>
            </div>
          </button>

          {/* Widget 4: Livello Avatar */}
          <div
            className="rounded-xl border p-3 flex flex-col justify-between min-h-[90px]"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
            }}
          >
            <div className="flex items-center justify-between gap-1.5">
              <span className="text-[11px] font-bold" style={{ color: 'var(--text-muted)' }}>
                Livello Avatar
              </span>
              <Zap className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            </div>
            <div className="mt-1.5 min-w-0 space-y-1">
              <p className="font-mono text-base font-extrabold leading-none tabular-nums">
                Lv. {rpg.level}{' '}
                <span className="text-[11px] font-bold" style={{ color: 'var(--accent)' }}>
                  · {rpg.totalXp} XP
                </span>
              </p>
              <p className="text-[11px] font-semibold truncate" style={{ color: 'var(--text-secondary)' }}>
                {rpg.rankTitle}
              </p>
            </div>
          </div>
        </div>

        <button
          type="button"
          onClick={handleSaveLockscreenWallpaper}
          className="w-full min-h-[42px] px-3.5 rounded-xl border text-xs font-extrabold inline-flex items-center justify-center gap-2 transition active:scale-[0.99]"
          style={{
            backgroundColor: lockscreenSaved ? 'var(--accent)' : 'var(--bg-elevated)',
            borderColor: 'var(--accent)',
            color: lockscreenSaved ? '#05070A' : 'var(--accent)',
          }}
        >
          {lockscreenSaved ? (
            <>
              <Check className="w-4 h-4 stroke-[2.5] shrink-0" />
              <span>Widget Sfondo salvato! Controlla i Download</span>
            </>
          ) : (
            <>
              <Download className="w-4 h-4 shrink-0" />
              <span>Salva Widget per Sfondo / Lockscreen</span>
            </>
          )}
        </button>
      </section>

      {/* 1. CHECK-IN MATTUTINO COMPLETO */}
      <div className="space-y-2.5">
        {!checkinEditorOpen && todayCheckin ? (
          <section
            className="rounded-2xl border p-4 flex flex-wrap items-center justify-between gap-3"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: todayCheckin.jointStatus !== 'ok' ? '#F59E0B' : 'var(--accent)',
              color: 'var(--text-main)',
            }}
          >
            <div className="min-w-0 space-y-1">
              <p className="text-xs font-extrabold" style={{ color: 'var(--accent)' }}>
                Check-in Mattutino Completato Oggi
              </p>
              <p className="text-xs font-semibold truncate" style={{ color: 'var(--text-secondary)' }}>
                {formatMorningCheckinSummary(todayCheckin)}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                playTechClick();
                setCheckinEditorOpen(true);
              }}
              className="min-h-[38px] px-3.5 rounded-xl border text-xs font-extrabold transition shrink-0"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--border-subtle)',
                color: 'var(--text-main)',
              }}
            >
              Modifica Check-in
            </button>
          </section>
        ) : (
          <MorningCheckinCard
            todayCheckin={todayCheckin}
            isOpen={true}
            hasJointRiskExercises={hasJointRiskExercises}
            onSaveCheckin={(vals) => {
              onSaveMorningCheckin(vals);
              if (
                vals.sleepQuality !== 'scarso' &&
                vals.energyLevel !== 'bassa' &&
                vals.jointStatus === 'ok'
              ) {
                setCheckinEditorOpen(false);
              }
            }}
            onAdaptVolumeMinusOne={onAdaptVolumeMinusOne}
            onProtectJointAndPrehab={(joint) => {
              onProtectJointExercises(joint);
              setPrehabOpen(true);
            }}
            onClose={() => setCheckinEditorOpen(false)}
          />
        )}
      </div>

      {/* 2. NUTRIZIONE, PROTEINE & IDRATAZIONE GIORNALIERA */}
      <NutritionHydrationWidget
        profile={profile}
        nutritionLogs={nutritionLogs}
        onUpdateTodayNutrition={onUpdateTodayNutrition}
      />

      {/* 3. STATO RECUPERO MUSCOLARE & TENDINI (Spostato qui da Scheda e Storico) */}
      <MuscleRecoveryCard history={history} />

      {/* 4. DIARIO INTELLIGENTE DEI TENDINI E PREVENZIONE INFORTUNI */}
      <section
        className="rounded-2xl border p-4 space-y-3"
        style={{
          backgroundColor: 'var(--bg-card)',
          borderColor: tendonAlerts.length > 0 ? '#F59E0B' : 'var(--border-subtle)',
          color: 'var(--text-main)',
        }}
      >
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            {tendonAlerts.length > 0 ? (
              <ShieldAlert className="w-4 h-4 text-[#F59E0B] shrink-0" />
            ) : (
              <Activity className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            )}
            <h2 className="text-sm font-extrabold">
              Diario Intelligente dei Tendini (10 Giorni)
            </h2>
          </div>

          <button
            type="button"
            onClick={() => {
              playTechClick();
              setPrehabOpen(true);
            }}
            className="min-h-[36px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--accent)',
              color: 'var(--accent)',
            }}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Avvia Prehab 3 min</span>
          </button>
        </div>

        {tendonAlerts.length > 0 ? (
          <div className="space-y-2.5">
            {tendonAlerts.map((alert) => (
              <div
                key={alert.joint}
                className="rounded-xl border p-3.5 space-y-2.5"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: '#F59E0B',
                }}
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-xs font-extrabold text-[#F59E0B]">
                    Avviso · {alert.jointLabel} ({alert.daysFlagged}gg/10)
                  </span>
                  <span
                    className="text-[11px] font-mono font-bold"
                    style={{ color: 'var(--text-muted)' }}
                  >
                    Scarico 48h consigliato
                  </span>
                </div>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-secondary)' }}>
                  {alert.recommendation}
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      playTechClick();
                      setPrehabOpen(true);
                    }}
                    className="min-h-[38px] px-3.5 rounded-xl font-extrabold text-xs inline-flex items-center gap-1.5 transition"
                    style={{
                      backgroundColor: '#F59E0B',
                      color: '#05070A',
                    }}
                  >
                    <Shield className="w-3.5 h-3.5" />
                    <span>Avvia Prehab Mirata</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      playTechClick();
                      onProtectJointExercises(alert.joint);
                    }}
                    className="min-h-[38px] px-3.5 rounded-xl border font-extrabold text-xs inline-flex items-center gap-1.5 transition"
                    style={{
                      backgroundColor: 'var(--bg-card)',
                      borderColor: 'var(--accent)',
                      color: 'var(--accent)',
                    }}
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>Proteggi Esercizi in Scheda</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-xs leading-relaxed" style={{ color: 'var(--text-muted)' }}>
            Nessun sovraccarico tendineo ripetuto negli ultimi 10 giorni. Se segnali fastidio alla
            stessa articolazione per 2+ giorni nei Check-in Mattutini, attiveremo il protocollo di
            scarico 48h e Prehab.
          </p>
        )}
      </section>

      {/* Recent Morning Check-ins Log */}
      {morningCheckins.length > 0 && (
        <section
          className="rounded-2xl border p-4 space-y-2.5"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        >
          <div className="flex items-center justify-between gap-2">
            <h2 className="text-sm font-extrabold">Ultime Rilevazioni Mattutine</h2>
            <span className="font-mono text-xs font-bold tabular-nums" style={{ color: 'var(--accent)' }}>
              {morningCheckins.length} totali
            </span>
          </div>
          <div className="space-y-1.5">
            {morningCheckins.slice(0, 6).map((c) => (
              <div
                key={c.id}
                className="rounded-xl border px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs"
                style={{
                  backgroundColor: 'var(--bg-elevated)',
                  borderColor: c.jointStatus !== 'ok' ? '#F59E0B' : 'var(--border-subtle)',
                }}
              >
                <span className="font-mono font-bold" style={{ color: 'var(--accent)' }}>
                  {new Date(c.timestampISO).toLocaleDateString('it-IT', {
                    day: '2-digit',
                    month: 'short',
                  })}
                </span>
                <span className="flex-1 min-w-0 truncate" style={{ color: 'var(--text-secondary)' }}>
                  {formatMorningCheckinSummary(c)}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      <PrehabModal
        isOpen={prehabOpen}
        onCompleted={onPrehabCompleted}
        onClose={() => setPrehabOpen(false)}
      />
    </div>
  );
};
