import React, { useCallback, useMemo, useRef, useState } from 'react';
import {
  AlertTriangle,
  ArrowLeftRight,
  Calculator,
  Check,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronUp,
  Clock,
  Droplets,
  Dumbbell,
  Eye,
  EyeOff,
  FileText,
  Flame,
  Info,
  Loader2,
  MessageSquare,
  Mic,
  MicOff,
  Pause,
  Play,
  PlayCircle,
  Plus,
  QrCode,
  RefreshCw,
  RotateCcw,
  Search,
  Shield,
  Sparkles,
  Swords,
  Timer,
  Trash2,
  TrendingDown,
  Users,
  Volume2,
  VolumeX,
  X,
  Zap,
} from 'lucide-react';
import { EXERCISE_CATALOG, getExerciseById } from '../data/exercises';
import { STRETCH_PRESETS, WARMUP_PRESETS } from '../data/skills';
import type {
  ActiveTimerState,
  AthleteProfile,
  ComboFlowPreset,
  ExerciseCategory,
  MorningCheckinRecord,
  MorningJointStatus,
  StretchExerciseItem,
  WarmupExerciseItem,
  WorkoutDayPlan,
  WorkoutExerciseItem,
  WorkoutSessionLog,
} from '../types/calisthenics';
import {
  type ExpressMinutesOption,
  isExerciseStressedByJoint,
  pickOccupiedAlternatives,
} from '../utils/athletePillars';
import { playTechClick, warmUpAudio } from '../utils/audio';
import type { WeeklyMissionItem } from '../utils/recoveryAndMissions';
import { useVoiceCommands } from '../utils/useVoiceCommands';
import { formatDurationHMS, speakItalian } from '../utils/voiceCoach';
import { AddExtraExerciseModal } from './AddExtraExerciseModal';
import { Battle1v1Modal } from './Battle1v1Modal';
import { CircuitTimerModal } from './CircuitTimerModal';
import { ComboBuilderModal } from './ComboBuilderModal';
import { ExerciseAnimationSVG } from './ExerciseAnimationSVG';
import { OneRMCalculatorModal } from './OneRMCalculatorModal';
import { PrehabModal } from './PrehabModal';
import { QuickWidgetsGrid } from './QuickWidgetsGrid';
import { SharePlanModal } from './SharePlanModal';
import { VoiceSetModal } from './VoiceSetModal';
import { WeeklyMissionsCard } from './WeeklyMissionsCard';

interface WorkoutViewProps {
  profile?: AthleteProfile | null;
  weeklyPlan: WorkoutDayPlan[];
  selectedDayIndex: number;
  activeWarmup: WarmupExerciseItem[];
  activeStretch: StretchExerciseItem[];
  activeExercises: WorkoutExerciseItem[];
  history: WorkoutSessionLog[];
  weeklyMissions?: WeeklyMissionItem[];
  defaultWeightKg?: number;
  todayCheckin?: MorningCheckinRecord | null;
  onProtectJointExercises?: (joint: MorningJointStatus) => number;
  expressMinutes?: ExpressMinutesOption | null;
  onApplyExpressTime?: (minutes: ExpressMinutesOption | null) => void;
  savedCombos?: ComboFlowPreset[];
  onSaveCombo?: (combo: ComboFlowPreset) => void;
  onUpdateComboRecord?: (comboId: string, durationSec: number) => void;
  onDeleteCombo?: (comboId: string) => void;
  onImportSharedPlan?: (plan: WorkoutDayPlan[]) => void;
  exerciseNotes?: Record<string, string>;
  onUpdateExerciseNote?: (exerciseKey: string, note: string) => void;
  onAddExtraExercise?: (item: WorkoutExerciseItem) => void;
  totalVoiceGuide?: boolean;
  onToggleTotalVoiceGuide?: () => void;
  sessionStatus: 'idle' | 'running' | 'paused';
  sessionElapsedSeconds: number;
  waterSipsCount: number;
  hasActiveTimerModal: boolean;
  isGeneratingAiPlan?: boolean;
  onGenerateAiPlan?: () => void;
  onPrehabCompleted?: () => void;
  onStartSession: () => void;
  onTogglePauseSession: () => void;
  onAddWaterSip: () => void;
  onVoiceTimerAction: (action: 'start' | 'stop') => void;
  onSelectDay: (dayIndex: number) => void;
  onOpenHistory: () => void;
  onToggleWarmupItem: (warmupId: string) => void;
  onAddWarmupItem: (item: { name: string; targetLabel: string; notes?: string }) => void;
  onRemoveWarmupItem: (warmupId: string) => void;
  onResetWarmupToDefault: () => void;
  onToggleStretchItem: (stretchId: string) => void;
  onAddStretchItem: (item: { name: string; targetLabel: string; notes?: string }) => void;
  onRemoveStretchItem: (stretchId: string) => void;
  onResetStretchToDefault: () => void;
  onUpdateSet: (
    exerciseInstanceId: string,
    setId: string,
    patch: { actualValue?: number; addedWeightKg?: number; rpe?: number | null; completed?: boolean }
  ) => void;
  onSetTechnicalScore: (exerciseInstanceId: string, score: 1 | 2 | 3) => void;
  onAddSet: (exerciseInstanceId: string) => void;
  onSwapExercise: (exerciseInstanceId: string, newExerciseId: string) => void;
  onOpenTimer: (state: ActiveTimerState) => void;
  onFinishWorkout: () => void;
}

const RPE_VALUES = [6, 7, 8, 8.5, 9, 9.5, 10];

const MUSCLE_GROUP_ORDER: ExerciseCategory[] = ['Spinta', 'Tirata', 'Core', 'Gambe', 'Skill'];

const MUSCLE_GROUP_LABELS: Record<ExerciseCategory, { title: string; subtitle: string }> = {
  Spinta: {
    title: 'Petto (Spinta)',
    subtitle: 'Push-up, Dip, Spinte e forza di petto/tricipiti/spalle',
  },
  Tirata: {
    title: 'Schiena (Tirata)',
    subtitle: 'Trazioni, Row, Muscle-up e catena posteriore alta',
  },
  Core: {
    title: 'Addome (Core)',
    subtitle: 'L-Sit, Hollow, Leg Raises e controllo pelvico',
  },
  Gambe: {
    title: 'Gambe',
    subtitle: 'Pistol Squat, Shrimp Squat e spinta inferiore',
  },
  Skill: {
    title: 'Skill & Equilibrio',
    subtitle: 'Planche, Front Lever, Verticale e tenute isometriche',
  },
};

const CATALOG_FILTERS: { id: 'Tutte' | ExerciseCategory; label: string }[] = [
  { id: 'Tutte', label: 'Tutte' },
  { id: 'Spinta', label: 'Petto (Spinta)' },
  { id: 'Tirata', label: 'Schiena (Tirata)' },
  { id: 'Core', label: 'Addome (Core)' },
  { id: 'Gambe', label: 'Gambe' },
  { id: 'Skill', label: 'Skill' },
];

export const WorkoutView: React.FC<WorkoutViewProps> = ({
  profile = null,
  weeklyPlan,
  selectedDayIndex,
  activeWarmup,
  activeStretch,
  activeExercises,
  history,
  weeklyMissions,
  defaultWeightKg,
  todayCheckin = null,
  onProtectJointExercises,
  expressMinutes = null,
  onApplyExpressTime,
  savedCombos = [],
  onSaveCombo,
  onUpdateComboRecord,
  onDeleteCombo,
  onImportSharedPlan,
  exerciseNotes = {},
  onUpdateExerciseNote,
  onAddExtraExercise,
  totalVoiceGuide = false,
  onToggleTotalVoiceGuide,
  sessionStatus,
  sessionElapsedSeconds,
  waterSipsCount,
  hasActiveTimerModal,
  isGeneratingAiPlan = false,
  onGenerateAiPlan,
  onPrehabCompleted,
  onStartSession,
  onTogglePauseSession,
  onAddWaterSip,
  onVoiceTimerAction,
  onSelectDay,
  onOpenHistory,
  onToggleWarmupItem,
  onAddWarmupItem,
  onRemoveWarmupItem,
  onResetWarmupToDefault,
  onToggleStretchItem,
  onAddStretchItem,
  onRemoveStretchItem,
  onResetStretchToDefault,
  onUpdateSet,
  onSetTechnicalScore,
  onAddSet,
  onSwapExercise,
  onOpenTimer,
  onFinishWorkout,
}) => {
  const [expandedCuesId, setExpandedCuesId] = useState<string | null>(null);
  const [expandedVisualId, setExpandedVisualId] = useState<string | null>(null);
  const [expandedNotesId, setExpandedNotesId] = useState<string | null>(null);
  const [quickSwapInstanceId, setQuickSwapInstanceId] = useState<string | null>(null);
  const [extraModalCategory, setExtraModalCategory] = useState<ExerciseCategory | null>(null);
  const [swapTargetInstanceId, setSwapTargetInstanceId] = useState<string | null>(null);
  const [catalogCategory, setCatalogCategory] = useState<'Tutte' | ExerciseCategory>('Tutte');
  const [catalogQuery, setCatalogQuery] = useState('');
  const [prehabOpen, setPrehabOpen] = useState(false);
  const [circuitModalOpen, setCircuitModalOpen] = useState(false);
  const [oneRmModalOpen, setOneRmModalOpen] = useState(false);
  const [battleModalOpen, setBattleModalOpen] = useState(false);
  const [comboModalOpen, setComboModalOpen] = useState(false);
  const [shareModalOpen, setShareModalOpen] = useState(false);
  const [focusMinimalMode, setFocusMinimalMode] = useState(false);
  const [focusExerciseIndex, setFocusExerciseIndex] = useState(0);
  const [partnerMode, setPartnerMode] = useState(false);
  const [activePartner, setActivePartner] = useState<1 | 2>(1);

  // Collapsible sections state
  const [warmupOpen, setWarmupOpen] = useState(false);
  const [warmupAddOpen, setWarmupAddOpen] = useState(false);
  const [customWarmupName, setCustomWarmupName] = useState('');
  const [customWarmupTarget, setCustomWarmupTarget] = useState('2 × 30s');

  const [stretchOpen, setStretchOpen] = useState(true);
  const [stretchAddOpen, setStretchAddOpen] = useState(false);
  const [customStretchName, setCustomStretchName] = useState('');
  const [customStretchTarget, setCustomStretchTarget] = useState('2 × 30s');

  const [collapsedGroups, setCollapsedGroups] = useState<Record<string, boolean>>({});

  // Voice timer preference per exercise (default true so speaker triggers spoken countdown)
  const [voiceDisabledMap, setVoiceDisabledMap] = useState<Record<string, boolean>>({});

  // Selected target set for hands-free voice rep counting
  const [manualVoiceTarget, setManualVoiceTarget] = useState<{
    instanceId: string;
    setId: string;
  } | null>(null);

  // Dedicated "Inizia Serie Vocale" modal state (strictly single set)
  const [voiceSetTarget, setVoiceSetTarget] = useState<{
    instanceId: string;
    setId: string;
    exerciseName: string;
    setNumber: number;
    totalSets: number;
    targetReps: number;
    setRpe: number | null;
    restSeconds: number;
    isVoiceOn: boolean;
  } | null>(null);

  const effectiveVoiceTarget = useMemo(() => {
    if (manualVoiceTarget) {
      const ex = activeExercises.find((e) => e.instanceId === manualVoiceTarget.instanceId);
      const set = ex?.sets.find((s) => s.id === manualVoiceTarget.setId);
      if (ex && set && !set.completed) {
        return { exercise: ex, set, setNumber: ex.sets.indexOf(set) + 1 };
      }
    }
    for (const ex of activeExercises) {
      const idx = ex.sets.findIndex((s) => !s.completed);
      if (idx >= 0) {
        return { exercise: ex, set: ex.sets[idx], setNumber: idx + 1 };
      }
    }
    const firstEx = activeExercises[0];
    if (firstEx && firstEx.sets[0]) {
      return { exercise: firstEx, set: firstEx.sets[0], setNumber: 1 };
    }
    return null;
  }, [activeExercises, manualVoiceTarget]);

  // Refs for voice command handler to avoid stale closures
  const effectiveTargetRef = useRef(effectiveVoiceTarget);
  effectiveTargetRef.current = effectiveVoiceTarget;
  const hasActiveTimerRef = useRef(hasActiveTimerModal);
  hasActiveTimerRef.current = hasActiveTimerModal;
  const sessionStatusRef = useRef(sessionStatus);
  sessionStatusRef.current = sessionStatus;
  const voiceDisabledRef = useRef(voiceDisabledMap);
  voiceDisabledRef.current = voiceDisabledMap;

  const handleVoiceCommand = useCallback(
    (cmd: { type: 'start' } | { type: 'stop' } | { type: 'finish_set' } | { type: 'rep'; value: number }) => {
      if (cmd.type === 'start') {
        if (hasActiveTimerRef.current) {
          onVoiceTimerAction('start');
          return;
        }
        const targetInfo = effectiveTargetRef.current;
        if (targetInfo) {
          const { exercise, set } = targetInfo;
          const def = getExerciseById(exercise.exerciseId);
          const displayName = exercise.customName ?? def?.name ?? exercise.exerciseId;
          const isNeg = Boolean(
            exercise.isNegative ||
              def?.isNegative ||
              displayName.toLowerCase().includes('negativ')
          );
          const isVoiceOn = !voiceDisabledRef.current[exercise.instanceId];

          if (exercise.isIsometric) {
            onOpenTimer({
              mode: 'isometric',
              exerciseName: displayName,
              exerciseInstanceId: exercise.instanceId,
              setId: set.id,
              targetSeconds: set.targetValue || 15,
              voiceEnabled: isVoiceOn,
              autoStart: true,
            });
            return;
          }
          if (isNeg) {
            onOpenTimer({
              mode: 'negative',
              exerciseName: displayName,
              exerciseInstanceId: exercise.instanceId,
              setId: set.id,
              targetSeconds: set.targetValue,
              negativeSeconds: exercise.negativeSeconds ?? def?.negativeSeconds ?? 6,
              targetReps: set.targetValue || 5,
              voiceEnabled: isVoiceOn,
              autoStart: true,
            });
            return;
          }
        }
        if (sessionStatusRef.current !== 'running') {
          if (sessionStatusRef.current === 'idle') {
            onStartSession();
          } else {
            onTogglePauseSession();
          }
        } else if (targetInfo) {
          onOpenTimer({
            mode: 'rest',
            exerciseName:
              targetInfo.exercise.customName ??
              getExerciseById(targetInfo.exercise.exerciseId)?.name ??
              'Recupero',
            targetSeconds: targetInfo.exercise.restSeconds,
            autoStart: true,
          });
        }
        return;
      }

      if (cmd.type === 'stop') {
        if (hasActiveTimerRef.current) {
          onVoiceTimerAction('stop');
          return;
        }
        if (sessionStatusRef.current === 'running') {
          onTogglePauseSession();
        }
        return;
      }

      const targetInfo = effectiveTargetRef.current;
      if (!targetInfo) return;

      const { exercise, set } = targetInfo;

      if (cmd.type === 'finish_set') {
        onUpdateSet(exercise.instanceId, set.id, {
          completed: true,
          rpe: set.rpe ?? 8,
        });
        speakItalian('Serie completata', { rate: 1.05 });
        return;
      }

      if (cmd.type === 'rep') {
        const nextVal = cmd.value;
        const reachedTarget = nextVal >= set.targetValue;
        onUpdateSet(exercise.instanceId, set.id, {
          actualValue: nextVal,
          ...(reachedTarget ? { completed: true, rpe: set.rpe ?? 8 } : {}),
        });
        if (reachedTarget && !set.completed) {
          speakItalian('Target raggiunto, serie completata!', { rate: 1.05 });
        }
      }
    },
    [
      onVoiceTimerAction,
      onOpenTimer,
      onStartSession,
      onTogglePauseSession,
      onUpdateSet,
    ]
  );

  const {
    voiceCommandsEnabled,
    speechSupported,
    lastTranscript,
    voiceError,
    toggleVoiceCommands,
  } = useVoiceCommands(handleVoiceCommand);

  const currentDay = weeklyPlan[selectedDayIndex] ?? weeklyPlan[0];

  const groupedExercises = useMemo(() => {
    const map = new Map<
      ExerciseCategory,
      { item: WorkoutExerciseItem; globalIndex: number }[]
    >();
    for (const cat of MUSCLE_GROUP_ORDER) {
      map.set(cat, []);
    }
    activeExercises.forEach((item, idx) => {
      const def = getExerciseById(item.exerciseId);
      const cat = item.customCategory ?? def?.category ?? 'Skill';
      const bucket = map.get(cat) ?? [];
      bucket.push({ item, globalIndex: idx });
      map.set(cat, bucket);
    });
    return MUSCLE_GROUP_ORDER.map((cat) => ({
      category: cat,
      meta: MUSCLE_GROUP_LABELS[cat],
      entries: map.get(cat) ?? [],
    })).filter((g) => g.entries.length > 0);
  }, [activeExercises]);

  const filteredCatalog = useMemo(() => {
    return EXERCISE_CATALOG.filter((ex) => {
      const matchCat = catalogCategory === 'Tutte' || ex.category === catalogCategory;
      const matchQuery =
        !catalogQuery.trim() ||
        ex.name.toLowerCase().includes(catalogQuery.toLowerCase()) ||
        ex.variantHint.toLowerCase().includes(catalogQuery.toLowerCase());
      return matchCat && matchQuery;
    });
  }, [catalogCategory, catalogQuery]);

  const groupedCatalog = useMemo(() => {
    const order =
      catalogCategory === 'Tutte' ? MUSCLE_GROUP_ORDER : [catalogCategory];
    return order
      .map((cat) => ({
        category: cat,
        label: MUSCLE_GROUP_LABELS[cat].title,
        items: filteredCatalog.filter((ex) => ex.category === cat),
      }))
      .filter((g) => g.items.length > 0);
  }, [catalogCategory, filteredCatalog]);

  if (!currentDay) {
    return (
      <div className="p-6 text-center text-sm text-[#94A3B8]">
        Nessuna scheda disponibile. Configura il tuo profilo per generare gli allenamenti.
      </div>
    );
  }

  const totalSets = activeExercises.reduce((acc, ex) => acc + ex.sets.length, 0);
  const completedSets = activeExercises.reduce(
    (acc, ex) => acc + ex.sets.filter((s) => s.completed).length,
    0
  );
  const progressPct = totalSets > 0 ? Math.round((completedSets / totalSets) * 100) : 0;

  const warmupCompletedCount = activeWarmup.filter((w) => w.completed).length;
  const stretchCompletedCount = activeStretch.filter((s) => s.completed).length;

  const handleCreateWarmupItem = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = customWarmupName.trim();
    if (!cleanName) return;
    onAddWarmupItem({
      name: cleanName,
      targetLabel: customWarmupTarget.trim() || '2 × 30s',
      notes: 'Esercizio di riscaldamento personalizzato',
    });
    setCustomWarmupName('');
    setCustomWarmupTarget('2 × 30s');
    setWarmupAddOpen(false);
  };

  const handleCreateStretchItem = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = customStretchName.trim();
    if (!cleanName) return;
    onAddStretchItem({
      name: cleanName,
      targetLabel: customStretchTarget.trim() || '2 × 30s',
      notes: 'Esercizio di stretching personalizzato',
    });
    setCustomStretchName('');
    setCustomStretchTarget('2 × 30s');
    setStretchAddOpen(false);
  };

  const toggleGroupCollapsed = (cat: ExerciseCategory) => {
    setCollapsedGroups((prev) => ({
      ...prev,
      [cat]: !prev[cat],
    }));
  };

  const toggleExerciseVoice = (instanceId: string) => {
    setVoiceDisabledMap((prev) => ({
      ...prev,
      [instanceId]: !prev[instanceId],
    }));
  };

  const announceHandsFreeTransition = useCallback(
    (completedItem: WorkoutExerciseItem, completesWholeExercise: boolean) => {
      if (!totalVoiceGuide) return;
      if (!completesWholeExercise) {
        speakItalian(
          `Serie completata! Recupero di ${completedItem.restSeconds} secondi avviato.`,
          { rate: 1.04 }
        );
        return;
      }

      const nextEx = activeExercises.find(
        (ex) =>
          ex.instanceId !== completedItem.instanceId &&
          ex.sets.some((s) => !s.completed)
      );
      if (nextEx) {
        const nextDef = getExerciseById(nextEx.exerciseId);
        const nextName = nextEx.customName ?? nextDef?.name ?? nextEx.exerciseId;
        const nextSets = nextEx.sets.length;
        const nextTarget = nextEx.sets[0]?.targetValue ?? 8;
        const nextUnit = nextEx.isIsometric ? 'secondi' : 'ripetizioni';
        speakItalian(
          `Esercizio terminato, bevi un sorso d'acqua. Prossimo esercizio: ${nextName}, ${nextSets} serie da ${nextTarget} ${nextUnit}.`,
          { rate: 1.0 }
        );
      } else {
        speakItalian(
          `Esercizio terminato, bevi un sorso d'acqua. Hai completato tutti gli esercizi di oggi!`,
          { rate: 1.0 }
        );
      }
    },
    [totalVoiceGuide, activeExercises]
  );

  const activeJointStatus: MorningJointStatus = todayCheckin?.jointStatus ?? 'ok';

  // Clamp focus exercise index cleanly
  const safeFocusIndex =
    activeExercises.length > 0
      ? Math.max(0, Math.min(activeExercises.length - 1, focusExerciseIndex))
      : 0;
  const focusedExercise = activeExercises[safeFocusIndex] ?? null;

  if (focusMinimalMode && focusedExercise) {
    const fDef = getExerciseById(focusedExercise.exerciseId);
    const fName = focusedExercise.customName ?? fDef?.name ?? focusedExercise.exerciseId;
    const fNextPendingIdx = focusedExercise.sets.findIndex((s) => !s.completed);
    const fSetIdx = fNextPendingIdx >= 0 ? fNextPendingIdx : Math.max(0, focusedExercise.sets.length - 1);
    const fSet = focusedExercise.sets[fSetIdx];
    const fIsVoiceOn = !voiceDisabledMap[focusedExercise.instanceId];

    return (
      <div className="space-y-4 pb-8 max-w-2xl mx-auto">
        {/* Minimal Top Header */}
        <div
          className="rounded-2xl border px-3.5 py-2.5 flex items-center justify-between gap-2"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--accent)',
          }}
        >
          <div className="flex items-center gap-2 min-w-0">
            <Eye className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            <div className="min-w-0">
              <p className="text-[11px] font-extrabold uppercase tracking-wider truncate" style={{ color: 'var(--accent)' }}>
                Focus Minimalista · Esercizio {safeFocusIndex + 1}/{activeExercises.length}
              </p>
              <p className="font-mono text-xs font-bold tabular-nums" style={{ color: 'var(--text-muted)' }}>
                {completedSets}/{totalSets} serie totali · {formatDurationHMS(sessionElapsedSeconds)}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              playTechClick();
              setFocusMinimalMode(false);
            }}
            className="min-h-[36px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 shrink-0"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          >
            <EyeOff className="w-3.5 h-3.5" />
            <span>Esci Focus</span>
          </button>
        </div>

        {/* Giant Distraction-Free Exercise Card */}
        <section
          className="rounded-3xl border-2 p-5 sm:p-7 space-y-5 shadow-2xl"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--primary)',
          }}
        >
          <div className="flex items-center justify-between gap-2">
            <button
              type="button"
              disabled={safeFocusIndex === 0}
              onClick={() => {
                playTechClick();
                setFocusExerciseIndex((i) => Math.max(0, i - 1));
              }}
              aria-label="Esercizio precedente"
              className="min-h-[44px] min-w-[44px] rounded-xl border flex items-center justify-center disabled:opacity-35"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--border-subtle)',
                color: 'var(--text-main)',
              }}
            >
              <ChevronLeft className="w-5 h-5" />
            </button>

            <div className="text-center min-w-0 px-2">
              <p className="text-xs font-bold uppercase tracking-wider" style={{ color: 'var(--accent)' }}>
                {focusedExercise.isIsometric ? 'Tenuta Isometrica' : 'Esercizio Dinamico'} · Rec {focusedExercise.restSeconds}s
              </p>
              <h2 className="text-2xl sm:text-3xl font-black leading-tight mt-0.5 truncate" style={{ color: 'var(--text-main)' }}>
                {fName}
              </h2>
            </div>

            <button
              type="button"
              disabled={safeFocusIndex >= activeExercises.length - 1}
              onClick={() => {
                playTechClick();
                setFocusExerciseIndex((i) => Math.min(activeExercises.length - 1, i + 1));
              }}
              aria-label="Prossimo esercizio"
              className="min-h-[44px] min-w-[44px] rounded-xl border flex items-center justify-center disabled:opacity-35"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--border-subtle)',
                color: 'var(--text-main)',
              }}
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {fSet && (
            <div
              className="rounded-2xl border p-5 text-center space-y-4"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: fSet.completed ? 'var(--accent)' : 'var(--border-subtle)',
              }}
            >
              <div className="flex items-center justify-between text-xs font-extrabold">
                <span style={{ color: 'var(--accent)' }}>
                  SERIE {fSetIdx + 1} DI {focusedExercise.sets.length}
                </span>
                <span className="font-mono" style={{ color: 'var(--text-muted)' }}>
                  Target: {fSet.targetValue}
                  {focusedExercise.isIsometric ? 's' : ' rep'}
                </span>
              </div>

              <div className="flex items-center justify-center gap-4">
                <button
                  type="button"
                  onClick={() =>
                    onUpdateSet(focusedExercise.instanceId, fSet.id, {
                      actualValue: Math.max(0, fSet.actualValue - 1),
                    })
                  }
                  aria-label="Riduci valore serie"
                  className="min-h-[58px] min-w-[64px] rounded-2xl border text-2xl font-black transition active:scale-95"
                  style={{
                    backgroundColor: 'var(--bg-card)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-main)',
                  }}
                >
                  -
                </button>

                <span className="font-mono text-6xl font-black tabular-nums min-w-[110px]" style={{ color: 'var(--text-main)' }}>
                  {fSet.actualValue}
                  {focusedExercise.isIsometric ? 's' : ''}
                </span>

                <button
                  type="button"
                  onClick={() =>
                    onUpdateSet(focusedExercise.instanceId, fSet.id, {
                      actualValue: fSet.actualValue + 1,
                    })
                  }
                  aria-label="Aumenta valore serie"
                  className="min-h-[58px] min-w-[64px] rounded-2xl border text-2xl font-black transition active:scale-95"
                  style={{
                    backgroundColor: 'var(--bg-card)',
                    borderColor: 'var(--border-subtle)',
                    color: 'var(--text-main)',
                  }}
                >
                  +
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {focusedExercise.isIsometric ? (
                  <button
                    type="button"
                    onClick={() =>
                      onOpenTimer({
                        mode: 'isometric',
                        exerciseName: fName,
                        exerciseInstanceId: focusedExercise.instanceId,
                        setId: fSet.id,
                        targetSeconds: fSet.targetValue || 15,
                        voiceEnabled: fIsVoiceOn,
                        handsFreeVoice: totalVoiceGuide,
                        autoStart: true,
                      })
                    }
                    className="min-h-[52px] rounded-2xl font-black text-sm inline-flex items-center justify-center gap-2"
                    style={{
                      backgroundColor: 'var(--accent)',
                      color: '#05070A',
                    }}
                  >
                    <Timer className="w-5 h-5" />
                    <span>Avvia Tenuta</span>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      warmUpAudio();
                      setVoiceSetTarget({
                        instanceId: focusedExercise.instanceId,
                        setId: fSet.id,
                        exerciseName: fName,
                        setNumber: fSetIdx + 1,
                        totalSets: focusedExercise.sets.length,
                        targetReps: fSet.targetValue,
                        setRpe: fSet.rpe,
                        restSeconds: focusedExercise.restSeconds,
                        isVoiceOn: fIsVoiceOn,
                      });
                    }}
                    className="min-h-[52px] rounded-2xl font-black text-sm inline-flex items-center justify-center gap-2"
                    style={{
                      backgroundColor: 'var(--accent)',
                      color: '#05070A',
                    }}
                  >
                    <Mic className="w-5 h-5" />
                    <span>Inizia Serie Vocale</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    const nextCompleted = !fSet.completed;
                    const otherDone = focusedExercise.sets
                      .filter((s) => s.id !== fSet.id)
                      .every((s) => s.completed);
                    onUpdateSet(focusedExercise.instanceId, fSet.id, {
                      completed: nextCompleted,
                      rpe: fSet.rpe ?? 8,
                    });
                    if (nextCompleted && !otherDone) {
                      onOpenTimer({
                        mode: 'rest',
                        exerciseName: fName,
                        targetSeconds: focusedExercise.restSeconds,
                        voiceEnabled: fIsVoiceOn,
                        handsFreeVoice: totalVoiceGuide,
                      });
                    }
                  }}
                  className="min-h-[52px] rounded-2xl font-black text-sm inline-flex items-center justify-center gap-2"
                  style={{
                    backgroundColor: fSet.completed ? 'var(--accent)' : 'var(--primary)',
                    color: fSet.completed ? '#05070A' : '#FFFFFF',
                  }}
                >
                  <Check className="w-5 h-5 stroke-[3]" />
                  <span>{fSet.completed ? 'Serie Completata ✓' : 'Completa Serie'}</span>
                </button>
              </div>
            </div>
          )}

          {/* Quick Timer + Technical Score 1 · 2 · 3 */}
          <div className="space-y-3">
            <button
              type="button"
              onClick={() =>
                onOpenTimer({
                  mode: 'rest',
                  exerciseName: fName,
                  targetSeconds: focusedExercise.restSeconds,
                  voiceEnabled: fIsVoiceOn,
                  handsFreeVoice: totalVoiceGuide,
                })
              }
              className="w-full min-h-[46px] rounded-2xl border font-extrabold text-xs sm:text-sm inline-flex items-center justify-center gap-2"
              style={{
                backgroundColor: 'var(--bg-elevated)',
                borderColor: 'var(--accent)',
                color: 'var(--accent)',
              }}
            >
              <Clock className="w-4 h-4" />
              <span>Apri Timer Recupero ({focusedExercise.restSeconds}s)</span>
            </button>

            <div className="grid grid-cols-3 gap-2">
              {([1, 2, 3] as const).map((score) => {
                const active = focusedExercise.technicalScore === score;
                return (
                  <button
                    key={score}
                    type="button"
                    onClick={() => onSetTechnicalScore(focusedExercise.instanceId, score)}
                    className="min-h-[44px] rounded-xl border text-xs font-black transition"
                    style={{
                      backgroundColor: active ? 'var(--accent)' : 'var(--bg-elevated)',
                      borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                      color: active ? '#05070A' : 'var(--text-main)',
                    }}
                  >
                    {score === 1 ? '1 · Sporca' : score === 2 ? '2 · Al limite' : '3 · Pulita'}
                  </button>
                );
              })}
            </div>
          </div>
        </section>

        <button
          type="button"
          onClick={onFinishWorkout}
          className="w-full min-h-[50px] rounded-2xl font-extrabold text-sm flex items-center justify-center gap-2"
          style={{
            backgroundColor: 'var(--primary)',
            color: '#FFFFFF',
          }}
        >
          <MessageSquare className="w-4 h-4" />
          <span>Concludi allenamento e parla con il Coach</span>
        </button>

        {/* Keep VoiceSetModal working even inside Focus Minimal Mode */}
        <VoiceSetModal
          key={voiceSetTarget?.setId ?? 'none'}
          isOpen={Boolean(voiceSetTarget)}
          exerciseName={voiceSetTarget?.exerciseName ?? ''}
          setNumber={voiceSetTarget?.setNumber ?? 1}
          totalSets={voiceSetTarget?.totalSets ?? 1}
          targetReps={voiceSetTarget?.targetReps ?? 8}
          onComplete={(finalReps) => {
            if (!voiceSetTarget) return;
            const target = voiceSetTarget;
            setVoiceSetTarget(null);
            const latestItem = activeExercises.find((e) => e.instanceId === target.instanceId);
            const allOthersDone = latestItem
              ? latestItem.sets.filter((s) => s.id !== target.setId).every((s) => s.completed)
              : false;
            onUpdateSet(target.instanceId, target.setId, {
              actualValue: finalReps,
              completed: true,
              rpe: target.setRpe ?? 8,
            });
            if (!allOthersDone) {
              onOpenTimer({
                mode: 'rest',
                exerciseName: target.exerciseName,
                targetSeconds: target.restSeconds,
                voiceEnabled: target.isVoiceOn,
                handsFreeVoice: totalVoiceGuide,
              });
            }
          }}
          onCancel={() => setVoiceSetTarget(null)}
        />
      </div>
    );
  }

  return (
    <div className="space-y-3.5 pb-6">
      {/* 9. GENERATORE ESPRESSO (15 / 30 / 45 / 60 MIN) */}
      {onApplyExpressTime && (
        <section
          className="rounded-2xl border p-3 flex flex-wrap items-center justify-between gap-2"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: expressMinutes ? 'var(--accent)' : 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        >
          <div className="flex items-center gap-2 min-w-0">
            <Zap className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            <div className="min-w-0">
              <p className="text-xs font-extrabold truncate">
                Quanto tempo hai oggi?{' '}
                {expressMinutes ? (
                  <span style={{ color: 'var(--accent)' }}>Modalità {expressMinutes} min attiva</span>
                ) : (
                  <span style={{ color: 'var(--text-muted)' }}>Generatore Espresso</span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 flex-wrap">
            {([15, 30, 45, 60] as const).map((mins) => {
              const active = expressMinutes === mins;
              return (
                <button
                  key={mins}
                  type="button"
                  onClick={() => {
                    playTechClick();
                    onApplyExpressTime(active ? null : mins);
                  }}
                  className="min-h-[32px] px-2.5 rounded-xl border font-mono text-xs font-extrabold transition"
                  style={{
                    backgroundColor: active ? 'var(--accent)' : 'var(--bg-elevated)',
                    borderColor: active ? 'var(--accent)' : 'var(--border-subtle)',
                    color: active ? '#05070A' : 'var(--text-main)',
                  }}
                >
                  {mins}m
                </button>
              );
            })}
            {expressMinutes && (
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  onApplyExpressTime(null);
                }}
                className="min-h-[32px] px-2.5 rounded-xl border text-[11px] font-bold transition"
                style={{
                  backgroundColor: 'var(--bg-main)',
                  borderColor: 'var(--border-subtle)',
                  color: 'var(--text-muted)',
                }}
              >
                Standard
              </button>
            )}
          </div>
        </section>
      )}

      {/* 4 iOS-style Interactive Mini-Widgets */}
      <QuickWidgetsGrid
        currentDay={currentDay}
        activeExercises={activeExercises}
        history={history}
        waterSipsCount={waterSipsCount}
        onAddWaterSip={onAddWaterSip}
        onOpenHistory={onOpenHistory}
        onNextDay={() => {
          if (weeklyPlan.length > 1) {
            onSelectDay((selectedDayIndex + 1) % weeklyPlan.length);
          }
        }}
      />

      {/* Weekly Automatic Missions (+150 XP) */}
      {weeklyMissions && weeklyMissions.length > 0 && (
        <WeeklyMissionsCard missions={weeklyMissions} />
      )}

      {/* Compact PRO Tools, Battle 1vs1, Combo Flow, QR Share & Focus Minimal */}
      <div className="flex flex-wrap items-center gap-1.5">
        <button
          type="button"
          onClick={() => {
            playTechClick();
            setFocusMinimalMode(true);
          }}
          className="min-h-[38px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--accent)',
            color: 'var(--accent)',
          }}
        >
          <Eye className="w-3.5 h-3.5 shrink-0" />
          <span>Focus Minimal</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playTechClick();
            setBattleModalOpen(true);
          }}
          className="min-h-[38px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition"
          style={{
            backgroundColor: 'var(--primary)',
            borderColor: 'var(--accent)',
            color: '#FFFFFF',
          }}
        >
          <Swords className="w-3.5 h-3.5 shrink-0" />
          <span>Battle 1vs1</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playTechClick();
            setComboModalOpen(true);
          }}
          className="min-h-[38px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        >
          <Flame className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--accent)' }} />
          <span>Crea Combo Flow</span>
        </button>

        {onImportSharedPlan && (
          <button
            type="button"
            onClick={() => {
              playTechClick();
              setShareModalOpen(true);
            }}
            className="min-h-[38px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition"
            style={{
              backgroundColor: 'var(--bg-card)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--text-main)',
            }}
          >
            <QrCode className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--accent)' }} />
            <span>Condividi / Importa</span>
          </button>
        )}

        <button
          type="button"
          onClick={() => {
            playTechClick();
            setCircuitModalOpen(true);
          }}
          className="min-h-[38px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--accent)',
            color: 'var(--accent)',
          }}
        >
          <Timer className="w-3.5 h-3.5 shrink-0" />
          <span>Circuiti &amp; Metronomo</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playTechClick();
            setOneRmModalOpen(true);
          }}
          className="min-h-[38px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition"
          style={{
            backgroundColor: 'var(--bg-card)',
            borderColor: 'var(--border-subtle)',
            color: 'var(--text-main)',
          }}
        >
          <Calculator className="w-3.5 h-3.5 shrink-0" style={{ color: 'var(--accent)' }} />
          <span>1RM Zavorre</span>
        </button>

        <button
          type="button"
          onClick={() => {
            playTechClick();
            setPartnerMode((p) => !p);
          }}
          aria-pressed={partnerMode}
          className="min-h-[38px] px-3 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1.5 transition ml-auto"
          style={{
            backgroundColor: partnerMode ? 'var(--primary)' : 'var(--bg-card)',
            borderColor: partnerMode ? 'var(--accent)' : 'var(--border-subtle)',
            color: partnerMode ? '#FFFFFF' : 'var(--text-secondary)',
          }}
        >
          <Users className="w-3.5 h-3.5 shrink-0" />
          <span>{partnerMode ? 'Coppia ON' : 'Modalità Coppia'}</span>
        </button>
      </div>

      {/* Partner Mode Turn Switcher Bar (2 Athletes, 1 Phone) */}
      {partnerMode && (
        <div
          className="rounded-2xl border p-2.5 flex items-center justify-between gap-2"
          style={{
            backgroundColor: 'var(--bg-elevated)',
            borderColor: 'var(--accent)',
            color: 'var(--text-main)',
          }}
        >
          <div className="flex items-center gap-2 min-w-0">
            <Users className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
            <div className="min-w-0">
              <p className="text-[11px] font-extrabold uppercase tracking-wider truncate" style={{ color: 'var(--accent)' }}>
                Allenamento in Coppia · Turno Atleta {activePartner}
              </p>
              <p className="text-[10px] truncate" style={{ color: 'var(--text-muted)' }}>
                Timer e conteggio vocale si alternano ad ogni serie completata
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1 shrink-0">
            {([1, 2] as const).map((num) => {
              const isCur = activePartner === num;
              return (
                <button
                  key={num}
                  type="button"
                  onClick={() => {
                    playTechClick();
                    setActivePartner(num);
                  }}
                  className="min-h-[34px] px-2.5 rounded-xl border text-xs font-extrabold transition"
                  style={{
                    backgroundColor: isCur ? 'var(--accent)' : 'var(--bg-main)',
                    borderColor: isCur ? 'var(--accent)' : 'var(--border-subtle)',
                    color: isCur ? '#05070A' : 'var(--text-muted)',
                  }}
                >
                  Atleta {num}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Compact Session Stopwatch Bar / Start Hero */}
      {sessionStatus === 'idle' ? (
        <section className="rounded-2xl bg-[#0B1D36] border border-[#2563EB]/70 p-3.5 space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <div>
              <p className="text-[11px] font-bold text-[#38BDF8]">
                Cronometro Sessione
              </p>
              <p className="font-mono text-2xl sm:text-3xl font-extrabold text-[#FFFFFF] tabular-nums tracking-tight leading-none mt-0.5">
                {formatDurationHMS(sessionElapsedSeconds)}
              </p>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  setPrehabOpen(true);
                }}
                title="Routine guidata 3 minuti: Prehab Polsi e Gomiti"
                className="min-h-[40px] px-2.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#00D2FF] hover:border-[#00D2FF]/60 inline-flex items-center gap-1.5 transition whitespace-nowrap"
              >
                <Shield className="w-4 h-4 shrink-0" />
                <span>Prehab</span>
              </button>

              <button
                type="button"
                onClick={toggleVoiceCommands}
                className={`min-h-[40px] px-3 rounded-xl border text-xs font-bold inline-flex items-center gap-1.5 transition whitespace-nowrap ${
                  voiceCommandsEnabled
                    ? 'bg-[#38BDF8] border-[#00D2FF] text-[#05070A]'
                    : 'bg-[#131C31] border-[#1E293B] text-[#CBD5E1] hover:text-[#FFFFFF]'
                }`}
              >
                {voiceCommandsEnabled ? (
                  <Mic className="w-4 h-4" />
                ) : (
                  <MicOff className="w-4 h-4 text-[#38BDF8]" />
                )}
                <span>{voiceCommandsEnabled ? 'Vocali ON' : 'Vocali OFF'}</span>
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2">
            <button
              type="button"
              onClick={onStartSession}
              className="flex-1 min-h-[48px] rounded-xl bg-[#2563EB] text-[#FFFFFF] text-sm font-extrabold flex items-center justify-center gap-2 hover:bg-[#3B82F6] active:scale-[0.99] transition shadow-lg shadow-[#05070A]/60"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>Inizia Allenamento</span>
            </button>

            {onToggleTotalVoiceGuide && (
              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  const willBeOn = !totalVoiceGuide;
                  onToggleTotalVoiceGuide();
                  if (willBeOn) {
                    speakItalian('Guida vocale totale attiva. Mani libere pronte!', {
                      rate: 1.05,
                    });
                  }
                }}
                aria-pressed={totalVoiceGuide}
                className="min-h-[46px] px-3.5 rounded-xl border text-xs font-extrabold flex items-center justify-center gap-1.5 transition shrink-0"
                style={{
                  backgroundColor: totalVoiceGuide ? 'var(--accent)' : 'var(--bg-elevated)',
                  borderColor: totalVoiceGuide ? 'var(--accent)' : 'var(--border-subtle)',
                  color: totalVoiceGuide ? '#05070A' : 'var(--text-main)',
                }}
              >
                {totalVoiceGuide ? (
                  <Volume2 className="w-4 h-4 shrink-0" />
                ) : (
                  <VolumeX className="w-4 h-4 shrink-0" style={{ color: 'var(--accent)' }} />
                )}
                <span>Guida Vocale Totale {totalVoiceGuide ? 'ON' : 'OFF'}</span>
              </button>
            )}

            {onGenerateAiPlan && (
              <button
                type="button"
                disabled={isGeneratingAiPlan}
                onClick={onGenerateAiPlan}
                className="min-h-[46px] px-4 rounded-xl bg-[#00D2FF] text-[#05070A] text-xs sm:text-sm font-extrabold flex items-center justify-center gap-1.5 hover:bg-[#38BDF8] disabled:opacity-60 active:scale-[0.99] transition shrink-0"
              >
                {isGeneratingAiPlan ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Genero scheda AI...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Genera la mia Scheda con AI</span>
                  </>
                )}
              </button>
            )}
          </div>
        </section>
      ) : (
        <div className="sticky top-14 z-20 -mx-3 sm:-mx-4 px-3 sm:px-4 py-2 bg-[#090D16]/95 backdrop-blur-md border-b border-[#2563EB]/60">
          <div className="flex items-center justify-between gap-2 max-w-[500px] mx-auto">
            <div className="flex items-center gap-2 min-w-0">
              <div className="min-w-0">
                <p className="text-[10px] font-bold text-[#38BDF8] leading-none">
                  {sessionStatus === 'running' ? 'In corso' : 'In pausa'}
                </p>
                <p className="font-mono text-lg font-extrabold text-[#FFFFFF] tabular-nums leading-tight">
                  {formatDurationHMS(sessionElapsedSeconds)}
                </p>
              </div>
              <button
                type="button"
                onClick={onTogglePauseSession}
                className={`min-h-[38px] px-2.5 rounded-xl text-xs font-extrabold inline-flex items-center gap-1 transition shrink-0 ${
                  sessionStatus === 'running'
                    ? 'bg-[#132347] border border-[#38BDF8]/50 text-[#38BDF8] hover:bg-[#1E3A6E]'
                    : 'bg-[#2563EB] text-[#FFFFFF] hover:bg-[#3B82F6]'
                }`}
              >
                {sessionStatus === 'running' ? (
                  <>
                    <Pause className="w-3.5 h-3.5" />
                    <span>Pausa</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-current" />
                    <span>Riprendi</span>
                  </>
                )}
              </button>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              {onToggleTotalVoiceGuide && (
                <button
                  type="button"
                  onClick={() => {
                    playTechClick();
                    onToggleTotalVoiceGuide();
                  }}
                  aria-pressed={totalVoiceGuide}
                  title="Guida Vocale Totale (annuncio recuperi, transizioni e 3-2-1)"
                  className="min-h-[38px] px-2.5 rounded-xl border text-xs font-extrabold inline-flex items-center gap-1 transition whitespace-nowrap"
                  style={{
                    backgroundColor: totalVoiceGuide ? 'var(--accent)' : 'var(--bg-card)',
                    borderColor: totalVoiceGuide ? 'var(--accent)' : 'var(--border-subtle)',
                    color: totalVoiceGuide ? '#05070A' : 'var(--text-secondary)',
                  }}
                >
                  {totalVoiceGuide ? (
                    <Volume2 className="w-3.5 h-3.5" />
                  ) : (
                    <VolumeX className="w-3.5 h-3.5" />
                  )}
                  <span className="hidden sm:inline">
                    {totalVoiceGuide ? 'Guida ON' : 'Guida OFF'}
                  </span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  playTechClick();
                  setPrehabOpen(true);
                }}
                aria-label="Prehab Polsi e Gomiti"
                title="Prehab Polsi e Gomiti (3 min)"
                className="min-h-[38px] px-2.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#00D2FF] hover:border-[#00D2FF]/60 inline-flex items-center gap-1 whitespace-nowrap"
              >
                <Shield className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Prehab</span>
              </button>

              <button
                type="button"
                onClick={onAddWaterSip}
                aria-label="Sorsi d'acqua bevuti"
                className="min-h-[38px] px-2.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#00D2FF] inline-flex items-center gap-1 tabular-nums"
              >
                <Droplets className="w-3.5 h-3.5" />
                <span>{waterSipsCount}</span>
              </button>

              <button
                type="button"
                onClick={toggleVoiceCommands}
                aria-label={
                  voiceCommandsEnabled
                    ? 'Disattiva comandi vocali'
                    : 'Attiva comandi vocali'
                }
                className={`min-h-[38px] px-2.5 rounded-xl border text-xs font-bold inline-flex items-center gap-1 transition whitespace-nowrap ${
                  voiceCommandsEnabled
                    ? 'bg-[#38BDF8] border-[#00D2FF] text-[#05070A]'
                    : 'bg-[#131C31] border-[#1E293B] text-[#CBD5E1] hover:text-[#FFFFFF]'
                }`}
              >
                {voiceCommandsEnabled ? (
                  <Mic className="w-3.5 h-3.5" />
                ) : (
                  <MicOff className="w-3.5 h-3.5 text-[#38BDF8]" />
                )}
                <span>{voiceCommandsEnabled ? 'Voce ON' : 'Voce OFF'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Voice Commands Live Feedback Strip */}
      {(voiceCommandsEnabled || voiceError) && (
        <div
          role="status"
          className="rounded-xl bg-[#0B1D36] border border-[#00D2FF]/60 px-3.5 py-2.5 text-xs space-y-1"
        >
          {voiceError ? (
            <p className="text-[#38BDF8] font-semibold">{voiceError}</p>
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="font-bold text-[#00D2FF] inline-flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5 shrink-0" />
                  <span>
                    {speechSupported
                      ? 'Ascolto mani libere (it-IT)'
                      : 'SpeechRecognition non supportato'}
                  </span>
                </span>
                {effectiveVoiceTarget && (
                  <span className="text-[#CBD5E1] font-medium truncate">
                    Attiva:{' '}
                    <strong className="text-[#FFFFFF]">
                      {effectiveVoiceTarget.exercise.customName ??
                        getExerciseById(effectiveVoiceTarget.exercise.exerciseId)?.name ??
                        effectiveVoiceTarget.exercise.exerciseId}
                    </strong>{' '}
                    · S{effectiveVoiceTarget.setNumber}
                  </span>
                )}
              </div>
              <p className="text-[11px] text-[#94A3B8]">
                Di&apos; <strong className="text-[#FFFFFF]">&quot;Via&quot;</strong>,{' '}
                <strong className="text-[#FFFFFF]">&quot;Stop&quot;</strong>, numeri (
                <strong className="text-[#FFFFFF]">&quot;1, 2, 3...&quot;</strong>) o{' '}
                <strong className="text-[#FFFFFF]">&quot;Fine serie&quot;</strong>.
                {lastTranscript ? ` · "${lastTranscript}"` : ''}
              </p>
            </>
          )}
        </div>
      )}

      {/* Compact Day Selector Carousel */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5 no-scrollbar">
        {weeklyPlan.map((day, idx) => {
          const active = idx === selectedDayIndex;
          return (
            <button
              key={day.id}
              type="button"
              onClick={() => onSelectDay(idx)}
              className={`min-h-[40px] px-3.5 py-1.5 rounded-xl border text-left transition whitespace-nowrap shrink-0 ${
                active
                  ? 'bg-[#2563EB] text-[#FFFFFF] border-[#38BDF8]/70 font-extrabold'
                  : 'bg-[#0F172A] text-[#CBD5E1] border-[#1E293B] font-semibold hover:border-[#38BDF8]/40'
              }`}
            >
              <span className="text-[11px] opacity-80 mr-1 tabular-nums">G{day.dayNumber}</span>
              <span className="text-xs sm:text-sm">{day.splitLabel}</span>
            </button>
          );
        })}
      </div>

      {/* Compact Workout Day Header Summary */}
      <section className="rounded-2xl bg-[#0F172A] border border-[#1E293B] p-3.5 sm:p-4">
        <div className="flex flex-wrap items-center justify-between gap-2.5">
          <div className="min-w-0">
            <p className="text-[11px] font-semibold text-[#94A3B8]">
              Giorno {currentDay.dayNumber} · {currentDay.focus}
            </p>
            <h2 className="text-lg sm:text-xl font-extrabold text-[#FFFFFF] tracking-tight leading-snug">
              {currentDay.title}
            </h2>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() =>
                onOpenTimer({
                  mode: 'rest',
                  exerciseName: currentDay.title,
                  targetSeconds: 90,
                  voiceEnabled: true,
                })
              }
              className="min-h-[38px] px-2.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#FFFFFF] inline-flex items-center gap-1 hover:bg-[#1E293B] transition whitespace-nowrap"
            >
              <Clock className="w-3.5 h-3.5 text-[#38BDF8]" />
              <span>Recupero</span>
            </button>
            <button
              type="button"
              onClick={() =>
                onOpenTimer({
                  mode: 'isometric',
                  exerciseName: 'Cronometro Tenuta',
                  targetSeconds: 15,
                  voiceEnabled: true,
                })
              }
              className="min-h-[38px] px-2.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-bold text-[#FFFFFF] inline-flex items-center gap-1 hover:bg-[#1E293B] transition whitespace-nowrap"
            >
              <Timer className="w-3.5 h-3.5 text-[#00D2FF]" />
              <span>Isometria</span>
            </button>
          </div>
        </div>

        {/* Clean Progress Bar */}
        <div className="mt-2.5">
          <div className="flex items-center justify-between text-xs text-[#94A3B8] mb-1 tabular-nums">
            <span className="font-semibold text-[#CBD5E1]">
              {completedSets}/{totalSets} serie completate
            </span>
            <span className="font-mono font-bold text-[#38BDF8]">{progressPct}%</span>
          </div>
          <div className="h-1.5 w-full rounded-full bg-[#090D16] border border-[#1E293B] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#2563EB] to-[#00D2FF] transition-all duration-300"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>
      </section>

      {/* Dedicated Riscaldamento Block (Auto + Customizable) */}
      <section className="rounded-2xl bg-[#0B1D36] border border-[#2563EB]/60 overflow-hidden">
        <button
          type="button"
          onClick={() => setWarmupOpen((o) => !o)}
          className="w-full p-4 flex items-center justify-between gap-3 text-left hover:bg-[#132347]/60 transition"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-xl bg-[#132347] border border-[#38BDF8]/40 flex items-center justify-center shrink-0">
              <Flame className="w-5 h-5 text-[#00D2FF]" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-base font-extrabold text-[#FFFFFF] tracking-tight">
                  Riscaldamento
                </h3>
                <span className="font-mono text-xs font-bold text-[#38BDF8] tabular-nums">
                  {warmupCompletedCount}/{activeWarmup.length}
                </span>
              </div>
              <p className="text-xs text-[#94A3B8] truncate">
                Mobilità articolare, scapole e attivazione Calisthenics
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 text-[#38BDF8]">
            {warmupOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </div>
        </button>

        {warmupOpen && (
          <div className="border-t border-[#1E293B] bg-[#0F172A]/90 divide-y divide-[#1E293B]">
            {activeWarmup.length === 0 ? (
              <p className="p-4 text-xs text-[#94A3B8]">
                Nessun esercizio nel riscaldamento. Aggiungine uno manualmente o ripristina quello automatico.
              </p>
            ) : (
              activeWarmup.map((item) => (
                <div
                  key={item.id}
                  className={`p-3.5 sm:px-4 flex items-center justify-between gap-3 transition-colors ${
                    item.completed ? 'bg-[#132347]' : ''
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      type="button"
                      onClick={() => onToggleWarmupItem(item.id)}
                      aria-label={
                        item.completed
                          ? `Segna ${item.name} da completare`
                          : `Completa ${item.name}`
                      }
                      className={`min-h-[44px] min-w-[44px] rounded-xl flex items-center justify-center border shrink-0 transition active:scale-95 ${
                        item.completed
                          ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]'
                          : 'bg-[#131C31] border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF]'
                      }`}
                    >
                      <Check className="w-5 h-5 stroke-[2.75]" />
                    </button>

                    <div className="min-w-0">
                      <p
                        className={`text-sm font-bold leading-snug ${
                          item.completed ? 'text-[#38BDF8]' : 'text-[#FFFFFF]'
                        }`}
                      >
                        {item.name}
                      </p>
                      <p className="text-xs text-[#94A3B8] mt-0.5 tabular-nums">
                        <span className="font-mono font-bold text-[#00D2FF]">
                          {item.targetLabel}
                        </span>
                        {item.notes ? ` · ${item.notes}` : ''}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onRemoveWarmupItem(item.id)}
                    aria-label={`Rimuovi ${item.name}`}
                    className="min-h-[40px] min-w-[40px] rounded-xl bg-[#131C31] border border-[#1E293B] flex items-center justify-center text-[#94A3B8] hover:text-[#38BDF8] shrink-0 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}

            {/* Add / Reset Warmup Toolbar */}
            <div className="p-3.5 sm:px-4 bg-[#090D16] space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setWarmupAddOpen((v) => !v)}
                  className="min-h-[40px] px-3.5 rounded-xl bg-[#132347] border border-[#38BDF8]/50 text-xs font-bold text-[#38BDF8] inline-flex items-center gap-1.5 hover:bg-[#1E3A6E] transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Aggiungi al riscaldamento</span>
                </button>

                <button
                  type="button"
                  onClick={onResetWarmupToDefault}
                  className="min-h-[40px] px-3 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-semibold text-[#94A3B8] hover:text-[#FFFFFF] inline-flex items-center gap-1.5 transition"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Ripristina automatico</span>
                </button>
              </div>

              {warmupAddOpen && (
                <div className="rounded-xl bg-[#0F172A] border border-[#1E293B] p-3.5 space-y-3">
                  <div>
                    <p className="text-[11px] font-semibold text-[#94A3B8] mb-2">
                      Aggiunta rapida Calisthenics:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {WARMUP_PRESETS.map((preset) => (
                        <button
                          key={preset.name}
                          type="button"
                          onClick={() => {
                            onAddWarmupItem(preset);
                            setWarmupAddOpen(false);
                          }}
                          className="min-h-[34px] px-2.5 py-1.5 rounded-lg bg-[#131C31] border border-[#1E293B] text-[11px] font-semibold text-[#CBD5E1] hover:border-[#38BDF8] hover:text-[#FFFFFF] transition text-left"
                        >
                          + {preset.name} ({preset.targetLabel})
                        </button>
                      ))}
                    </div>
                  </div>

                  <form
                    onSubmit={handleCreateWarmupItem}
                    className="pt-2 border-t border-[#1E293B] grid grid-cols-1 sm:grid-cols-[1fr_120px_auto] gap-2"
                  >
                    <input
                      type="text"
                      value={customWarmupName}
                      onChange={(e) => setCustomWarmupName(e.target.value)}
                      placeholder="Es. Skin the Cat leggero, Wrist push-up..."
                      className="min-h-[42px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 text-xs text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                    />
                    <input
                      type="text"
                      value={customWarmupTarget}
                      onChange={(e) => setCustomWarmupTarget(e.target.value)}
                      placeholder="Es. 2 × 30s"
                      className="min-h-[42px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 font-mono text-xs text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                    />
                    <button
                      type="submit"
                      className="min-h-[42px] px-4 rounded-xl bg-[#2563EB] text-xs font-extrabold text-[#FFFFFF] hover:bg-[#3B82F6] transition whitespace-nowrap"
                    >
                      Aggiungi
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </section>

      {/* Muscle-Group Collapsible Sections */}
      <div className="space-y-4">
        {groupedExercises.map((group) => {
          const isCollapsed = Boolean(collapsedGroups[group.category]);
          const groupSets = group.entries.reduce((acc, e) => acc + e.item.sets.length, 0);
          const groupDoneSets = group.entries.reduce(
            (acc, e) => acc + e.item.sets.filter((s) => s.completed).length,
            0
          );

          return (
            <section key={group.category} className="space-y-3">
              {/* Collapsible Muscle Group Banner */}
              <button
                type="button"
                onClick={() => toggleGroupCollapsed(group.category)}
                className="w-full rounded-2xl bg-[#0B1D36] border border-[#1E293B] hover:border-[#38BDF8]/60 px-4 py-3 flex items-center justify-between gap-3 text-left transition"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-9 h-9 rounded-xl bg-[#132347] border border-[#2563EB]/60 flex items-center justify-center shrink-0">
                    <Dumbbell className="w-4 h-4 text-[#38BDF8]" />
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm sm:text-base font-extrabold text-[#FFFFFF] tracking-tight">
                        {group.meta.title}
                      </h3>
                      <span className="font-mono text-xs font-bold text-[#00D2FF] tabular-nums">
                        {groupDoneSets}/{groupSets} serie
                      </span>
                    </div>
                    <p className="text-[11px] text-[#94A3B8] truncate">{group.meta.subtitle}</p>
                  </div>
                </div>

                <span className="text-[#38BDF8] shrink-0">
                  {isCollapsed ? (
                    <ChevronDown className="w-5 h-5" />
                  ) : (
                    <ChevronUp className="w-5 h-5" />
                  )}
                </span>
              </button>

              {!isCollapsed && (
                <div className="space-y-4">
                  {group.entries.map(({ item, globalIndex }) => {
                    const def = getExerciseById(item.exerciseId);
                    const displayName = item.customName ?? def?.name ?? item.exerciseId;
                    const displayCategory = item.customCategory ?? def?.category ?? 'Skill';
                    const cues = def?.cues ?? [
                      'Controlla la fase negativa per 2-3 secondi',
                      'Mantieni il core compatto e la traiettoria pulita',
                    ];
                    const supportsWeight = def?.supportsWeight ?? true;
                    const isNegative = Boolean(
                      item.isNegative ||
                        def?.isNegative ||
                        displayName.toLowerCase().includes('negativ')
                    );
                    const negSeconds = item.negativeSeconds ?? def?.negativeSeconds ?? 6;
                    const isVoiceOn = !voiceDisabledMap[item.instanceId];

                    const cuesOpen = expandedCuesId === item.instanceId;
                    const visualOpen = expandedVisualId === item.instanceId;
                    const notesOpen = expandedNotesId === item.instanceId;
                    const quickSwapOpen = quickSwapInstanceId === item.instanceId;
                    const noteKey = item.exerciseId;
                    const savedNote = exerciseNotes[noteKey] ?? '';
                    const jointWarningActive = isExerciseStressedByJoint(
                      item.exerciseId,
                      item.customName,
                      activeJointStatus
                    );
                    const occupiedAlternatives = quickSwapOpen
                      ? pickOccupiedAlternatives(item)
                      : [];
                    const targetSummary = item.sets[0]?.targetValue ?? 8;
                    const addedKg = item.sets[0]?.addedWeightKg ?? 0;
                    const completedCount = item.sets.filter((s) => s.completed).length;

                    // Ghost Record: most recent session entry for this exercise
                    let prevExerciseRecord: {
                      bestValue: number;
                      technicalScore?: 1 | 2 | 3 | null;
                    } | null = null;
                    for (const sess of history) {
                      const match = sess.exercises.find((e) => e.exerciseId === item.exerciseId);
                      if (match) {
                        prevExerciseRecord = {
                          bestValue: match.bestValue,
                          technicalScore: match.technicalScore ?? null,
                        };
                        break;
                      }
                    }
                    const currentBestCompleted = Math.max(
                      0,
                      ...item.sets.filter((s) => s.completed).map((s) => s.actualValue)
                    );
                    const isNewGhostRecord =
                      prevExerciseRecord !== null &&
                      prevExerciseRecord.bestValue > 0 &&
                      currentBestCompleted > prevExerciseRecord.bestValue;

                    // Single active set for Voice Counting
                    const manualTargetMatch =
                      manualVoiceTarget?.instanceId === item.instanceId
                        ? item.sets.find((s) => s.id === manualVoiceTarget.setId && !s.completed)
                        : undefined;
                    const singleVoiceSet =
                      manualTargetMatch ?? item.sets.find((s) => !s.completed) ?? item.sets[0];
                    const singleVoiceSetIdx = singleVoiceSet
                      ? item.sets.findIndex((s) => s.id === singleVoiceSet.id)
                      : 0;

                    return (
                      <article
                        key={item.instanceId}
                        className="rounded-2xl bg-[#0F172A] border overflow-hidden transition"
                        style={{
                          borderColor: jointWarningActive ? '#F59E0B' : 'var(--border-subtle)',
                          boxShadow: jointWarningActive
                            ? '0 0 0 1px rgba(245, 158, 11, 0.35)'
                            : undefined,
                        }}
                      >
                        {/* Compact Card Header */}
                        <div className="p-3 sm:p-3.5 border-b border-[#1E293B]">
                          {jointWarningActive && (
                            <div
                              className="mb-2.5 rounded-xl border px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-xs"
                              style={{
                                backgroundColor: 'var(--bg-elevated)',
                                borderColor: '#F59E0B',
                                color: 'var(--text-main)',
                              }}
                            >
                              <span className="inline-flex items-center gap-1.5 font-bold" style={{ color: '#F59E0B' }}>
                                <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                                <span>Attenzione: carico su {activeJointStatus}</span>
                              </span>
                              {onProtectJointExercises && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    playTechClick();
                                    onProtectJointExercises(activeJointStatus);
                                    setPrehabOpen(true);
                                  }}
                                  className="min-h-[30px] px-2.5 rounded-lg text-[11px] font-extrabold transition"
                                  style={{
                                    backgroundColor: '#F59E0B',
                                    color: '#05070A',
                                  }}
                                >
                                  Sostituisci &amp; Avvia Prehab
                                </button>
                              )}
                            </div>
                          )}

                          <div className="flex items-start justify-between gap-2.5">
                            <div className="min-w-0">
                              <p className="text-[11px] font-semibold text-[#94A3B8] tabular-nums">
                                0{globalIndex + 1} · {MUSCLE_GROUP_LABELS[displayCategory].title} ·{' '}
                                {item.isIsometric
                                  ? 'Isometria'
                                  : isNegative
                                  ? `Negativa ${negSeconds}s`
                                  : 'Ripetizioni'}{' '}
                                · Rec {item.restSeconds}s
                              </p>
                              <div className="flex flex-wrap items-center gap-2 mt-0.5">
                                <h3 className="text-base sm:text-lg font-extrabold text-[#FFFFFF] leading-snug">
                                  {displayName}
                                </h3>
                                <button
                                  type="button"
                                  onClick={() => {
                                    playTechClick();
                                    setQuickSwapInstanceId(quickSwapOpen ? null : item.instanceId);
                                  }}
                                  title="Attrezzo occupato? Cambia esercizio al volo (3 alternative)"
                                  aria-label={`Cambia ${displayName} al volo`}
                                  className="min-h-[30px] min-w-[30px] px-2 rounded-lg border inline-flex items-center justify-center gap-1 text-[11px] font-extrabold transition"
                                  style={{
                                    backgroundColor: quickSwapOpen ? 'var(--primary)' : 'var(--bg-elevated)',
                                    borderColor: quickSwapOpen ? 'var(--accent)' : 'var(--border-subtle)',
                                    color: quickSwapOpen ? '#FFFFFF' : 'var(--accent)',
                                  }}
                                >
                                  <RefreshCw className="w-3.5 h-3.5 shrink-0" />
                                </button>
                                {isNewGhostRecord && (
                                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#00D2FF] text-[#05070A] text-[10px] font-extrabold shadow-[0_0_12px_rgba(0,210,255,0.45)] animate-pulse whitespace-nowrap">
                                    Nuovo Record! 🔥
                                  </span>
                                )}
                              </div>
                              {prevExerciseRecord && (
                                <p className="text-[11px] font-semibold text-[#38BDF8] mt-0.5 tabular-nums">
                                  Scorsa volta: {prevExerciseRecord.bestValue}
                                  {item.isIsometric ? 's' : ' rep'}
                                  {prevExerciseRecord.technicalScore
                                    ? ` • Voto ${prevExerciseRecord.technicalScore}`
                                    : ''}
                                </p>
                              )}
                              <p className="text-xs text-[#CBD5E1] mt-0.5 leading-snug">
                                {item.variantNote}
                              </p>
                            </div>

                            <div className="text-right shrink-0">
                              <p className="font-mono text-sm font-extrabold text-[#38BDF8] tabular-nums">
                                {item.sets.length} × {targetSummary}
                                {item.isIsometric ? 's' : ''}
                                {addedKg > 0 ? ` +${addedKg}kg` : ''}
                              </p>
                              <p className="text-[11px] font-bold text-[#94A3B8] mt-0.5 tabular-nums">
                                {completedCount}/{item.sets.length} fatte
                              </p>
                            </div>
                          </div>

                          {/* "Attrezzo Occupato" Instant 3-Alternative Quick Menu */}
                          {quickSwapOpen && (
                            <div
                              className="mt-2.5 rounded-xl border p-3 space-y-2"
                              style={{
                                backgroundColor: 'var(--bg-elevated)',
                                borderColor: 'var(--accent)',
                              }}
                            >
                              <div className="flex items-center justify-between gap-2">
                                <p className="text-xs font-extrabold" style={{ color: 'var(--accent)' }}>
                                  Attrezzo occupato? 3 alternative equivalenti ({displayCategory})
                                </p>
                                <button
                                  type="button"
                                  onClick={() => setQuickSwapInstanceId(null)}
                                  className="text-xs font-bold"
                                  style={{ color: 'var(--text-muted)' }}
                                >
                                  Chiudi
                                </button>
                              </div>
                              <div className="grid grid-cols-1 sm:grid-cols-3 gap-1.5">
                                {occupiedAlternatives.map((alt) => (
                                  <button
                                    key={alt.id}
                                    type="button"
                                    onClick={() => {
                                      playTechClick();
                                      onSwapExercise(item.instanceId, alt.id);
                                      setQuickSwapInstanceId(null);
                                    }}
                                    className="min-h-[42px] px-2.5 py-2 rounded-xl border text-left transition"
                                    style={{
                                      backgroundColor: 'var(--bg-card)',
                                      borderColor: 'var(--border-subtle)',
                                      color: 'var(--text-main)',
                                    }}
                                  >
                                    <p className="text-xs font-extrabold truncate">{alt.name}</p>
                                    <p className="text-[10px] truncate" style={{ color: 'var(--text-muted)' }}>
                                      {alt.equipment.join(' · ')}
                                    </p>
                                  </button>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Compact Action Row */}
                          <div className="mt-2.5 flex flex-wrap items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() =>
                                setExpandedVisualId(visualOpen ? null : item.instanceId)
                              }
                              className={`min-h-[36px] px-2.5 rounded-xl border text-xs font-bold inline-flex items-center gap-1 transition ${
                                visualOpen
                                  ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]'
                                  : 'bg-[#132347] border-[#38BDF8]/50 text-[#38BDF8] hover:bg-[#1E3A6E]'
                              }`}
                            >
                              <PlayCircle className="w-3.5 h-3.5" />
                              <span>Guida Esecuzione</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => setExpandedCuesId(cuesOpen ? null : item.instanceId)}
                              className="min-h-[36px] px-2.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-semibold text-[#CBD5E1] inline-flex items-center gap-1 hover:text-[#FFFFFF] transition"
                            >
                              <Info className="w-3.5 h-3.5 text-[#38BDF8]" />
                              <span>Tecnica</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => {
                                setCatalogCategory(displayCategory);
                                setSwapTargetInstanceId(item.instanceId);
                              }}
                              className="min-h-[36px] px-2.5 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-semibold text-[#CBD5E1] inline-flex items-center gap-1 hover:text-[#FFFFFF] transition"
                            >
                              <ArrowLeftRight className="w-3.5 h-3.5 text-[#38BDF8]" />
                              <span>Variante</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => setExpandedNotesId(notesOpen ? null : item.instanceId)}
                              className="min-h-[36px] px-2.5 rounded-xl border text-xs font-semibold inline-flex items-center gap-1 transition"
                              style={{
                                backgroundColor:
                                  notesOpen || savedNote
                                    ? 'var(--bg-elevated)'
                                    : 'var(--bg-main)',
                                borderColor:
                                  notesOpen || savedNote
                                    ? 'var(--accent)'
                                    : 'var(--border-subtle)',
                                color: savedNote ? 'var(--accent)' : 'var(--text-secondary)',
                              }}
                            >
                              <FileText className="w-3.5 h-3.5 shrink-0" />
                              <span>{savedNote ? 'Setup / Note ✓' : 'Setup / Note'}</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => toggleExerciseVoice(item.instanceId)}
                              aria-label={
                                isVoiceOn
                                  ? 'Disattiva voce guidata su questo esercizio'
                                  : 'Attiva voce guidata su questo esercizio'
                              }
                              className={`min-h-[36px] px-2.5 rounded-xl border text-xs font-bold inline-flex items-center gap-1 transition ${
                                isVoiceOn
                                  ? 'bg-[#132347] border-[#38BDF8]/50 text-[#00D2FF]'
                                  : 'bg-[#131C31] border-[#1E293B] text-[#94A3B8]'
                              }`}
                            >
                              {isVoiceOn ? (
                                <Volume2 className="w-3.5 h-3.5" />
                              ) : (
                                <VolumeX className="w-3.5 h-3.5" />
                              )}
                              <span>{isVoiceOn ? 'Voce' : 'Muto'}</span>
                            </button>

                            {item.isIsometric && (
                              <button
                                type="button"
                                onClick={() => {
                                  const nextPending =
                                    item.sets.find((s) => !s.completed) ?? item.sets[0];
                                  onOpenTimer({
                                    mode: 'isometric',
                                    exerciseName: displayName,
                                    partnerLabel: partnerMode ? `Turno Atleta ${activePartner}` : undefined,
                                    exerciseInstanceId: item.instanceId,
                                    setId: nextPending?.id,
                                    targetSeconds: nextPending?.targetValue ?? 15,
                                    voiceEnabled: isVoiceOn,
                                    handsFreeVoice: totalVoiceGuide,
                                    autoStart: isVoiceOn,
                                  });
                                }}
                                className="min-h-[36px] px-2.5 rounded-xl bg-[#00D2FF] text-[#05070A] text-xs font-extrabold inline-flex items-center gap-1 hover:bg-[#38BDF8] transition"
                              >
                                <Timer className="w-3.5 h-3.5" />
                                <span>Avvia Tenuta</span>
                              </button>
                            )}

                            {!item.isIsometric && (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    warmUpAudio();
                                    if (voiceCommandsEnabled) {
                                      toggleVoiceCommands();
                                    }
                                    if (!singleVoiceSet) return;
                                    setVoiceSetTarget({
                                      instanceId: item.instanceId,
                                      setId: singleVoiceSet.id,
                                      exerciseName: displayName,
                                      setNumber: singleVoiceSetIdx + 1,
                                      totalSets: item.sets.length,
                                      targetReps: singleVoiceSet.targetValue,
                                      setRpe: singleVoiceSet.rpe,
                                      restSeconds: item.restSeconds,
                                      isVoiceOn,
                                    });
                                  }}
                                  className="min-h-[36px] px-3 rounded-xl bg-[#00D2FF] text-[#05070A] text-xs font-extrabold inline-flex items-center gap-1.5 hover:bg-[#38BDF8] active:scale-[0.98] transition whitespace-nowrap"
                                >
                                  <Mic className="w-3.5 h-3.5 stroke-[2.5]" />
                                  <span>
                                    Inizia Serie Vocale · S{singleVoiceSetIdx + 1}/{item.sets.length}
                                  </span>
                                </button>

                                {isNegative && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      const nextPending =
                                        item.sets.find((s) => !s.completed) ?? item.sets[0];
                                      onOpenTimer({
                                        mode: 'negative',
                                        exerciseName: displayName,
                                        exerciseInstanceId: item.instanceId,
                                        setId: nextPending?.id,
                                        targetSeconds: nextPending?.targetValue ?? 5,
                                        negativeSeconds: negSeconds,
                                        targetReps: nextPending?.targetValue ?? 5,
                                        voiceEnabled: isVoiceOn,
                                        handsFreeVoice: totalVoiceGuide,
                                        autoStart: true,
                                      });
                                    }}
                                    className="min-h-[36px] px-2.5 rounded-xl bg-[#0B1D36] border border-[#00D2FF]/70 text-[#00D2FF] text-xs font-bold inline-flex items-center gap-1 hover:bg-[#132347] transition"
                                  >
                                    <TrendingDown className="w-3.5 h-3.5" />
                                    <span>Negativa ({negSeconds}s)</span>
                                  </button>
                                )}
                              </>
                            )}
                          </div>

                          {/* Technical Execution Quality Rating (1 - 2 - 3) */}
                          <div className="mt-2.5 pt-2.5 border-t border-[#1E293B] flex flex-wrap items-center justify-between gap-2">
                            <span className="text-[11px] font-bold text-[#94A3B8]">
                              Voto tecnica:
                            </span>
                            <div className="grid grid-cols-3 gap-1.5 flex-1 sm:flex-none sm:w-[320px]">
                              {(
                                [
                                  {
                                    val: 1 as const,
                                    label: '1 · Sporca',
                                    title: 'Molto sporca / Tecnica persa',
                                    activeClass:
                                      'bg-[#1E293B] border-[#94A3B8] text-[#FFFFFF]',
                                  },
                                  {
                                    val: 2 as const,
                                    label: '2 · Al limite',
                                    title: 'Tirata / Al limite',
                                    activeClass:
                                      'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]',
                                  },
                                  {
                                    val: 3 as const,
                                    label: '3 · Pulita',
                                    title: 'Molto semplice / Pulita',
                                    activeClass:
                                      'bg-[#00D2FF] border-[#7DD3FC] text-[#05070A]',
                                  },
                                ] as const
                              ).map((opt) => {
                                const selected = item.technicalScore === opt.val;
                                return (
                                  <button
                                    key={opt.val}
                                    type="button"
                                    title={opt.title}
                                    onClick={() => onSetTechnicalScore(item.instanceId, opt.val)}
                                    className={`min-h-[34px] px-2 rounded-lg border text-[11px] font-extrabold transition whitespace-nowrap ${
                                      selected
                                        ? opt.activeClass
                                        : 'bg-[#090D16] border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF]'
                                    }`}
                                  >
                                    {opt.label}
                                  </button>
                                );
                              })}
                            </div>
                          </div>

                          {visualOpen && (
                            <ExerciseAnimationSVG
                              exerciseId={item.exerciseId}
                              animationId={def?.animationId}
                              exerciseName={displayName}
                              category={displayCategory}
                              cues={cues}
                            />
                          )}

                          {cuesOpen && (
                            <ul className="mt-2.5 pt-2.5 border-t border-[#1E293B] space-y-1 text-xs text-[#CBD5E1]">
                              {cues.map((cue, cIdx) => (
                                <li key={cIdx} className="flex items-start gap-2">
                                  <span className="font-mono text-[#38BDF8]">•</span>
                                  <span>{cue}</span>
                                </li>
                              ))}
                            </ul>
                          )}

                          {/* Fixed Personal Setup / Band / Note Preview & Editor */}
                          {(notesOpen || savedNote.trim().length > 0) && onUpdateExerciseNote && (
                            <div
                              className="mt-2.5 pt-2.5 border-t space-y-1.5"
                              style={{ borderColor: 'var(--border-subtle)' }}
                            >
                              <div className="flex items-center justify-between gap-2">
                                <span
                                  className="text-[11px] font-extrabold inline-flex items-center gap-1"
                                  style={{ color: 'var(--accent)' }}
                                >
                                  <FileText className="w-3 h-3" />
                                  <span>Setup / Elastico / Note personali</span>
                                </span>
                                {!notesOpen && (
                                  <button
                                    type="button"
                                    onClick={() => setExpandedNotesId(item.instanceId)}
                                    className="text-[11px] font-bold"
                                    style={{ color: 'var(--accent)' }}
                                  >
                                    Modifica
                                  </button>
                                )}
                              </div>

                              {notesOpen ? (
                                <textarea
                                  rows={2}
                                  value={savedNote}
                                  onChange={(e) => onUpdateExerciseNote(noteKey, e.target.value)}
                                  placeholder="Es. Elastico rosso medio, anelli alla tacca 4, presa +5cm..."
                                  className="w-full rounded-xl border p-2.5 text-xs focus:outline-none"
                                  style={{
                                    backgroundColor: 'var(--bg-main)',
                                    borderColor: 'var(--accent)',
                                    color: 'var(--text-main)',
                                  }}
                                />
                              ) : (
                                <p
                                  onClick={() => setExpandedNotesId(item.instanceId)}
                                  className="text-xs rounded-lg px-2.5 py-1.5 border cursor-pointer"
                                  style={{
                                    backgroundColor: 'var(--bg-elevated)',
                                    borderColor: 'var(--border-subtle)',
                                    color: 'var(--text-secondary)',
                                  }}
                                >
                                  {savedNote}
                                </p>
                              )}
                            </div>
                          )}
                        </div>

                        {/* Sets Table / Rapid Touch Logger */}
                        <div className="divide-y divide-[#1E293B]">
                          {item.sets.map((set, sIdx) => {
                            const isVoiceFocused =
                              voiceCommandsEnabled &&
                              effectiveVoiceTarget?.exercise.instanceId === item.instanceId &&
                              effectiveVoiceTarget?.set.id === set.id;

                            return (
                              <div
                                key={set.id}
                                className={`p-3.5 sm:px-4 transition-colors ${
                                  set.completed
                                    ? 'bg-[#132347]'
                                    : isVoiceFocused
                                    ? 'bg-[#0B1D36]'
                                    : 'bg-transparent'
                                }`}
                              >
                                <div className="flex items-center justify-between gap-2">
                                  {/* Set Number & Target (tap to focus voice commands when active) */}
                                  <button
                                    type="button"
                                    onClick={() =>
                                      setManualVoiceTarget({
                                        instanceId: item.instanceId,
                                        setId: set.id,
                                      })
                                    }
                                    className="flex items-center gap-2.5 min-w-0 text-left"
                                  >
                                    <span
                                      className={`w-7 h-7 rounded-lg font-mono text-xs font-bold flex items-center justify-center tabular-nums shrink-0 ${
                                        isVoiceFocused
                                          ? 'bg-[#00D2FF] text-[#05070A]'
                                          : 'bg-[#131C31] text-[#94A3B8]'
                                      }`}
                                    >
                                      {sIdx + 1}
                                    </span>
                                    <div className="text-xs text-[#94A3B8] tabular-nums">
                                      Target:{' '}
                                      <span className="text-[#FFFFFF] font-semibold">
                                        {set.targetValue}
                                        {item.isIsometric ? 's' : ' rep'}
                                      </span>
                                      {isVoiceFocused && (
                                        <span className="ml-1.5 text-[11px] font-bold text-[#00D2FF]">
                                          · Voce attiva
                                        </span>
                                      )}
                                    </div>
                                  </button>

                                  {/* Actual Reps / Sec Stepper + Check */}
                                  <div className="flex items-center gap-1.5">
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onUpdateSet(item.instanceId, set.id, {
                                          actualValue: Math.max(0, set.actualValue - 1),
                                        })
                                      }
                                      aria-label="Riduci valore"
                                      className="min-h-[44px] min-w-[42px] rounded-xl bg-[#131C31] border border-[#1E293B] text-base font-bold text-[#FFFFFF] hover:bg-[#1E293B] active:scale-95 transition"
                                    >
                                      -
                                    </button>
                                    <div className="min-w-[54px] min-h-[44px] px-2 rounded-xl bg-[#090D16] border border-[#1E293B] flex flex-col items-center justify-center">
                                      <span className="font-mono text-sm font-bold text-[#FFFFFF] tabular-nums">
                                        {set.actualValue}
                                        {item.isIsometric ? 's' : ''}
                                      </span>
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() =>
                                        onUpdateSet(item.instanceId, set.id, {
                                          actualValue: set.actualValue + 1,
                                        })
                                      }
                                      aria-label="Aumenta valore"
                                      className="min-h-[44px] min-w-[42px] rounded-xl bg-[#131C31] border border-[#1E293B] text-base font-bold text-[#FFFFFF] hover:bg-[#1E293B] active:scale-95 transition"
                                    >
                                      +
                                    </button>

                                    {/* Complete Set Button */}
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const nextCompleted = !set.completed;
                                        const otherAllDone = item.sets
                                          .filter((s) => s.id !== set.id)
                                          .every((s) => s.completed);
                                        const completesWholeExercise =
                                          nextCompleted && otherAllDone;

                                        onUpdateSet(item.instanceId, set.id, {
                                          completed: nextCompleted,
                                          rpe: set.rpe ?? 8,
                                        });
                                        if (nextCompleted) {
                                          announceHandsFreeTransition(item, completesWholeExercise);
                                        }
                                        if (nextCompleted && !completesWholeExercise) {
                                          const nextPartner = partnerMode
                                            ? activePartner === 1
                                              ? 2
                                              : 1
                                            : null;
                                          if (nextPartner) {
                                            setActivePartner(nextPartner);
                                          }
                                          onOpenTimer({
                                            mode: 'rest',
                                            exerciseName: displayName,
                                            partnerLabel: nextPartner
                                              ? `Prossimo turno: Atleta ${nextPartner}`
                                              : undefined,
                                            targetSeconds: item.restSeconds,
                                            voiceEnabled: isVoiceOn,
                                            handsFreeVoice: totalVoiceGuide,
                                          });
                                        }
                                      }}
                                      aria-label={
                                        set.completed
                                          ? 'Annulla serie completata'
                                          : 'Completa serie'
                                      }
                                      className={`min-h-[44px] min-w-[46px] rounded-xl flex items-center justify-center border transition active:scale-95 ${
                                        set.completed
                                          ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]'
                                          : 'bg-[#131C31] border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF]'
                                      }`}
                                    >
                                      <Check className="w-5 h-5 stroke-[2.75]" />
                                    </button>
                                  </div>
                                </div>

                                {/* Second compact row: RPE & Optional Weight */}
                                <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2">
                                  <div className="flex items-center gap-1 overflow-x-auto no-scrollbar">
                                    <span className="text-[11px] font-semibold text-[#94A3B8] mr-1">
                                      RPE
                                    </span>
                                    {RPE_VALUES.map((val) => {
                                      const selected = set.rpe === val;
                                      return (
                                        <button
                                          key={val}
                                          type="button"
                                          onClick={() =>
                                            onUpdateSet(item.instanceId, set.id, { rpe: val })
                                          }
                                          className={`min-h-[32px] min-w-[34px] px-1.5 rounded-lg font-mono text-xs font-bold tabular-nums transition ${
                                            selected
                                              ? val >= 9.5
                                                ? 'bg-[#38BDF8] text-[#05070A]'
                                                : 'bg-[#2563EB] text-[#FFFFFF]'
                                              : 'bg-[#131C31] text-[#94A3B8] hover:text-[#FFFFFF]'
                                          }`}
                                        >
                                          {val}
                                        </button>
                                      );
                                    })}
                                  </div>

                                  {supportsWeight && (
                                    <div className="flex items-center gap-1">
                                      <span className="text-[11px] text-[#94A3B8]">Zavorra</span>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          onUpdateSet(item.instanceId, set.id, {
                                            addedWeightKg: Math.max(0, set.addedWeightKg - 2.5),
                                          })
                                        }
                                        className="min-h-[32px] min-w-[30px] rounded-lg bg-[#131C31] text-xs font-bold text-[#FFFFFF] hover:bg-[#1E293B]"
                                      >
                                        -
                                      </button>
                                      <span className="font-mono text-xs font-bold text-[#38BDF8] min-w-[44px] text-center tabular-nums">
                                        +{set.addedWeightKg}kg
                                      </span>
                                      <button
                                        type="button"
                                        onClick={() =>
                                          onUpdateSet(item.instanceId, set.id, {
                                            addedWeightKg: set.addedWeightKg + 2.5,
                                          })
                                        }
                                        className="min-h-[32px] min-w-[30px] rounded-lg bg-[#131C31] text-xs font-bold text-[#FFFFFF] hover:bg-[#1E293B]"
                                      >
                                        +
                                      </button>
                                    </div>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        <div className="px-4 py-2.5 bg-[#090D16] border-t border-[#1E293B]">
                          <button
                            type="button"
                            onClick={() => onAddSet(item.instanceId)}
                            className="min-h-[38px] text-xs font-semibold text-[#94A3B8] hover:text-[#38BDF8] inline-flex items-center gap-1.5 transition"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>Aggiungi serie</span>
                          </button>
                        </div>
                      </article>
                    );
                  })}

                  {onAddExtraExercise && (
                    <button
                      type="button"
                      onClick={() => {
                        playTechClick();
                        setExtraModalCategory(group.category);
                      }}
                      className="w-full min-h-[42px] px-4 rounded-xl border border-dashed text-xs font-extrabold flex items-center justify-center gap-1.5 transition"
                      style={{
                        backgroundColor: 'var(--bg-card)',
                        borderColor: 'var(--accent)',
                        color: 'var(--accent)',
                      }}
                    >
                      <Plus className="w-4 h-4 shrink-0" />
                      <span>+ Aggiungi Esercizio in {group.meta.title}</span>
                    </button>
                  )}
                </div>
              )}
            </section>
          );
        })}

        {onAddExtraExercise && (
          <button
            type="button"
            onClick={() => {
              playTechClick();
              setExtraModalCategory('Spinta');
            }}
            className="w-full min-h-[44px] px-4 rounded-2xl border text-xs font-extrabold flex items-center justify-center gap-1.5 transition"
            style={{
              backgroundColor: 'var(--bg-elevated)',
              borderColor: 'var(--border-subtle)',
              color: 'var(--accent)',
            }}
          >
            <Plus className="w-4 h-4 shrink-0" />
            <span>+ Aggiungi Esercizio Extra a qualsiasi reparto</span>
          </button>
        )}
      </div>

      {/* Dedicated Stretching e Defaticamento Block (Customizable, End of Workout) */}
      <section className="rounded-2xl bg-[#0B1D36] border border-[#38BDF8]/50 overflow-hidden">
        <button
          type="button"
          onClick={() => setStretchOpen((o) => !o)}
          className="w-full p-3.5 flex items-center justify-between gap-3 text-left hover:bg-[#132347]/60 transition"
        >
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-[#132347] border border-[#00D2FF]/50 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4 text-[#00D2FF]" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm sm:text-base font-extrabold text-[#FFFFFF] tracking-tight">
                  Stretching e Defaticamento
                </h3>
                <span className="font-mono text-xs font-bold text-[#00D2FF] tabular-nums">
                  {stretchCompletedCount}/{activeStretch.length}
                </span>
              </div>
              <p className="text-[11px] text-[#94A3B8] truncate">
                Allungamento dorsali, petto, addome, femorali e scarico polsi
              </p>
            </div>
          </div>

          <span className="text-[#38BDF8] shrink-0">
            {stretchOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
          </span>
        </button>

        {stretchOpen && (
          <div className="border-t border-[#1E293B] bg-[#0F172A]/90 divide-y divide-[#1E293B]">
            {activeStretch.length === 0 ? (
              <p className="p-3.5 text-xs text-[#94A3B8]">
                Nessuno stretching configurato. Aggiungine uno manualmente o ripristina quelli predefiniti.
              </p>
            ) : (
              activeStretch.map((item) => (
                <div
                  key={item.id}
                  className={`p-3 sm:px-4 flex items-center justify-between gap-2.5 transition-colors ${
                    item.completed ? 'bg-[#132347]' : ''
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <button
                      type="button"
                      onClick={() => onToggleStretchItem(item.id)}
                      aria-label={
                        item.completed
                          ? `Segna ${item.name} da completare`
                          : `Completa ${item.name}`
                      }
                      className={`min-h-[42px] min-w-[42px] rounded-xl flex items-center justify-center border shrink-0 transition active:scale-95 ${
                        item.completed
                          ? 'bg-[#2563EB] border-[#38BDF8] text-[#FFFFFF]'
                          : 'bg-[#131C31] border-[#1E293B] text-[#94A3B8] hover:text-[#FFFFFF]'
                      }`}
                    >
                      <Check className="w-5 h-5 stroke-[2.75]" />
                    </button>

                    <div className="min-w-0">
                      <p
                        className={`text-sm font-bold leading-snug ${
                          item.completed ? 'text-[#38BDF8]' : 'text-[#FFFFFF]'
                        }`}
                      >
                        {item.name}
                      </p>
                      <p className="text-[11px] text-[#94A3B8] mt-0.5 tabular-nums">
                        <span className="font-mono font-bold text-[#00D2FF]">
                          {item.targetLabel}
                        </span>
                        {item.notes ? ` · ${item.notes}` : ''}
                      </p>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onRemoveStretchItem(item.id)}
                    aria-label={`Rimuovi ${item.name}`}
                    className="min-h-[38px] min-w-[38px] rounded-xl bg-[#131C31] border border-[#1E293B] flex items-center justify-center text-[#94A3B8] hover:text-[#38BDF8] shrink-0 transition"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}

            {/* Add / Reset Stretching Toolbar */}
            <div className="p-3 sm:px-4 bg-[#090D16] space-y-2.5">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => setStretchAddOpen((v) => !v)}
                  className="min-h-[38px] px-3 rounded-xl bg-[#132347] border border-[#38BDF8]/50 text-xs font-bold text-[#38BDF8] inline-flex items-center gap-1.5 hover:bg-[#1E3A6E] transition"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Aggiungi stretching</span>
                </button>

                <button
                  type="button"
                  onClick={onResetStretchToDefault}
                  className="min-h-[38px] px-3 rounded-xl bg-[#131C31] border border-[#1E293B] text-xs font-semibold text-[#94A3B8] hover:text-[#FFFFFF] inline-flex items-center gap-1.5 transition"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Ripristina automatico</span>
                </button>
              </div>

              {stretchAddOpen && (
                <div className="rounded-xl bg-[#0F172A] border border-[#1E293B] p-3 space-y-2.5">
                  <div>
                    <p className="text-[11px] font-semibold text-[#94A3B8] mb-1.5">
                      Preset Stretching Finale:
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {STRETCH_PRESETS.map((preset) => (
                        <button
                          key={preset.name}
                          type="button"
                          onClick={() => {
                            onAddStretchItem(preset);
                            setStretchAddOpen(false);
                          }}
                          className="min-h-[32px] px-2.5 py-1 rounded-lg bg-[#131C31] border border-[#1E293B] text-[11px] font-semibold text-[#CBD5E1] hover:border-[#38BDF8] hover:text-[#FFFFFF] transition text-left"
                        >
                          + {preset.name} ({preset.targetLabel})
                        </button>
                      ))}
                    </div>
                  </div>

                  <form
                    onSubmit={handleCreateStretchItem}
                    className="pt-2 border-t border-[#1E293B] grid grid-cols-1 sm:grid-cols-[1fr_110px_auto] gap-2"
                  >
                    <input
                      type="text"
                      value={customStretchName}
                      onChange={(e) => setCustomStretchName(e.target.value)}
                      placeholder="Es. Pancake Stretch, Squat profondo..."
                      className="min-h-[40px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 text-xs text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                    />
                    <input
                      type="text"
                      value={customStretchTarget}
                      onChange={(e) => setCustomStretchTarget(e.target.value)}
                      placeholder="Es. 2 × 30s"
                      className="min-h-[40px] rounded-xl bg-[#090D16] border border-[#1E293B] px-3 font-mono text-xs text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                    />
                    <button
                      type="submit"
                      className="min-h-[40px] px-4 rounded-xl bg-[#2563EB] text-xs font-extrabold text-[#FFFFFF] hover:bg-[#3B82F6] transition whitespace-nowrap"
                    >
                      Aggiungi
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </section>

      {/* Prominent Finish & Talk to Coach CTA */}
      <div className="pt-1">
        <button
          type="button"
          onClick={onFinishWorkout}
          className="w-full min-h-[52px] rounded-2xl bg-[#2563EB] text-[#FFFFFF] text-sm sm:text-base font-extrabold flex items-center justify-center gap-2 hover:bg-[#3B82F6] active:scale-[0.98] transition shadow-lg shadow-[#05070A]/70 px-4"
        >
          <MessageSquare className="w-5 h-5 shrink-0" />
          <span>Concludi allenamento e parla con il Coach</span>
        </button>
      </div>

      {/* Catalog Swap Modal organized by Muscle Groups */}
      {swapTargetInstanceId && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-[#05070A]/80 backdrop-blur-sm p-3 sm:p-4">
          <div className="w-full max-w-lg max-h-[85vh] rounded-3xl bg-[#0F172A] border border-[#1E293B] flex flex-col overflow-hidden shadow-2xl">
            <div className="p-4 border-b border-[#1E293B] flex items-center justify-between">
              <h3 className="text-base font-bold text-[#FFFFFF]">
                Catalogo Esercizi per Gruppo Muscolare
              </h3>
              <button
                type="button"
                onClick={() => setSwapTargetInstanceId(null)}
                aria-label="Chiudi catalogo"
                className="min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl text-[#94A3B8] hover:text-[#FFFFFF]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 space-y-3 border-b border-[#1E293B]">
              <div className="relative">
                <Search className="w-4 h-4 text-[#94A3B8] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={catalogQuery}
                  onChange={(e) => setCatalogQuery(e.target.value)}
                  placeholder="Cerca esercizio (es. Planche, Dead Hang, V-Up, Negative...)"
                  className="w-full min-h-[44px] pl-10 pr-4 rounded-xl bg-[#090D16] border border-[#1E293B] text-sm text-[#FFFFFF] placeholder:text-[#64748B] focus:outline-none focus:border-[#38BDF8]"
                />
              </div>

              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                {CATALOG_FILTERS.map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setCatalogCategory(cat.id)}
                    className={`min-h-[36px] px-3 rounded-lg text-xs font-bold whitespace-nowrap transition ${
                      catalogCategory === cat.id
                        ? 'bg-[#2563EB] text-[#FFFFFF]'
                        : 'bg-[#131C31] text-[#94A3B8] hover:text-[#FFFFFF]'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {groupedCatalog.map((group) => (
                <div key={group.category}>
                  <div className="sticky top-0 z-10 px-4 py-2 bg-[#0B1D36] border-y border-[#1E293B] flex items-center justify-between">
                    <span className="text-xs font-extrabold text-[#38BDF8] uppercase tracking-wider">
                      {group.label}
                    </span>
                    <span className="font-mono text-[11px] text-[#94A3B8] tabular-nums">
                      {group.items.length}
                    </span>
                  </div>
                  <div className="divide-y divide-[#1E293B]">
                    {group.items.map((ex) => (
                      <button
                        key={ex.id}
                        type="button"
                        onClick={() => {
                          onSwapExercise(swapTargetInstanceId, ex.id);
                          setSwapTargetInstanceId(null);
                          setCatalogQuery('');
                        }}
                        className="w-full text-left p-3.5 hover:bg-[#131C31] transition flex items-center justify-between gap-3"
                      >
                        <div>
                          <p className="text-sm font-bold text-[#FFFFFF]">{ex.name}</p>
                          <p className="text-xs text-[#94A3B8] mt-0.5">
                            {group.label} ·{' '}
                            {ex.type === 'isometric'
                              ? 'Isometria (s)'
                              : ex.isNegative
                              ? `Negativa (${ex.negativeSeconds ?? 6}s discesa)`
                              : 'Ripetizioni'}{' '}
                            · {ex.variantHint}
                          </p>
                        </div>
                        <span className="text-xs font-bold text-[#38BDF8] shrink-0">Seleziona</span>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Dedicated Voice Set Counter Modal (strictly single active set) */}
      <VoiceSetModal
        key={voiceSetTarget?.setId ?? 'none'}
        isOpen={Boolean(voiceSetTarget)}
        exerciseName={voiceSetTarget?.exerciseName ?? ''}
        setNumber={voiceSetTarget?.setNumber ?? 1}
        totalSets={voiceSetTarget?.totalSets ?? 1}
        targetReps={voiceSetTarget?.targetReps ?? 8}
        partnerLabel={partnerMode ? `Turno Atleta ${activePartner}` : undefined}
        onComplete={(finalReps) => {
          if (!voiceSetTarget) return;
          const target = voiceSetTarget;
          setVoiceSetTarget(null);

          const latestItem = activeExercises.find((e) => e.instanceId === target.instanceId);
          const allOthersDone = latestItem
            ? latestItem.sets.filter((s) => s.id !== target.setId).every((s) => s.completed)
            : false;

          onUpdateSet(target.instanceId, target.setId, {
            actualValue: finalReps,
            completed: true,
            rpe: target.setRpe ?? 8,
          });

          if (target) {
            announceHandsFreeTransition(latestItem ?? {
              instanceId: target.instanceId,
              exerciseId: '',
              variantNote: '',
              isIsometric: false,
              restSeconds: target.restSeconds,
              sets: [],
            }, allOthersDone);
          }

          if (!allOthersDone) {
            const nextPartner = partnerMode ? (activePartner === 1 ? 2 : 1) : null;
            if (nextPartner) {
              setActivePartner(nextPartner);
            }
            onOpenTimer({
              mode: 'rest',
              exerciseName: target.exerciseName,
              partnerLabel: nextPartner
                ? `Prossimo turno: Atleta ${nextPartner}`
                : undefined,
              targetSeconds: target.restSeconds,
              voiceEnabled: target.isVoiceOn,
              handsFreeVoice: totalVoiceGuide,
            });
          }
        }}
        onCancel={() => setVoiceSetTarget(null)}
      />

      {/* 3-Minute Guided Prehab Modal (Wrists & Elbows) */}
      <PrehabModal
        isOpen={prehabOpen}
        onClose={() => setPrehabOpen(false)}
        onCompleted={onPrehabCompleted}
      />

      {/* PRO Circuit Timer Modal (EMOM, TABATA, TUT Metronome) */}
      <CircuitTimerModal
        isOpen={circuitModalOpen}
        onClose={() => setCircuitModalOpen(false)}
      />

      {/* Weighted Calisthenics 1RM Calculator Modal */}
      <OneRMCalculatorModal
        isOpen={oneRmModalOpen}
        defaultWeightKg={defaultWeightKg}
        onClose={() => setOneRmModalOpen(false)}
      />

      {/* Add Extra Exercise Modal (Catalog + Custom On-the-Fly) */}
      {onAddExtraExercise && (
        <AddExtraExerciseModal
          isOpen={extraModalCategory !== null}
          initialCategory={extraModalCategory ?? 'Spinta'}
          onAddExercise={onAddExtraExercise}
          onClose={() => setExtraModalCategory(null)}
        />
      )}

      {/* Battle 1vs1 Split-Screen Live Duel */}
      <Battle1v1Modal
        isOpen={battleModalOpen}
        defaultAthlete1Name={profile?.name || 'Atleta 1'}
        onClose={() => setBattleModalOpen(false)}
      />

      {/* Freestyle Combo Builder & Flow Stopwatch */}
      <ComboBuilderModal
        isOpen={comboModalOpen}
        savedCombos={savedCombos}
        onSaveCombo={(combo) => onSaveCombo?.(combo)}
        onUpdateComboRecord={(comboId, sec) => onUpdateComboRecord?.(comboId, sec)}
        onDeleteCombo={(comboId) => onDeleteCombo?.(comboId)}
        onClose={() => setComboModalOpen(false)}
      />

      {/* Offline QR Code & Shareable Plan Link */}
      {onImportSharedPlan && (
        <SharePlanModal
          isOpen={shareModalOpen}
          weeklyPlan={weeklyPlan}
          onImportPlan={onImportSharedPlan}
          onClose={() => setShareModalOpen(false)}
        />
      )}
    </div>
  );
};


