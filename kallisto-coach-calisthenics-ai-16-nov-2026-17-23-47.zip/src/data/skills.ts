import type {
  SkillBranchId,
  SkillNodeDefinition,
  StretchExerciseItem,
  WarmupExerciseItem,
} from '../types/calisthenics';

export interface SkillBranchMeta {
  id: SkillBranchId;
  title: string;
  subtitle: string;
}

export const SKILL_BRANCHES: SkillBranchMeta[] = [
  {
    id: 'tirata',
    title: 'Ramo Tirata',
    subtitle: 'Dalla tirata orizzontale al Muscle-up esplosivo',
  },
  {
    id: 'spinta_planche',
    title: 'Ramo Spinta / Planche',
    subtitle: 'Protrazione scapolare, sbilanciamento e tenuta in Planche',
  },
  {
    id: 'leve_core',
    title: 'Ramo Leve / Core',
    subtitle: 'Controllo pelvico, L-Sit e linee orizzontali di trazione',
  },
  {
    id: 'verticale',
    title: 'Ramo Verticale',
    subtitle: 'Linea verticale, spinta di spalle ed equilibrio libero',
  },
];

export const SKILL_TREE_NODES: SkillNodeDefinition[] = [
  // Ramo Tirata: Australian Pull-up -> Trazioni -> Trazioni Esplosive -> Muscle-up
  {
    id: 'skill_australian_pullup',
    branchId: 'tirata',
    order: 1,
    name: 'Australian Pull-up',
    prerequisiteId: null,
    mode: 'reps',
    targetValue: 10,
    requirementLabel: 'Esegui 10 Australian Pull-up pulite',
    cameraHint: 'Inquadra il corpo di profilo sotto la sbarra bassa per verificare la linea retta.',
    cues: [
      'Corpo rigido da testa a talloni',
      'Porta il petto fino a toccare la sbarra',
      'Controlla la discesa senza perdere tensione scapolare',
    ],
  },
  {
    id: 'skill_pullup',
    branchId: 'tirata',
    order: 2,
    name: 'Trazioni alla Sbarra',
    prerequisiteId: 'skill_australian_pullup',
    mode: 'reps',
    targetValue: 5,
    requirementLabel: 'Esegui 5 trazioni pulite (mento sopra la sbarra)',
    cameraHint: 'Posiziona la camera frontalmente o di 3/4 inquadrando sbarra e busto.',
    cues: [
      'Partenza a braccia tese con scapole attive',
      'Nessun slancio delle gambe (zero kipping)',
      'Supera chiaramente la sbarra con il mento',
    ],
  },
  {
    id: 'skill_high_pullup',
    branchId: 'tirata',
    order: 3,
    name: 'Trazioni Esplosive',
    prerequisiteId: 'skill_pullup',
    mode: 'reps',
    targetValue: 4,
    requirementLabel: 'Esegui 4 trazioni esplosive fino allo sterno',
    cameraHint: 'Inquadra sbarra e tronco di lato o di fronte per verificare l’altezza della tirata.',
    cues: [
      'Accelerazione massima fin dall’inizio della tirata',
      'Porta la sbarra almeno all’altezza del petto basso',
      'Discesa controllata prima della ripetizione successiva',
    ],
  },
  {
    id: 'skill_muscle_up',
    branchId: 'tirata',
    order: 4,
    name: 'Muscle-up',
    prerequisiteId: 'skill_high_pullup',
    mode: 'reps',
    targetValue: 2,
    requirementLabel: 'Esegui 2 Muscle-up puliti alla sbarra',
    cameraHint: 'Inquadra sbarra e spazio sopra la sbarra di profilo per la transizione completa.',
    cues: [
      'Tirata curva attorno alla sbarra senza strappi asimmetrici',
      'Transizione rapida dei polsi sopra la sbarra',
      'Lockout completo a braccia tese in cima',
    ],
  },

  // Ramo Spinta / Planche: Push-up -> Pike Push-up -> Frog Stand -> Tuck Planche -> Planche
  {
    id: 'skill_pushup',
    branchId: 'spinta_planche',
    order: 1,
    name: 'Push-up',
    prerequisiteId: null,
    mode: 'reps',
    targetValue: 15,
    requirementLabel: 'Esegui 15 Push-up puliti a terra',
    cameraHint: 'Inquadra il corpo di profilo sul tappetino per controllare escursione e linea del bacino.',
    cues: [
      'Bacino in retroversione senza cedere coi lombari',
      'Petto a sfiorare il suolo in ogni ripetizione',
      'Protrazione scapolare completa in spinta',
    ],
  },
  {
    id: 'skill_pike_pushup',
    branchId: 'spinta_planche',
    order: 2,
    name: 'Pike Push-up',
    prerequisiteId: 'skill_pushup',
    mode: 'reps',
    targetValue: 8,
    requirementLabel: 'Esegui 8 Pike Push-up controllati',
    cameraHint: 'Posiziona la camera lateralmente per mostrare l’angolo a V e la traiettoria avanti.',
    cues: [
      'Forma un triangolo tra testa e mani in appoggio',
      'Gomiti chiusi verso l’interno, non larghi',
      'Spingi fino a elevare le spalle in alto',
    ],
  },
  {
    id: 'skill_frog_stand',
    branchId: 'spinta_planche',
    order: 3,
    name: 'Frog Stand',
    prerequisiteId: 'skill_pike_pushup',
    mode: 'isometric',
    targetValue: 15,
    requirementLabel: 'Mantieni il Frog Stand per 15 secondi',
    cameraHint: 'Inquadra mani e corpo di lato per verificare i piedi staccati da terra.',
    cues: [
      'Dita ben aperte che afferrano il pavimento',
      'Ginocchia stabili sui tricipiti',
      'Sguardo 30 cm avanti alle mani',
    ],
  },
  {
    id: 'skill_tuck_planche',
    branchId: 'spinta_planche',
    order: 4,
    name: 'Tuck Planche',
    prerequisiteId: 'skill_frog_stand',
    mode: 'isometric',
    targetValue: 10,
    requirementLabel: 'Mantieni la Tuck Planche per 10 secondi',
    cameraHint: 'Inquadra di profilo a terra o su parallettes per mostrare braccia tese e bacino alto.',
    cues: [
      'Gomiti bloccati completamente tesi (zero flessione)',
      'Scapole in protrazione e depressione massima',
      'Bacino sollevato all’altezza delle spalle',
    ],
  },
  {
    id: 'skill_planche',
    branchId: 'spinta_planche',
    order: 5,
    name: 'Planche',
    prerequisiteId: 'skill_tuck_planche',
    mode: 'isometric',
    targetValue: 5,
    requirementLabel: 'Mantieni la Full Planche per 5 secondi',
    cameraHint: 'Inquadra tutto il corpo di profilo a braccia tese orizzontale al suolo.',
    cues: [
      'Linea orizzontale parallela al suolo da spalle a punte',
      'Braccia bloccate e forte lean anteriore',
      'Glutei e addome contratti al 100%',
    ],
  },

  // Ramo Leve / Core: Hanging Leg Raises -> L-Sit -> Tuck Front Lever -> Front Lever
  {
    id: 'skill_hanging_leg_raises',
    branchId: 'leve_core',
    order: 1,
    name: 'Hanging Leg Raises',
    prerequisiteId: null,
    mode: 'reps',
    targetValue: 8,
    requirementLabel: 'Esegui 8 Hanging Leg Raises a gambe tese',
    cameraHint: 'Inquadra tutto il corpo appeso alla sbarra di profilo per vedere l’angolo delle gambe.',
    cues: [
      'Gambe completamente distese e unite',
      'Solleva i piedi oltre i 90° senza dondolare',
      'Frena la fase di discesa',
    ],
  },
  {
    id: 'skill_l_sit',
    branchId: 'leve_core',
    order: 2,
    name: 'L-Sit',
    prerequisiteId: 'skill_hanging_leg_raises',
    mode: 'isometric',
    targetValue: 15,
    requirementLabel: 'Mantieni la L-Sit per 15 secondi',
    cameraHint: 'Inquadra di profilo a terra o su parallettes per verificare angolo a 90° e ginocchia tese.',
    cues: [
      'Spalle depresse lontane dalle orecchie',
      'Gambe tese parallele al pavimento',
      'Anche leggermente spinte indietro tra le braccia',
    ],
  },
  {
    id: 'skill_tuck_front_lever',
    branchId: 'leve_core',
    order: 3,
    name: 'Tuck Front Lever',
    prerequisiteId: 'skill_l_sit',
    mode: 'isometric',
    targetValue: 12,
    requirementLabel: 'Mantieni il Tuck Front Lever per 12 secondi',
    cameraHint: 'Inquadra sbarra e corpo di profilo per controllare l’orizzontalità della schiena.',
    cues: [
      'Braccia tese che spingono la sbarra verso le cosce',
      'Schiena piatta parallela al suolo',
      'Scapole depresse e addotte',
    ],
  },
  {
    id: 'skill_front_lever',
    branchId: 'leve_core',
    order: 4,
    name: 'Front Lever',
    prerequisiteId: 'skill_tuck_front_lever',
    mode: 'isometric',
    targetValue: 5,
    requirementLabel: 'Mantieni il Front Lever completo per 5 secondi',
    cameraHint: 'Inquadra tutto il corpo sospeso alla sbarra di lato lungo l’asse orizzontale.',
    cues: [
      'Corpo perfettamente teso dalla testa ai piedi',
      'Linea parallela al suolo senza cedere col bacino',
      'Braccia distese con dorsali in massima tensione',
    ],
  },

  // Ramo Verticale: Wall Handstand -> Freestanding Handstand
  {
    id: 'skill_wall_handstand',
    branchId: 'verticale',
    order: 1,
    name: 'Wall Handstand',
    prerequisiteId: null,
    mode: 'isometric',
    targetValue: 30,
    requirementLabel: 'Mantieni la Verticale al muro per 30 secondi',
    cameraHint: 'Inquadra il muro lateralmente per vedere l’allineamento polsi-spalle-bacino-caviglie.',
    cues: [
      'Spinta attiva delle spalle verso il soffitto',
      'Addome in hollow senza inarcare i lombari',
      'Punte dei piedi unite e tese',
    ],
  },
  {
    id: 'skill_freestanding_handstand',
    branchId: 'verticale',
    order: 2,
    name: 'Freestanding Handstand',
    prerequisiteId: 'skill_wall_handstand',
    mode: 'isometric',
    targetValue: 10,
    requirementLabel: 'Mantieni la Verticale libera per 10 secondi',
    cameraHint: 'Inquadra l’intera altezza in verticale libera lontano dal muro.',
    cues: [
      'Bilancia la posizione premendo coi polpastrelli e palmi',
      'Linea verticale compatta senza compensi di schiena',
      'Sguardo fisso tra le mani',
    ],
  },
];

export const SKILL_NODE_MAP: Record<string, SkillNodeDefinition> = Object.fromEntries(
  SKILL_TREE_NODES.map((n) => [n.id, n])
);

export const WARMUP_PRESETS: Omit<WarmupExerciseItem, 'id' | 'completed'>[] = [
  {
    name: 'Rotazioni polsi e appoggi palmari',
    targetLabel: '2 × 30s',
    notes: 'Mobilità articolare in flessione, estensione e rotazioni lente',
  },
  {
    name: 'Circonduzioni spalle (elastico o bastone)',
    targetLabel: '2 × 12 rip',
    notes: 'Dislocazioni controllate a braccia tese per aprire la cuffia',
  },
  {
    name: 'Scapular Pull-up / Attivazione scapolare',
    targetLabel: '2 × 10 rip',
    notes: 'Depressione e adduzione scapolare senza piegare i gomiti',
  },
  {
    name: 'Plank di attivazione e Hollow Hold leggero',
    targetLabel: '2 × 25s',
    notes: 'Retroversione pelvica, protrazione scapolare e core compatto',
  },
  {
    name: 'Scapular Push-up a terra',
    targetLabel: '2 × 12 rip',
    notes: 'Protrazione e retrazione scapolare controllata in appoggio',
  },
  {
    name: 'Mobilità anche e caviglie (Deep Squat Hold)',
    targetLabel: '2 × 30s',
    notes: 'Talloni a terra, busto aperto e spinta leggera sulle ginocchia',
  },
];

export const STRETCH_PRESETS: Omit<StretchExerciseItem, 'id' | 'completed'>[] = [
  {
    name: 'Allungamento dorsali alla sbarra o al muro',
    targetLabel: '2 × 30s',
    notes: 'Spingi il petto verso il basso mantenendo le braccia distese e respiro lento',
  },
  {
    name: 'Stretching pettorali e spalle al muro',
    targetLabel: '2 × 30s per lato',
    notes: 'Avambraccio in appoggio e leggera torsione controllata del busto',
  },
  {
    name: 'Cobra Stretch per addome e flessori',
    targetLabel: '2 × 30s',
    notes: 'Bacino rilassato verso terra, spalle lontane dalle orecchie',
  },
  {
    name: 'Piega in avanti per femorali (Forward Fold)',
    targetLabel: '2 × 35s',
    notes: 'Schiena lunga, fletti dalle anche lasciando scendere il busto senza forzare',
  },
  {
    name: 'Mobilità e scarico polsi a terra',
    targetLabel: '2 × 25s',
    notes: 'Pressione leggera sul dorso e palmi delle mani per decomprimere i flessori',
  },
];

