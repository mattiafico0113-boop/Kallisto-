import { createRoot } from 'react-dom/client';
import { registerSW } from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

if (typeof window !== 'undefined' && 'serviceWorker' in navigator) {
  const hadController = Boolean(navigator.serviceWorker.controller);
  let hasReloadedOnUpdate = false;

  if (hadController) {
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (hasReloadedOnUpdate) return;
      hasReloadedOnUpdate = true;
      window.location.reload();
    });
  }

  registerSW({
    immediate: true,
    onRegisteredSW(_swUrl, registration) {
      if (!registration) return;

      // Controlla silenziosamente nuovi aggiornamenti ad ogni apertura e ogni 60s
      window.setInterval(() => {
        registration.update().catch(() => {});
      }, 60 * 1000);

      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
          registration.update().catch(() => {});
        }
      });
    },
  });
}

createRoot(document.getElementById('root')!).render(<App />);
