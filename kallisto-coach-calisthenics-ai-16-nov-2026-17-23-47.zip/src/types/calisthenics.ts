export type GoalType = 'forza' | 'ipertrofia' | 'skill' | 'ricomposizione';

export type SkillTarget =
  | 'muscle_up'
  | 'planche'
  | 'front_lever'
  | 'handstand'
  | 'human_flag'
  | 'pistol_squat';

export type AvatarBodyType = 'atletico_m' | 'atletico_f' | 'snello' | 'potente';
export type AvatarHairStyle = 'corto' | 'rasato' | 'ciuffo' | 'coda' | 'fascia_barba';
export type AvatarAuraTheme = 'blue' | 'cyan' | 'ice' | 'neon';
export type AvatarAccessoryId = 'polsini' | 'fascia' | 'canotta';

export interface AthleteAvatarConfig {
  bodyType: AvatarBodyType;
  hairStyle: AvatarHairStyle;
  auraTheme: AvatarAuraTheme;
  accessories: AvatarAccessoryId[];
}

export type EquipmentId =
  | 'sbarra'
  | 'parallele'
  | 'anelli'
  | 'elastici'
  | 'zavorra'
  | 'parallettes'
  | 'pavimento';

export type JointId =
  | 'polsi'
  | 'gomiti'
  | 'spalle'
  | 'lombare'
  | 'ginocchia';

export type WeekdayId = 'lun' | 'mar' | 'mer' | 'gio' | 'ven' | 'sab' | 'dom';

export type ExerciseCategory = 'Tirata' | 'Spinta' | 'Core' | 'Gambe' | 'Skill';

export type ExerciseType = 'reps' | 'isometric';

export type AnimationId =
  | 'pullup'
  | 'chinup'
  | 'australian_pullup'
  | 'ring_row'
  | 'archer_pullup'
  | 'explosive_pullup'
  | 'muscle_up'
  | 'dead_hang'
  | 'scapular_pullup'
  | 'skin_the_cat'
  | 'pushup'
  | 'diamond_pushup'
  | 'archer_pushup'
  | 'pseudo_planche_pushup'
  | 'pike_pushup'
  | 'hspu'
  | 'dip'
  | 'ring_dip'
  | 'korean_dip'
  | 'hanging_leg_raises'
  | 'knee_raises'
  | 'crunch'
  | 'situp'
  | 'bicycle_crunch'
  | 'russian_twist'
  | 'plank'
  | 'hollow_body'
  | 'lsit'
  | 'front_lever'
  | 'planche'
  | 'handstand'
  | 'squat'
  | 'pistol_squat'
  | 'lunges'
  | 'stretching_cobra_pike';

export interface ExerciseDefinition {
  id: string;
  animationId: AnimationId;
  name: string;
  category: ExerciseCategory;
  type: ExerciseType;
  equipment: EquipmentId[];
  requiresAnyOf?: EquipmentId[];
  difficulty: number;
  progressionChainId?: string;
  progressionOrder?: number;
  nextProgressionId?: string;
  prevProgressionId?: string;
  jointLoad: JointId[];
  safeAlternativeId?: string;
  variantHint: string;
  cues: string[];
  defaultRestSec: number;
  supportsWeight: boolean;
  isNegative?: boolean;
  negativeSeconds?: number;
}

export interface SetLog {
  id: string;
  targetValue: number; // reps or seconds
  actualValue: number;
  addedWeightKg: number;
  rpe: number | null;
  completed: boolean;
}

export interface WorkoutExerciseItem {
  instanceId: string;
  exerciseId: string;
  customName?: string;
  customCategory?: ExerciseCategory;
  variantNote: string;
  isIsometric: boolean;
  isNegative?: boolean;
  negativeSeconds?: number;
  restSeconds: number;
  technicalScore?: 1 | 2 | 3 | null;
  sets: SetLog[];
}

export interface WarmupExerciseItem {
  id: string;
  name: string;
  targetLabel: string; // es. "2 × 30s" o "2 × 12 rip"
  notes?: string;
  completed: boolean;
  isCustom?: boolean;
}

export interface StretchExerciseItem {
  id: string;
  name: string;
  targetLabel: string;
  notes?: string;
  completed: boolean;
  isCustom?: boolean;
}

export interface WorkoutDayPlan {
  id: string;
  dayNumber: number;
  weekday?: WeekdayId;
  title: string;
  splitLabel: string;
  focus: string;
  warmup?: WarmupExerciseItem[];
  stretch?: StretchExerciseItem[];
  exercises: WorkoutExerciseItem[];
}

export interface AthleteBaselines {
  pullups: number;
  dips: number;
  pushups: number;
  legRaises: number;
}

export interface AthleteProfile {
  name: string;
  goal: GoalType;
  targetSkill?: SkillTarget;
  ageYears?: number;
  heightCm?: number;
  weightKg?: number;
  avatar?: AthleteAvatarConfig;
  featuredTrophyIds?: string[];
  equipment: EquipmentId[];
  baselines: AthleteBaselines;
  daysPerWeek: number;
  trainingDays: WeekdayId[];
  reminderEnabled: boolean;
  reminderTime: string; // HH:MM
  injuries: JointId[];
  onboardingCompleted: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface CompletedExerciseRecord {
  exerciseId: string;
  exerciseName: string;
  category: ExerciseCategory;
  isIsometric: boolean;
  targetValue: number;
  sets: SetLog[];
  bestValue: number;
  totalVolume: number;
  avgRpe: number;
  maxAddedWeightKg: number;
  technicalScore?: 1 | 2 | 3 | null;
}

export interface WorkoutSessionLog {
  id: string;
  dateISO: string;
  dayPlanId: string;
  dayTitle: string;
  durationMinutes: number;
  durationSeconds?: number;
  exercises: CompletedExerciseRecord[];
  avgRpe: number;
  maxRpe: number;
  avgTechnicalScore?: number | null;
  stretchesCompletedCount?: number;
  coachFeedback?: string;
  moodNote?: string;
  jointAlerts?: JointId[];
}

export type CoachActionType =
  | 'increase_target'
  | 'advance_progression'
  | 'deload_volume'
  | 'joint_swap';

export interface CoachActionProposal {
  id: string;
  type: CoachActionType;
  title: string;
  description: string;
  exerciseId: string;
  exerciseName: string;
  newExerciseId?: string;
  newExerciseName?: string;
  newTargetDelta?: number;
  deloadMultiplier?: number;
  jointProtected?: JointId;
}

export interface CoachMessage {
  id: string;
  role: 'coach' | 'user';
  content: string;
  timestampISO: string;
  source?: 'puter';
  proposals?: CoachActionProposal[];
  appliedProposalIds?: string[];
  error?: boolean;
}

export type AppTab = 'scheda' | 'skill' | 'benessere' | 'coach' | 'storico' | 'profilo';

export type SkillBranchId = 'tirata' | 'spinta_planche' | 'leve_core' | 'verticale';

export interface SkillNodeDefinition {
  id: string;
  branchId: SkillBranchId;
  order: number;
  name: string;
  prerequisiteId: string | null;
  mode: 'reps' | 'isometric';
  targetValue: number; // reps or seconds
  requirementLabel: string;
  cameraHint: string;
  cues: string[];
}

export interface UnlockedSkillRecord {
  skillId: string;
  unlockedAtISO: string;
  certifiedBy: 'camera_mediapipe' | 'camera_vision' | 'timer_verified';
  achievedValue: number;
}

export interface ActiveTimerState {
  mode: 'rest' | 'isometric' | 'negative' | 'transition';
  exerciseName?: string;
  nextExerciseName?: string;
  partnerLabel?: string;
  exerciseInstanceId?: string;
  setId?: string;
  targetSeconds: number;
  negativeSeconds?: number;
  targetReps?: number;
  voiceEnabled?: boolean;
  handsFreeVoice?: boolean;
  autoStart?: boolean;
  externalAction?: { type: 'start' | 'stop'; nonce: number };
}

export interface UserAccount {
  id: string;
  email: string;
  passwordHash: string;
  salt: string;
  createdAt: string;
}

export interface AuthSession {
  accountId: string; // 'guest' or UserAccount.id
  email: string | null;
  isGuest: boolean;
}

export type SleepQuality = 'scarso' | 'medio' | 'ottimo';
export type EnergyLevel = 'bassa' | 'media' | 'alta';
export type MorningJointStatus = 'ok' | 'polsi' | 'gomiti' | 'spalle' | 'lombare';

export interface MorningCheckinRecord {
  id: string;
  dateKey: string; // YYYY-MM-DD local date
  timestampISO: string;
  sleepQuality: SleepQuality;
  energyLevel: EnergyLevel;
  jointStatus: MorningJointStatus;
  volumeAdapted?: boolean;
  jointProtectedApplied?: boolean;
}

export interface DailyNutritionLog {
  dateKey: string; // YYYY-MM-DD local date
  waterMl: number;
  proteinMeals: number;
  creatineTaken: boolean;
}

export interface BodyWeightEntry {
  id: string;
  dateISO: string;
  weightKg: number;
}

export type ManualWorkoutIntensity = 'leggera' | 'media' | 'alta';

export interface ComboFlowStep {
  id: string;
  exerciseId: string;
  name: string;
  isIsometric: boolean;
  targetValue: number; // reps or seconds
}

export interface ComboFlowPreset {
  id: string;
  name: string;
  steps: ComboFlowStep[];
  bestDurationSeconds?: number | null;
  createdAtISO: string;
}



