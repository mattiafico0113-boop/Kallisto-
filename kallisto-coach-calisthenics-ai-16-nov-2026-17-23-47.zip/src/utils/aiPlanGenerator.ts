import { EXERCISE_CATALOG, getExerciseById } from '../data/exercises';
import type {
  AthleteProfile,
  ExerciseCategory,
  WorkoutDayPlan,
  WorkoutExerciseItem,
} from '../types/calisthenics';
import { getWeekdayShort } from './notifications';
import {
  generateStretchingForDay,
  generateWarmupForDay,
  generateWeeklyProgram,
} from './programGenerator';

interface AiRawExercise {
  exerciseId?: string;
  name?: string;
  category?: string;
  isIsometric?: boolean;
  sets?: number;
  targetValue?: number;
  restSeconds?: number;
  variantNote?: string;
}

interface AiRawWarmupOrStretch {
  name?: string;
  targetLabel?: string;
  notes?: string;
}

interface AiRawDay {
  dayNumber?: number;
  title?: string;
  splitLabel?: string;
  focus?: string;
  warmup?: AiRawWarmupOrStretch[];
  exercises?: AiRawExercise[];
  stretch?: AiRawWarmupOrStretch[];
}

interface AiRawPlanResponse {
  days?: AiRawDay[];
}

function extractReplyText(result: unknown): string {
  if (typeof result === 'string') return result.trim();
  if (!result || typeof result !== 'object') return '';
  const obj = result as {
    message?: { content?: string | { text?: string }[] };
    text?: string;
    toString?: () => string;
  };
  const content = obj.message?.content;
  if (typeof content === 'string') return content.trim();
  if (Array.isArray(content)) {
    return content
      .map((b) => (typeof b === 'string' ? b : b?.text ?? ''))
      .join('\n')
      .trim();
  }
  if (typeof obj.text === 'string') return obj.text.trim();
  if (typeof obj.toString === 'function') {
    const s = obj.toString().trim();
    if (s && s !== '[object Object]') return s;
  }
  return '';
}

function parseAiPlanJson(rawText: string): AiRawPlanResponse | null {
  const cleaned = rawText
    .replace(/```json\s*/gi, '')
    .replace(/```\s*/g, '')
    .trim();

  const startIdx = cleaned.indexOf('{');
  const endIdx = cleaned.lastIndexOf('}');
  if (startIdx < 0 || endIdx <= startIdx) return null;

  try {
    const parsed = JSON.parse(cleaned.slice(startIdx, endIdx + 1)) as AiRawPlanResponse;
    if (parsed && Array.isArray(parsed.days) && parsed.days.length > 0) {
      return parsed;
    }
  } catch {
    return null;
  }
  return null;
}

function normalizeCategory(rawCat?: string): ExerciseCategory {
  const lower = (rawCat ?? '').toLowerCase();
  if (lower.includes('spint') || lower.includes('pett') || lower.includes('push')) return 'Spinta';
  if (lower.includes('tirat') || lower.includes('schien') || lower.includes('pull')) return 'Tirata';
  if (lower.includes('core') || lower.includes('addom')) return 'Core';
  if (lower.includes('gamb') || lower.includes('leg')) return 'Gambe';
  return 'Skill';
}

function uid(prefix: string): string {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 7)}`;
}

function hydrateAiExercise(raw: AiRawExercise): WorkoutExerciseItem | null {
  const matchedById = raw.exerciseId ? getExerciseById(raw.exerciseId) : undefined;
  const matchedByName =
    !matchedById && raw.name
      ? EXERCISE_CATALOG.find(
          (ex) => ex.name.toLowerCase() === raw.name!.trim().toLowerCase()
        )
      : undefined;

  const def = matchedById ?? matchedByName;
  const setsCount = Math.max(2, Math.min(6, Number(raw.sets) || 3));
  const isIsometric = def ? def.type === 'isometric' : Boolean(raw.isIsometric);
  const rawTarget = Number(raw.targetValue);
  const targetValue = Number.isFinite(rawTarget)
    ? Math.max(isIsometric ? 8 : 3, Math.min(90, Math.round(rawTarget)))
    : isIsometric
    ? 20
    : 8;
  const restSeconds = Math.max(
    45,
    Math.min(240, Number(raw.restSeconds) || def?.defaultRestSec || 90)
  );

  if (def) {
    return {
      instanceId: uid('ex'),
      exerciseId: def.id,
      variantNote: raw.variantNote?.trim() || def.variantHint,
      isIsometric: def.type === 'isometric',
      isNegative: def.isNegative,
      negativeSeconds: def.negativeSeconds,
      restSeconds,
      technicalScore: null,
      sets: Array.from({ length: setsCount }, () => ({
        id: uid('set'),
        targetValue,
        actualValue: targetValue,
        addedWeightKg: 0,
        rpe: null,
        completed: false,
      })),
    };
  }

  const customName = raw.name?.trim();
  if (!customName) return null;

  return {
    instanceId: uid('ex'),
    exerciseId: `ai_custom_${Math.random().toString(36).slice(2, 7)}`,
    customName,
    customCategory: normalizeCategory(raw.category),
    variantNote: raw.variantNote?.trim() || 'Esercizio selezionato dal Coach AI',
    isIsometric,
    restSeconds,
    technicalScore: null,
    sets: Array.from({ length: setsCount }, () => ({
      id: uid('set'),
      targetValue,
      actualValue: targetValue,
      addedWeightKg: 0,
      rpe: null,
      completed: false,
    })),
  };
}

export async function generateWeeklyPlanWithPuterAI(
  profile: AthleteProfile
): Promise<WorkoutDayPlan[]> {
  const chatFn = window.puter?.ai?.chat;
  if (typeof chatFn !== 'function') {
    throw new Error(
      'Puter.js non è pronto o non è stato caricato. Verifica la connessione Internet e riprova.'
    );
  }

  const catalogLines = EXERCISE_CATALOG.map(
    (ex) => `${ex.id} | ${ex.name} | ${ex.category} | ${ex.type}`
  ).join('\n');

  const weightHeightRatio =
    profile.weightKg && profile.heightCm && profile.heightCm > 0
      ? (profile.weightKg / profile.heightCm).toFixed(2)
      : 'non calcolabile';

  const skillLabel = profile.targetSkill
    ? profile.targetSkill.replace('_', ' ').toUpperCase()
    : 'Nessuna specifica (Forza generale)';

  const daysCount = Math.max(1, Math.min(6, profile.trainingDays?.length || profile.daysPerWeek || 3));

  const systemPrompt = `Sei un preparatore atletico esperto di Calisthenics.
Devi generare una scheda settimanale completa e personalizzata in italiano in formato STRICT JSON (zero testo extra fuori dal JSON).
Organizza gli esercizi mantenendo chiaramente le categorie: Riscaldamento ("warmup"), Petto/Spinta ("Spinta"), Schiena/Tirata ("Tirata"), Addome/Core ("Core"), Gambe ("Gambe"), Skill ("Skill") e Defaticamento finale ("stretch").
Rispetta attrezzatura disponibile, eventuali fastidi articolari, età, altezza, peso e massimali dell'atleta.

CATALOGO ESERCIZI VALIDI (usa preferibilmente esattamente questi exerciseId):
${catalogLines}

SCHEMA JSON ESATTO DA RESTITUIRE:
{
  "days": [
    {
      "dayNumber": 1,
      "title": "Giorno 1 — Titolo Allenamento",
      "splitLabel": "Spinta & Core",
      "focus": "Descrizione sintetica del focus",
      "warmup": [
        { "name": "Nome esercizio riscaldamento", "targetLabel": "2 × 30s", "notes": "Consiglio breve" }
      ],
      "exercises": [
        {
          "exerciseId": "id_dal_catalogo",
          "name": "Nome esercizio",
          "category": "Spinta",
          "isIsometric": false,
          "sets": 4,
          "targetValue": 8,
          "restSeconds": 90,
          "variantNote": "Nota tecnica breve"
        }
      ],
      "stretch": [
        { "name": "Nome stretching", "targetLabel": "2 × 30s", "notes": "Indicazione respirazione" }
      ]
    }
  ]
}`;

  const userPrompt = `Crea una scheda settimanale di esattamente ${daysCount} giorni per questo atleta:
- Nome: ${profile.name}
- Età: ${profile.ageYears ?? 'non indicata'} anni
- Altezza: ${profile.heightCm ?? 'non indicata'} cm
- Peso: ${profile.weightKg ?? 'non indicato'} kg (rapporto peso/altezza: ${weightHeightRatio} kg/cm)
- Obiettivo principale: ${profile.goal}
- Skill obiettivo principale: ${skillLabel}
- Giorni di allenamento (${daysCount}): ${profile.trainingDays.join(', ')}
- Attrezzatura disponibile: ${profile.equipment.join(', ')}
- Fastidi / infortuni da proteggere: ${profile.injuries.length > 0 ? profile.injuries.join(', ') : 'nessuno'}
- Massimali attuali: Pull-up ${profile.baselines.pullups}, Dip ${profile.baselines.dips}, Push-up ${profile.baselines.pushups}, Leg Raises ${profile.baselines.legRaises}.

Assicurati che nella settimana siano presenti esercizi di Spinta (Petto), Tirata (Schiena), Core (Addome), Gambe e propedeutiche verso ${skillLabel}, oltre a Riscaldamento e Stretching su ogni giorno.`;

  const result = await chatFn([
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt },
  ]);

  const replyText = extractReplyText(result);
  const parsed = parseAiPlanJson(replyText);

  if (!parsed || !parsed.days || parsed.days.length === 0) {
    throw new Error(
      'Il modello AI ha restituito un formato non valido per la scheda. Riprova tra qualche secondo.'
    );
  }

  const baseFallback = generateWeeklyProgram(profile);

  const hydratedDays: WorkoutDayPlan[] = parsed.days.slice(0, 7).map((rawDay, idx) => {
    const weekday = profile.trainingDays[idx];
    const fallbackDay = baseFallback[idx % baseFallback.length];
    const dayTitle = rawDay.title?.trim() || `Giorno ${idx + 1} — Calisthenics AI`;
    const baseSplit =
      rawDay.splitLabel?.trim() ||
      fallbackDay?.splitLabel?.replace(/^(Lun|Mar|Mer|Gio|Ven|Sab|Dom)\s·\s/i, '') ||
      `Giorno ${idx + 1}`;
    const splitLabel = weekday ? `${getWeekdayShort(weekday)} · ${baseSplit}` : baseSplit;

    const hydratedExercises = (rawDay.exercises ?? [])
      .map(hydrateAiExercise)
      .filter((ex): ex is WorkoutExerciseItem => ex !== null);

    const warmup =
      Array.isArray(rawDay.warmup) && rawDay.warmup.length > 0
        ? rawDay.warmup.map((w) => ({
            id: uid('warm'),
            name: w.name?.trim() || 'Mobilità articolare',
            targetLabel: w.targetLabel?.trim() || '2 × 30s',
            notes: w.notes?.trim() || 'Movimento lento e controllato',
            completed: false,
          }))
        : generateWarmupForDay(dayTitle, profile.equipment, profile.injuries);

    const stretch =
      Array.isArray(rawDay.stretch) && rawDay.stretch.length > 0
        ? rawDay.stretch.map((s) => ({
            id: uid('stretch'),
            name: s.name?.trim() || 'Allungamento post-allenamento',
            targetLabel: s.targetLabel?.trim() || '2 × 30s',
            notes: s.notes?.trim() || 'Respira profondamente durante il rilascio',
            completed: false,
          }))
        : generateStretchingForDay(dayTitle, profile.equipment);

    return {
      id: uid('day_ai'),
      dayNumber: idx + 1,
      weekday,
      title: dayTitle,
      splitLabel,
      focus: rawDay.focus?.trim() || `Focus ${skillLabel}`,
      warmup,
      stretch,
      exercises:
        hydratedExercises.length > 0
          ? hydratedExercises
          : fallbackDay?.exercises ?? [],
    };
  });

  if (hydratedDays.length === 0) {
    throw new Error('Impossibile costruire la scheda AI dai dati ricevuti.');
  }

  return hydratedDays;
}
