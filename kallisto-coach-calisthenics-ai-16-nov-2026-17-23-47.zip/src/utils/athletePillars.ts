import { EXERCISE_CATALOG, getExerciseById } from '../data/exercises';
import type {
  AthleteProfile,
  DailyNutritionLog,
  ExerciseCategory,
  ExerciseDefinition,
  JointId,
  ManualWorkoutIntensity,
  MorningCheckinRecord,
  MorningJointStatus,
  SkillNodeDefinition,
  UnlockedSkillRecord,
  WorkoutDayPlan,
  WorkoutExerciseItem,
  WorkoutSessionLog,
} from '../types/calisthenics';
import { calculateCalisthenics1RM } from './recoveryAndMissions';

export function getLocalDateKey(date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export interface NutritionTargets {
  caloriesKcal: number;
  caloriesLabel: string;
  proteinGrams: number;
  proteinMealsTarget: number;
  waterTargetMl: number;
  usingDefaultMetrics: boolean;
}

export function computeNutritionTargets(profile: AthleteProfile | null): NutritionTargets {
  const hasWeight = typeof profile?.weightKg === 'number' && profile.weightKg > 0;
  const hasHeight = typeof profile?.heightCm === 'number' && profile.heightCm > 0;
  const hasAge = typeof profile?.ageYears === 'number' && profile.ageYears > 0;

  const weight = hasWeight ? profile!.weightKg! : 70;
  const height = hasHeight ? profile!.heightCm! : 175;
  const age = hasAge ? profile!.ageYears! : 28;
  const days = Math.max(1, profile?.trainingDays?.length ?? profile?.daysPerWeek ?? 3);

  const bmr = 10 * weight + 6.25 * height - 5 * age + 5;
  const activityFactor = days >= 5 ? 1.62 : days === 4 ? 1.55 : days === 3 ? 1.48 : 1.4;
  const tdee = bmr * activityFactor;

  let goalDelta = 0;
  let caloriesLabel = 'Normocalorica (Ricomposizione)';
  if (profile?.goal === 'skill') {
    goalDelta = -180;
    caloriesLabel = 'Leggero deficit (Skill & leggerezza)';
  } else if (profile?.goal === 'ipertrofia') {
    goalDelta = 240;
    caloriesLabel = 'Leggero surplus (Ipertrofia)';
  } else if (profile?.goal === 'forza') {
    goalDelta = 100;
    caloriesLabel = 'Surplus controllato (Forza)';
  }

  const caloriesKcal = Math.max(1500, Math.round((tdee + goalDelta) / 10) * 10);
  const proteinPerKg = profile?.goal === 'skill' || profile?.goal === 'ricomposizione' ? 2.0 : 1.85;
  const proteinGrams = Math.round(weight * proteinPerKg);
  const proteinMealsTarget = Math.max(3, Math.min(5, Math.round(proteinGrams / 35)));
  const waterTargetMl = Math.max(1800, Math.round((weight * 35) / 50) * 50);

  return {
    caloriesKcal,
    caloriesLabel,
    proteinGrams,
    proteinMealsTarget,
    waterTargetMl,
    usingDefaultMetrics: !hasWeight || !hasHeight || !hasAge,
  };
}

export function computeCreatineConsistencyDays(logs: DailyNutritionLog[]): number {
  return logs.filter((l) => l.creatineTaken).length;
}

export function formatMorningCheckinSummary(c: MorningCheckinRecord): string {
  const sleepMap = {
    scarso: 'Sonno scarso (<6h)',
    medio: 'Sonno nella media (6-7h)',
    ottimo: 'Sonno ottimo (8h+)',
  } as const;
  const energyMap = {
    bassa: 'Energia bassa',
    media: 'Energia media',
    alta: 'Energia alta',
  } as const;
  const jointMap = {
    ok: 'Articolazioni OK',
    polsi: 'Fastidio Polsi',
    gomiti: 'Fastidio Gomiti',
    spalle: 'Fastidio Spalle',
    lombare: 'Fastidio Zona Lombare',
  } as const;
  return `${sleepMap[c.sleepQuality]} | ${energyMap[c.energyLevel]} | ${jointMap[c.jointStatus]}`;
}

export function isExerciseStressedByJoint(
  exerciseId: string,
  customName: string | undefined,
  jointStatus: MorningJointStatus
): boolean {
  if (jointStatus === 'ok') return false;
  const joint = jointStatus as JointId;
  const def = getExerciseById(exerciseId);
  if (def && def.jointLoad.includes(joint)) {
    return true;
  }

  const nameLow = (customName ?? def?.name ?? exerciseId).toLowerCase();
  if (joint === 'polsi') {
    return (
      nameLow.includes('planche') ||
      nameLow.includes('handstand') ||
      nameLow.includes('verticale') ||
      nameLow.includes('push-up') ||
      nameLow.includes('pike') ||
      nameLow.includes('hspu')
    );
  }
  if (joint === 'gomiti') {
    return (
      nameLow.includes('dip') ||
      nameLow.includes('chin') ||
      nameLow.includes('pull-up') ||
      nameLow.includes('trazion') ||
      nameLow.includes('muscle') ||
      nameLow.includes('lever') ||
      nameLow.includes('planche')
    );
  }
  if (joint === 'spalle') {
    return (
      nameLow.includes('dip') ||
      nameLow.includes('hspu') ||
      nameLow.includes('pike') ||
      nameLow.includes('handstand') ||
      nameLow.includes('planche') ||
      nameLow.includes('skin the cat')
    );
  }
  if (joint === 'lombare') {
    return (
      nameLow.includes('lever') ||
      nameLow.includes('hollow') ||
      nameLow.includes('leg raises') ||
      nameLow.includes('l-sit') ||
      nameLow.includes('plank')
    );
  }
  return false;
}

export function pickSafeAlternativeForJoint(
  exerciseId: string,
  category: ExerciseCategory,
  jointStatus: MorningJointStatus
): ExerciseDefinition | null {
  if (jointStatus === 'ok') return null;
  const joint = jointStatus as JointId;
  const currentDef = getExerciseById(exerciseId);

  if (currentDef?.safeAlternativeId) {
    const direct = getExerciseById(currentDef.safeAlternativeId);
    if (direct && !direct.jointLoad.includes(joint)) {
      return direct;
    }
  }

  const sameCatSafe = EXERCISE_CATALOG.filter(
    (ex) =>
      ex.id !== exerciseId &&
      ex.category === category &&
      !ex.jointLoad.includes(joint)
  ).sort((a, b) => a.difficulty - b.difficulty);

  if (sameCatSafe.length > 0) {
    if (currentDef) {
      sameCatSafe.sort(
        (a, b) =>
          Math.abs(a.difficulty - currentDef.difficulty) -
          Math.abs(b.difficulty - currentDef.difficulty)
      );
    }
    return sameCatSafe[0];
  }

  // Fallback across catalog preferring lower difficulty safe exercises
  const anySafe = EXERCISE_CATALOG.filter(
    (ex) => ex.id !== exerciseId && !ex.jointLoad.includes(joint)
  ).sort((a, b) => a.difficulty - b.difficulty);
  return anySafe[0] ?? null;
}

/**
 * Picks 3 equivalent exercises in the same muscle group for "Attrezzo Occupato" quick swap,
 * prioritizing exercises that use different equipment (e.g. Parallels busy -> Push-up variants).
 */
export function pickOccupiedAlternatives(
  item: WorkoutExerciseItem
): ExerciseDefinition[] {
  const currentDef = getExerciseById(item.exerciseId);
  const category = item.customCategory ?? currentDef?.category ?? 'Spinta';
  const currentEq = new Set(currentDef?.equipment ?? []);

  const candidates = EXERCISE_CATALOG.filter(
    (ex) => ex.id !== item.exerciseId && ex.category === category
  );

  const scored = candidates.map((ex) => {
    const sharesPrimaryEquipment = ex.equipment.some((eq) => currentEq.has(eq));
    const diffGap = currentDef ? Math.abs(ex.difficulty - currentDef.difficulty) : 0;
    const typeMatch = currentDef ? (ex.type === currentDef.type ? 0 : 1) : 0;
    // Lower score = better quick replacement when equipment is occupied
    const score = (sharesPrimaryEquipment ? 10 : 0) + typeMatch * 3 + diffGap;
    return { ex, score };
  });

  scored.sort((a, b) => a.score - b.score);

  // Also ensure safe variety when all share floor equipment
  if (scored.length >= 3) {
    return scored.slice(0, 3).map((s) => s.ex);
  }

  // If category has fewer than 3 alternatives (e.g. small category), top up from catalog
  const selected = scored.map((s) => s.ex);
  for (const ex of EXERCISE_CATALOG) {
    if (selected.length >= 3) break;
    if (ex.id !== item.exerciseId && !selected.some((s) => s.id === ex.id)) {
      selected.push(ex);
    }
  }
  return selected.slice(0, 3);
}

export interface RelativeStrengthMetrics {
  bodyWeightKg: number;
  bestPullOneRmTotalKg: number;
  bestPullAddedKg: number;
  pullRatio: number; // total 1RM / BW (e.g. 1.32x)
  bestDipOneRmTotalKg: number;
  bestDipAddedKg: number;
  dipRatio: number;
  combinedRatio: number;
  efficiencyScore: number; // 0..100
  readinessLabel: string;
  readinessDetail: string;
}

export function computeRelativeStrengthMetrics(
  profile: AthleteProfile | null,
  history: WorkoutSessionLog[],
  overrideWeightKg?: number
): RelativeStrengthMetrics {
  const bw = Math.max(
    35,
    overrideWeightKg && overrideWeightKg > 0
      ? overrideWeightKg
      : profile?.weightKg && profile.weightKg > 0
      ? profile.weightKg
      : 70
  );

  // Start from onboarding baselines
  let bestPullOneRm = calculateCalisthenics1RM({
    bodyWeightKg: bw,
    addedWeightKg: 0,
    reps: Math.max(1, profile?.baselines?.pullups ?? 6),
  }).oneRmTotalKg;

  let bestDipOneRm = calculateCalisthenics1RM({
    bodyWeightKg: bw,
    addedWeightKg: 0,
    reps: Math.max(1, profile?.baselines?.dips ?? 8),
  }).oneRmTotalKg;

  for (const sess of history) {
    for (const ex of sess.exercises) {
      if (ex.isIsometric) continue;
      const idLow = ex.exerciseId.toLowerCase();
      const nameLow = ex.exerciseName.toLowerCase();
      const isPull =
        idLow.includes('pullup') ||
        idLow.includes('chin') ||
        nameLow.includes('trazion') ||
        nameLow.includes('pull-up');
      const isDip = idLow.includes('dip') || nameLow.includes('dip');

      if (!isPull && !isDip) continue;

      for (const st of ex.sets) {
        if (!st.completed || st.actualValue <= 0) continue;
        const est = calculateCalisthenics1RM({
          bodyWeightKg: bw,
          addedWeightKg: Math.max(0, st.addedWeightKg || 0),
          reps: Math.min(20, st.actualValue),
        }).oneRmTotalKg;

        if (isPull) {
          bestPullOneRm = Math.max(bestPullOneRm, est);
        }
        if (isDip) {
          bestDipOneRm = Math.max(bestDipOneRm, est);
        }
      }
    }
  }

  const pullRatio = Math.round((bestPullOneRm / bw) * 100) / 100;
  const dipRatio = Math.round((bestDipOneRm / bw) * 100) / 100;
  const combinedRatio = Math.round(((pullRatio + dipRatio) / 2) * 100) / 100;

  // Efficiency Score calibrated for Calisthenics: 1.0x = ~35, 1.35x = ~68, 1.65x = ~95
  const rawScore = ((combinedRatio - 0.85) / 0.85) * 85 + 15;
  const efficiencyScore = Math.max(15, Math.min(100, Math.round(rawScore)));

  let readinessLabel = 'Costruzione Base';
  let readinessDetail =
    'Consolida trazioni e dip strict per alzare il rapporto forza/peso prima delle leve avanzate.';
  if (combinedRatio >= 1.55) {
    readinessLabel = 'Elite · Skill Ready';
    readinessDetail =
      'Rapporto peso/potenza eccellente per sbloccare Planche, Front Lever e Muscle-up strict.';
  } else if (combinedRatio >= 1.32) {
    readinessLabel = 'Avanzato';
    readinessDetail =
      'Ottima forza relativa: sei pronto per propedeutiche intermedie di Front Lever e Planche.';
  } else if (combinedRatio >= 1.15) {
    readinessLabel = 'Intermedio';
    readinessDetail =
      'Buon equilibrio corporeo: aggiungi piccole zavorre o progressioni pulite per accelerare.';
  }

  return {
    bodyWeightKg: bw,
    bestPullOneRmTotalKg: Math.round(bestPullOneRm * 10) / 10,
    bestPullAddedKg: Math.round((bestPullOneRm - bw) * 10) / 10,
    pullRatio,
    bestDipOneRmTotalKg: Math.round(bestDipOneRm * 10) / 10,
    bestDipAddedKg: Math.round((bestDipOneRm - bw) * 10) / 10,
    dipRatio,
    combinedRatio,
    efficiencyScore,
    readinessLabel,
    readinessDetail,
  };
}

export interface BrokenRecordItem {
  exerciseName: string;
  valueLabel: string;
}

export interface PostWorkoutSummaryData {
  session: WorkoutSessionLog;
  dateFormatted: string;
  durationFormatted: string;
  totalReps: number;
  totalIsoSeconds: number;
  completedSetsCount: number;
  avgTechScore: number | null;
  techVerdictLabel: string;
  brokenRecords: BrokenRecordItem[];
  xpEarned: number;
}

export function computePostWorkoutSummary(
  session: WorkoutSessionLog,
  previousHistory: WorkoutSessionLog[]
): PostWorkoutSummaryData {
  const totalSec =
    typeof session.durationSeconds === 'number' && session.durationSeconds > 0
      ? session.durationSeconds
      : Math.max(60, Math.round((session.durationMinutes || 1) * 60));
  const mins = Math.floor(totalSec / 60);
  const secs = totalSec % 60;
  const durationFormatted = `${mins} min ${String(secs).padStart(2, '0')} sec`;

  const dateFormatted = new Date(session.dateISO).toLocaleDateString('it-IT', {
    weekday: 'long',
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  let totalReps = 0;
  let totalIsoSeconds = 0;
  let completedSetsCount = 0;
  const brokenRecords: BrokenRecordItem[] = [];

  for (const ex of session.exercises) {
    const doneSets = ex.sets.filter((s) => s.completed);
    completedSetsCount += doneSets.length;
    const evalSets = doneSets.length > 0 ? doneSets : ex.sets;

    for (const st of evalSets) {
      if (ex.isIsometric) {
        totalIsoSeconds += Math.max(0, st.actualValue || 0);
      } else {
        totalReps += Math.max(0, st.actualValue || 0);
      }
    }

    let prevBest = 0;
    for (const prev of previousHistory) {
      if (prev.id === session.id) continue;
      const match = prev.exercises.find((pe) => pe.exerciseId === ex.exerciseId);
      if (match) {
        prevBest = Math.max(prevBest, match.bestValue);
      }
    }
    if (prevBest > 0 && ex.bestValue > prevBest) {
      brokenRecords.push({
        exerciseName: ex.exerciseName,
        valueLabel: `${ex.bestValue}${ex.isIsometric ? 's' : ' rep'}`,
      });
    }
  }

  const techScores = session.exercises
    .map((e) => e.technicalScore)
    .filter((v): v is 1 | 2 | 3 => v === 1 || v === 2 || v === 3);
  const avgTechScore =
    techScores.length > 0
      ? Math.round((techScores.reduce((a, b) => a + b, 0) / techScores.length) * 10) / 10
      : null;

  let techVerdictLabel = 'Da valutare';
  if (avgTechScore !== null) {
    if (avgTechScore >= 2.6) techVerdictLabel = 'Esecuzione Pulita';
    else if (avgTechScore >= 1.8) techVerdictLabel = 'Buon Controllo';
    else techVerdictLabel = 'Da Consolidare';
  }

  // Matches rpgProgression.ts XP per session + extra record XP highlight
  const xpEarned =
    110 +
    Math.min(40, (completedSetsCount || session.exercises.length * 3) * 2) +
    brokenRecords.length * 25;

  return {
    session,
    dateFormatted,
    durationFormatted,
    totalReps,
    totalIsoSeconds,
    completedSetsCount,
    avgTechScore,
    techVerdictLabel,
    brokenRecords,
    xpEarned,
  };
}

// ==================== SMART TENDON HEALTH JOURNAL (10-DAY WINDOW) ====================

export interface TendonAlertItem {
  joint: Exclude<MorningJointStatus, 'ok'>;
  jointLabel: string;
  daysFlagged: number;
  lastDateKey: string;
  recommendation: string;
}

const JOINT_DISPLAY_LABELS: Record<Exclude<MorningJointStatus, 'ok'>, string> = {
  polsi: 'Polsi',
  gomiti: 'Gomiti',
  spalle: 'Spalle',
  lombare: 'Zona Lombare',
};

export function analyzeTendonHealthAlerts(
  checkins: MorningCheckinRecord[],
  now = new Date()
): TendonAlertItem[] {
  const cutoffMs = now.getTime() - 10 * 86400000;
  const byJoint = new Map<Exclude<MorningJointStatus, 'ok'>, Set<string>>();
  const latestByJoint = new Map<Exclude<MorningJointStatus, 'ok'>, string>();

  for (const c of checkins) {
    if (c.jointStatus === 'ok') continue;
    const ms = new Date(c.timestampISO || `${c.dateKey}T12:00:00`).getTime();
    if (!Number.isFinite(ms) || ms < cutoffMs) continue;

    const joint = c.jointStatus;
    const set = byJoint.get(joint) ?? new Set<string>();
    set.add(c.dateKey);
    byJoint.set(joint, set);

    const prevLatest = latestByJoint.get(joint);
    if (!prevLatest || c.dateKey > prevLatest) {
      latestByJoint.set(joint, c.dateKey);
    }
  }

  const alerts: TendonAlertItem[] = [];
  for (const [joint, dateSet] of byJoint.entries()) {
    if (dateSet.size >= 2) {
      const jointLabel = JOINT_DISPLAY_LABELS[joint];
      alerts.push({
        joint,
        jointLabel,
        daysFlagged: dateSet.size,
        lastDateKey: latestByJoint.get(joint) ?? getLocalDateKey(now),
        recommendation: `Hai segnalato fastidio a ${jointLabel} per ${dateSet.size} giorni negli ultimi 10 giorni. Consigliamo 48 ore di scarico sui carichi diretti e l'esecuzione della routine Prehab mirata.`,
      });
    }
  }

  return alerts.sort((a, b) => b.daysFlagged - a.daysFlagged);
}

// ==================== EXPRESS WORKOUT TIME GENERATOR (15/30/45/60 MIN) ====================

export type ExpressMinutesOption = 15 | 30 | 45 | 60;

export function adaptExercisesForTimeBudget(
  dayPlan: WorkoutDayPlan,
  minutes: ExpressMinutesOption
): WorkoutExerciseItem[] {
  const source = dayPlan.exercises;
  if (source.length === 0) return [];

  const maxExercises =
    minutes === 15 ? 3 : minutes === 30 ? 4 : minutes === 45 ? Math.min(6, source.length) : source.length;
  const targetSets = minutes === 15 ? 2 : minutes === 30 ? 3 : minutes === 45 ? 3 : 4;
  const restMultiplier = minutes === 15 ? 0.55 : minutes === 30 ? 0.72 : minutes === 45 ? 0.9 : 1.05;

  const picked = source.slice(0, maxExercises);

  return picked.map((ex, idx) => {
    const restSec = Math.max(
      35,
      Math.min(180, Math.round((ex.restSeconds * restMultiplier) / 5) * 5)
    );
    const baseSet = ex.sets[0];
    const desiredSets = minutes === 60 && idx < 2 ? Math.max(4, ex.sets.length) : targetSets;
    const nextSets = Array.from({ length: desiredSets }, (_, sIdx) => {
      const existing = ex.sets[sIdx];
      if (existing) {
        return { ...existing, completed: false };
      }
      return {
        id: `exp_${minutes}_${ex.instanceId}_${sIdx}`,
        targetValue: baseSet?.targetValue ?? (ex.isIsometric ? 15 : 8),
        actualValue: baseSet?.targetValue ?? (ex.isIsometric ? 15 : 8),
        addedWeightKg: baseSet?.addedWeightKg ?? 0,
        rpe: null,
        completed: false,
      };
    });

    return {
      ...ex,
      restSeconds: restSec,
      sets: nextSets,
    };
  });
}

// ==================== SKILL UNLOCK DAYS SIMULATOR ====================

export interface SkillUnlockEstimate {
  estimatedDays: number;
  readinessPct: number;
  weeklySessionsRate: number;
  avgTechScore: number | null;
  label: string;
}

export function estimateSkillUnlockDays(params: {
  skill: SkillNodeDefinition;
  allNodes: SkillNodeDefinition[];
  unlockedSkills: UnlockedSkillRecord[];
  history: WorkoutSessionLog[];
  manualWorkoutDays?: Record<string, ManualWorkoutIntensity>;
  profile?: AthleteProfile | null;
}): SkillUnlockEstimate {
  const { skill, allNodes, unlockedSkills, history, manualWorkoutDays = {}, profile } = params;
  const unlockedIds = new Set(unlockedSkills.map((u) => u.skillId));

  // Walk prerequisite chain depth remaining
  let remainingChain = 1;
  let cursor = skill;
  const guard = new Set<string>();
  while (cursor.prerequisiteId && !unlockedIds.has(cursor.prerequisiteId) && !guard.has(cursor.id)) {
    guard.add(cursor.id);
    remainingChain += 1;
    const parent = allNodes.find((n) => n.id === cursor.prerequisiteId);
    if (!parent) break;
    cursor = parent;
  }

  // Training frequency over last 28 days (history + manual logs)
  const cutoff28 = Date.now() - 28 * 86400000;
  const recentKeys = new Set<string>();
  for (const s of history) {
    const ms = new Date(s.dateISO).getTime();
    if (Number.isFinite(ms) && ms >= cutoff28) {
      recentKeys.add(s.dateISO.slice(0, 10));
    }
  }
  for (const dk of Object.keys(manualWorkoutDays)) {
    const ms = new Date(`${dk}T12:00:00`).getTime();
    if (Number.isFinite(ms) && ms >= cutoff28) {
      recentKeys.add(dk);
    }
  }
  const plannedWeekly = profile?.trainingDays?.length ?? profile?.daysPerWeek ?? 3;
  const observedWeekly = recentKeys.size > 0 ? Math.max(1.5, recentKeys.size / 4) : plannedWeekly;
  const weeklySessionsRate = Math.round(((observedWeekly * 0.65 + plannedWeekly * 0.35)) * 10) / 10;

  // Average technical score across recent sessions
  const techValues: number[] = [];
  for (const s of history.slice(0, 8)) {
    for (const ex of s.exercises) {
      if (ex.technicalScore === 1 || ex.technicalScore === 2 || ex.technicalScore === 3) {
        techValues.push(ex.technicalScore);
      }
    }
  }
  const avgTechScore =
    techValues.length > 0
      ? Math.round((techValues.reduce((a, b) => a + b, 0) / techValues.length) * 10) / 10
      : null;

  // Bodyweight leverage factor (lighter BW relative to height accelerates static skills)
  const bw = profile?.weightKg ?? 72;
  const ht = profile?.heightCm ?? 175;
  const bmi = bw / ((ht / 100) ** 2);
  const leverageFactor = bmi <= 22.5 ? 0.9 : bmi <= 25 ? 1.0 : 1.16;

  // Base days by tier order (1..3/4)
  const baseTierDays = skill.order === 1 ? 14 : skill.order === 2 ? 26 : skill.order === 3 ? 42 : 60;
  const freqFactor = Math.max(0.68, Math.min(1.45, 3.2 / Math.max(1, weeklySessionsRate)));
  const techFactor =
    avgTechScore === null ? 1.0 : avgTechScore >= 2.6 ? 0.82 : avgTechScore >= 2.0 ? 1.0 : 1.24;
  const chainMultiplier = 1 + (remainingChain - 1) * 0.55;

  const estimatedDays = Math.max(
    5,
    Math.min(180, Math.round(baseTierDays * freqFactor * techFactor * leverageFactor * chainMultiplier))
  );

  const readinessRaw =
    (unlockedIds.has(skill.prerequisiteId ?? '') || !skill.prerequisiteId ? 48 : 22) +
    Math.min(28, Math.round(weeklySessionsRate * 7)) +
    (avgTechScore !== null ? Math.round((avgTechScore / 3) * 20) : 10);
  const readinessPct = Math.max(18, Math.min(94, readinessRaw));

  return {
    estimatedDays,
    readinessPct,
    weeklySessionsRate,
    avgTechScore,
    label: `Ritmo attuale: sblocco stimato tra circa ${estimatedDays} giorni`,
  };
}

