let audioCtx: AudioContext | null = null;

const SFX_ENABLED_KEY = 'kallisto_sfx_enabled';

export function isSoundEffectsEnabled(): boolean {
  if (typeof window === 'undefined') return true;
  try {
    const raw = window.localStorage.getItem(SFX_ENABLED_KEY);
    return raw === null ? true : raw === 'true';
  } catch {
    return true;
  }
}

export function setSoundEffectsEnabled(enabled: boolean): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(SFX_ENABLED_KEY, enabled ? 'true' : 'false');
  } catch {
    // Ignore storage quota errors
  }
}

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  const Ctx =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return null;
  if (!audioCtx) {
    audioCtx = new Ctx();
  }
  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export function playTone(
  freq = 880,
  durationMs = 140,
  type: OscillatorType = 'sine',
  volume = 0.16,
  delaySec = 0
) {
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const startAt = ctx.currentTime + delaySec;
    const endAt = startAt + durationMs / 1000;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, startAt);
    gain.gain.setValueAtTime(0.001, startAt);
    gain.gain.linearRampToValueAtTime(volume, startAt + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.001, endAt);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(startAt);
    osc.stop(endAt + 0.01);
  } catch {
    // Ignore audio blocked errors
  }
}

export function playTimerCompleteChime() {
  if (!isSoundEffectsEnabled()) return;
  playTone(784, 120, 'triangle', 0.18);
  setTimeout(() => playTone(1046.5, 220, 'triangle', 0.2), 140);
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([120, 60, 180]);
    } catch {
      // Ignore vibration errors
    }
  }
}

export function warmUpAudio() {
  try {
    getAudioContext();
  } catch {
    // Ignore audio context warmup errors
  }
}

export function playDoubleDing() {
  // Bright double "ding" chime using native AudioContext (zero external files)
  playTone(1174.66, 170, 'sine', 0.24);
  playTone(1760.0, 120, 'triangle', 0.1);
  setTimeout(() => {
    playTone(1567.98, 280, 'sine', 0.26);
    playTone(2349.32, 200, 'triangle', 0.11);
  }, 165);
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate([100, 60, 180]);
    } catch {
      // Ignore vibration errors
    }
  }
}

export function playTickBeep(high = false) {
  if (!isSoundEffectsEnabled()) return;
  playTone(high ? 1174.66 : 660, high ? 180 : 80, 'sine', 0.14);
}

/**
 * Click morbido tech su pulsanti principali o cambio tab nella barra inferiore
 */
export function playTechClick() {
  if (!isSoundEffectsEnabled()) return;
  playTone(540, 38, 'sine', 0.065);
  playTone(1080, 28, 'triangle', 0.03, 0.012);
}

/**
 * Tono positivo ascendente quando si completa una serie o si assegna un voto tecnico (1-2-3)
 */
export function playSetCompleteTone() {
  if (!isSoundEffectsEnabled()) return;
  playTone(659.25, 95, 'sine', 0.12, 0);
  playTone(880.0, 120, 'triangle', 0.12, 0.065);
  playTone(1174.66, 170, 'sine', 0.11, 0.13);
}

/**
 * Breve fanfara elettronica futuristica + leggera vibrazione su Level Up / Sblocco Skill
 */
export function playLevelUpFanfare() {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
    try {
      navigator.vibrate(100);
    } catch {
      // Ignore vibration errors
    }
  }
  if (!isSoundEffectsEnabled()) return;
  playTone(523.25, 110, 'triangle', 0.14, 0);
  playTone(659.25, 110, 'triangle', 0.14, 0.085);
  playTone(783.99, 130, 'triangle', 0.15, 0.17);
  playTone(1046.5, 290, 'sine', 0.19, 0.255);
  playTone(1567.98, 220, 'triangle', 0.09, 0.27);
}
