import type { AnimationId, ExerciseCategory } from '../types/calisthenics';

export interface Point2D {
  x: number;
  y: number;
}

export type ApparatusType =
  | 'high_bar'
  | 'mid_bar'
  | 'mid_bar_behind'
  | 'low_bar'
  | 'rings_low'
  | 'rings_high'
  | 'parallel_bars'
  | 'parallettes'
  | 'floor'
  | 'floor_bench_back'
  | 'elevated_box_rear'
  | 'wall_floor'
  | 'ankle_anchor'
  | 'step';

export type MuscleGroupId =
  | 'lats'
  | 'biceps'
  | 'triceps'
  | 'chest'
  | 'shoulders'
  | 'abs'
  | 'obliques'
  | 'lowerBack'
  | 'quads'
  | 'glutesHamstrings'
  | 'calves'
  | 'forearms';

export interface MotionArrow {
  from: Point2D;
  to: Point2D;
  curved?: boolean;
  ctrl?: Point2D;
}

export interface BiomechanicalPose {
  apparatus: ApparatusType;
  barY?: number;
  barX?: number;
  wallX?: number;
  /** Render far limb at full contrast (used for frontal/bilateral poses like archer, russian twist, bicycle, ring dip) */
  bilateralFront?: boolean;
  /** Optional diamond hand stencil on floor for diamond push-ups */
  diamondHandPos?: Point2D;
  /** Optional micro technique annotation inside SVG */
  techniqueTag?: string;
  /** Optional ring anchor positions */
  ringAnchors?: { left: Point2D; right: Point2D };
  /** Primary visible side */
  head: Point2D;
  neck: Point2D;
  shoulder: Point2D;
  elbow: Point2D;
  wrist: Point2D;
  pelvis: Point2D;
  knee: Point2D;
  ankle: Point2D;
  footTip: Point2D;
  /** Optional second limb (far side or bilateral left/right pair) */
  shoulderFar?: Point2D;
  elbowFar?: Point2D;
  wristFar?: Point2D;
  kneeFar?: Point2D;
  ankleFar?: Point2D;
  footTipFar?: Point2D;
  /** Visual trajectory guide arrows */
  arrows: MotionArrow[];
  /** Optional alignment laser line */
  guideLine?: { p1: Point2D; p2: Point2D };
}

export interface BiomechExerciseSpec {
  key: AnimationId;
  isIsometric: boolean;
  apparatusLabel: string;
  activeMuscles: MuscleGroupId[];
  muscleSummaryLabel: string;
  phase1Label: string;
  phase2Label: string;
  phase1Detail: string;
  phase2Detail: string;
  phase3Detail: string;
  commonMistake: string;
  /** Exact animation t values [0..1] mapped to the 3 interactive phase buttons */
  phase1Progress: number;
  phase2Progress: number;
  phase3Progress: number;
}

export const MUSCLE_LABELS_IT: Record<MuscleGroupId, string> = {
  lats: 'Dorsali',
  biceps: 'Bicipiti',
  triceps: 'Tricipiti',
  chest: 'Petto',
  shoulders: 'Deltoidi',
  abs: 'Addome',
  obliques: 'Obliqui',
  lowerBack: 'Lombari',
  quads: 'Quadricipiti',
  glutesHamstrings: 'Glutei & Femorali',
  calves: 'Polpacci',
  forearms: 'Avambracci',
};

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

function lerpPt(a: Point2D, b: Point2D, t: number): Point2D {
  return { x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t) };
}

function polar(origin: Point2D, length: number, angleDeg: number): Point2D {
  const rad = (angleDeg * Math.PI) / 180;
  return {
    x: origin.x + length * Math.cos(rad),
    y: origin.y + length * Math.sin(rad),
  };
}

/**
 * Analytical 2-bone Inverse Kinematics solver:
 * Guarantees bone lengths remain constant while bending elbow or knee naturally.
 */
export function solve2LinkIK(
  root: Point2D,
  target: Point2D,
  len1: number,
  len2: number,
  bendSign: 1 | -1
): Point2D {
  const dx = target.x - root.x;
  const dy = target.y - root.y;
  const rawDist = Math.hypot(dx, dy) || 0.001;
  const minDist = Math.abs(len1 - len2) + 0.5;
  const maxDist = len1 + len2 - 0.15;
  const d = Math.max(minDist, Math.min(maxDist, rawDist));

  const baseAngle = Math.atan2(dy, dx);
  const cosAngle = (len1 * len1 + d * d - len2 * len2) / (2 * len1 * d);
  const clampedCos = Math.max(-1, Math.min(1, cosAngle));
  const jointOffset = Math.acos(clampedCos);
  const finalAngle = baseAngle + bendSign * jointOffset;

  return {
    x: root.x + len1 * Math.cos(finalAngle),
    y: root.y + len1 * Math.sin(finalAngle),
  };
}

export function detectAnimationId(
  exerciseId: string,
  name: string,
  category: ExerciseCategory,
  explicitAnimationId?: AnimationId
): AnimationId {
  if (explicitAnimationId) return explicitAnimationId;
  const s = `${exerciseId} ${name}`.toLowerCase();

  // Tirata
  if (s.includes('scapular')) return 'scapular_pullup';
  if (s.includes('dead_hang') || s.includes('dead hang') || s.includes('sospensione')) return 'dead_hang';
  if (s.includes('skin_the_cat') || s.includes('skin the cat')) return 'skin_the_cat';
  if (s.includes('muscle_up') || s.includes('muscle-up')) return 'muscle_up';
  if (s.includes('ring_row') || s.includes('row agli anelli')) return 'ring_row';
  if (s.includes('australian')) return 'australian_pullup';
  if (s.includes('archer_pullup') || (s.includes('archer') && (s.includes('pull') || s.includes('traz')))) {
    return 'archer_pullup';
  }
  if (s.includes('high_pullup') || s.includes('esplosiv')) return 'explosive_pullup';
  if (s.includes('chin_up') || s.includes('chin-up') || s.includes('supina')) return 'chinup';
  if (s.includes('pull_up') || s.includes('pull-up') || s.includes('trazioni')) return 'pullup';

  // Spinta
  if (s.includes('ring_dip') || (s.includes('dip') && s.includes('anelli'))) return 'ring_dip';
  if (s.includes('korean_dip') || s.includes('korean dip')) return 'korean_dip';
  if (s.includes('dip')) return 'dip';
  if (s.includes('hspu') || s.includes('piegamenti in verticale')) return 'hspu';
  if (s.includes('pike')) return 'pike_pushup';
  if (s.includes('pseudo_planche')) return 'pseudo_planche_pushup';
  if (s.includes('archer_pushup') || (s.includes('archer') && (s.includes('push') || s.includes('piegam')))) {
    return 'archer_pushup';
  }
  if (s.includes('diamond')) return 'diamond_pushup';
  if (s.includes('push_up') || s.includes('push-up') || s.includes('piegamenti')) return 'pushup';

  // Core / Leve / Skill
  if (s.includes('knee_raises') || s.includes('knee raises')) return 'knee_raises';
  if (s.includes('hanging_leg') || s.includes('toes_to_bar') || s.includes('toes to bar') || s.includes('lying_leg')) {
    return 'hanging_leg_raises';
  }
  if (s.includes('bicycle')) return 'bicycle_crunch';
  if (s.includes('russian_twist') || s.includes('russian twist')) return 'russian_twist';
  if (s.includes('sit_up') || s.includes('sit-up') || s.includes('v_up') || s.includes('v-up')) return 'situp';
  if (s.includes('crunch')) return 'crunch';
  if (s.includes('hollow') || s.includes('arch_body') || s.includes('dragon_flag')) return 'hollow_body';
  if (s.includes('plank') || s.includes('mountain_climbers')) return 'plank';
  if (s.includes('l_sit') || s.includes('l-sit')) return 'lsit';
  if (s.includes('front_lever') || s.includes('front lever') || s.includes('back_lever')) return 'front_lever';
  if (s.includes('planche') || s.includes('frog_stand')) return 'planche';
  if (s.includes('handstand') || s.includes('verticale')) return 'handstand';

  // Gambe & Mobilità
  if (s.includes('pistol')) return 'pistol_squat';
  if (s.includes('lunge') || s.includes('affond') || s.includes('bulgarian')) return 'lunges';
  if (s.includes('squat') || s.includes('shrimp') || s.includes('nordic') || s.includes('calf')) return 'squat';
  if (s.includes('stretch') || s.includes('cobra') || s.includes('mobilit')) return 'stretching_cobra_pike';

  if (category === 'Tirata') return 'pullup';
  if (category === 'Spinta') return 'pushup';
  if (category === 'Core') return 'plank';
  if (category === 'Gambe') return 'squat';
  return 'planche';
}

export function getBiomechSpec(
  exerciseId: string,
  name: string,
  category: ExerciseCategory,
  cues: string[],
  explicitAnimationId?: AnimationId
): BiomechExerciseSpec {
  const key = detectAnimationId(exerciseId, name, category, explicitAnimationId);
  const cue0 = cues[0] ?? 'Allinea polsi, gomiti e spalle mantenendo il core attivo.';

  const specs: Record<AnimationId, Omit<BiomechExerciseSpec, 'key' | 'muscleSummaryLabel'>> = {
    // ------------------------------------------------------------------
    // TIRATA (10)
    // ------------------------------------------------------------------
    pullup: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Alta · Presa Prona',
      activeMuscles: ['lats', 'biceps', 'forearms'],
      phase1Label: 'Partenza (Dead Hang)',
      phase2Label: 'Mento Sopra la Sbarra',
      phase1Detail: 'Presa prona poco oltre le spalle, braccia tese e scapole già attive.',
      phase2Detail: 'Tira i gomiti verso il basso portando lo sterno alto verso la sbarra.',
      phase3Detail: 'Controlla la discesa per 2–3s tornando fino alla completa estensione.',
      commonMistake: 'Slanciare le gambe (kipping) o chiudere le spalle verso le orecchie.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    chinup: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Alta · Presa Supina',
      activeMuscles: ['biceps', 'lats', 'forearms'],
      phase1Label: 'Partenza (Palmi Viso)',
      phase2Label: 'Picco ai Bicipiti',
      phase1Detail: 'Presa supina (palmi verso il viso) larghezza spalle, braccia tese.',
      phase2Detail: 'Gomiti stretti davanti al busto fino a portare il mento sopra la sbarra.',
      phase3Detail: 'Distendi lentamente i gomiti mantenendo il petto aperto.',
      commonMistake: 'Tagliare il movimento a metà senza distendere i gomiti in basso.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    australian_pullup: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Bassa · Inclinato',
      activeMuscles: ['lats', 'biceps', 'shoulders'],
      phase1Label: 'Plank Inclinato Teso',
      phase2Label: 'Petto alla Sbarra',
      phase1Detail: 'Talloni puntati a terra, linea rigida caviglie-spalle e braccia tese.',
      phase2Detail: 'Tira i gomiti indietro toccando lo sterno alla sbarra a busto dritto.',
      phase3Detail: 'Stringi le scapole 1s in cima e ridistendi controllando la discesa.',
      commonMistake: 'Far cadere il bacino verso terra o sporgere la testa avanti.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    ring_row: {
      isIsometric: false,
      apparatusLabel: 'Anelli Sospesi · Presa Neutra',
      activeMuscles: ['lats', 'biceps', 'shoulders'],
      phase1Label: 'Sospensione agli Anelli',
      phase2Label: 'Chiusura ai Fianchi',
      phase1Detail: 'Afferra i due anelli sospesi a braccia tese con corpo in linea rigida.',
      phase2Detail: 'Tira ruotando i palmi verso il busto fino a portare gli anelli ai lati del petto.',
      phase3Detail: 'Pausa 1s a scapole chiuse, poi distendi lento tenendo i cavi in tensione.',
      commonMistake: 'Allargare troppo i gomiti o flettere l’anca per facilitare la tirata.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    archer_pullup: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Alta · Frontale Asimmetrico',
      activeMuscles: ['lats', 'biceps', 'shoulders'],
      phase1Label: 'Presa Ampia Tesa',
      phase2Label: 'Tirata Su Un Braccio',
      phase1Detail: 'Presa ampia alla sbarra: un braccio tira mentre l’opposto resta teso.',
      phase2Detail: 'Sposta il torace lateralmente verso la mano di lavoro tenendo l’altro braccio disteso.',
      phase3Detail: 'Ritorna lento al centro controllando la discesa unilaterale.',
      commonMistake: 'Piegare il braccio assistente trasformandolo in una trazione classica.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    explosive_pullup: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Alta · Esplosiva',
      activeMuscles: ['lats', 'biceps', 'abs'],
      phase1Label: 'Caricamento Compatto',
      phase2Label: 'Sbarra allo Sterno / Ombelico',
      phase1Detail: 'Partenza compatta in hollow con presa leggermente oltre le spalle.',
      phase2Detail: 'Accelera verticalmente portando la sbarra fino allo sterno basso.',
      phase3Detail: 'Frena la discesa mantenendo controllo scapolare fino alla base.',
      commonMistake: 'Tirare solo con le braccia verso il collo senza aprire i gomiti dietro.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    muscle_up: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Alta · 3 Fasi',
      activeMuscles: ['lats', 'triceps', 'chest', 'abs'],
      phase1Label: 'Fase 1: Tirata Esplosiva',
      phase2Label: 'Fase 2: Transizione ai Polsi',
      phase1Detail: 'Tirata esplosiva dal basso portando il petto alto sopra la linea della sbarra.',
      phase2Detail: 'Ruota rapidamente i polsi e porta le spalle avanti sopra la sbarra.',
      phase3Detail: 'Spingi con i tricipiti fino al blocco completo a braccia tese sopra la sbarra.',
      commonMistake: 'Tirare a un gomito alla volta (“chicken wing”) o sbattere sul petto.',
      phase1Progress: 0,
      phase2Progress: 0.52,
      phase3Progress: 1,
    },
    dead_hang: {
      isIsometric: true,
      apparatusLabel: 'Sbarra Alta · Tenuta',
      activeMuscles: ['forearms', 'lats', 'shoulders'],
      phase1Label: 'Presa Chiusa Piena',
      phase2Label: 'Decompressione & Scapole',
      phase1Detail: 'Afferra la sbarra con pollice opposto e braccia completamente tese.',
      phase2Detail: 'Deprimi leggermente le scapole tenendo il corpo immobile verticale.',
      phase3Detail: 'Respira profondo scaricando la colonna senza oscillare con le gambe.',
      commonMistake: 'Dondolare in avanti o appendere il peso solo sulle falangi distali.',
      phase1Progress: 0,
      phase2Progress: 0.6,
      phase3Progress: 1,
    },
    scapular_pullup: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Alta · Gomiti Bloccati',
      activeMuscles: ['lats', 'shoulders', 'forearms'],
      phase1Label: 'Scapole Elevate (Passivo)',
      phase2Label: 'Depressione Scapolare',
      phase1Detail: 'Appeso alla sbarra con gomiti bloccati al 100% e spalle vicino alle orecchie.',
      phase2Detail: 'Senza piegare minimamente i gomiti, abbassa le scapole sollevando il petto.',
      phase3Detail: 'Mantieni 1s la depressione scapolare al picco e ritorna controllato.',
      commonMistake: 'Flettere i gomiti trasformando il lavoro scapolare in mezza trazione.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    skin_the_cat: {
      isIsometric: false,
      apparatusLabel: 'Sbarra / Anelli · Rotazione',
      activeMuscles: ['shoulders', 'lats', 'abs'],
      phase1Label: 'Chiusura Tuck Tra le Braccia',
      phase2Label: 'German Hang Posteriore',
      phase1Detail: 'Porta le ginocchia al petto passando con le gambe raccolte tra le braccia tese.',
      phase2Detail: 'Ruota lentamente all’indietro aprendo le spalle fino al German Hang.',
      phase3Detail: 'Sosta 2–3s in apertura controllata e inverti la rotazione per tornare su.',
      commonMistake: 'Lasciar cadere di colpo i piedi indietro stressando i tendini delle spalle.',
      phase1Progress: 0,
      phase2Progress: 0.68,
      phase3Progress: 1,
    },

    // ------------------------------------------------------------------
    // SPINTA (9)
    // ------------------------------------------------------------------
    pushup: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Plank Alto',
      activeMuscles: ['chest', 'triceps', 'shoulders'],
      phase1Label: 'Plank Alto Rigido',
      phase2Label: 'Petto Sfiora il Suolo',
      phase1Detail: 'Mani sotto le spalle, linea retta testa-talloni con glutei e addome attivi.',
      phase2Detail: 'Piega i gomiti a 45° lungo i fianchi finché il petto sfiora il pavimento.',
      phase3Detail: 'Spingi verso l’alto fino a distendere i gomiti con leggera protrazione.',
      commonMistake: 'Aprire i gomiti a 90° (“a T”) o lasciar cedere la zona lombare.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    diamond_pushup: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Mani Unite',
      activeMuscles: ['triceps', 'chest', 'shoulders'],
      phase1Label: 'Mani a Diamante Sotto Sterno',
      phase2Label: 'Sterno Sulle Mani',
      phase1Detail: 'Pollici e indici uniti a triangolo/diamante esattamente sotto lo sterno.',
      phase2Detail: 'Scendi con gomiti aderenti ai fianchi fino a sfiorare le mani col petto.',
      phase3Detail: 'Estendi forte i tricipiti fino al lockout completo delle braccia.',
      commonMistake: 'Posizionare le mani davanti al viso o aprire i gomiti verso l’esterno.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    archer_pushup: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Frontale Ampio',
      activeMuscles: ['chest', 'triceps', 'shoulders'],
      phase1Label: 'Posizione Ampia',
      phase2Label: 'Affondo Laterale su 1 Braccio',
      phase1Detail: 'Mani molto più larghe delle spalle con dita ruotate verso l’esterno.',
      phase2Detail: 'Sposta il peso e piega il braccio di lavoro mantenendo l’altro 100% teso.',
      phase3Detail: 'Spingi dal braccio flesso tornando esattamente al centro.',
      commonMistake: 'Piegare il braccio teso o ruotare il bacino durante la discesa.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    pseudo_planche_pushup: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Lean Avanti',
      activeMuscles: ['shoulders', 'chest', 'triceps'],
      phase1Label: 'Spalle Oltre i Polsi (Lean)',
      phase2Label: 'Discesa a Lean Mantenuto',
      phase1Detail: 'Mani all’altezza dell’ombelico ruotate fuori, spalle sbilanciate ben avanti.',
      phase2Detail: 'Scendi piegando i gomiti indietro senza mai arretrare le spalle dai polsi.',
      phase3Detail: 'Spingi fino a protrarre forte le scapole mantenendo lo sbilanciamento.',
      commonMistake: 'Spostare indietro il bacino verso i talloni mentre si spinge su.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    pike_pushup: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · V Rovesciata',
      activeMuscles: ['shoulders', 'triceps'],
      phase1Label: 'V Rovesciata Alta',
      phase2Label: 'Fronte Avanti alle Mani',
      phase1Detail: 'Mani e punte a terra formando una V chiusa con bacino spinto verso l’alto.',
      phase2Detail: 'Scendi portando la testa avanti oltre le mani formando un triangolo a terra.',
      phase3Detail: 'Spingi via il suolo tornando con orecchie allineate tra le spalle.',
      commonMistake: 'Scendere verticalmente tra le mani aprendo i gomiti verso l’esterno.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    hspu: {
      isIsometric: false,
      apparatusLabel: 'Muro · Verticale Dinamica',
      activeMuscles: ['shoulders', 'triceps', 'abs'],
      phase1Label: 'Verticale Tesa al Muro',
      phase2Label: 'Capo Sfiora Avanti a Terra',
      phase1Detail: 'Braccia bloccate in spinta verticale, core in hollow e talloni leggeri al muro.',
      phase2Detail: 'Piega i gomiti stretti avanti portando la testa oltre la linea delle mani.',
      phase3Detail: 'Spingi esplosivo verso l’alto chiudendo le costole fino al lockout.',
      commonMistake: 'Inarcare i lombari (“banana back”) o aprire i gomiti larghi.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    dip: {
      isIsometric: false,
      apparatusLabel: 'Parallele Laterali',
      activeMuscles: ['chest', 'triceps', 'shoulders'],
      phase1Label: 'Appoggio Braccia Tese',
      phase2Label: 'Discesa Sotto i 90°',
      phase1Detail: 'Braccia bloccate tese sulle parallele con scapole depresse e petto aperto.',
      phase2Detail: 'Scendi piegando i gomiti indietro finché le spalle scendono sotto i gomiti.',
      phase3Detail: 'Spingi deciso verso l’alto fino all’estensione completa.',
      commonMistake: 'Incassare il collo tra le spalle o fermarsi con escursione incompleta.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    ring_dip: {
      isIsometric: false,
      apparatusLabel: 'Anelli Alti · Con RTO',
      activeMuscles: ['chest', 'triceps', 'shoulders'],
      phase1Label: 'Supporto RTO (Polsi Fuori)',
      phase2Label: 'Discesa Profonda Stabile',
      phase1Detail: 'In cima agli anelli ruota i palmi verso l’esterno (RTO) a braccia bloccate.',
      phase2Detail: 'Scendi controllato mantenendo gli anelli aderenti ai fianchi.',
      phase3Detail: 'Risali spingendo giù e richiudi in supporto RTO stabile per 1s.',
      commonMistake: 'Far oscillare gli anelli allontanandoli dal corpo per instabilità.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    korean_dip: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Dietro la Schiena',
      activeMuscles: ['triceps', 'shoulders', 'chest'],
      phase1Label: 'Appoggio Posteriore',
      phase2Label: 'Flessione Dietro il Bacino',
      phase1Detail: 'Sbarra afferrata dietro i glutei a braccia tese e spalle ben aperte.',
      phase2Detail: 'Scendi verticale piegando i gomiti indietro nel rispetto della mobilità.',
      phase3Detail: 'Estendi i tricipiti spingendo il bacino su fino al blocco.',
      commonMistake: 'Forzare la profondità oltre la mobilità della capsula della spalla.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },

    // ------------------------------------------------------------------
    // ADDOME / CORE / LEVE (12)
    // ------------------------------------------------------------------
    hanging_leg_raises: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Alta · Busto Fisso',
      activeMuscles: ['abs', 'quads', 'forearms'],
      phase1Label: 'Verticale Fermo (0°)',
      phase2Label: 'Gambe Tese a 90° / Sbarra',
      phase1Detail: 'Sospeso con braccia bloccate e busto fermo verticale senza oscillare.',
      phase2Detail: 'Ruota le gambe tese dall’anca fino a 90° orizzontali (o fino alla sbarra).',
      phase3Detail: 'Frena la discesa per 2s fermandoti esattamente sulla verticale.',
      commonMistake: 'Piegare le ginocchia o dondolare indietro le spalle per slancio.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    knee_raises: {
      isIsometric: false,
      apparatusLabel: 'Sbarra Alta · Ginocchia Flesse',
      activeMuscles: ['abs', 'forearms'],
      phase1Label: 'Sospensione Stabile',
      phase2Label: 'Ginocchia al Petto',
      phase1Detail: 'Braccia tese e busto immobile verticale con scapole attive.',
      phase2Detail: 'Arrotola il bacino portando le ginocchia piegate fin sopra l’ombelico.',
      phase3Detail: 'Controlla il ritorno senza lasciare oscillare i piedi indietro.',
      commonMistake: 'Fermarsi a 90° senza arrotolare il bacino verso le costole.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    crunch: {
      isIsometric: false,
      apparatusLabel: 'Pavimento Supino · Solo Scapole',
      activeMuscles: ['abs'],
      phase1Label: 'Schiena Aderente',
      phase2Label: 'Sollevamento Scapole',
      phase1Detail: 'Supino a ginocchia piegate con zona lombare incollata al pavimento.',
      phase2Detail: 'Solleva solo le scapole di pochi centimetri avvicinando costole e bacino.',
      phase3Detail: 'Pausa 1s espirando al picco e riappoggia lento le spalle.',
      commonMistake: 'Tirare il collo con le mani o staccare tutta la bassa schiena.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    situp: {
      isIsometric: false,
      apparatusLabel: 'Pavimento Supino · Completo',
      activeMuscles: ['abs'],
      phase1Label: 'Supino Completo',
      phase2Label: 'Chiusura Busto Verticale',
      phase1Detail: 'Schiena distesa a terra, ginocchia piegate e piedi stabili sul suolo.',
      phase2Detail: 'Srotola l’intera colonna portando il torace verticale verso le ginocchia.',
      phase3Detail: 'Frena la discesa vertebra dopo vertebra senza lasciarti cadere.',
      commonMistake: 'Usare slanci bruschi con le braccia o staccare i talloni da terra.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.08,
    },
    bicycle_crunch: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Incrocio Alternato',
      activeMuscles: ['obliques', 'abs'],
      phase1Label: 'Gamba Tesa + Ginocchio Al Petto',
      phase2Label: 'Torsione Gomito-Ginocchio Opposto',
      phase1Detail: 'Lombari aderenti al suolo, una gamba flessa e l’altra tesa sospesa avanti.',
      phase2Detail: 'Ruota il torace portando il gomito verso il ginocchio opposto in modo fluido.',
      phase3Detail: 'Alterna il lato mantenendo ritmo controllato senza tirare il collo.',
      commonMistake: 'Pedalare velocemente a casaccio senza reale rotazione delle spalle.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.1,
    },
    russian_twist: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Seduto a 45°',
      activeMuscles: ['obliques', 'abs'],
      phase1Label: 'Equilibrio Inclinato a 45°',
      phase2Label: 'Torsione Toracica Laterale',
      phase1Detail: 'Busto inclinato indietro a 45°, schiena dritta e piedi sollevati da terra.',
      phase2Detail: 'Ruota spalle e torace da un lato all’altro tenendo le ginocchia ferme.',
      phase3Detail: 'Tocca lateralmente vicino al fianco e ripeti sul lato opposto.',
      commonMistake: 'Muovere solo le mani lasciando le spalle ferme frontali.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    plank: {
      isIsometric: true,
      apparatusLabel: 'Pavimento · Tenuta Statica',
      activeMuscles: ['abs', 'glutesHamstrings', 'shoulders'],
      phase1Label: 'Appoggio Avambracci',
      phase2Label: 'Allineamento RKC Attivo',
      phase1Detail: 'Gomiti esattamente sotto le spalle, avambracci paralleli e punte unite.',
      phase2Detail: 'Ruota il bacino in retroversione contraendo forte glutei e addome.',
      phase3Detail: 'Mantieni la linea retta continua senza cedimenti lombari.',
      commonMistake: 'Inarcare la bassa schiena o alzare i glutei a triangolo.',
      phase1Progress: 0,
      phase2Progress: 0.55,
      phase3Progress: 1,
    },
    hollow_body: {
      isIsometric: true,
      apparatusLabel: 'Pavimento · Barchetta Supina',
      activeMuscles: ['abs', 'quads'],
      phase1Label: 'Lombari Incollati a Terra',
      phase2Label: 'Tenuta Hollow Completa',
      phase1Detail: 'Supino con zona lombare schiacciata al suolo senza lasciare aria sotto.',
      phase2Detail: 'Solleva scapole, braccia indietro e gambe tese a 15 cm dal pavimento.',
      phase3Detail: 'Tieni il respiro corto e addome compatto per tutta la durata.',
      commonMistake: 'Creare un arco lombare abbassando troppo i talloni.',
      phase1Progress: 0,
      phase2Progress: 0.55,
      phase3Progress: 1,
    },
    lsit: {
      isIsometric: true,
      apparatusLabel: 'Parallele / Parallettes · 90°',
      activeMuscles: ['abs', 'quads', 'triceps'],
      phase1Label: 'Spinta & Depressione',
      phase2Label: 'Squadra a 90° Tesa',
      phase1Detail: 'Braccia bloccate tese sulle parallettes spingendo lontano il suolo.',
      phase2Detail: 'Gambe unite e completamente tese parallele al pavimento a 90°.',
      phase3Detail: 'Spalle depresse e punte dei piedi tese avanti per tutto il set.',
      commonMistake: 'Piegare i gomiti, flettere le ginocchia o incassare il collo.',
      phase1Progress: 0,
      phase2Progress: 0.55,
      phase3Progress: 1,
    },
    front_lever: {
      isIsometric: true,
      apparatusLabel: 'Sbarra Alta · Leva Orizzontale',
      activeMuscles: ['lats', 'abs', 'shoulders'],
      phase1Label: 'Braccia Tese & Depressione',
      phase2Label: 'Linea Orizzontale Stabile',
      phase1Detail: 'Afferra la sbarra con gomiti bloccati al 100% e dorsali attivati.',
      phase2Detail: 'Spingi idealmente la sbarra verso i fianchi portando il dorso orizzontale.',
      phase3Detail: 'Sostieni la linea delle spalle e del bacino senza calare sotto il piano.',
      commonMistake: 'Flettere leggermente i gomiti o lasciar cadere il bacino verso il basso.',
      phase1Progress: 0,
      phase2Progress: 0.55,
      phase3Progress: 1,
    },
    planche: {
      isIsometric: true,
      apparatusLabel: 'Pavimento / Parallettes · Equilibrio',
      activeMuscles: ['shoulders', 'abs', 'chest'],
      phase1Label: 'Protrazione & Sbilanciamento',
      phase2Label: 'Corpo Sospeso Braccia Tese',
      phase1Detail: 'Gomiti bloccati tesi, scapole protratte al massimo e spalle oltre i polsi.',
      phase2Detail: 'Stacca i piedi sostenendo il peso orizzontale sopra il baricentro delle mani.',
      phase3Detail: 'Mantieni spinta continua nel pavimento senza cedere sui gomiti.',
      commonMistake: 'Piegare le braccia o arretrare le spalle dietro alla linea dei polsi.',
      phase1Progress: 0,
      phase2Progress: 0.55,
      phase3Progress: 1,
    },
    handstand: {
      isIsometric: true,
      apparatusLabel: 'Verticale · Linea 180°',
      activeMuscles: ['shoulders', 'triceps', 'abs'],
      phase1Label: 'Spinta Verticale Dalle Spalle',
      phase2Label: 'Impilamento Hollow Perfetto',
      phase1Detail: 'Dita aperte a terra, gomiti bloccati e spalle spinte verso l’alto.',
      phase2Detail: 'Allinea polsi, spalle, bacino e caviglie lungo un’unica retta verticale.',
      phase3Detail: 'Bilancia micro-correzioni tramite i polpastrelli chiudendo le costole.',
      commonMistake: 'Inarcare la zona lombare (“banana back”) o flettere i gomiti.',
      phase1Progress: 0,
      phase2Progress: 0.55,
      phase3Progress: 1,
    },

    // ------------------------------------------------------------------
    // GAMBE & MOBILITÀ (4)
    // ------------------------------------------------------------------
    squat: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Accosciata Profonda',
      activeMuscles: ['quads', 'glutesHamstrings'],
      phase1Label: 'Stazione Eretta Stabile',
      phase2Label: 'Sotto il Parallelo',
      phase1Detail: 'Piedi stabili larghezza spalle, petto alto e braccia avanti per equilibrio.',
      phase2Detail: 'Scendi piegando insieme anca e ginocchio finché il bacino scende sotto il ginocchio.',
      phase3Detail: 'Spingi uniforme da tutta la pianta del piede fino all’estensione completa.',
      commonMistake: 'Sollevare i talloni da terra o far cedere le ginocchia verso l’interno.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    pistol_squat: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Su 1 Gamba',
      activeMuscles: ['quads', 'glutesHamstrings', 'abs'],
      phase1Label: 'Equilibrio su 1 Gamba',
      phase2Label: 'Accosciata Completa in Basso',
      phase1Detail: 'In equilibrio su un piede con l’altra gamba distesa orizzontale davanti.',
      phase2Detail: 'Scendi controllato fino a toccare il polpaccio con la coscia senza staccare il tallone.',
      phase3Detail: 'Risali spingendo dal centro del piede mantenendo la gamba libera alta.',
      commonMistake: 'Alzare il tallone di appoggio o far toccare terra al piede disteso.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    lunges: {
      isIsometric: false,
      apparatusLabel: 'Pavimento · Passo Divaricato',
      activeMuscles: ['quads', 'glutesHamstrings'],
      phase1Label: 'Affondo Alto Divaricato',
      phase2Label: 'Entrambe le Ginocchia a 90°',
      phase1Detail: 'Passo lungo stabile con busto verticale e tallone posteriore sollevato.',
      phase2Detail: 'Scendi verticale piegando entrambe le ginocchia a 90° sfiorando il suolo dietro.',
      phase3Detail: 'Spingi dal tallone anteriore per tornare in posizione di partenza.',
      commonMistake: 'Inclinarsi avanti col busto o sbattere il ginocchio posteriore a terra.',
      phase1Progress: 0,
      phase2Progress: 1,
      phase3Progress: 0.05,
    },
    stretching_cobra_pike: {
      isIsometric: true,
      apparatusLabel: 'Pavimento · Mobilità & Stretching',
      activeMuscles: ['lowerBack', 'shoulders', 'glutesHamstrings'],
      phase1Label: 'Apertura Dolce Cobra / Pike',
      phase2Label: 'Massimo Allungamento Attivo',
      phase1Detail: cue0,
      phase2Detail: 'Espira lentamente mantenendo il bacino ancorato e aprendo petto e colonna.',
      phase3Detail: 'Sostieni l’allungamento fluido senza tensioni o dolore articolare.',
      commonMistake: 'Molleggiare bruscamente a freddo o incassare le spalle verso il collo.',
      phase1Progress: 0,
      phase2Progress: 0.6,
      phase3Progress: 1,
    },
  };

  const base = specs[key];
  const muscleSummaryLabel = base.activeMuscles.map((m) => MUSCLE_LABELS_IT[m]).join(' + ');

  return {
    key,
    ...base,
    muscleSummaryLabel,
  };
}

/**
 * Computes dedicated 1-to-1 anatomical joint coordinates for every AnimationId at progress t in [0, 1].
 * Optional exerciseId allows fine anatomical variants inside a shared AnimationId (e.g. tuck vs full front lever,
 * wall vs freestanding handstand, side plank, bulgarian split squat, nordic curl, calf raises, toes to bar).
 */
export function computeBiomechanicalPose(
  animationId: AnimationId,
  rawT: number,
  exerciseId?: string
): BiomechanicalPose {
  const t = Math.max(0, Math.min(1, rawT));
  const idLower = (exerciseId || '').toLowerCase();

  switch (animationId) {
    // ==================================================================
    // 1. TIRATA (10 DISTINCT ANIMATION SCHEMAS)
    // ==================================================================
    case 'pullup': {
      const p = idLower.includes('negative') ? 1 - t : t;
      const barY = 36;
      const wrist: Point2D = { x: 146, y: barY };
      const shoulder: Point2D = { x: lerp(146, 138, p), y: lerp(88, 48, p) };
      const elbow = solve2LinkIK(shoulder, wrist, 27, 27, -1);
      const pelvis = polar(shoulder, 44, lerp(90, 96, p));
      const knee = polar(pelvis, 25, 92);
      const ankle = polar(knee, 24, lerp(92, 108, p));
      return {
        apparatus: 'high_bar',
        barY,
        techniqueTag: 'Presa Prona',
        head: { x: shoulder.x + 8, y: shoulder.y - 16 },
        neck: { x: shoulder.x + 2, y: shoulder.y - 5 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x + 6, y: ankle.y + 3 },
        arrows: [{ from: { x: 204, y: 102 }, to: { x: 204, y: 36 } }],
      };
    }

    case 'chinup': {
      const barY = 36;
      const wrist: Point2D = { x: 144, y: barY };
      const shoulder: Point2D = { x: lerp(144, 146, t), y: lerp(88, 46, t) };
      // Supinated grip: elbows drive strictly FORWARD (bendSign = +1)
      const elbow = solve2LinkIK(shoulder, wrist, 27, 27, 1);
      const pelvis = polar(shoulder, 44, lerp(90, 86, t));
      const knee = polar(pelvis, 25, 92);
      const ankle = polar(knee, 24, lerp(94, 106, t));
      return {
        apparatus: 'high_bar',
        barY,
        techniqueTag: 'Presa Supina (Palmi Viso)',
        head: { x: shoulder.x + 8, y: shoulder.y - 16 },
        neck: { x: shoulder.x + 2, y: shoulder.y - 5 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x + 6, y: ankle.y + 3 },
        arrows: [{ from: { x: 206, y: 100 }, to: { x: 206, y: 36 } }],
      };
    }

    case 'australian_pullup': {
      const barY = 58;
      const wrist: Point2D = { x: 178, y: barY };
      const ankle: Point2D = { x: 56, y: 150 };
      const angleDeg = lerp(-24, -45, t);
      const knee = polar(ankle, 38, angleDeg);
      const pelvis = polar(knee, 40, angleDeg);
      const shoulder = polar(pelvis, 54, angleDeg);
      const elbow = solve2LinkIK(shoulder, wrist, 24, 24, 1);
      const neck = polar(shoulder, 9, angleDeg);
      const head = polar(neck, 10, angleDeg - 10);
      return {
        apparatus: 'low_bar',
        barX: wrist.x,
        barY,
        techniqueTag: idLower.includes('supina') ? 'Sbarra Bassa · Supina' : 'Sbarra Bassa · Prona',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x - 4, y: ankle.y - 8 },
        arrows: [{ from: { x: 140, y: 98 }, to: { x: 164, y: 66 } }],
        guideLine: { p1: ankle, p2: shoulder },
      };
    }

    case 'ring_row': {
      // Dedicated rings apparatus: two vertical straps from top beam + two rings at waist height
      const ringLeft: Point2D = { x: 168, y: 66 };
      const ringRight: Point2D = { x: 190, y: 60 };
      const wrist = ringLeft;
      const ankle: Point2D = { x: 56, y: 150 };
      const angleDeg = lerp(-22, -46, t);
      const knee = polar(ankle, 38, angleDeg);
      const pelvis = polar(knee, 40, angleDeg);
      const shoulder = polar(pelvis, 54, angleDeg);
      const elbow = solve2LinkIK(shoulder, wrist, 24, 24, 1);
      const shoulderFar: Point2D = { x: shoulder.x + 10, y: shoulder.y - 4 };
      const elbowFar = solve2LinkIK(shoulderFar, ringRight, 24, 24, 1);
      const neck = polar(shoulder, 9, angleDeg);
      const head = polar(neck, 10, angleDeg - 10);
      return {
        apparatus: 'rings_low',
        ringAnchors: { left: ringLeft, right: ringRight },
        techniqueTag: 'Anelli Sospesi · Presa Neutra',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        shoulderFar,
        elbowFar,
        wristFar: ringRight,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x - 4, y: ankle.y - 8 },
        arrows: [{ from: { x: 136, y: 102 }, to: { x: 162, y: 68 } }],
      };
    }

    case 'archer_pullup': {
      // Frontal wide-grip asymmetrical pull-up: left arm pulls up, right arm stays 100% straight laterally!
      const barY = 34;
      const wristWork: Point2D = { x: 96, y: barY };
      const wristAssist: Point2D = { x: 186, y: barY };
      const shoulderCenterX = lerp(140, 104, t);
      const shoulderCenterY = lerp(84, 50, t);
      const shoulderWork: Point2D = { x: shoulderCenterX - 15, y: shoulderCenterY };
      const shoulderAssist: Point2D = { x: shoulderCenterX + 15, y: shoulderCenterY + 2 };
      const elbowWork = solve2LinkIK(shoulderWork, wristWork, 29, 29, -1);
      // Assisting arm stays locked straight!
      const elbowAssist = lerpPt(shoulderAssist, wristAssist, 0.5);
      const pelvis: Point2D = { x: shoulderCenterX - lerp(0, 4, t), y: shoulderCenterY + 46 };
      const knee: Point2D = { x: pelvis.x - 5, y: pelvis.y + 24 };
      const ankle: Point2D = { x: knee.x - 2, y: knee.y + 22 };
      return {
        apparatus: 'high_bar',
        barY,
        bilateralFront: true,
        techniqueTag: '1 Braccio Tira · 1 Braccio Teso',
        head: { x: shoulderCenterX, y: shoulderCenterY - 16 },
        neck: { x: shoulderCenterX, y: shoulderCenterY - 6 },
        shoulder: shoulderWork,
        elbow: elbowWork,
        wrist: wristWork,
        shoulderFar: shoulderAssist,
        elbowFar: elbowAssist,
        wristFar: wristAssist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x - 6, y: ankle.y + 4 },
        kneeFar: { x: pelvis.x + 5, y: pelvis.y + 24 },
        ankleFar: { x: pelvis.x + 7, y: pelvis.y + 46 },
        footTipFar: { x: pelvis.x + 13, y: pelvis.y + 50 },
        arrows: [
          { from: { x: 140, y: 84 }, to: { x: 102, y: 48 }, curved: true, ctrl: { x: 112, y: 74 } },
        ],
      };
    }

    case 'explosive_pullup': {
      // Chest / lower sternum drives all the way up above bar height
      const barY = 54;
      const wrist: Point2D = { x: 146, y: barY };
      const shoulder: Point2D = { x: lerp(146, 134, t), y: lerp(104, 42, t) };
      const elbow = solve2LinkIK(shoulder, wrist, 26, 26, -1);
      const pelvis = polar(shoulder, 44, lerp(90, 102, t));
      const knee = polar(pelvis, 24, 92);
      const ankle = polar(knee, 22, lerp(92, 106, t));
      return {
        apparatus: 'high_bar',
        barY,
        techniqueTag: 'Sbarra allo Sterno (Esplosiva)',
        head: { x: shoulder.x + 7, y: shoulder.y - 16 },
        neck: { x: shoulder.x + 2, y: shoulder.y - 5 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x + 6, y: ankle.y + 3 },
        arrows: [
          { from: { x: 200, y: 116 }, to: { x: 200, y: 38 } },
          { from: { x: 212, y: 106 }, to: { x: 212, y: 48 } },
        ],
      };
    }

    case 'muscle_up': {
      // 3 distinct stages: t=0 hang -> t=0.5 transition around wrists -> t=1 straight-arm lockout ABOVE bar
      const barY = 82;
      const wrist: Point2D = { x: 144, y: barY };
      let shoulder: Point2D;
      let pelvis: Point2D;
      let elbow: Point2D;
      if (t < 0.5) {
        const k = t * 2;
        shoulder = { x: lerp(144, 156, k), y: lerp(128, 86, k) };
        elbow = solve2LinkIK(shoulder, wrist, 24, 24, -1);
        pelvis = { x: shoulder.x - 6, y: shoulder.y + 42 };
      } else {
        const k = (t - 0.5) * 2;
        shoulder = { x: lerp(156, 144, k), y: lerp(86, 36, k) };
        elbow = solve2LinkIK(shoulder, wrist, 24, 24, -1);
        pelvis = { x: shoulder.x - 2, y: lerp(126, 80, k) };
      }
      const knee = { x: pelvis.x + 2, y: pelvis.y + 24 };
      const ankle = { x: knee.x + 2, y: knee.y + 22 };
      return {
        apparatus: 'mid_bar',
        barY,
        techniqueTag: t < 0.4 ? '1. Tirata' : t < 0.7 ? '2. Transizione' : '3. Lockout Sopra',
        head: { x: shoulder.x + 6, y: shoulder.y - 14 },
        neck: { x: shoulder.x + 1, y: shoulder.y - 5 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x + 6, y: ankle.y + 3 },
        arrows: [
          {
            from: { x: 194, y: 120 },
            to: { x: 194, y: 38 },
            curved: true,
            ctrl: { x: 218, y: 80 },
          },
        ],
      };
    }

    case 'dead_hang': {
      const drop = lerp(1.5, -2.5, t);
      const wrist = { x: 140, y: 24 };
      const shoulder = { x: 140, y: 74 + drop };
      const elbow = lerpPt(shoulder, wrist, 0.5);
      const pelvis = { x: 140, y: 118 + drop };
      const knee = { x: 140, y: 142 + drop };
      const ankle = { x: 140, y: 164 + drop };
      return {
        apparatus: 'high_bar',
        barY: 24,
        techniqueTag: 'Decompressione Verticale',
        head: { x: 148, y: 60 + drop },
        neck: { x: 142, y: 69 + drop },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: 146, y: 168 + drop },
        arrows: [
          { from: { x: 110, y: 64 }, to: { x: 110, y: 86 } },
          { from: { x: 170, y: 86 }, to: { x: 170, y: 62 } },
        ],
        guideLine: { p1: { x: 140, y: 16 }, p2: { x: 140, y: 170 } },
      };
    }

    case 'scapular_pullup': {
      // Elbows 100% locked straight throughout! Only shoulder + pelvis column shifts up/down 14px
      const shY = lerp(76, 62, t);
      const wrist = { x: 140, y: 24 };
      const shoulder = { x: 140, y: shY };
      const elbow = lerpPt(shoulder, wrist, 0.5);
      const pelvis = { x: 140, y: shY + 44 };
      const knee = { x: 140, y: shY + 68 };
      const ankle = { x: 140, y: shY + 90 };
      return {
        apparatus: 'high_bar',
        barY: 24,
        techniqueTag: 'Gomiti Bloccati 100%',
        head: { x: 147, y: shY - 14 },
        neck: { x: 141, y: shY - 5 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: 146, y: shY + 94 },
        arrows: [{ from: { x: 110, y: 82 }, to: { x: 110, y: 58 } }],
      };
    }

    case 'skin_the_cat': {
      const barY = 30;
      const wrist: Point2D = { x: 140, y: barY };
      const shoulder: Point2D = { x: lerp(146, 134, t), y: lerp(74, 76, t) };
      const elbow = lerpPt(shoulder, wrist, 0.5);
      const hipArcDeg = lerp(-75, 195, t);
      const pelvis = polar(shoulder, 40, hipArcDeg);
      const knee = polar(pelvis, 22, hipArcDeg + 90);
      const ankle = polar(knee, 22, hipArcDeg + 135);
      return {
        apparatus: 'high_bar',
        barY,
        techniqueTag: 'Rotazione Indietro Spalle',
        head: { x: shoulder.x + 10, y: shoulder.y + 8 },
        neck: { x: shoulder.x + 4, y: shoulder.y + 3 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: polar(ankle, 6, hipArcDeg + 90),
        arrows: [
          {
            from: { x: 178, y: 48 },
            to: { x: 96, y: 92 },
            curved: true,
            ctrl: { x: 136, y: 20 },
          },
        ],
      };
    }

    // ==================================================================
    // 2. SPINTA (9 DISTINCT ANIMATION SCHEMAS)
    // ==================================================================
    case 'pushup': {
      const ankle: Point2D = { x: 52, y: 144 };
      const footTip: Point2D = { x: 48, y: 150 };
      const wrist: Point2D = { x: 192, y: 150 };
      const bodyDeg = lerp(-19, -4, t);
      const knee = polar(ankle, 38, bodyDeg);
      const pelvis = polar(knee, 40, bodyDeg);
      const shoulder = polar(pelvis, 56, bodyDeg);
      const elbow = solve2LinkIK(shoulder, wrist, 25, 25, 1);
      const neck = polar(shoulder, 9, bodyDeg);
      const head = polar(neck, 10, bodyDeg + 6);
      return {
        apparatus: 'floor',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip,
        arrows: [{ from: { x: 222, y: 92 }, to: { x: 222, y: 134 } }],
      };
    }

    case 'diamond_pushup': {
      // Hands joined closely under lower sternum + diamond stencil + elbows tight along torso
      const ankle: Point2D = { x: 50, y: 144 };
      const footTip: Point2D = { x: 46, y: 150 };
      const wrist: Point2D = { x: 176, y: 150 };
      const bodyDeg = lerp(-20, -5, t);
      const knee = polar(ankle, 38, bodyDeg);
      const pelvis = polar(knee, 40, bodyDeg);
      const shoulder = polar(pelvis, 56, bodyDeg);
      // Slight forward shoulder offset from joined hands -> steeper tricep flexion
      const elbow = solve2LinkIK(shoulder, wrist, 25, 25, 1);
      const neck = polar(shoulder, 9, bodyDeg);
      const head = polar(neck, 10, bodyDeg + 6);
      return {
        apparatus: 'floor',
        diamondHandPos: { x: wrist.x, y: 153 },
        techniqueTag: 'Mani a Diamante · Gomiti Stretti',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip,
        arrows: [{ from: { x: 214, y: 90 }, to: { x: 214, y: 134 } }],
      };
    }

    case 'archer_pushup': {
      // Angled/frontal floor view: one arm bends lowering chest laterally, opposite arm stays 100% locked!
      const wristWork: Point2D = { x: 86, y: 146 };
      const wristAssist: Point2D = { x: 196, y: 146 };
      const shoulderCenterX = lerp(141, 102, t);
      const shoulderCenterY = lerp(96, 128, t);
      const shoulderWork: Point2D = { x: shoulderCenterX - 18, y: shoulderCenterY };
      const shoulderAssist: Point2D = { x: shoulderCenterX + 18, y: shoulderCenterY };
      const elbowWork = solve2LinkIK(shoulderWork, wristWork, 28, 28, 1);
      // Opposite arm stays strictly straight out laterally
      const elbowAssist = lerpPt(shoulderAssist, wristAssist, 0.5);
      const pelvis: Point2D = { x: lerp(141, 134, t), y: shoulderCenterY + 18 };
      const knee: Point2D = { x: 130, y: 134 };
      const ankle: Point2D = { x: 124, y: 146 };
      const kneeFar: Point2D = { x: 152, y: 134 };
      const ankleFar: Point2D = { x: 158, y: 146 };
      return {
        apparatus: 'floor',
        bilateralFront: true,
        techniqueTag: '1 Braccio Flesso · 1 Braccio Teso',
        head: { x: shoulderCenterX, y: shoulderCenterY - 14 },
        neck: { x: shoulderCenterX, y: shoulderCenterY - 4 },
        shoulder: shoulderWork,
        elbow: elbowWork,
        wrist: wristWork,
        shoulderFar: shoulderAssist,
        elbowFar: elbowAssist,
        wristFar: wristAssist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x - 4, y: 150 },
        kneeFar,
        ankleFar,
        footTipFar: { x: ankleFar.x + 4, y: 150 },
        arrows: [
          { from: { x: 141, y: 88 }, to: { x: 102, y: 124 }, curved: true, ctrl: { x: 112, y: 98 } },
        ],
      };
    }

    case 'pseudo_planche_pushup': {
      // Hands back near waist/pelvis + shoulders leaned STRONGLY forward past wrists + plumb line!
      const ankle: Point2D = { x: 48, y: 144 };
      const footTip: Point2D = { x: 44, y: 150 };
      const wrist: Point2D = { x: 160, y: 150 };
      const bodyDeg = lerp(-18, -4, t);
      const knee = polar(ankle, 38, bodyDeg);
      const pelvis = polar(knee, 42, bodyDeg);
      // Long reach puts shoulder well forward of wrist (x ~ 188 vs wrist x=160)
      const shoulder = polar(pelvis, 62, bodyDeg);
      const elbow = solve2LinkIK(shoulder, wrist, 27, 27, 1);
      const neck = polar(shoulder, 9, bodyDeg);
      const head = polar(neck, 10, bodyDeg + 5);
      return {
        apparatus: 'floor',
        techniqueTag: 'Spalle Oltre i Polsi (Lean)',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip,
        arrows: [{ from: { x: 222, y: 92 }, to: { x: 222, y: 132 } }],
        guideLine: { p1: { x: shoulder.x, y: 80 }, p2: { x: shoulder.x, y: 152 } },
      };
    }

    case 'pike_pushup': {
      const isElev = idLower.includes('elevated');
      const footTip: Point2D = isElev ? { x: 64, y: 116 } : { x: 64, y: 150 };
      const ankle: Point2D = { x: footTip.x + 2, y: footTip.y - 6 };
      const wrist: Point2D = { x: 176, y: 150 };
      const pelvis: Point2D = isElev
        ? { x: lerp(136, 146, t), y: lerp(52, 60, t) }
        : { x: lerp(126, 138, t), y: lerp(58, 68, t) };
      const knee = lerpPt(ankle, pelvis, 0.5);
      const shoulder: Point2D = { x: lerp(164, 194, t), y: lerp(104, 130, t) };
      const elbow = solve2LinkIK(shoulder, wrist, 25, 25, 1);
      const neck: Point2D = { x: shoulder.x + 7, y: shoulder.y + 6 };
      const head: Point2D = { x: neck.x + 7, y: neck.y + 8 };
      return {
        apparatus: isElev ? 'elevated_box_rear' : 'floor',
        techniqueTag: isElev ? 'Piedi Rialzati · V Verticale' : 'V Rovesciata · Fronte Avanti',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip,
        arrows: [{ from: { x: 186, y: 92 }, to: { x: 210, y: 134 } }],
      };
    }

    case 'hspu': {
      const p = idLower.includes('negative') ? t : t;
      const wrist: Point2D = { x: 148, y: 150 };
      const down = lerp(0, 32, p);
      const shoulder: Point2D = { x: lerp(148, 160, p), y: 102 + down };
      const elbow = solve2LinkIK(shoulder, wrist, 25, 25, 1);
      const pelvis: Point2D = { x: 132, y: 60 + down };
      const knee: Point2D = { x: 124, y: 38 + down };
      const ankle: Point2D = { x: 116, y: 18 + down };
      return {
        apparatus: 'wall_floor',
        wallX: 110,
        techniqueTag: idLower.includes('negative') ? 'Discesa Lenta al Muro' : 'Spinta Verticale al Muro',
        head: { x: shoulder.x + 2, y: shoulder.y + 15 },
        neck: { x: shoulder.x, y: shoulder.y + 6 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x + 8, y: ankle.y - 3 },
        arrows: [{ from: { x: 190, y: 68 }, to: { x: 190, y: 122 } }],
      };
    }

    case 'dip': {
      const barY = 86;
      const wrist: Point2D = { x: 144, y: barY };
      const wristFar: Point2D = { x: 162, y: barY - 4 };
      const shoulder: Point2D = { x: lerp(146, 158, t), y: lerp(42, 74, t) };
      const shoulderFar: Point2D = { x: shoulder.x + 16, y: shoulder.y - 3 };
      const elbow = solve2LinkIK(shoulder, wrist, 24, 24, 1);
      const elbowFar = solve2LinkIK(shoulderFar, wristFar, 24, 24, 1);
      const pelvis = { x: lerp(142, 134, t), y: shoulder.y + 42 };
      const knee = { x: pelvis.x + 4, y: pelvis.y + 24 };
      const ankle = { x: knee.x - 14, y: knee.y + 18 };
      return {
        apparatus: 'parallel_bars',
        barY,
        techniqueTag: 'Parallele · Gomiti 90°',
        head: { x: shoulder.x + 6, y: shoulder.y - 14 },
        neck: { x: shoulder.x + 2, y: shoulder.y - 5 },
        shoulder,
        elbow,
        wrist,
        shoulderFar,
        elbowFar,
        wristFar,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x - 6, y: ankle.y + 4 },
        arrows: [{ from: { x: 204, y: 46 }, to: { x: 204, y: 88 } }],
      };
    }

    case 'ring_dip': {
      // Dedicated rings_high apparatus with two vertical straps, floating rings & RTO cue at top lockout
      const ringL: Point2D = { x: 118, y: 92 };
      const ringR: Point2D = { x: 162, y: 92 };
      const centerX = 140;
      const shoulderY = lerp(46, 80, t);
      const shoulderL: Point2D = { x: centerX - 16, y: shoulderY };
      const shoulderR: Point2D = { x: centerX + 16, y: shoulderY };
      const elbowL = solve2LinkIK(shoulderL, ringL, 25, 25, 1);
      const elbowR = solve2LinkIK(shoulderR, ringR, 25, 25, -1);
      const pelvis: Point2D = { x: centerX, y: shoulderY + 42 };
      const knee: Point2D = { x: centerX - 5, y: pelvis.y + 22 };
      const ankle: Point2D = { x: centerX - 8, y: knee.y + 20 };
      return {
        apparatus: 'rings_high',
        ringAnchors: { left: ringL, right: ringR },
        bilateralFront: true,
        techniqueTag: t < 0.25 ? 'RTO (Polsi Ruotati Fuori)' : 'Anelli Stabili ai Fianchi',
        head: { x: centerX, y: shoulderY - 15 },
        neck: { x: centerX, y: shoulderY - 5 },
        shoulder: shoulderL,
        elbow: elbowL,
        wrist: ringL,
        shoulderFar: shoulderR,
        elbowFar: elbowR,
        wristFar: ringR,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x - 4, y: ankle.y + 5 },
        kneeFar: { x: centerX + 5, y: pelvis.y + 22 },
        ankleFar: { x: centerX + 8, y: knee.y + 20 },
        footTipFar: { x: centerX + 12, y: knee.y + 25 },
        arrows: [{ from: { x: 196, y: 48 }, to: { x: 196, y: 92 } }],
      };
    }

    case 'korean_dip': {
      // Bar strictly BEHIND pelvis/glutes!
      const barY = 88;
      const wrist: Point2D = { x: 120, y: barY };
      const shoulder: Point2D = { x: lerp(132, 138, t), y: lerp(44, 74, t) };
      const elbow = solve2LinkIK(shoulder, wrist, 24, 24, 1);
      const pelvis = { x: shoulder.x + 8, y: shoulder.y + 42 };
      const knee = { x: pelvis.x + 4, y: pelvis.y + 24 };
      const ankle = { x: knee.x + 4, y: knee.y + 22 };
      return {
        apparatus: 'mid_bar_behind',
        barX: 120,
        barY,
        techniqueTag: 'Sbarra Dietro la Schiena',
        head: { x: shoulder.x + 6, y: shoulder.y - 14 },
        neck: { x: shoulder.x + 2, y: shoulder.y - 5 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x + 6, y: ankle.y + 3 },
        arrows: [{ from: { x: 186, y: 48 }, to: { x: 186, y: 86 } }],
      };
    }

    // ==================================================================
    // 3. ADDOME / CORE / LEVE (12 DISTINCT ANIMATION SCHEMAS)
    // ==================================================================
    case 'hanging_leg_raises': {
      const isToes = idLower.includes('toes');
      const isLying = idLower.includes('lying');
      if (isLying) {
        const pelvis: Point2D = { x: 144, y: 144 };
        const legDeg = lerp(-174, -92, t);
        const knee = polar(pelvis, 32, legDeg);
        const ankle = polar(knee, 32, legDeg);
        return {
          apparatus: 'floor',
          techniqueTag: 'Supino · Gambe Tese a 90°',
          head: { x: 214, y: 138 },
          neck: { x: 204, y: 141 },
          shoulder: { x: 196, y: 142 },
          elbow: { x: 174, y: 148 },
          wrist: { x: 148, y: 148 },
          pelvis,
          knee,
          ankle,
          footTip: polar(ankle, 7, legDeg + 70),
          arrows: [
            { from: { x: 78, y: 136 }, to: { x: 136, y: 78 }, curved: true, ctrl: { x: 84, y: 88 } },
          ],
        };
      }

      const barY = 24;
      const wrist: Point2D = { x: 112, y: barY };
      const shoulder: Point2D = { x: 112, y: 68 };
      const elbow = lerpPt(shoulder, wrist, 0.5);
      const pelvis: Point2D = { x: 112, y: 112 };
      const thighDeg = isToes ? lerp(88, -82, t) : lerp(90, 0, t);
      const knee = polar(pelvis, 28, thighDeg);
      const ankle = polar(knee, 28, thighDeg);
      return {
        apparatus: 'high_bar',
        barY,
        techniqueTag: isToes ? 'Punte alla Sbarra (180°)' : 'Busto Fisso · Squadra 90°',
        head: { x: 120, y: 52 },
        neck: { x: 114, y: 62 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: polar(ankle, 7, thighDeg - 60),
        arrows: [
          {
            from: { x: 124, y: 156 },
            to: isToes ? { x: 136, y: 40 } : { x: 168, y: 108 },
            curved: true,
            ctrl: { x: 184, y: 146 },
          },
        ],
      };
    }

    case 'knee_raises': {
      const barY = 24;
      const wrist: Point2D = { x: 114, y: barY };
      const shoulder: Point2D = { x: 114, y: 68 };
      const elbow = lerpPt(shoulder, wrist, 0.5);
      const pelvis: Point2D = { x: 114, y: 112 };
      const thighDeg = lerp(90, -18, t);
      const shinDeg = lerp(90, 86, t);
      const knee = polar(pelvis, 28, thighDeg);
      const ankle = polar(knee, 26, shinDeg);
      return {
        apparatus: 'high_bar',
        barY,
        techniqueTag: 'Ginocchia Raccolte al Petto',
        head: { x: 122, y: 52 },
        neck: { x: 116, y: 62 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: polar(ankle, 6, shinDeg - 60),
        arrows: [
          {
            from: { x: 126, y: 154 },
            to: { x: 158, y: 98 },
            curved: true,
            ctrl: { x: 162, y: 132 },
          },
        ],
      };
    }

    case 'crunch': {
      const pelvis: Point2D = { x: 142, y: 144 };
      const knee: Point2D = { x: 182, y: 114 };
      const ankle: Point2D = { x: 210, y: 146 };
      const footTip: Point2D = { x: 222, y: 150 };
      const curlDeg = lerp(-174, -142, t);
      const shoulder = polar(pelvis, 50, curlDeg);
      const neck = polar(shoulder, 9, curlDeg);
      const head = polar(neck, 10, curlDeg + 15);
      const elbow = polar(shoulder, 18, curlDeg + 50);
      const wrist = polar(elbow, 16, curlDeg + 15);
      return {
        apparatus: 'floor',
        techniqueTag: 'Solo Scapole Off-Ground',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip,
        arrows: [
          {
            from: { x: 98, y: 124 },
            to: { x: 128, y: 94 },
            curved: true,
            ctrl: { x: 102, y: 96 },
          },
        ],
      };
    }

    case 'situp': {
      if (idLower.includes('v_up')) {
        const pelvis: Point2D = { x: 138, y: 144 };
        const torsoDeg = lerp(-166, -124, t);
        const legDeg = lerp(-14, -56, t);
        const shoulder = polar(pelvis, 48, torsoDeg);
        const neck = polar(shoulder, 9, torsoDeg);
        const head = polar(neck, 10, torsoDeg + 12);
        const armReachDeg = lerp(-160, -45, t);
        const elbow = polar(shoulder, 22, armReachDeg);
        const wrist = polar(elbow, 22, armReachDeg);
        const knee = polar(pelvis, 32, legDeg);
        const ankle = polar(knee, 30, legDeg);
        return {
          apparatus: 'floor',
          techniqueTag: 'Chiusura Simmetrica a V',
          head,
          neck,
          shoulder,
          elbow,
          wrist,
          pelvis,
          knee,
          ankle,
          footTip: polar(ankle, 7, legDeg - 65),
          arrows: [
            { from: { x: 88, y: 122 }, to: { x: 128, y: 88 } },
            { from: { x: 192, y: 122 }, to: { x: 152, y: 88 } },
          ],
        };
      }
      const pelvis: Point2D = { x: 142, y: 144 };
      const knee: Point2D = { x: 182, y: 114 };
      const ankle: Point2D = { x: 210, y: 146 };
      const footTip: Point2D = { x: 222, y: 150 };
      const curlDeg = lerp(-174, -100, t);
      const shoulder = polar(pelvis, 50, curlDeg);
      const neck = polar(shoulder, 9, curlDeg);
      const head = polar(neck, 10, curlDeg + 15);
      const elbow = polar(shoulder, 18, curlDeg + 50);
      const wrist = polar(elbow, 16, curlDeg + 15);
      return {
        apparatus: 'floor',
        techniqueTag: 'Salita Busto Completo',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip,
        arrows: [
          {
            from: { x: 96, y: 124 },
            to: { x: 142, y: 84 },
            curved: true,
            ctrl: { x: 106, y: 86 },
          },
        ],
      };
    }

    case 'bicycle_crunch': {
      // Reciprocal alternating elbow-to-knee cross crunch + opposite leg extending forward!
      const pelvis: Point2D = { x: 136, y: 144 };
      const shoulder: Point2D = { x: lerp(96, 114, t), y: lerp(132, 114, t) };
      const neck: Point2D = { x: shoulder.x - 8, y: shoulder.y - 6 };
      const head: Point2D = { x: neck.x - 9, y: neck.y - 6 };
      // Near elbow rotates forward toward near bent knee; far leg kicks straight out!
      const elbow: Point2D = { x: lerp(104, 146, t), y: lerp(112, 108, t) };
      const wrist: Point2D = { x: elbow.x - 10, y: elbow.y - 10 };
      const elbowFar: Point2D = { x: lerp(92, 84, t), y: lerp(116, 122, t) };
      const wristFar: Point2D = { x: elbowFar.x - 8, y: elbowFar.y - 8 };

      const knee: Point2D = { x: lerp(176, 152, t), y: lerp(136, 110, t) };
      const ankle: Point2D = { x: knee.x + 22, y: knee.y + 10 };
      const kneeFar: Point2D = { x: lerp(152, 186, t), y: lerp(112, 136, t) };
      const ankleFar: Point2D = { x: kneeFar.x + 26, y: lerp(124, 138, t) };

      return {
        apparatus: 'floor',
        bilateralFront: true,
        techniqueTag: 'Incrocio Gomito-Ginocchio Opposto',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        shoulderFar: shoulder,
        elbowFar,
        wristFar,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x + 5, y: ankle.y - 5 },
        kneeFar,
        ankleFar,
        footTipFar: { x: ankleFar.x + 5, y: ankleFar.y - 5 },
        arrows: [
          { from: { x: 112, y: 102 }, to: { x: 148, y: 102 }, curved: true, ctrl: { x: 130, y: 88 } },
          { from: { x: 184, y: 136 }, to: { x: 214, y: 136 } },
        ],
      };
    }

    case 'russian_twist': {
      // Seated V-balance leaned 45 deg back, feet hovering, hands + chest rotating laterally side-to-side
      const pelvis: Point2D = { x: 134, y: 144 };
      const leanBackX = 112;
      const shoulderCenterY = 104;
      const twistShift = lerp(-18, 22, t);
      const shoulderNear: Point2D = { x: leanBackX + twistShift * 0.45, y: shoulderCenterY + 3 };
      const shoulderFar: Point2D = { x: leanBackX - twistShift * 0.45, y: shoulderCenterY - 3 };
      const elbow: Point2D = { x: shoulderNear.x + 14 + twistShift * 0.6, y: 118 };
      const wrist: Point2D = { x: elbow.x + 12 + twistShift * 0.4, y: 126 };
      const elbowFar: Point2D = { x: shoulderFar.x + 14 + twistShift * 0.6, y: 114 };
      const wristFar = wrist;
      const knee: Point2D = { x: 168, y: 120 };
      const ankle: Point2D = { x: 196, y: 132 };
      return {
        apparatus: 'floor',
        bilateralFront: true,
        techniqueTag: 'Torsione Torace · Piedi Sollevati',
        head: { x: leanBackX - 4, y: shoulderCenterY - 16 },
        neck: { x: leanBackX - 2, y: shoulderCenterY - 6 },
        shoulder: shoulderNear,
        elbow,
        wrist,
        shoulderFar,
        elbowFar,
        wristFar,
        pelvis,
        knee,
        ankle,
        footTip: { x: 202, y: 125 },
        arrows: [
          { from: { x: 114, y: 120 }, to: { x: 162, y: 120 }, curved: true, ctrl: { x: 138, y: 102 } },
        ],
      };
    }

    case 'plank': {
      if (idLower.includes('side_plank')) {
        const lift = lerp(-1.5, 2, t);
        const elbow: Point2D = { x: 182, y: 148 };
        const wrist: Point2D = { x: 204, y: 148 };
        const shoulder: Point2D = { x: 182, y: 112 - lift };
        const pelvis: Point2D = { x: 122, y: 126 - lift };
        const ankle: Point2D = { x: 58, y: 146 };
        return {
          apparatus: 'floor',
          techniqueTag: 'Side Plank · Anche Alte',
          head: { x: 200, y: 105 - lift },
          neck: { x: 190, y: 109 - lift },
          shoulder,
          elbow,
          wrist,
          shoulderFar: shoulder,
          elbowFar: { x: 176, y: 84 - lift },
          wristFar: { x: 176, y: 68 - lift },
          pelvis,
          knee: lerpPt(ankle, pelvis, 0.5),
          ankle,
          footTip: { x: 54, y: 148 },
          arrows: [{ from: { x: 122, y: 142 }, to: { x: 122, y: 128 } }],
          guideLine: { p1: { x: 54, y: 146 }, p2: { x: 196, y: 108 } },
        };
      }
      if (idLower.includes('mountain')) {
        const wrist: Point2D = { x: 198, y: 150 };
        const shoulder: Point2D = { x: 188, y: 106 };
        const elbow = lerpPt(shoulder, wrist, 0.5);
        const pelvis: Point2D = { x: 124, y: 114 };
        const knee: Point2D = { x: lerp(94, 152, t), y: lerp(130, 126, t) };
        const ankle: Point2D = { x: lerp(62, 134, t), y: lerp(146, 144, t) };
        const kneeFar: Point2D = { x: lerp(148, 92, t), y: lerp(126, 130, t) };
        const ankleFar: Point2D = { x: lerp(130, 62, t), y: lerp(144, 146, t) };
        return {
          apparatus: 'floor',
          techniqueTag: 'Richiamo Ginocchia al Petto',
          head: { x: 206, y: 98 },
          neck: { x: 196, y: 102 },
          shoulder,
          elbow,
          wrist,
          pelvis,
          knee,
          ankle,
          footTip: { x: ankle.x - 5, y: ankle.y + 5 },
          kneeFar,
          ankleFar,
          footTipFar: { x: ankleFar.x - 5, y: ankleFar.y + 5 },
          arrows: [{ from: { x: 104, y: 128 }, to: { x: 154, y: 126 } }],
        };
      }
      const footTip: Point2D = { x: 54, y: 150 };
      const ankle: Point2D = { x: 56, y: 144 };
      const wrist: Point2D = { x: 206, y: 148 };
      const elbow: Point2D = { x: 182, y: 148 };
      const brace = lerp(1.5, -1.5, t);
      const shoulder: Point2D = { x: 184, y: 120 + brace };
      const pelvis: Point2D = { x: 118, y: 126 + brace };
      return {
        apparatus: 'floor',
        techniqueTag: 'Retroversione Bacino RKC',
        head: { x: 204, y: 116 + brace },
        neck: { x: 193, y: 118 + brace },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee: lerpPt(ankle, pelvis, 0.5),
        ankle,
        footTip,
        arrows: [{ from: { x: 118, y: 108 }, to: { x: 118, y: 122 } }],
        guideLine: { p1: { x: 52, y: 126 }, p2: { x: 202, y: 118 } },
      };
    }

    case 'hollow_body': {
      if (idLower.includes('arch_body')) {
        const arc = lerp(2, 10, t);
        return {
          apparatus: 'floor',
          techniqueTag: 'Estensione Superman Prona',
          head: { x: 196, y: 128 - arc },
          neck: { x: 186, y: 131 - arc },
          shoulder: { x: 178, y: 134 - arc },
          elbow: { x: 204, y: 128 - arc },
          wrist: { x: 228, y: 122 - arc },
          pelvis: { x: 132, y: 144 },
          knee: { x: 94, y: 138 - arc * 0.6 },
          ankle: { x: 58, y: 126 - arc },
          footTip: { x: 50, y: 122 - arc },
          arrows: [
            { from: { x: 190, y: 140 }, to: { x: 190, y: 114 } },
            { from: { x: 64, y: 142 }, to: { x: 64, y: 114 } },
          ],
        };
      }
      if (idLower.includes('dragon_flag')) {
        const shoulder: Point2D = { x: 184, y: 142 };
        const leverDeg = lerp(-112, -168, t);
        const pelvis = polar(shoulder, 46, leverDeg);
        const knee = polar(pelvis, 30, leverDeg);
        const ankle = polar(knee, 30, leverDeg);
        return {
          apparatus: 'floor_bench_back',
          techniqueTag: 'Peso Solo sulle Spalle',
          head: { x: 200, y: 140 },
          neck: { x: 191, y: 141 },
          shoulder,
          elbow: { x: 196, y: 136 },
          wrist: { x: 206, y: 140 },
          pelvis,
          knee,
          ankle,
          footTip: polar(ankle, 7, leverDeg - 65),
          arrows: [
            { from: { x: 132, y: 58 }, to: { x: 84, y: 120 }, curved: true, ctrl: { x: 96, y: 74 } },
          ],
        };
      }
      if (idLower.includes('reverse_plank')) {
        const hipLift = lerp(124, 114, t);
        const ankle: Point2D = { x: 214, y: 148 };
        const shoulder: Point2D = { x: 98, y: 104 };
        const pelvis: Point2D = { x: 152, y: hipLift };
        return {
          apparatus: 'floor',
          techniqueTag: 'Ponte Inverso · Glutei Stretti',
          head: { x: 82, y: 94 },
          neck: { x: 91, y: 100 },
          shoulder,
          elbow: lerpPt(shoulder, { x: 86, y: 150 }, 0.5),
          wrist: { x: 86, y: 150 },
          pelvis,
          knee: lerpPt(pelvis, ankle, 0.5),
          ankle,
          footTip: { x: 218, y: 142 },
          arrows: [{ from: { x: 152, y: 134 }, to: { x: 152, y: 112 } }],
          guideLine: { p1: { x: 96, y: 104 }, p2: { x: 214, y: 148 } },
        };
      }
      const lift = lerp(0, 4, t);
      return {
        apparatus: 'floor',
        techniqueTag: 'Zona Lombare Incollata a Terra',
        head: { x: 194, y: 116 - lift },
        neck: { x: 185, y: 124 - lift },
        shoulder: { x: 176, y: 130 - lift },
        elbow: { x: 204, y: 122 - lift },
        wrist: { x: 228, y: 116 - lift },
        pelvis: { x: 128, y: 144 },
        knee: { x: 92, y: 136 - lift },
        ankle: { x: 56, y: 124 - lift },
        footTip: { x: 48, y: 120 - lift },
        arrows: [{ from: { x: 128, y: 120 }, to: { x: 128, y: 142 } }],
      };
    }

    case 'lsit': {
      if (idLower.includes('bar')) {
        const barY = 24;
        const wrist: Point2D = { x: 112, y: barY };
        const lift = lerp(1, -2, t);
        const shoulder: Point2D = { x: 112, y: 70 };
        const pelvis: Point2D = { x: 112, y: 112 };
        return {
          apparatus: 'high_bar',
          barY,
          techniqueTag: 'Squadra a 90° alla Sbarra',
          head: { x: 120, y: 54 },
          neck: { x: 114, y: 64 },
          shoulder,
          elbow: lerpPt(shoulder, wrist, 0.5),
          wrist,
          pelvis,
          knee: { x: 148, y: 112 + lift },
          ankle: { x: 184, y: 111 + lift },
          footTip: { x: 192, y: 106 + lift },
          arrows: [{ from: { x: 158, y: 132 }, to: { x: 158, y: 118 } }],
          guideLine: { p1: { x: 112, y: 112 }, p2: { x: 206, y: 112 } },
        };
      }
      const barY = 122;
      const wrist: Point2D = { x: 118, y: barY };
      const wristFar: Point2D = { x: 132, y: barY - 4 };
      const lift = lerp(1.5, -2.5, t);
      const shoulder: Point2D = { x: 116, y: 74 + lift };
      const shoulderFar: Point2D = { x: 130, y: 71 + lift };
      return {
        apparatus: 'parallettes',
        barY,
        techniqueTag: 'Spalle Depresse · Gambe 90°',
        head: { x: 120, y: 58 + lift },
        neck: { x: 116, y: 68 + lift },
        shoulder,
        elbow: lerpPt(shoulder, wrist, 0.5),
        wrist,
        shoulderFar,
        elbowFar: lerpPt(shoulderFar, wristFar, 0.5),
        wristFar,
        pelvis: { x: 112, y: 114 + lift },
        knee: { x: 148, y: 114 + lift },
        ankle: { x: 184, y: 113 + lift },
        footTip: { x: 192, y: 109 + lift },
        arrows: [{ from: { x: 90, y: 84 }, to: { x: 90, y: 60 } }],
        guideLine: { p1: { x: 112, y: 114 }, p2: { x: 204, y: 114 } },
      };
    }

    case 'front_lever': {
      if (idLower.includes('back_lever')) {
        const barY = 26;
        const wrist: Point2D = { x: 130, y: barY };
        const wobble = lerp(2, -2, t);
        const shoulder: Point2D = { x: 158, y: 82 + wobble };
        return {
          apparatus: 'high_bar',
          barY,
          techniqueTag: 'Back Lever Prono Orizzontale',
          head: { x: 176, y: 88 + wobble },
          neck: { x: 165, y: 85 + wobble },
          shoulder,
          elbow: lerpPt(shoulder, wrist, 0.5),
          wrist,
          pelvis: { x: 108, y: 82 + wobble },
          knee: { x: 80, y: 84 + wobble },
          ankle: { x: 54, y: 85 + wobble },
          footTip: { x: 48, y: 91 + wobble },
          arrows: [{ from: { x: 108, y: 108 }, to: { x: 108, y: 86 } }],
          guideLine: { p1: { x: 48, y: 84 }, p2: { x: 188, y: 84 } },
        };
      }
      const isNegative = idLower.includes('negative');
      const isAdv = idLower.includes('adv');
      const barY = 26;
      const wrist: Point2D = { x: 164, y: barY };
      const bodyAngle = isNegative ? lerp(-72, 18, t) : lerp(3, -2, t);
      const shoulder = polar(wrist, 56, 78);
      const elbow = lerpPt(shoulder, wrist, 0.5);
      const pelvis = polar(shoulder, 48, 180 + bodyAngle);
      const knee = isNegative
        ? polar(pelvis, 28, 180 + bodyAngle)
        : isAdv
        ? polar(pelvis, 28, 134)
        : polar(pelvis, 28, 108);
      const ankle = isNegative
        ? polar(knee, 26, 180 + bodyAngle)
        : polar(knee, 26, 92);
      return {
        apparatus: 'high_bar',
        barY,
        techniqueTag: isNegative ? 'Discesa Orizzontale' : isAdv ? 'Adv. Tuck Front Lever' : 'Front Lever Orizzontale',
        head: { x: shoulder.x + 14, y: shoulder.y - 4 },
        neck: { x: shoulder.x + 5, y: shoulder.y - 2 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x - 6, y: ankle.y + 4 },
        arrows: isNegative
          ? [{ from: { x: 106, y: 44 }, to: { x: 96, y: 102 }, curved: true, ctrl: { x: 86, y: 74 } }]
          : [{ from: { x: 116, y: 108 }, to: { x: 116, y: 84 } }],
        guideLine: { p1: { x: 88, y: 82 }, p2: { x: 204, y: 82 } },
      };
    }

    case 'planche': {
      if (idLower.includes('frog')) {
        const wrist: Point2D = { x: 148, y: 150 };
        const lean = lerp(0, 6, t);
        const shoulder: Point2D = { x: 158 + lean, y: 108 };
        const elbow = solve2LinkIK(shoulder, wrist, 24, 24, 1);
        return {
          apparatus: 'floor',
          techniqueTag: 'Frog Stand · Ginocchia sui Gomiti',
          head: { x: shoulder.x + 16, y: shoulder.y + 4 },
          neck: { x: shoulder.x + 7, y: shoulder.y + 2 },
          shoulder,
          elbow,
          wrist,
          pelvis: { x: 116 + lean, y: 106 },
          knee: { x: elbow.x - 4, y: elbow.y - 4 },
          ankle: { x: 106 + lean, y: 126 },
          footTip: { x: 100 + lean, y: 129 },
          arrows: [{ from: { x: 134, y: 108 }, to: { x: 174, y: 108 } }],
        };
      }
      const isTuck = idLower.includes('tuck');
      const wrist: Point2D = { x: 156, y: 150 };
      const lean = lerp(0, 5, t);
      const shoulder: Point2D = { x: 178 + lean, y: 100 };
      const elbow = lerpPt(shoulder, wrist, 0.5);
      const pelvis: Point2D = { x: 124 + lean, y: 98 };
      const knee: Point2D = isTuck ? { x: 140 + lean, y: 124 } : { x: 88 + lean, y: 98 };
      const ankle: Point2D = isTuck ? { x: 114 + lean, y: 128 } : { x: 54 + lean, y: 98 };
      return {
        apparatus: 'floor',
        techniqueTag: isTuck ? 'Tuck Planche · Braccia Tese' : 'Planche · Lean & Protrazione',
        head: { x: shoulder.x + 15, y: shoulder.y + 2 },
        neck: { x: shoulder.x + 6, y: shoulder.y + 1 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x - 6, y: ankle.y + 2 },
        arrows: [{ from: { x: 156, y: 96 }, to: { x: 186, y: 96 } }],
        guideLine: { p1: { x: 54, y: 98 }, p2: { x: 196, y: 98 } },
      };
    }

    case 'handstand': {
      const isWall = idLower.includes('wall');
      const wrist: Point2D = { x: 146, y: 150 };
      const lift = lerp(0, -2, t);
      const shoulder: Point2D = { x: 146, y: 102 + lift };
      const pelvis: Point2D = { x: isWall ? 132 : 146, y: 60 + lift };
      const knee: Point2D = { x: isWall ? 124 : 146, y: 38 + lift };
      const ankle: Point2D = { x: isWall ? 116 : 146, y: 18 + lift };
      return {
        apparatus: isWall ? 'wall_floor' : 'floor',
        wallX: 110,
        techniqueTag: isWall ? 'Verticale al Muro (Hollow)' : 'Equilibrio Polpastrelli (180°)',
        head: { x: shoulder.x + 2, y: shoulder.y + 15 },
        neck: { x: shoulder.x, y: shoulder.y + 6 },
        shoulder,
        elbow: lerpPt(shoulder, wrist, 0.5),
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: ankle.x + 8, y: ankle.y - 3 },
        arrows: [{ from: { x: 184, y: 96 }, to: { x: 184, y: 54 } }],
        guideLine: { p1: { x: 146, y: 14 }, p2: { x: 146, y: 150 } },
      };
    }

    // ==================================================================
    // 4. GAMBE & STRETCHING (4 DISTINCT ANIMATION SCHEMAS + SUB-VARIANTS)
    // ==================================================================
    case 'squat': {
      if (idLower.includes('nordic')) {
        const knee: Point2D = { x: 108, y: 146 };
        const hingeDeg = lerp(-88, -22, t);
        const pelvis = polar(knee, 36, hingeDeg);
        const shoulder = polar(pelvis, 42, hingeDeg);
        const neck = polar(shoulder, 9, hingeDeg);
        const elbow = polar(shoulder, 20, lerp(65, 30, t));
        return {
          apparatus: 'ankle_anchor',
          techniqueTag: 'Nordic Curl · Discesa Frenata',
          head: polar(neck, 10, hingeDeg),
          neck,
          shoulder,
          elbow,
          wrist: polar(elbow, 18, lerp(30, 45, t)),
          pelvis,
          knee,
          ankle: { x: 66, y: 146 },
          footTip: { x: 62, y: 150 },
          arrows: [
            { from: { x: 122, y: 64 }, to: { x: 186, y: 108 }, curved: true, ctrl: { x: 164, y: 72 } },
          ],
        };
      }
      if (idLower.includes('calf')) {
        const stepY = 136;
        const ankle: Point2D = { x: 132, y: lerp(stepY + 8, stepY - 12, t) };
        const knee: Point2D = { x: 134, y: ankle.y - 36 };
        const pelvis: Point2D = { x: 134, y: knee.y - 36 };
        const shoulder: Point2D = { x: 135, y: pelvis.y - 40 };
        return {
          apparatus: 'step',
          techniqueTag: 'Polpacci su Gradino',
          head: { x: shoulder.x + 1, y: shoulder.y - 16 },
          neck: { x: shoulder.x, y: shoulder.y - 6 },
          shoulder,
          elbow: { x: shoulder.x - 4, y: shoulder.y + 20 },
          wrist: { x: shoulder.x + 2, y: shoulder.y + 38 },
          pelvis,
          knee,
          ankle,
          footTip: { x: 146, y: stepY },
          arrows: [{ from: { x: 174, y: 132 }, to: { x: 174, y: 88 } }],
        };
      }
      if (idLower.includes('shrimp')) {
        const ankle: Point2D = { x: 142, y: 146 };
        const knee = polar(ankle, 34, lerp(-86, -60, t));
        const pelvis = polar(knee, 36, lerp(-94, -182, t));
        const torsoDeg = lerp(-84, -56, t);
        const shoulder = polar(pelvis, 42, torsoDeg);
        const neck = polar(shoulder, 9, torsoDeg);
        const kneeFar = polar(pelvis, 32, lerp(110, 134, t));
        const ankleFar = polar(kneeFar, 26, lerp(-25, 10, t));
        const elbow = polar(shoulder, 20, 6);
        return {
          apparatus: 'floor',
          techniqueTag: 'Shrimp Squat Unilaterale',
          head: polar(neck, 10, torsoDeg),
          neck,
          shoulder,
          elbow,
          wrist: polar(elbow, 18, 2),
          pelvis,
          knee,
          ankle,
          footTip: { x: 158, y: 150 },
          kneeFar,
          ankleFar,
          footTipFar: { x: ankleFar.x - 4, y: ankleFar.y - 6 },
          arrows: [{ from: { x: 184, y: 56 }, to: { x: 184, y: 112 } }],
        };
      }

      const ankle: Point2D = { x: 134, y: 146 };
      const footTip: Point2D = { x: 152, y: 150 };
      const shinDeg = lerp(-86, -62, t);
      const thighDeg = lerp(-94, -172, t);
      const torsoDeg = lerp(-88, -60, t);
      const knee = polar(ankle, 34, shinDeg);
      const pelvis = polar(knee, 36, thighDeg);
      const shoulder = polar(pelvis, 44, torsoDeg);
      const neck = polar(shoulder, 9, torsoDeg);
      const head = polar(neck, 10, torsoDeg);
      const elbow = polar(shoulder, 20, lerp(78, 0, t));
      const wrist = polar(elbow, 18, lerp(80, -4, t));
      return {
        apparatus: 'floor',
        techniqueTag: 'Anca Sotto il Ginocchio',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip,
        arrows: [{ from: { x: 184, y: 48 }, to: { x: 184, y: 108 } }],
      };
    }

    case 'pistol_squat': {
      const ankle: Point2D = { x: 132, y: 146 };
      const footTip: Point2D = { x: 150, y: 150 };
      const shinDeg = lerp(-86, -56, t);
      const thighDeg = lerp(-94, -184, t);
      const torsoDeg = lerp(-88, -54, t);
      const knee = polar(ankle, 34, shinDeg);
      const pelvis = polar(knee, 36, thighDeg);
      const shoulder = polar(pelvis, 42, torsoDeg);
      const neck = polar(shoulder, 9, torsoDeg);
      const head = polar(neck, 10, torsoDeg);
      const freeLegDeg = lerp(58, -4, t);
      const kneeFar = polar(pelvis, 34, freeLegDeg);
      const ankleFar = polar(kneeFar, 32, freeLegDeg);
      const elbow = polar(shoulder, 20, 4);
      const wrist = polar(elbow, 18, 0);
      return {
        apparatus: 'floor',
        bilateralFront: true,
        techniqueTag: '1 Gamba Tesa Orizzontale Avanti',
        head,
        neck,
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip,
        kneeFar,
        ankleFar,
        footTipFar: polar(ankleFar, 7, freeLegDeg - 70),
        arrows: [{ from: { x: 102, y: 60 }, to: { x: 90, y: 122 } }],
      };
    }

    case 'lunges': {
      const isBulg = idLower.includes('bulgarian');
      const ankleFront: Point2D = { x: 174, y: 146 };
      const footTipFront: Point2D = { x: 192, y: 150 };
      const ankleRear: Point2D = isBulg ? { x: 74, y: 112 } : { x: 88, y: 144 };
      const footTipRear: Point2D = isBulg ? { x: 64, y: 116 } : { x: 84, y: 150 };

      const pelvis: Point2D = { x: lerp(132, 130, t), y: lerp(80, 114, t) };
      const knee = solve2LinkIK(pelvis, ankleFront, 34, 34, 1);
      const kneeFar = solve2LinkIK(pelvis, ankleRear, 34, 34, -1);
      const shoulder: Point2D = { x: pelvis.x + 2, y: pelvis.y - 42 };
      const elbow: Point2D = { x: shoulder.x + 4, y: shoulder.y + 20 };
      const wrist: Point2D = { x: elbow.x + 4, y: elbow.y + 18 };
      return {
        apparatus: isBulg ? 'elevated_box_rear' : 'floor',
        techniqueTag: isBulg ? 'Bulgarian Split Squat · Box' : 'Affondo · Ginocchia 90°',
        head: { x: shoulder.x + 2, y: shoulder.y - 16 },
        neck: { x: shoulder.x + 1, y: shoulder.y - 6 },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle: ankleFront,
        footTip: footTipFront,
        kneeFar,
        ankleFar: ankleRear,
        footTipFar: footTipRear,
        arrows: [{ from: { x: 204, y: 66 }, to: { x: 204, y: 114 } }],
      };
    }

    case 'stretching_cobra_pike':
    default: {
      // Cobra spinal extension pose on floor (pelvis grounded, chest opens smoothly upward)
      const ankle: Point2D = { x: 56, y: 148 };
      const knee: Point2D = { x: 90, y: 148 };
      const pelvis: Point2D = { x: 124, y: 146 };
      const wrist: Point2D = { x: 176, y: 150 };
      const chestLift = lerp(0, -14, t);
      const shoulder: Point2D = { x: 172, y: 108 + chestLift };
      const elbow = solve2LinkIK(shoulder, wrist, 24, 24, -1);
      return {
        apparatus: 'floor',
        techniqueTag: 'Cobra · Apertura Toracica Dolce',
        head: { x: 184, y: 90 + chestLift },
        neck: { x: 177, y: 100 + chestLift },
        shoulder,
        elbow,
        wrist,
        pelvis,
        knee,
        ankle,
        footTip: { x: 46, y: 144 },
        arrows: [{ from: { x: 184, y: 88 }, to: { x: 204, y: 64 } }],
      };
    }
  }
}

export interface VisualCalloutLabel {
  text: string;
  x: number;
  y: number;
  anchor?: 'start' | 'end';
}

export function getVisualCalloutLabels(
  animationId: AnimationId,
  exerciseId?: string
): VisualCalloutLabel[] {
  const idLower = (exerciseId || '').toLowerCase();

  switch (animationId) {
    case 'pullup':
      return [
        { text: 'Mento sopra la sbarra', x: 248, y: 20, anchor: 'end' },
        { text: 'Scapole depresse', x: 32, y: 88, anchor: 'start' },
      ];
    case 'chinup':
      return [
        { text: 'Mento sopra la sbarra', x: 248, y: 20, anchor: 'end' },
        { text: 'Presa supina · Gomiti avanti', x: 32, y: 88, anchor: 'start' },
      ];
    case 'explosive_pullup':
      return [
        { text: 'Porta la sbarra allo sterno', x: 248, y: 20, anchor: 'end' },
        { text: 'Tirata esplosiva', x: 32, y: 90, anchor: 'start' },
      ];
    case 'archer_pullup':
      return [
        { text: 'Mento alla mano di lavoro', x: 32, y: 20, anchor: 'start' },
        { text: 'Braccio opposto teso', x: 248, y: 86, anchor: 'end' },
      ];
    case 'muscle_up':
      return [
        { text: 'Transizione sopra i polsi', x: 248, y: 20, anchor: 'end' },
        { text: 'Lockout braccia tese su', x: 32, y: 42, anchor: 'start' },
      ];
    case 'dead_hang':
      return [
        { text: 'Braccia bloccate tese', x: 32, y: 44, anchor: 'start' },
        { text: 'Spalle attive · No dondolo', x: 248, y: 120, anchor: 'end' },
      ];
    case 'scapular_pullup':
      return [
        { text: 'Braccia bloccate tese', x: 32, y: 44, anchor: 'start' },
        { text: 'Muovi solo le scapole', x: 248, y: 84, anchor: 'end' },
      ];
    case 'australian_pullup':
      return [
        { text: 'Corpo in linea rigida', x: 32, y: 44, anchor: 'start' },
        { text: 'Petto tocca la sbarra', x: 248, y: 44, anchor: 'end' },
      ];
    case 'ring_row':
      return [
        { text: 'Anelli ai lati del petto', x: 248, y: 34, anchor: 'end' },
        { text: 'Corpo dritto e teso', x: 32, y: 88, anchor: 'start' },
      ];
    case 'skin_the_cat':
      return [
        { text: 'Braccia tese in rotazione', x: 32, y: 20, anchor: 'start' },
        { text: 'Controllo lento indietro', x: 248, y: 122, anchor: 'end' },
      ];
    case 'pushup':
      return [
        { text: 'Schiena dritta / Core attivo', x: 32, y: 38, anchor: 'start' },
        { text: 'Gomiti a 45° ai fianchi', x: 248, y: 66, anchor: 'end' },
      ];
    case 'diamond_pushup':
      return [
        { text: 'Mani a diamante sotto sterno', x: 248, y: 38, anchor: 'end' },
        { text: 'Schiena dritta / Core attivo', x: 32, y: 66, anchor: 'start' },
      ];
    case 'archer_pushup':
      return [
        { text: '1 braccio piega · 1 braccio teso', x: 140, y: 20, anchor: 'start' },
        { text: 'Core fermo senza ruotare', x: 32, y: 42, anchor: 'start' },
      ];
    case 'pseudo_planche_pushup':
      return [
        { text: 'Spalle molto oltre i polsi', x: 248, y: 40, anchor: 'end' },
        { text: 'Schiena dritta / Core attivo', x: 32, y: 68, anchor: 'start' },
      ];
    case 'pike_pushup':
      return [
        { text: 'V rovesciata · Bacino alto', x: 32, y: 24, anchor: 'start' },
        { text: 'Fronte avanti alle mani', x: 248, y: 54, anchor: 'end' },
      ];
    case 'hspu':
      return [
        { text: 'Testa avanti alle mani', x: 248, y: 128, anchor: 'end' },
        { text: 'Addome in hollow al muro', x: 248, y: 34, anchor: 'end' },
      ];
    case 'dip':
      return [
        { text: 'Scendi con spalle sotto gomiti', x: 248, y: 24, anchor: 'end' },
        { text: 'Spalle lontane dalle orecchie', x: 32, y: 56, anchor: 'start' },
      ];
    case 'ring_dip':
      return [
        { text: 'Anelli vicini ai fianchi', x: 32, y: 24, anchor: 'start' },
        { text: 'Ruota polsi fuori (RTO)', x: 248, y: 24, anchor: 'end' },
      ];
    case 'korean_dip':
      return [
        { text: 'Sbarra dietro il bacino', x: 32, y: 34, anchor: 'start' },
        { text: 'Spalle aperte controllate', x: 248, y: 24, anchor: 'end' },
      ];
    case 'hanging_leg_raises':
      return idLower.includes('lying')
        ? [
            { text: 'Lombari aderenti a terra', x: 248, y: 50, anchor: 'end' },
            { text: 'Solleva solo le gambe', x: 32, y: 50, anchor: 'start' },
          ]
        : [
            { text: 'Solleva solo le gambe', x: 248, y: 76, anchor: 'end' },
            { text: 'Busto fermo senza dondolo', x: 248, y: 44, anchor: 'end' },
          ];
    case 'knee_raises':
      return [
        { text: 'Solleva solo le gambe', x: 248, y: 76, anchor: 'end' },
        { text: 'Arrotola il bacino al petto', x: 248, y: 44, anchor: 'end' },
      ];
    case 'crunch':
      return [
        { text: 'Lombari incollati a terra', x: 248, y: 50, anchor: 'end' },
        { text: 'Stacca solo le scapole', x: 32, y: 50, anchor: 'start' },
      ];
    case 'situp':
      return [
        { text: 'Sali fluido con la colonna', x: 32, y: 44, anchor: 'start' },
        { text: 'Piedi stabili sul suolo', x: 248, y: 66, anchor: 'end' },
      ];
    case 'bicycle_crunch':
      return [
        { text: 'Gomito verso ginocchio opposto', x: 32, y: 34, anchor: 'start' },
        { text: 'Lombari bassi aderenti', x: 248, y: 58, anchor: 'end' },
      ];
    case 'russian_twist':
      return [
        { text: 'Ruota le spalle a 45°', x: 32, y: 38, anchor: 'start' },
        { text: 'Piedi staccati e stabili', x: 248, y: 64, anchor: 'end' },
      ];
    case 'plank':
      return idLower.includes('side_plank')
        ? [
            { text: 'Linea dritta testa-piedi', x: 32, y: 44, anchor: 'start' },
            { text: 'Spingi le anche in alto', x: 248, y: 44, anchor: 'end' },
          ]
        : [
            { text: 'Schiena dritta / Core attivo', x: 32, y: 48, anchor: 'start' },
            { text: 'Glutei stretti · No arco lombare', x: 248, y: 72, anchor: 'end' },
          ];
    case 'hollow_body':
      return idLower.includes('dragon_flag')
        ? [
            { text: 'Corpo rigido su spalle', x: 32, y: 36, anchor: 'start' },
            { text: 'Mai peso sul collo', x: 248, y: 64, anchor: 'end' },
          ]
        : [
            { text: 'Lombari incollati a terra', x: 32, y: 54, anchor: 'start' },
            { text: 'Braccia e gambe tese basse', x: 248, y: 78, anchor: 'end' },
          ];
    case 'lsit':
      return [
        { text: 'Braccia bloccate spinta giù', x: 32, y: 36, anchor: 'start' },
        { text: 'Gambe tese a 90°', x: 248, y: 74, anchor: 'end' },
      ];
    case 'front_lever':
      return [
        { text: 'Braccia bloccate tese', x: 248, y: 34, anchor: 'end' },
        { text: 'Linea orizzontale dorsali', x: 32, y: 122, anchor: 'start' },
      ];
    case 'planche':
      return [
        { text: 'Braccia bloccate tese', x: 32, y: 44, anchor: 'start' },
        { text: 'Spalle sbilanciate avanti', x: 248, y: 44, anchor: 'end' },
      ];
    case 'handstand':
      return [
        { text: 'Linea verticale 180°', x: 248, y: 32, anchor: 'end' },
        { text: 'Bilancia coi polpastrelli', x: 248, y: 128, anchor: 'end' },
      ];
    case 'squat':
      return idLower.includes('nordic')
        ? [
            { text: 'Anche dritte in discesa', x: 248, y: 40, anchor: 'end' },
            { text: 'Frena coi femorali', x: 32, y: 68, anchor: 'start' },
          ]
        : [
            { text: 'Anca sotto al ginocchio', x: 248, y: 36, anchor: 'end' },
            { text: 'Talloni fissi a terra', x: 32, y: 128, anchor: 'start' },
          ];
    case 'pistol_squat':
      return [
        { text: '1 gamba tesa orizzontale', x: 248, y: 40, anchor: 'end' },
        { text: 'Tallone fisso a terra', x: 32, y: 128, anchor: 'start' },
      ];
    case 'lunges':
      return [
        { text: 'Busto dritto · Ginocchia 90°', x: 32, y: 34, anchor: 'start' },
        { text: 'Sfiora terra senza sbattere', x: 248, y: 64, anchor: 'end' },
      ];
    case 'stretching_cobra_pike':
    default:
      return [
        { text: 'Bacino appoggiato a terra', x: 32, y: 66, anchor: 'start' },
        { text: 'Apri il petto verso l’alto', x: 248, y: 42, anchor: 'end' },
      ];
  }
}
