import { getExerciseById } from '../data/exercises';
import type {
  AthleteProfile,
  CoachActionProposal,
  WorkoutDayPlan,
} from '../types/calisthenics';

export function applyCoachProposalToPlan(
  proposal: CoachActionProposal,
  weeklyPlan: WorkoutDayPlan[],
  profile: AthleteProfile
): { updatedPlan: WorkoutDayPlan[]; updatedProfile: AthleteProfile } {
  let updatedProfile = { ...profile };

  const updatedPlan = weeklyPlan.map((day) => {
    const updatedExercises = day.exercises.map((item) => {
      if (proposal.type === 'deload_volume') {
        const mult = proposal.deloadMultiplier ?? 0.75;
        return {
          ...item,
          sets: item.sets.map((s) => ({
            ...s,
            targetValue: Math.max(3, Math.round(s.targetValue * mult)),
            actualValue: Math.max(3, Math.round(s.targetValue * mult)),
          })),
        };
      }

      if (item.exerciseId !== proposal.exerciseId) return item;

      if (proposal.type === 'increase_target' && proposal.newTargetDelta) {
        const delta = proposal.newTargetDelta;
        return {
          ...item,
          sets: item.sets.map((s) => ({
            ...s,
            targetValue: Math.max(1, s.targetValue + delta),
            actualValue: Math.max(1, s.targetValue + delta),
          })),
        };
      }

      if (
        (proposal.type === 'advance_progression' || proposal.type === 'joint_swap') &&
        proposal.newExerciseId
      ) {
        const newDef = getExerciseById(proposal.newExerciseId);
        if (!newDef) return item;
        const baseTarget = newDef.type === 'isometric' ? 12 : 6;
        return {
          ...item,
          exerciseId: newDef.id,
          customName: undefined,
          customCategory: undefined,
          isIsometric: newDef.type === 'isometric',
          variantNote: newDef.variantHint,
          restSeconds: newDef.defaultRestSec,
          sets: item.sets.map((s) => ({
            ...s,
            targetValue: baseTarget,
            actualValue: baseTarget,
            addedWeightKg: newDef.supportsWeight ? s.addedWeightKg : 0,
            completed: false,
            rpe: null,
          })),
        };
      }

      return item;
    });

    return { ...day, exercises: updatedExercises };
  });

  if (proposal.type === 'joint_swap' && proposal.jointProtected) {
    if (!updatedProfile.injuries.includes(proposal.jointProtected)) {
      updatedProfile = {
        ...updatedProfile,
        injuries: [...updatedProfile.injuries, proposal.jointProtected],
        updatedAt: new Date().toISOString(),
      };
    }
  }

  return { updatedPlan, updatedProfile };
}
