import { getExerciseById } from '../data/exercises';
import type { AthleteProfile, WeekdayId, WorkoutDayPlan } from '../types/calisthenics';

export const WEEKDAY_ORDER: { id: WeekdayId; short: string; label: string; jsDay: number }[] = [
  { id: 'lun', short: 'Lun', label: 'Lunedì', jsDay: 1 },
  { id: 'mar', short: 'Mar', label: 'Martedì', jsDay: 2 },
  { id: 'mer', short: 'Mer', label: 'Mercoledì', jsDay: 3 },
  { id: 'gio', short: 'Gio', label: 'Giovedì', jsDay: 4 },
  { id: 'ven', short: 'Ven', label: 'Venerdì', jsDay: 5 },
  { id: 'sab', short: 'Sab', label: 'Sabato', jsDay: 6 },
  { id: 'dom', short: 'Dom', label: 'Domenica', jsDay: 0 },
];

export function getTodayWeekdayId(date = new Date()): WeekdayId {
  const jsDay = date.getDay();
  return WEEKDAY_ORDER.find((w) => w.jsDay === jsDay)?.id ?? 'lun';
}

export function getWeekdayLabel(id: WeekdayId): string {
  return WEEKDAY_ORDER.find((w) => w.id === id)?.label ?? id;
}

export function getWeekdayShort(id: WeekdayId): string {
  return WEEKDAY_ORDER.find((w) => w.id === id)?.short ?? id;
}

export function buildWorkoutNotificationBody(
  profile: AthleteProfile,
  weeklyPlan: WorkoutDayPlan[]
): string {
  const todayId = getTodayWeekdayId();
  const matchingDay =
    weeklyPlan.find((d) => d.weekday === todayId) ?? weeklyPlan[0];

  if (!matchingDay || matchingDay.exercises.length === 0) {
    return `È l'ora del tuo allenamento di Calisthenics, ${profile.name}! Apri Kallisto e inizia la sessione.`;
  }

  const names = matchingDay.exercises
    .slice(0, 2)
    .map((ex) => ex.customName ?? getExerciseById(ex.exerciseId)?.name ?? ex.exerciseId);

  const exerciseText =
    names.length === 2
      ? `${names[0]} e ${names[1]}`
      : names[0] ?? matchingDay.title;

  return `È l'ora del tuo allenamento di Calisthenics! Oggi ti aspettano ${exerciseText}.`;
}

export function isNotificationSupported(): boolean {
  return typeof window !== 'undefined' && 'Notification' in window;
}

export async function requestNotificationPermission(): Promise<NotificationPermission | 'unsupported'> {
  if (!isNotificationSupported()) return 'unsupported';
  try {
    const result = await window.Notification.requestPermission();
    return result;
  } catch {
    return window.Notification.permission;
  }
}

export async function sendWorkoutNotification(
  title: string,
  body: string
): Promise<{ ok: boolean; reason?: string }> {
  if (!isNotificationSupported()) {
    return { ok: false, reason: 'Il browser non supporta le notifiche Web.' };
  }

  let permission: NotificationPermission | 'unsupported' = window.Notification.permission;
  if (permission === 'default') {
    permission = await requestNotificationPermission();
  }

  if (permission !== 'granted') {
    return {
      ok: false,
      reason:
        permission === 'denied'
          ? 'Permesso notifiche negato nelle impostazioni del browser/telefono.'
          : 'Permesso notifiche non concesso.',
    };
  }

  try {
    if ('serviceWorker' in navigator) {
      const reg = await Promise.race([
        navigator.serviceWorker.ready,
        new Promise<null>((resolve) => setTimeout(() => resolve(null), 600)),
      ]);
      if (reg && typeof reg.showNotification === 'function') {
        await reg.showNotification(title, {
          body,
          icon: '/pwa-192x192.png',
          badge: '/pwa-192x192.png',
          tag: 'kallisto-workout-reminder',
        });
        return { ok: true };
      }
    }

    new window.Notification(title, {
      body,
      icon: '/pwa-192x192.png',
      tag: 'kallisto-workout-reminder',
    });
    return { ok: true };
  } catch (err) {
    return {
      ok: false,
      reason:
        err instanceof Error
          ? err.message
          : 'Impossibile mostrare la notifica in questo contesto.',
    };
  }
}
