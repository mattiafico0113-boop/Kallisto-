export interface ProgressPhotoEntry {
  id: string;
  accountId: string;
  dateISO: string;
  weightKg: number | null;
  note?: string;
  dataUrl: string;
}

const DB_NAME = 'kallisto_photo_diary_v1';
const DB_VERSION = 1;
const STORE_NAME = 'progress_photos';

function openPhotoDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !('indexedDB' in window)) {
      reject(new Error('IndexedDB non supportato su questo browser.'));
      return;
    }
    const req = window.indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' });
        store.createIndex('accountId', 'accountId', { unique: false });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error('Errore apertura database foto.'));
  });
}

export async function loadProgressPhotos(accountId: string): Promise<ProgressPhotoEntry[]> {
  try {
    const db = await openPhotoDB();
    return await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const index = store.index('accountId');
      const req = index.getAll(accountId);
      req.onsuccess = () => {
        const items = (req.result as ProgressPhotoEntry[]) ?? [];
        items.sort((a, b) => new Date(b.dateISO).getTime() - new Date(a.dateISO).getTime());
        resolve(items);
      };
      req.onerror = () => reject(req.error);
    });
  } catch {
    return [];
  }
}

export async function saveProgressPhoto(entry: ProgressPhotoEntry): Promise<void> {
  const db = await openPhotoDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).put(entry);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('Errore salvataggio foto.'));
  });
}

export async function deleteProgressPhoto(id: string): Promise<void> {
  const db = await openPhotoDB();
  await new Promise<void>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, 'readwrite');
    tx.objectStore(STORE_NAME).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error('Errore eliminazione foto.'));
  });
}

export async function replaceProgressPhotosForAccount(
  accountId: string,
  entries: ProgressPhotoEntry[]
): Promise<void> {
  if (!Array.isArray(entries)) return;
  try {
    const db = await openPhotoDB();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      for (const entry of entries) {
        if (entry && typeof entry.id === 'string' && typeof entry.dataUrl === 'string') {
          store.put({
            ...entry,
            accountId,
          });
        }
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error('Errore ripristino foto.'));
    });
  } catch {
    // ignore IndexedDB errors
  }
}

/**
 * Comprime automaticamente qualsiasi immagine (camera o galleria) in JPEG compatto max 960px
 * prima del salvataggio su IndexedDB per non appesantire la memoria del telefono.
 */
export async function compressProgressImage(file: File): Promise<string> {
  const maxDim = 960;
  const quality = 0.76;

  const rawDataUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        resolve(reader.result);
      } else {
        reject(new Error('Lettura file immagine non riuscita.'));
      }
    };
    reader.onerror = () => reject(new Error('Impossibile leggere il file selezionato.'));
    reader.readAsDataURL(file);
  });

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = () => reject(new Error('Formato immagine non valido.'));
    el.src = rawDataUrl;
  });

  const scale = Math.min(1, maxDim / Math.max(img.naturalWidth || 1, img.naturalHeight || 1));
  const targetW = Math.max(1, Math.round((img.naturalWidth || maxDim) * scale));
  const targetH = Math.max(1, Math.round((img.naturalHeight || maxDim) * scale));

  const canvas = document.createElement('canvas');
  canvas.width = targetW;
  canvas.height = targetH;
  const ctx = canvas.getContext('2d');
  if (!ctx) return rawDataUrl;

  ctx.drawImage(img, 0, 0, targetW, targetH);
  return canvas.toDataURL('image/jpeg', quality);
}
