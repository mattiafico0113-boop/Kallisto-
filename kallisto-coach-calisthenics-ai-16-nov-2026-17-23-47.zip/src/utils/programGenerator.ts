import { EXERCISE_CATALOG, getExerciseById } from '../data/exercises';
import type {
  AthleteProfile,
  EquipmentId,
  ExerciseCategory,
  ExerciseDefinition,
  JointId,
  SetLog,
  StretchExerciseItem,
  WarmupExerciseItem,
  WeekdayId,
  WorkoutDayPlan,
  WorkoutExerciseItem,
} from '../types/calisthenics';
import { getWeekdayShort } from './notifications';

export function generateWarmupForDay(
  dayTitleOrFocus: string,
  equipment: EquipmentId[] = ['sbarra', 'pavimento'],
  injuries: JointId[] = []
): WarmupExerciseItem[] {
  const lower = dayTitleOrFocus.toLowerCase();
  const hasBar = equipment.includes('sbarra') || equipment.includes('anelli');
  const hasBands = equipment.includes('elastici');
  const isLowerFocus =
    lower.includes('lower') || lower.includes('legs') || lower.includes('gambe');

  const items: WarmupExerciseItem[] = [
    {
      id: uid('warm'),
      name: injuries.includes('polsi')
        ? 'Rotazioni dolci dei polsi e mobilità avambracci'
        : 'Rotazioni polsi e appoggi palmari a terra',
      targetLabel: '2 × 30s',
      notes: 'Prepara polsi e flessori alle spinte e verticali',
      completed: false,
    },
    {
      id: uid('warm'),
      name: hasBands
        ? 'Circonduzioni spalle con elastico'
        : 'Circonduzioni ampie delle spalle e apertura toracica',
      targetLabel: '2 × 12 rip',
      notes: 'Braccia tese, movimento fluido per scaldare la cuffia dei rotatori',
      completed: false,
    },
  ];

  if (isLowerFocus) {
    items.push({
      id: uid('warm'),
      name: 'Mobilità anche e caviglie (Deep Squat Hold)',
      targetLabel: '2 × 30s',
      notes: 'Talloni saldi a terra, busto aperto e controllo del ginocchio',
      completed: false,
    });
  } else {
    items.push({
      id: uid('warm'),
      name: hasBar
        ? 'Scapular Pull-up alla sbarra'
        : 'Scapular Push-up di attivazione',
      targetLabel: '2 × 10 rip',
      notes: 'Attivazione scapolare pura mantenendo i gomiti bloccati tesi',
      completed: false,
    });
  }

  items.push({
    id: uid('warm'),
    name: 'Plank di attivazione e Hollow Hold',
    targetLabel: '2 × 25s',
    notes: 'Retroversione del bacino e attivazione del core prima delle serie allenanti',
    completed: false,
  });

  return items;
}

export function generateStretchingForDay(
  dayTitleOrFocus: string,
  equipment: EquipmentId[] = ['sbarra', 'pavimento']
): StretchExerciseItem[] {
  const lower = dayTitleOrFocus.toLowerCase();
  const hasBar = equipment.includes('sbarra') || equipment.includes('anelli');
  const isLower = lower.includes('lower') || lower.includes('legs') || lower.includes('gambe');

  return [
    {
      id: uid('stretch'),
      name: hasBar
        ? 'Allungamento dorsali alla sbarra (o muro)'
        : 'Allungamento dorsali al muro / Child Pose',
      targetLabel: '2 × 30s',
      notes: 'Respira profondamente lasciando aprire gran dorsale e torace',
      completed: false,
    },
    {
      id: uid('stretch'),
      name: 'Stretching pettorali e spalle al muro',
      targetLabel: '2 × 30s per lato',
      notes: 'Apertura controllata della spalla senza forzare la capsula articolare',
      completed: false,
    },
    {
      id: uid('stretch'),
      name: 'Cobra Stretch per addome e flessori',
      targetLabel: '2 × 30s',
      notes: 'Decomprimi addome e psoas tenendo le spalle basse e rilassate',
      completed: false,
    },
    {
      id: uid('stretch'),
      name: isLower
        ? 'Piega in avanti profonda e stretching quadricipiti'
        : 'Piega in avanti per femorali (Forward Fold)',
      targetLabel: '2 × 35s',
      notes: 'Schiena lunga, rilassa il collo ad ogni espirazione',
      completed: false,
    },
    {
      id: uid('stretch'),
      name: 'Mobilità e scarico polsi a terra',
      targetLabel: '2 × 25s',
      notes: 'Scarico dolce dei flessori ed estensori dell’avambraccio post-allenamento',
      completed: false,
    },
  ];
}

function uid(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}

export function isExerciseAvailable(
  ex: ExerciseDefinition,
  equipment: EquipmentId[],
  injuries: JointId[]
): boolean {
  // Joint check: avoid exercises that load injured joints if a safe alternative exists
  if (injuries.some((inj) => ex.jointLoad.includes(inj))) {
    return false;
  }

  // Equipment check
  if (ex.requiresAnyOf && ex.requiresAnyOf.length > 0) {
    const hasRequired = ex.requiresAnyOf.some((eq) => equipment.includes(eq));
    if (!hasRequired) return false;
  }

  // Extra equipment requirements (e.g., weighted_pullup requires zavorra)
  if (ex.id === 'weighted_pullup' && !equipment.includes('zavorra')) {
    return false;
  }

  return true;
}

function pickBestExercise(
  preferredIds: string[],
  fallbackCategory: ExerciseCategory,
  profile: AthleteProfile,
  usedIds: Set<string>,
  targetDifficulty: number
): ExerciseDefinition | null {
  const { equipment, injuries } = profile;

  // 1. Try preferred list in order, respecting availability & avoiding duplicates in same day
  for (const id of preferredIds) {
    if (usedIds.has(id)) continue;
    const ex = getExerciseById(id);
    if (!ex) continue;
    if (isExerciseAvailable(ex, equipment, injuries)) {
      return ex;
    }
    // Check safe alternative if blocked by injury
    if (ex.safeAlternativeId && !usedIds.has(ex.safeAlternativeId)) {
      const alt = getExerciseById(ex.safeAlternativeId);
      if (alt && isExerciseAvailable(alt, equipment, injuries)) {
        return alt;
      }
    }
  }

  // 2. Fallback to any available exercise in same category closest to targetDifficulty
  const candidates = EXERCISE_CATALOG.filter(
    (ex) =>
      ex.category === fallbackCategory &&
      !usedIds.has(ex.id) &&
      isExerciseAvailable(ex, equipment, injuries)
  ).sort((a, b) => Math.abs(a.difficulty - targetDifficulty) - Math.abs(b.difficulty - targetDifficulty));

  if (candidates.length > 0) return candidates[0];

  // 3. Relax injury filter only if zero exercises exist in category (pick lowest jointLoad overlap)
  const relaxed = EXERCISE_CATALOG.filter(
    (ex) =>
      ex.category === fallbackCategory &&
      !usedIds.has(ex.id) &&
      (!ex.requiresAnyOf || ex.requiresAnyOf.some((eq) => equipment.includes(eq)))
  ).sort((a, b) => a.jointLoad.length - b.jointLoad.length);

  return relaxed[0] ?? null;
}

function calibrateTarget(ex: ExerciseDefinition, profile: AthleteProfile): {
  setsCount: number;
  targetValue: number;
  addedWeightKg: number;
  restSeconds: number;
  variantNote: string;
} {
  const { baselines, goal, equipment } = profile;
  const hasBands = equipment.includes('elastici');
  const hasWeight = equipment.includes('zavorra') && ex.supportsWeight;

  let setsCount = goal === 'forza' ? 4 : goal === 'ipertrofia' ? 4 : 3;
  if (ex.category === 'Core' || ex.category === 'Skill') {
    setsCount = goal === 'skill' && ex.category === 'Skill' ? 5 : 3;
  }

  let restSeconds = ex.defaultRestSec;
  if (goal === 'forza') restSeconds = Math.max(restSeconds, 150);
  if (goal === 'ricomposizione') restSeconds = Math.max(60, Math.round(restSeconds * 0.75));

  let targetValue = ex.type === 'isometric' ? 15 : 8;
  let addedWeightKg = 0;
  let variantNote = ex.variantHint;

  // Calibrate using baselines
  if (ex.category === 'Tirata') {
    if (ex.id === 'pull_up' || ex.id === 'chin_up' || ex.id === 'commando_pullup') {
      if (baselines.pullups <= 3) {
        targetValue = 4;
        variantNote = hasBands
          ? `${ex.variantHint} · Con elastico leggero o negative lente 4s`
          : `${ex.variantHint} · Negative lente 4s se necessario`;
      } else if (baselines.pullups <= 8) {
        targetValue = Math.max(4, Math.round(baselines.pullups * 0.7));
      } else {
        targetValue = Math.min(12, Math.round(baselines.pullups * 0.72));
        if (hasWeight && goal === 'forza') {
          addedWeightKg = 5;
          targetValue = 6;
        }
      }
    } else if (ex.id === 'weighted_pullup') {
      addedWeightKg = baselines.pullups >= 12 ? 10 : 5;
      targetValue = 5;
    } else if (ex.id === 'australian_pullup_prona' || ex.id === 'australian_pullup_supina' || ex.id === 'ring_row') {
      targetValue = baselines.pullups >= 8 ? 12 : 10;
    } else if (ex.id === 'high_pullup' || ex.id === 'archer_pullup') {
      targetValue = 4;
    } else if (ex.id === 'scapular_pullup') {
      targetValue = 10;
    }
  } else if (ex.category === 'Spinta') {
    if (ex.id === 'dip_parallele' || ex.id === 'ring_dip') {
      if (baselines.dips <= 3) {
        targetValue = 5;
        variantNote = hasBands
          ? `${ex.variantHint} · Elastico sotto le ginocchia o negative controllate`
          : `${ex.variantHint} · Concentrati su negative lente 3-4s`;
      } else if (baselines.dips <= 10) {
        targetValue = Math.max(5, Math.round(baselines.dips * 0.7));
      } else {
        targetValue = Math.min(14, Math.round(baselines.dips * 0.72));
        if (hasWeight && (goal === 'forza' || goal === 'ipertrofia')) {
          addedWeightKg = baselines.dips >= 15 ? 10 : 5;
          targetValue = goal === 'forza' ? 6 : 8;
        }
      }
    } else if (ex.id === 'push_up' || ex.id === 'parallettes_pushup') {
      targetValue = Math.max(8, Math.min(20, Math.round(baselines.pushups * 0.65)));
    } else if (ex.id === 'diamond_pushup' || ex.id === 'pike_pushup_floor') {
      targetValue = Math.max(6, Math.min(12, Math.round(baselines.pushups * 0.45)));
    } else if (ex.id === 'archer_pushup' || ex.id === 'pseudo_planche_pushup' || ex.id === 'pike_pushup_elevated') {
      targetValue = 6;
    } else if (ex.id === 'wall_hspu' || ex.id === 'korean_dip') {
      targetValue = 5;
    }
  } else if (ex.category === 'Core') {
    if (ex.type === 'isometric') {
      if (ex.id.startsWith('l_sit')) {
        targetValue = baselines.legRaises >= 10 ? 15 : 10;
      } else if (ex.id === 'dead_hang') {
        targetValue = 30;
      } else {
        targetValue = baselines.legRaises >= 8 ? 30 : 20;
      }
    } else if (ex.id === 'crunch' || ex.id === 'bicycle_crunch' || ex.id === 'mountain_climbers' || ex.id === 'russian_twist') {
      targetValue = 16;
    } else {
      targetValue = Math.max(6, Math.min(14, Math.round(Math.max(6, baselines.legRaises) * 0.75)));
    }
  } else if (ex.category === 'Gambe') {
    if (ex.id === 'bodyweight_squat' || ex.id === 'lunges' || ex.id === 'calf_raises') {
      targetValue = goal === 'ricomposizione' ? 16 : 12;
    } else if (ex.id === 'bulgarian_split_squat') {
      targetValue = 10;
    } else {
      targetValue = 6;
    }
  } else if (ex.category === 'Skill') {
    if (ex.id.includes('handstand')) {
      targetValue = 25;
    } else if (ex.id === 'frog_stand' || ex.id === 'skin_the_cat') {
      targetValue = 15;
    } else {
      targetValue = 10;
    }
  }

  if (goal === 'ricomposizione' && ex.type === 'reps') {
    targetValue = Math.min(20, targetValue + 2);
  }

  return { setsCount, targetValue, addedWeightKg, restSeconds, variantNote };
}

function buildExerciseItem(ex: ExerciseDefinition, profile: AthleteProfile): WorkoutExerciseItem {
  const cal = calibrateTarget(ex, profile);
  const sets: SetLog[] = Array.from({ length: cal.setsCount }, () => ({
    id: uid('set'),
    targetValue: cal.targetValue,
    actualValue: cal.targetValue,
    addedWeightKg: cal.addedWeightKg,
    rpe: null,
    completed: false,
  }));

  return {
    instanceId: uid('ex'),
    exerciseId: ex.id,
    variantNote: cal.variantNote,
    isIsometric: ex.type === 'isometric',
    isNegative: ex.isNegative,
    negativeSeconds: ex.negativeSeconds,
    restSeconds: cal.restSeconds,
    sets,
  };
}

function getLevelScore(profile: AthleteProfile): number {
  const { pullups, dips, pushups, legRaises } = profile.baselines;
  return Math.min(10, Math.max(2, Math.round((pullups * 0.4 + dips * 0.3 + pushups * 0.12 + legRaises * 0.25) / 2)));
}

function getSkillChainPreferences(profile: AthleteProfile): string[] {
  const level = getLevelScore(profile);
  switch (profile.targetSkill) {
    case 'planche':
      return level >= 6
        ? ['tuck_planche', 'pseudo_planche_pushup', 'frog_stand']
        : ['frog_stand', 'pseudo_planche_pushup', 'l_sit_parallettes'];
    case 'front_lever':
      return level >= 6
        ? ['adv_tuck_front_lever', 'tuck_front_lever', 'scapular_pullup']
        : ['tuck_front_lever', 'scapular_pullup', 'hollow_body_hold'];
    case 'handstand':
      return level >= 7
        ? ['freestanding_handstand', 'wall_handstand', 'pike_pushup_elevated']
        : ['wall_handstand', 'frog_stand', 'pike_pushup_floor'];
    case 'muscle_up':
      return ['high_pullup', 'pull_up', 'dip_parallele', 'korean_dip'];
    case 'human_flag':
      return ['side_plank', 'wall_handstand', 'archer_pullup', 'hanging_leg_raises'];
    default:
      return ['wall_handstand', 'l_sit_parallettes', 'tuck_front_lever', 'frog_stand'];
  }
}

export function generateWeeklyProgram(profile: AthleteProfile): WorkoutDayPlan[] {
  const level = getLevelScore(profile);
  const selectedWeekdays: WeekdayId[] =
    profile.trainingDays && profile.trainingDays.length > 0
      ? profile.trainingDays
      : ['lun', 'mer', 'ven', 'sab'];
  const days = Math.max(1, Math.min(7, selectedWeekdays.length));

  const pullChain =
    level >= 7
      ? ['weighted_pullup', 'high_pullup', 'pull_up', 'archer_pullup', 'ring_row', 'australian_pullup_prona']
      : level >= 4
      ? ['pull_up', 'chin_up', 'ring_row', 'australian_pullup_prona', 'scapular_pullup']
      : ['australian_pullup_prona', 'ring_row', 'scapular_pullup', 'australian_pullup_supina', 'pull_up'];

  const pullSecondary =
    level >= 6
      ? ['ring_row', 'commando_pullup', 'australian_pullup_supina', 'scapular_pullup']
      : ['australian_pullup_supina', 'scapular_pullup', 'ring_row', 'arch_body_hold'];

  const pushChain =
    level >= 7
      ? ['dip_parallele', 'ring_dip', 'pseudo_planche_pushup', 'pike_pushup_elevated', 'archer_pushup']
      : level >= 4
      ? ['dip_parallele', 'diamond_pushup', 'pike_pushup_floor', 'parallettes_pushup', 'push_up']
      : ['parallettes_pushup', 'push_up', 'diamond_pushup', 'pike_pushup_floor'];

  const pushSecondary =
    level >= 6
      ? ['pike_pushup_elevated', 'archer_pushup', 'diamond_pushup', 'wall_hspu']
      : ['pike_pushup_floor', 'diamond_pushup', 'push_up', 'parallettes_pushup'];

  const coreChain =
    level >= 6
      ? ['hanging_leg_raises', 'l_sit_parallettes', 'v_up', 'dragon_flag_tuck', 'hollow_body_hold', 'dead_hang']
      : ['lying_leg_raises', 'hollow_body_hold', 'crunch', 'bicycle_crunch', 'dead_hang', 'reverse_plank'];

  const legChain =
    level >= 6
      ? ['pistol_squat_assisted', 'pistol_squat', 'bulgarian_split_squat', 'nordic_hamstring_curl', 'calf_raises']
      : ['bulgarian_split_squat', 'bodyweight_squat', 'lunges', 'calf_raises'];

  const skillPrefs = getSkillChainPreferences(profile);

  interface DaySpec {
    title: string;
    splitLabel: string;
    focus: string;
    slots: { prefs: string[]; category: ExerciseCategory }[];
  }

  let specs: DaySpec[] = [];

  if (days <= 3) {
    // Full Body A / B (/ C)
    specs = Array.from({ length: days }, (_, i) => ({
      title: `Full Body ${String.fromCharCode(65 + i)}`,
      splitLabel: 'Full Body',
      focus:
        profile.goal === 'skill' && i === 0
          ? 'Skill + Forza Fondamentale'
          : i % 2 === 0
          ? 'Spinta, Tirata e Gambe'
          : 'Tirata, Spinta Verticale e Core',
      slots: [
        ...(profile.goal === 'skill' ? [{ prefs: skillPrefs, category: 'Skill' as ExerciseCategory }] : []),
        { prefs: i % 2 === 0 ? pullChain : pullSecondary, category: 'Tirata' },
        { prefs: i % 2 === 0 ? pushChain : pushSecondary, category: 'Spinta' },
        { prefs: legChain, category: 'Gambe' },
        { prefs: coreChain, category: 'Core' },
      ],
    }));
  } else if (days === 4) {
    // Upper / Lower x2
    specs = [
      {
        title: 'Upper A — Forza',
        splitLabel: 'Upper',
        focus: 'Trazioni, Dip e Controllo Scapolare',
        slots: [
          ...(profile.goal === 'skill' ? [{ prefs: skillPrefs, category: 'Skill' as ExerciseCategory }] : []),
          { prefs: pullChain, category: 'Tirata' },
          { prefs: pushChain, category: 'Spinta' },
          { prefs: pullSecondary, category: 'Tirata' },
          { prefs: pushSecondary, category: 'Spinta' },
        ],
      },
      {
        title: 'Lower A — Gambe & Core',
        splitLabel: 'Lower',
        focus: 'Forza unilaterale e tenuta addominale',
        slots: [
          { prefs: legChain, category: 'Gambe' },
          { prefs: ['nordic_hamstring_curl', 'lunges', 'bodyweight_squat'], category: 'Gambe' },
          { prefs: coreChain, category: 'Core' },
          { prefs: ['arch_body_hold', 'side_plank', 'calf_raises'], category: 'Core' },
        ],
      },
      {
        title: 'Upper B — Volume & Skill',
        splitLabel: 'Upper',
        focus: 'Spinta verticale, Row e Isometrie',
        slots: [
          { prefs: skillPrefs, category: 'Skill' },
          { prefs: pushSecondary, category: 'Spinta' },
          { prefs: pullSecondary, category: 'Tirata' },
          { prefs: pushChain, category: 'Spinta' },
          { prefs: ['l_sit_parallettes', 'l_sit_floor', 'hollow_body_hold'], category: 'Core' },
        ],
      },
      {
        title: 'Lower B — Esplosività & Core',
        splitLabel: 'Lower',
        focus: 'Catena posteriore, equilibrio e addome',
        slots: [
          { prefs: ['pistol_squat_assisted', 'bulgarian_split_squat', 'lunges'], category: 'Gambe' },
          { prefs: ['calf_raises', 'nordic_hamstring_curl', 'bodyweight_squat'], category: 'Gambe' },
          { prefs: ['hanging_leg_raises', 'dragon_flag_tuck', 'knee_raises'], category: 'Core' },
          { prefs: ['side_plank', 'plank'], category: 'Core' },
        ],
      },
    ];
  } else {
    // 5 or 6 days: Push / Pull / Legs + Upper/Skill
    const basePPL: DaySpec[] = [
      {
        title: 'Push — Spinta & Verticale',
        splitLabel: 'Push',
        focus: 'Dip, Piegamenti avanzati e Spalle',
        slots: [
          { prefs: skillPrefs.filter((id) => getExerciseById(id)?.category === 'Skill').length ? skillPrefs : ['wall_handstand', 'frog_stand'], category: 'Skill' },
          { prefs: pushChain, category: 'Spinta' },
          { prefs: pushSecondary, category: 'Spinta' },
          { prefs: ['diamond_pushup', 'parallettes_pushup', 'push_up'], category: 'Spinta' },
          { prefs: ['l_sit_parallettes', 'l_sit_floor', 'hollow_body_hold'], category: 'Core' },
        ],
      },
      {
        title: 'Pull — Tirata & Leve',
        splitLabel: 'Pull',
        focus: 'Trazioni, Row e Propedeutiche Lever',
        slots: [
          { prefs: ['tuck_front_lever', 'adv_tuck_front_lever', 'skin_the_cat', 'scapular_pullup'], category: 'Skill' },
          { prefs: pullChain, category: 'Tirata' },
          { prefs: pullSecondary, category: 'Tirata' },
          { prefs: ['scapular_pullup', 'australian_pullup_prona', 'ring_row'], category: 'Tirata' },
          { prefs: ['hanging_leg_raises', 'knee_raises', 'hollow_body_hold'], category: 'Core' },
        ],
      },
      {
        title: 'Legs & Core — Basso & Tenuta',
        splitLabel: 'Legs',
        focus: 'Squat unilaterali, Femorali e Core',
        slots: [
          { prefs: legChain, category: 'Gambe' },
          { prefs: ['nordic_hamstring_curl', 'lunges', 'bodyweight_squat'], category: 'Gambe' },
          { prefs: ['calf_raises', 'bodyweight_squat'], category: 'Gambe' },
          { prefs: coreChain, category: 'Core' },
          { prefs: ['arch_body_hold', 'side_plank'], category: 'Core' },
        ],
      },
    ];

    if (days === 5) {
      specs = [
        ...basePPL,
        {
          title: 'Upper Skill & Forza',
          splitLabel: 'Skill',
          focus: 'Qualità tecnica su skill e fondamentali',
          slots: [
            { prefs: skillPrefs, category: 'Skill' },
            { prefs: pullChain, category: 'Tirata' },
            { prefs: pushChain, category: 'Spinta' },
            { prefs: ['l_sit_bar', 'l_sit_parallettes', 'hollow_body_hold'], category: 'Core' },
          ],
        },
        {
          title: 'Full Conditioning & Core',
          splitLabel: 'Condizionamento',
          focus: 'Volume pulito su spinta/tirata e addome',
          slots: [
            { prefs: pushSecondary, category: 'Spinta' },
            { prefs: pullSecondary, category: 'Tirata' },
            { prefs: ['bulgarian_split_squat', 'lunges'], category: 'Gambe' },
            { prefs: ['hanging_leg_raises', 'plank', 'side_plank'], category: 'Core' },
          ],
        },
      ];
    } else if (days === 6) {
      specs = [
        ...basePPL,
        { ...basePPL[0], title: 'Push B — Volume & Skill' },
        { ...basePPL[1], title: 'Pull B — Volume & Controllo' },
        { ...basePPL[2], title: 'Legs & Core B' },
      ];
    } else {
      // 7 days: PPL x2 + Active Skill & Mobility Day
      specs = [
        ...basePPL,
        { ...basePPL[0], title: 'Push B — Volume & Skill' },
        { ...basePPL[1], title: 'Pull B — Volume & Controllo' },
        { ...basePPL[2], title: 'Legs & Core B' },
        {
          title: 'Skill Focus & Mobilità',
          splitLabel: 'Skill',
          focus: 'Tecnica pulita su verticali, leve e core',
          slots: [
            { prefs: skillPrefs, category: 'Skill' },
            { prefs: ['l_sit_parallettes', 'hollow_body_hold', 'arch_body_hold'], category: 'Core' },
            { prefs: ['scapular_pullup', 'plank'], category: 'Tirata' },
          ],
        },
      ];
    }
  }

  return specs.map((spec, idx) => {
    const usedIds = new Set<string>();
    const exercises: WorkoutExerciseItem[] = [];
    const weekday = selectedWeekdays[idx];

    for (const slot of spec.slots) {
      const picked = pickBestExercise(slot.prefs, slot.category, profile, usedIds, level);
      if (picked) {
        usedIds.add(picked.id);
        exercises.push(buildExerciseItem(picked, profile));
      }
    }

    return {
      id: `day_${idx + 1}`,
      dayNumber: idx + 1,
      weekday,
      title: spec.title,
      splitLabel: weekday ? `${getWeekdayShort(weekday)} · ${spec.splitLabel}` : spec.splitLabel,
      focus: spec.focus,
      warmup: generateWarmupForDay(`${spec.title} ${spec.focus}`, profile.equipment, profile.injuries),
      stretch: generateStretchingForDay(`${spec.title} ${spec.focus}`, profile.equipment),
      exercises,
    };
  });
}
