import type { WorkoutDayPlan, WorkoutExerciseItem } from '../types/calisthenics';
import { getExerciseById } from '../data/exercises';

/**
 * Pure TypeScript, zero-dependency, 100% offline QR Code Matrix Generator (Byte mode, EC Level L)
 * Supports Versions 1..14 so workout share tokens render as real scannable QR codes.
 */

const GF_EXP = new Uint8Array(512);
const GF_LOG = new Uint8Array(256);

(() => {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    GF_EXP[i] = x;
    GF_LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i++) {
    GF_EXP[i] = GF_EXP[i - 255];
  }
})();

function gfMul(a: number, b: number): number {
  if (a === 0 || b === 0) return 0;
  return GF_EXP[GF_LOG[a] + GF_LOG[b]];
}

function rsGeneratorPoly(degree: number): Uint8Array {
  let poly = new Uint8Array([1]);
  for (let i = 0; i < degree; i++) {
    const next = new Uint8Array(poly.length + 1);
    const factor = GF_EXP[i];
    for (let j = 0; j < poly.length; j++) {
      next[j] ^= poly[j];
      next[j + 1] ^= gfMul(poly[j], factor);
    }
    poly = next;
  }
  return poly;
}

function rsEncode(data: Uint8Array, ecCount: number): Uint8Array {
  const gen = rsGeneratorPoly(ecCount);
  const res = new Uint8Array(data.length + ecCount);
  res.set(data, 0);
  for (let i = 0; i < data.length; i++) {
    const coef = res[i];
    if (coef !== 0) {
      for (let j = 0; j < gen.length; j++) {
        res[i + j] ^= gfMul(gen[j], coef);
      }
    }
  }
  return res.slice(data.length);
}

// Version capacity & block spec for EC Level L (Versions 1..14)
interface QrVersionSpec {
  version: number;
  totalCodewords: number;
  ecPerBlock: number;
  g1Blocks: number;
  g1Data: number;
  g2Blocks: number;
  g2Data: number;
  alignments: number[];
}

const QR_SPECS_L: QrVersionSpec[] = [
  { version: 1, totalCodewords: 26, ecPerBlock: 7, g1Blocks: 1, g1Data: 19, g2Blocks: 0, g2Data: 0, alignments: [] },
  { version: 2, totalCodewords: 44, ecPerBlock: 10, g1Blocks: 1, g1Data: 34, g2Blocks: 0, g2Data: 0, alignments: [6, 18] },
  { version: 3, totalCodewords: 70, ecPerBlock: 15, g1Blocks: 1, g1Data: 55, g2Blocks: 0, g2Data: 0, alignments: [6, 22] },
  { version: 4, totalCodewords: 100, ecPerBlock: 20, g1Blocks: 1, g1Data: 80, g2Blocks: 0, g2Data: 0, alignments: [6, 26] },
  { version: 5, totalCodewords: 134, ecPerBlock: 26, g1Blocks: 1, g1Data: 108, g2Blocks: 0, g2Data: 0, alignments: [6, 30] },
  { version: 6, totalCodewords: 172, ecPerBlock: 18, g1Blocks: 2, g1Data: 68, g2Blocks: 0, g2Data: 0, alignments: [6, 34] },
  { version: 7, totalCodewords: 196, ecPerBlock: 20, g1Blocks: 2, g1Data: 78, g2Blocks: 0, g2Data: 0, alignments: [6, 22, 38] },
  { version: 8, totalCodewords: 242, ecPerBlock: 24, g1Blocks: 2, g1Data: 97, g2Blocks: 0, g2Data: 0, alignments: [6, 24, 42] },
  { version: 9, totalCodewords: 292, ecPerBlock: 30, g1Blocks: 2, g1Data: 116, g2Blocks: 0, g2Data: 0, alignments: [6, 26, 46] },
  { version: 10, totalCodewords: 346, ecPerBlock: 18, g1Blocks: 2, g1Data: 68, g2Blocks: 2, g2Data: 69, alignments: [6, 28, 50] },
  { version: 11, totalCodewords: 404, ecPerBlock: 20, g1Blocks: 4, g1Data: 81, g2Blocks: 0, g2Data: 0, alignments: [6, 30, 54] },
  { version: 12, totalCodewords: 466, ecPerBlock: 24, g1Blocks: 2, g1Data: 92, g2Blocks: 2, g2Data: 93, alignments: [6, 32, 58] },
  { version: 13, totalCodewords: 532, ecPerBlock: 26, g1Blocks: 4, g1Data: 107, g2Blocks: 0, g2Data: 0, alignments: [6, 34, 62] },
  { version: 14, totalCodewords: 581, ecPerBlock: 30, g1Blocks: 3, g1Data: 115, g2Blocks: 1, g2Data: 116, alignments: [6, 26, 46, 66] },
];

function computeFormatBits(mask: number): number {
  const data = (0b01 << 3) | (mask & 7); // EC L = 01
  let d = data << 10;
  const gen = 0b10100110111;
  for (let i = 14; i >= 10; i--) {
    if ((d >> i) & 1) {
      d ^= gen << (i - 10);
    }
  }
  return ((data << 10) | d) ^ 0b101010000010010;
}

function computeVersionBits(version: number): number {
  let d = version << 12;
  const gen = 0b1111100100101;
  for (let i = 17; i >= 12; i--) {
    if ((d >> i) & 1) {
      d ^= gen << (i - 12);
    }
  }
  return (version << 12) | d;
}

export function generateQrMatrix(text: string): boolean[][] | null {
  const bytes = new TextEncoder().encode(text);
  const spec = QR_SPECS_L.find((s) => {
    const capBytes = s.g1Blocks * s.g1Data + s.g2Blocks * s.g2Data;
    const headerBytes = s.version >= 10 ? 3 : 2;
    return bytes.length + headerBytes <= capBytes;
  });
  if (!spec) return null;

  const dataCap = spec.g1Blocks * spec.g1Data + spec.g2Blocks * spec.g2Data;
  const bits: number[] = [];
  const pushBits = (val: number, len: number) => {
    for (let i = len - 1; i >= 0; i--) {
      bits.push((val >> i) & 1);
    }
  };

  // Mode Byte (0100) + char count
  pushBits(0b0100, 4);
  pushBits(bytes.length, spec.version >= 10 ? 16 : 8);
  for (const b of bytes) pushBits(b, 8);

  // Terminator up to 4 bits
  const maxBits = dataCap * 8;
  for (let i = 0; i < 4 && bits.length < maxBits; i++) bits.push(0);
  while (bits.length % 8 !== 0) bits.push(0);

  const dataCodewords = new Uint8Array(dataCap);
  let byteIdx = 0;
  for (let i = 0; i < bits.length; i += 8) {
    let v = 0;
    for (let b = 0; b < 8; b++) v = (v << 1) | bits[i + b];
    dataCodewords[byteIdx++] = v;
  }
  const pads = [0xec, 0x11];
  let p = 0;
  while (byteIdx < dataCap) {
    dataCodewords[byteIdx++] = pads[p % 2];
    p++;
  }

  // Split blocks & RS encode
  const dataBlocks: Uint8Array[] = [];
  const ecBlocks: Uint8Array[] = [];
  let offset = 0;
  for (let b = 0; b < spec.g1Blocks; b++) {
    const slice = dataCodewords.slice(offset, offset + spec.g1Data);
    offset += spec.g1Data;
    dataBlocks.push(slice);
    ecBlocks.push(rsEncode(slice, spec.ecPerBlock));
  }
  for (let b = 0; b < spec.g2Blocks; b++) {
    const slice = dataCodewords.slice(offset, offset + spec.g2Data);
    offset += spec.g2Data;
    dataBlocks.push(slice);
    ecBlocks.push(rsEncode(slice, spec.ecPerBlock));
  }

  // Interleave
  const finalBytes: number[] = [];
  const maxDataLen = Math.max(spec.g1Data, spec.g2Data);
  for (let i = 0; i < maxDataLen; i++) {
    for (const blk of dataBlocks) {
      if (i < blk.length) finalBytes.push(blk[i]);
    }
  }
  for (let i = 0; i < spec.ecPerBlock; i++) {
    for (const blk of ecBlocks) {
      if (i < blk.length) finalBytes.push(blk[i]);
    }
  }

  const size = spec.version * 4 + 17;
  const modules: boolean[][] = Array.from({ length: size }, () => Array(size).fill(false));
  const isFunc: boolean[][] = Array.from({ length: size }, () => Array(size).fill(false));

  const setFunc = (r: number, c: number, dark: boolean) => {
    if (r >= 0 && r < size && c >= 0 && c < size) {
      modules[r][c] = dark;
      isFunc[r][c] = true;
    }
  };

  const drawFinder = (top: number, left: number) => {
    for (let r = -1; r <= 7; r++) {
      for (let c = -1; c <= 7; c++) {
        const rr = top + r;
        const cc = left + c;
        if (rr < 0 || rr >= size || cc < 0 || cc >= size) continue;
        const inBorder = r === -1 || r === 7 || c === -1 || c === 7;
        const dark =
          !inBorder &&
          (r === 0 || r === 6 || c === 0 || c === 6 || (r >= 2 && r <= 4 && c >= 2 && c <= 4));
        setFunc(rr, cc, dark);
      }
    }
  };

  drawFinder(0, 0);
  drawFinder(0, size - 7);
  drawFinder(size - 7, 0);

  // Alignment patterns
  const centers = spec.alignments;
  for (const r of centers) {
    for (const c of centers) {
      if (
        (r === 6 && c === 6) ||
        (r === 6 && c === size - 7) ||
        (r === size - 7 && c === 6)
      ) {
        continue;
      }
      for (let dr = -2; dr <= 2; dr++) {
        for (let dc = -2; dc <= 2; dc++) {
          const dark = Math.max(Math.abs(dr), Math.abs(dc)) !== 1;
          setFunc(r + dr, c + dc, dark);
        }
      }
    }
  }

  // Timing patterns
  for (let i = 8; i < size - 8; i++) {
    setFunc(6, i, i % 2 === 0);
    setFunc(i, 6, i % 2 === 0);
  }

  // Dark module & reserve format info
  setFunc(size - 8, 8, true);
  for (let i = 0; i < 9; i++) {
    if (i !== 6) {
      isFunc[8][i] = true;
      isFunc[i][8] = true;
    }
  }
  for (let i = size - 8; i < size; i++) {
    isFunc[8][i] = true;
    isFunc[i][8] = true;
  }

  if (spec.version >= 7) {
    const vBits = computeVersionBits(spec.version);
    for (let i = 0; i < 18; i++) {
      const dark = ((vBits >> i) & 1) === 1;
      const a = Math.floor(i / 3);
      const b = size - 11 + (i % 3);
      setFunc(a, b, dark);
      setFunc(b, a, dark);
    }
  }

  // Place data bits zig-zag
  const bitStream: number[] = [];
  for (const byte of finalBytes) {
    for (let b = 7; b >= 0; b--) bitStream.push((byte >> b) & 1);
  }
  let bitPtr = 0;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++) {
      const upward = ((right + 1) & 2) === 0;
      const r = upward ? size - 1 - vert : vert;
      for (let j = 0; j < 2; j++) {
        const c = right - j;
        if (!isFunc[r][c]) {
          modules[r][c] = bitPtr < bitStream.length ? bitStream[bitPtr] === 1 : false;
          bitPtr++;
        }
      }
    }
  }

  // Apply best mask (mask 0..7, pick balanced dark count + simple penalty)
  let bestMask = 0;
  let bestPenalty = Infinity;
  for (let mask = 0; mask < 8; mask++) {
    let darkCount = 0;
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        let bit = modules[r][c];
        if (!isFunc[r][c]) {
          const cond =
            mask === 0
              ? (r + c) % 2 === 0
              : mask === 1
              ? r % 2 === 0
              : mask === 2
              ? c % 3 === 0
              : mask === 3
              ? (r + c) % 3 === 0
              : mask === 4
              ? (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0
              : mask === 5
              ? ((r * c) % 2) + ((r * c) % 3) === 0
              : mask === 6
              ? (((r * c) % 2) + ((r * c) % 3)) % 2 === 0
              : (((r + c) % 2) + ((r * c) % 3)) % 2 === 0;
          if (cond) bit = !bit;
        }
        if (bit) darkCount++;
      }
    }
    const ratioPenalty = Math.abs(darkCount * 2 - size * size);
    if (ratioPenalty < bestPenalty) {
      bestPenalty = ratioPenalty;
      bestMask = mask;
    }
  }

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (!isFunc[r][c]) {
        const cond =
          bestMask === 0
            ? (r + c) % 2 === 0
            : bestMask === 1
            ? r % 2 === 0
            : bestMask === 2
            ? c % 3 === 0
            : bestMask === 3
            ? (r + c) % 3 === 0
            : bestMask === 4
            ? (Math.floor(r / 2) + Math.floor(c / 3)) % 2 === 0
            : bestMask === 5
            ? ((r * c) % 2) + ((r * c) % 3) === 0
            : bestMask === 6
            ? (((r * c) % 2) + ((r * c) % 3)) % 2 === 0
            : (((r + c) % 2) + ((r * c) % 3)) % 2 === 0;
        if (cond) modules[r][c] = !modules[r][c];
      }
    }
  }

  // Write format bits
  const fBits = computeFormatBits(bestMask);
  for (let i = 0; i <= 5; i++) setFunc(8, i, ((fBits >> i) & 1) === 1);
  setFunc(8, 7, ((fBits >> 6) & 1) === 1);
  setFunc(8, 8, ((fBits >> 7) & 1) === 1);
  setFunc(7, 8, ((fBits >> 8) & 1) === 1);
  for (let i = 9; i < 15; i++) setFunc(14 - i, 8, ((fBits >> i) & 1) === 1);

  for (let i = 0; i < 8; i++) setFunc(size - 1 - i, 8, ((fBits >> i) & 1) === 1);
  for (let i = 8; i < 15; i++) setFunc(8, size - 15 + i, ((fBits >> i) & 1) === 1);

  return modules;
}

// ==================== COMPACT WORKOUT PLAN SHARE CODEC ====================

interface CompactPlanPayload {
  v: 1;
  d: Array<{
    t: string;
    s: string;
    e: Array<[string, number, number, number, string?]>; // [exerciseId, setsCount, targetValue, restSec, customName?]
  }>;
}

export function encodeWorkoutPlanToCode(plan: WorkoutDayPlan[]): string {
  const payload: CompactPlanPayload = {
    v: 1,
    d: plan.slice(0, 6).map((day) => ({
      t: day.title.slice(0, 40),
      s: day.splitLabel.slice(0, 28),
      e: day.exercises.slice(0, 10).map((ex) => {
        const target = ex.sets[0]?.targetValue ?? (ex.isIsometric ? 15 : 8);
        const tuple: [string, number, number, number, string?] = ex.customName
          ? [ex.exerciseId, ex.sets.length, target, ex.restSeconds, ex.customName.slice(0, 32)]
          : [ex.exerciseId, ex.sets.length, target, ex.restSeconds];
        return tuple;
      }),
    })),
  };

  const json = JSON.stringify(payload);
  const bytes = new TextEncoder().encode(json);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  const base64url = btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return `CALIPRO1:${base64url}`;
}

export function decodeWorkoutPlanFromCode(rawInput: string): WorkoutDayPlan[] | null {
  try {
    let token = rawInput.trim();
    if (!token) return null;

    // Also accept full share link containing ?importPlan=...
    const linkMatch = token.match(/[?&]importPlan=([^&\s]+)/);
    if (linkMatch) {
      token = decodeURIComponent(linkMatch[1]);
    }

    if (token.startsWith('CALIPRO1:')) {
      token = token.slice('CALIPRO1:'.length);
    }

    const padded = token.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((token.length + 3) % 4);
    const bin = atob(padded);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    const json = new TextDecoder().decode(bytes);
    const parsed = JSON.parse(json) as CompactPlanPayload;

    if (!parsed || parsed.v !== 1 || !Array.isArray(parsed.d) || parsed.d.length === 0) {
      return null;
    }

    return parsed.d.map((day, dIdx) => {
      const exercises: WorkoutExerciseItem[] = (Array.isArray(day.e) ? day.e : []).map(
        (entry, eIdx) => {
          const [exerciseId, setsCountRaw, targetRaw, restRaw, customName] = entry;
          const def = getExerciseById(exerciseId);
          const setsCount = Math.max(1, Math.min(8, Number(setsCountRaw) || 3));
          const targetVal = Math.max(1, Math.min(300, Number(targetRaw) || 8));
          const restSec = Math.max(20, Math.min(300, Number(restRaw) || def?.defaultRestSec || 90));
          const isIso = def ? def.type === 'isometric' : false;
          return {
            instanceId: `imp_${Date.now()}_${dIdx}_${eIdx}`,
            exerciseId: def ? def.id : exerciseId,
            customName: def ? undefined : customName || exerciseId,
            customCategory: def?.category ?? 'Spinta',
            isIsometric: isIso,
            isNegative: def?.isNegative,
            negativeSeconds: def?.negativeSeconds,
            variantNote: def?.variantHint ?? 'Scheda importata',
            restSeconds: restSec,
            sets: Array.from({ length: setsCount }, (_, sIdx) => ({
              id: `imp_set_${dIdx}_${eIdx}_${sIdx}`,
              targetValue: targetVal,
              actualValue: targetVal,
              addedWeightKg: 0,
              rpe: null,
              completed: false,
            })),
          };
        }
      );

      return {
        id: `day_imp_${Date.now()}_${dIdx}`,
        dayNumber: dIdx + 1,
        title: String(day.t || `Giorno ${dIdx + 1}`),
        splitLabel: String(day.s || `Giorno ${dIdx + 1}`),
        focus: String(day.s || 'Full Body'),
        exercises,
      };
    });
  } catch {
    return null;
  }
}
