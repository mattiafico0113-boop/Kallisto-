import { getExerciseById } from '../data/exercises';
import { SKILL_NODE_MAP } from '../data/skills';
import type {
  StretchExerciseItem,
  UnlockedSkillRecord,
  WorkoutExerciseItem,
  WorkoutSessionLog,
} from '../types/calisthenics';

export type MuscleRecoveryZoneId = 'spinta' | 'tirata' | 'core' | 'gambe' | 'tendini';

export interface MuscleRecoveryItem {
  id: MuscleRecoveryZoneId;
  label: string;
  percent: number; // 0..100
  statusLabel: string;
  statusTone: 'recovering' | 'moderate' | 'ready';
}

export interface WeeklyMissionItem {
  id: 'weekly_workouts' | 'weekly_reps' | 'weekly_prehab_stretch';
  claimKey: string;
  title: string;
  current: number;
  target: number;
  completed: boolean;
  xpBonus: number;
}

export interface TrophyDefinition {
  id:
    | 'king_of_bar'
    | 'steel_tendons'
    | 'park_explorer'
    | 'iron_mind'
    | 'consistency_30';
  title: string;
  description: string;
  progressLabel: string;
  unlocked: boolean;
}

export interface OneRMTargetZone {
  id: 'strength' | 'hypertrophy' | 'endurance';
  title: string;
  repsRange: string;
  pctLabel: string;
  minAddedKg: number;
  maxAddedKg: number;
  minTotalKg: number;
  maxTotalKg: number;
}

export interface OneRMCalculationResult {
  oneRmTotalKg: number;
  oneRmAddedKg: number;
  bodyWeightKg: number;
  zones: OneRMTargetZone[];
}

export function getISOWeekInfo(refDate = new Date()): {
  weekKey: string;
  startMs: number;
  endMs: number;
} {
  const local = new Date(refDate);
  local.setHours(0, 0, 0, 0);
  const dayOffset = (local.getDay() + 6) % 7; // Monday = 0
  const monday = new Date(local);
  monday.setDate(local.getDate() - dayOffset);
  monday.setHours(0, 0, 0, 0);

  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  sunday.setHours(23, 59, 59, 999);

  // ISO week number
  const thursday = new Date(monday);
  thursday.setDate(monday.getDate() + 3);
  const yearStart = new Date(thursday.getFullYear(), 0, 1);
  const weekNo = Math.ceil(
    ((thursday.getTime() - yearStart.getTime()) / 86400000 + 1) / 7
  );

  return {
    weekKey: `${thursday.getFullYear()}-W${String(weekNo).padStart(2, '0')}`,
    startMs: monday.getTime(),
    endMs: sunday.getTime(),
  };
}

export function computeMuscleRecovery(
  history: WorkoutSessionLog[],
  nowMs = Date.now()
): MuscleRecoveryItem[] {
  const fatigue: Record<MuscleRecoveryZoneId, number> = {
    spinta: 0,
    tirata: 0,
    core: 0,
    gambe: 0,
    tendini: 0,
  };

  for (const sess of history) {
    const sessMs = new Date(sess.dateISO).getTime();
    if (!Number.isFinite(sessMs)) continue;
    const hoursAgo = (nowMs - sessMs) / 3600000;
    if (hoursAgo < 0 || hoursAgo > 96) continue;

    // 72h half-life for heavy sessions, tendons recover a little slower
    const muscleDecay = Math.max(0, 1 - hoursAgo / 68);
    const tendonDecay = Math.max(0, 1 - hoursAgo / 78);

    const rpeFactor = Math.max(0.7, Math.min(1.45, (sess.avgRpe || 8) / 8));

    for (const ex of sess.exercises) {
      const doneSets = ex.sets.filter((s) => s.completed).length;
      const effSets = doneSets > 0 ? doneSets : Math.min(3, ex.sets.length);
      if (effSets <= 0) continue;

      const techPenalty =
        ex.technicalScore === 1 ? 1.25 : ex.technicalScore === 2 ? 1.08 : 0.95;
      const baseLoad = effSets * 11 * rpeFactor * techPenalty;

      const def = getExerciseById(ex.exerciseId);
      const cat = ex.category;

      if (cat === 'Spinta') {
        fatigue.spinta += baseLoad * muscleDecay;
      } else if (cat === 'Tirata') {
        fatigue.tirata += baseLoad * muscleDecay;
      } else if (cat === 'Core') {
        fatigue.core += baseLoad * muscleDecay;
      } else if (cat === 'Gambe') {
        fatigue.gambe += baseLoad * muscleDecay;
      } else if (cat === 'Skill') {
        // Skills recruit push/pull/core + high tendon tension
        const lowerName = ex.exerciseName.toLowerCase();
        if (lowerName.includes('lever')) {
          fatigue.tirata += baseLoad * 0.55 * muscleDecay;
          fatigue.core += baseLoad * 0.45 * muscleDecay;
        } else {
          fatigue.spinta += baseLoad * 0.55 * muscleDecay;
          fatigue.core += baseLoad * 0.45 * muscleDecay;
        }
        fatigue.tendini += baseLoad * 0.72 * tendonDecay;
      }

      const joints = def?.jointLoad ?? [];
      if (joints.includes('polsi') || joints.includes('gomiti')) {
        fatigue.tendini += effSets * 6.5 * rpeFactor * techPenalty * tendonDecay;
      } else if (ex.isIsometric || ex.maxAddedWeightKg > 0) {
        fatigue.tendini += effSets * 4 * rpeFactor * tendonDecay;
      }
    }
  }

  const zones: { id: MuscleRecoveryZoneId; label: string }[] = [
    { id: 'spinta', label: 'Spinta (Petto/Tricipiti)' },
    { id: 'tirata', label: 'Tirata (Schiena/Bicipiti)' },
    { id: 'core', label: 'Core & Addome' },
    { id: 'gambe', label: 'Gambe' },
    { id: 'tendini', label: 'Tendini (Polsi/Gomiti)' },
  ];

  return zones.map((z) => {
    const pct = Math.max(5, Math.min(100, Math.round(100 - fatigue[z.id])));
    if (pct < 50) {
      return {
        id: z.id,
        label: z.label,
        percent: pct,
        statusLabel: 'In recupero',
        statusTone: 'recovering',
      };
    }
    if (pct <= 85) {
      return {
        id: z.id,
        label: z.label,
        percent: pct,
        statusLabel: 'Quasi pronto',
        statusTone: 'moderate',
      };
    }
    return {
      id: z.id,
      label: z.label,
      percent: pct,
      statusLabel: 'Pronto al 100%',
      statusTone: 'ready',
    };
  });
}

export function computeWeeklyMissions(params: {
  history: WorkoutSessionLog[];
  activeExercises?: WorkoutExerciseItem[];
  activeStretch?: StretchExerciseItem[];
  prehabCompletedDates?: string[];
  now?: Date;
}): WeeklyMissionItem[] {
  const {
    history,
    activeExercises = [],
    activeStretch = [],
    prehabCompletedDates = [],
    now = new Date(),
  } = params;

  const { weekKey, startMs, endMs } = getISOWeekInfo(now);

  const weekSessions = history.filter((s) => {
    const ms = new Date(s.dateISO).getTime();
    return Number.isFinite(ms) && ms >= startMs && ms <= endMs;
  });

  const workoutsCount = weekSessions.length;

  let repsCount = 0;
  for (const s of weekSessions) {
    for (const ex of s.exercises) {
      if (ex.isIsometric) continue;
      for (const st of ex.sets) {
        if (st.completed) {
          repsCount += Math.max(0, st.actualValue || 0);
        }
      }
    }
  }
  // Include live completed reps from active draft not yet saved
  for (const ex of activeExercises) {
    if (ex.isIsometric) continue;
    for (const st of ex.sets) {
      if (st.completed) {
        repsCount += Math.max(0, st.actualValue || 0);
      }
    }
  }

  // Prehab / Stretching routines completed this week
  let prehabAndStretchCount = 0;
  for (const iso of prehabCompletedDates) {
    const ms = new Date(iso).getTime();
    if (Number.isFinite(ms) && ms >= startMs && ms <= endMs) {
      prehabAndStretchCount += 1;
    }
  }
  for (const s of weekSessions) {
    if (typeof s.stretchesCompletedCount === 'number' && s.stretchesCompletedCount >= 2) {
      prehabAndStretchCount += 1;
    }
  }
  const activeStretchDone = activeStretch.filter((st) => st.completed).length;
  if (activeStretchDone >= 2) {
    prehabAndStretchCount += 1;
  }

  return [
    {
      id: 'weekly_workouts',
      claimKey: `${weekKey}:weekly_workouts`,
      title: 'Completa 3 allenamenti questa settimana',
      current: workoutsCount,
      target: 3,
      completed: workoutsCount >= 3,
      xpBonus: 150,
    },
    {
      id: 'weekly_reps',
      claimKey: `${weekKey}:weekly_reps`,
      title: 'Esegui 80 ripetizioni totali',
      current: repsCount,
      target: 80,
      completed: repsCount >= 80,
      xpBonus: 150,
    },
    {
      id: 'weekly_prehab_stretch',
      claimKey: `${weekKey}:weekly_prehab_stretch`,
      title: 'Completa 2 routine Prehab o Stretching',
      current: prehabAndStretchCount,
      target: 2,
      completed: prehabAndStretchCount >= 2,
      xpBonus: 150,
    },
  ];
}

export function computeTrophies(params: {
  history: WorkoutSessionLog[];
  unlockedSkills: UnlockedSkillRecord[];
  conqueredParksCount: number;
  prehabCompletedDates?: string[];
  nowMs?: number;
}): TrophyDefinition[] {
  const {
    history,
    unlockedSkills,
    conqueredParksCount,
    prehabCompletedDates = [],
    nowMs = Date.now(),
  } = params;

  // 1. Re della Sbarra: pull-up branch skill OR >= 10 pull-up reps in a logged set
  const hasPullSkill = unlockedSkills.some(
    (s) => SKILL_NODE_MAP[s.skillId]?.branchId === 'tirata'
  );
  let bestPullReps = 0;
  for (const sess of history) {
    for (const ex of sess.exercises) {
      const idLow = ex.exerciseId.toLowerCase();
      const nameLow = ex.exerciseName.toLowerCase();
      if (
        idLow.includes('pullup') ||
        idLow.includes('chinup') ||
        idLow.includes('muscle') ||
        nameLow.includes('trazion') ||
        nameLow.includes('chin')
      ) {
        bestPullReps = Math.max(bestPullReps, ex.bestValue);
      }
    }
  }
  const kingOfBarUnlocked = hasPullSkill || bestPullReps >= 10;

  // 2. Tendini d'Acciaio: >= 2 prehab completions OR >= 4 isometric/skill sessions
  const isoSessionsCount = history.filter((s) =>
    s.exercises.some((e) => e.isIsometric || e.category === 'Skill')
  ).length;
  const tendonUnits = prehabCompletedDates.length + Math.floor(isoSessionsCount / 2);
  const steelTendonsUnlocked = prehabCompletedDates.length >= 2 || isoSessionsCount >= 4;

  // 3. Padrone della Skill: >= 1 Skill certificata nell'Albero
  const skillMasterUnlocked = unlockedSkills.length >= 1;

  // 4. Mente d'Acciaio: >= 5 completed sessions
  const ironMindUnlocked = history.length >= 5;

  // 5. Costanza 30 Giorni: >= 12 workouts in last 30 days (or total >= 12)
  const thirtyDaysAgo = nowMs - 30 * 86400000;
  const recent30Days = history.filter((s) => {
    const ms = new Date(s.dateISO).getTime();
    return Number.isFinite(ms) && ms >= thirtyDaysAgo;
  }).length;
  const consistencyUnlocked = recent30Days >= 12 || history.length >= 12;

  return [
    {
      id: 'king_of_bar',
      title: 'Re della Sbarra',
      description: '10+ trazioni in una serie o 1 Skill di Tirata sbloccata',
      progressLabel: kingOfBarUnlocked
        ? 'Sbloccato'
        : `${bestPullReps}/10 rep`,
      unlocked: kingOfBarUnlocked,
    },
    {
      id: 'steel_tendons',
      title: "Tendini d'Acciaio",
      description: '2 routine Prehab o 4 sedute con isometrie/skill',
      progressLabel: steelTendonsUnlocked
        ? 'Sbloccato'
        : `${Math.min(2, tendonUnits)}/2 step`,
      unlocked: steelTendonsUnlocked,
    },
    {
      id: 'park_explorer',
      title: 'Padrone della Tecnica',
      description: "Certifica almeno 1 Skill nell'Albero delle Skill",
      progressLabel: skillMasterUnlocked
        ? `${unlockedSkills.length} skill`
        : '0/1 skill',
      unlocked: skillMasterUnlocked,
    },
    {
      id: 'iron_mind',
      title: "Mente d'Acciaio",
      description: 'Completa almeno 5 sessioni complete con attivazione',
      progressLabel: ironMindUnlocked
        ? 'Sbloccato'
        : `${history.length}/5 sedute`,
      unlocked: ironMindUnlocked,
    },
    {
      id: 'consistency_30',
      title: 'Costanza 30 Giorni',
      description: 'Completa almeno 12 allenamenti negli ultimi 30 giorni',
      progressLabel: consistencyUnlocked
        ? 'Sbloccato'
        : `${recent30Days}/12 sedute`,
      unlocked: consistencyUnlocked,
    },
  ];
}

export function calculateCalisthenics1RM(params: {
  bodyWeightKg: number;
  addedWeightKg: number;
  reps: number;
}): OneRMCalculationResult {
  const bw = Math.max(30, Number.isFinite(params.bodyWeightKg) ? params.bodyWeightKg : 70);
  const added = Math.max(0, Number.isFinite(params.addedWeightKg) ? params.addedWeightKg : 0);
  const reps = Math.max(1, Math.min(20, Math.round(params.reps || 1)));

  const totalLoad = bw + added;
  let oneRmTotalKg = totalLoad;
  if (reps > 1) {
    const epley = totalLoad * (1 + reps / 30);
    const brzycki = totalLoad * (36 / (37 - reps));
    oneRmTotalKg = (epley + brzycki) / 2;
  }

  const roundedTotal = Math.round(oneRmTotalKg * 10) / 10;
  const roundedAdded = Math.round((roundedTotal - bw) * 10) / 10;

  const makeZone = (
    id: OneRMTargetZone['id'],
    title: string,
    repsRange: string,
    pctMin: number,
    pctMax: number
  ): OneRMTargetZone => {
    const minTotalKg = Math.round(oneRmTotalKg * pctMin * 2) / 2;
    const maxTotalKg = Math.round(oneRmTotalKg * pctMax * 2) / 2;
    return {
      id,
      title,
      repsRange,
      pctLabel: `${Math.round(pctMin * 100)}–${Math.round(pctMax * 100)}% 1RM`,
      minTotalKg,
      maxTotalKg,
      minAddedKg: Math.round((minTotalKg - bw) * 2) / 2,
      maxAddedKg: Math.round((maxTotalKg - bw) * 2) / 2,
    };
  };

  return {
    oneRmTotalKg: roundedTotal,
    oneRmAddedKg: roundedAdded,
    bodyWeightKg: bw,
    zones: [
      makeZone('strength', 'Forza Massimale', '3–5 rep', 0.85, 0.9),
      makeZone('hypertrophy', 'Ipertrofia Funzionale', '8–10 rep', 0.75, 0.8),
      makeZone('endurance', 'Resistenza / Volume', '12–15 rep', 0.65, 0.7),
    ],
  };
}
