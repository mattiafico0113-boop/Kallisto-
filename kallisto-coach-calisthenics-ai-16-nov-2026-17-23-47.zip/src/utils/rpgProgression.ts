import { SKILL_NODE_MAP } from '../data/skills';
import type {
  AthleteAvatarConfig,
  ExerciseCategory,
  UnlockedSkillRecord,
  WorkoutSessionLog,
} from '../types/calisthenics';

export const DEFAULT_AVATAR_CONFIG: AthleteAvatarConfig = {
  bodyType: 'atletico_m',
  hairStyle: 'corto',
  auraTheme: 'cyan',
  accessories: ['polsini'],
};

interface LevelTier {
  level: number;
  title: string;
  minXp: number;
}

const LEVEL_TIERS: LevelTier[] = [
  { level: 1, title: 'Principiante', minXp: 0 },
  { level: 2, title: 'Apprendista Sbarra', minXp: 120 },
  { level: 3, title: 'Praticante Costante', minXp: 280 },
  { level: 4, title: 'Atleta Intermedio', minXp: 500 },
  { level: 5, title: 'Atleta Corpo Libero', minXp: 800 },
  { level: 6, title: 'Specialista Spinta & Tirata', minXp: 1180 },
  { level: 7, title: 'Dominatore di Leve', minXp: 1620 },
  { level: 8, title: 'Atleta Avanzato Elite', minXp: 2150 },
  { level: 9, title: 'Virtuoso Calisthenics', minXp: 2780 },
  { level: 10, title: 'Master Calisthenics', minXp: 3500 },
];

export interface RpgProgressSummary {
  totalXp: number;
  skillXp: number;
  workoutXp: number;
  missionXp: number;
  level: number;
  rankTitle: string;
  currentLevelMinXp: number;
  nextLevelXp: number | null;
  progressPct: number;
  xpToNext: number;
  auraTier: 0 | 1 | 2 | 3 | 4;
  auraName: string;
  nextAuraHint: string;
}

const XP_BY_SKILL_ORDER: Record<number, number> = {
  1: 120,
  2: 220,
  3: 350,
  4: 520,
  5: 750,
};

export function computeRpgProgress(
  unlockedSkills: UnlockedSkillRecord[],
  history: WorkoutSessionLog[],
  bonusMissionXp = 0
): RpgProgressSummary {
  let skillXp = 0;
  let maxUnlockedOrder = 0;

  for (const rec of unlockedSkills) {
    const def = SKILL_NODE_MAP[rec.skillId];
    const order = def?.order ?? 1;
    if (order > maxUnlockedOrder) maxUnlockedOrder = order;
    skillXp += XP_BY_SKILL_ORDER[order] ?? 150;
  }

  let workoutXp = 0;
  for (const sess of history) {
    const qualityBonus =
      typeof sess.avgTechnicalScore === 'number' && sess.avgTechnicalScore >= 2.5 ? 15 : 0;
    workoutXp += 60 + qualityBonus;
  }

  const missionXp = Math.max(0, Math.round(bonusMissionXp));
  const totalXp = skillXp + workoutXp + missionXp;

  let currentTier = LEVEL_TIERS[0];
  let nextTier: LevelTier | null = LEVEL_TIERS[1];

  for (let i = 0; i < LEVEL_TIERS.length; i++) {
    if (totalXp >= LEVEL_TIERS[i].minXp) {
      currentTier = LEVEL_TIERS[i];
      nextTier = LEVEL_TIERS[i + 1] ?? null;
    }
  }

  const progressPct = nextTier
    ? Math.min(
        100,
        Math.max(
          0,
          Math.round(
            ((totalXp - currentTier.minXp) / Math.max(1, nextTier.minXp - currentTier.minXp)) *
              100
          )
        )
      )
    : 100;

  const xpToNext = nextTier ? Math.max(0, nextTier.minXp - totalXp) : 0;

  // Aura frames unlock directly with Skill Tree difficulty/milestones
  let auraTier: 0 | 1 | 2 | 3 | 4 = 0;
  let auraName = 'Scudo Base Notte';
  let nextAuraHint = 'Sblocca 1 skill per attivare la Cornice Blu Elettrico';

  if (maxUnlockedOrder >= 4 || unlockedSkills.length >= 10) {
    auraTier = 4;
    auraName = 'Corona Neon Master';
    nextAuraHint = 'Livello massimo di aura sbloccato!';
  } else if (maxUnlockedOrder >= 3 || unlockedSkills.length >= 6) {
    auraTier = 3;
    auraName = 'Anelli Orbitali Pro';
    nextAuraHint = 'Sblocca una skill Livello 4 (es. Tuck Planche o Muscle-up)';
  } else if (maxUnlockedOrder >= 2 || unlockedSkills.length >= 3) {
    auraTier = 2;
    auraName = 'Bagliore Ciano Polare';
    nextAuraHint = 'Sblocca una skill Livello 3 (es. Frog Stand o Tuck Front Lever)';
  } else if (unlockedSkills.length >= 1) {
    auraTier = 1;
    auraName = 'Cornice Blu Elettrico';
    nextAuraHint = 'Sblocca una skill di Livello 2 o 3 skill totali per il grado Ciano';
  }

  return {
    totalXp,
    skillXp,
    workoutXp,
    missionXp,
    level: currentTier.level,
    rankTitle: currentTier.title,
    currentLevelMinXp: currentTier.minXp,
    nextLevelXp: nextTier ? nextTier.minXp : null,
    progressPct,
    xpToNext,
    auraTier,
    auraName,
    nextAuraHint,
  };
}

export interface RadarVertexStat {
  key: 'Skill' | 'Core' | 'Spinta' | 'Tirata' | 'Gambe';
  label: string;
  shortLabel: string;
  score: number; // 0 to 100
  completedSets: number;
  avgTech: number | null;
  unlockedCount: number;
  insight: string;
}

const AREA_ORDER: {
  key: RadarVertexStat['key'];
  label: string;
  shortLabel: string;
  category: ExerciseCategory;
}[] = [
  { key: 'Skill', label: 'Skill', shortLabel: 'Skill', category: 'Skill' },
  { key: 'Core', label: 'Addome & Core', shortLabel: 'Core', category: 'Core' },
  { key: 'Spinta', label: 'Petto & Spinta', shortLabel: 'Spinta', category: 'Spinta' },
  { key: 'Tirata', label: 'Schiena & Tirata', shortLabel: 'Tirata', category: 'Tirata' },
  { key: 'Gambe', label: 'Gambe', shortLabel: 'Gambe', category: 'Gambe' },
];

function mapSkillBranchToRadarArea(skillId: string): RadarVertexStat['key'] {
  const def = SKILL_NODE_MAP[skillId];
  if (!def) return 'Skill';
  if (def.branchId === 'tirata') return 'Tirata';
  if (def.branchId === 'spinta_planche') return def.order >= 3 ? 'Skill' : 'Spinta';
  if (def.branchId === 'leve_core') return def.order >= 3 ? 'Skill' : 'Core';
  return 'Skill';
}

export function computeAthleteRadarMetrics(
  history: WorkoutSessionLog[],
  unlockedSkills: UnlockedSkillRecord[]
): RadarVertexStat[] {
  const setsByCat: Record<ExerciseCategory, number> = {
    Skill: 0,
    Core: 0,
    Spinta: 0,
    Tirata: 0,
    Gambe: 0,
  };
  const techScoresByCat: Record<ExerciseCategory, number[]> = {
    Skill: [],
    Core: [],
    Spinta: [],
    Tirata: [],
    Gambe: [],
  };
  const skillsByArea: Record<RadarVertexStat['key'], number> = {
    Skill: 0,
    Core: 0,
    Spinta: 0,
    Tirata: 0,
    Gambe: 0,
  };
  const skillOrderSumByArea: Record<RadarVertexStat['key'], number> = {
    Skill: 0,
    Core: 0,
    Spinta: 0,
    Tirata: 0,
    Gambe: 0,
  };

  for (const sess of history) {
    for (const ex of sess.exercises) {
      const cat = ex.category ?? 'Skill';
      const doneSets = ex.sets.filter((s) => s.completed).length;
      const effectiveSets = doneSets > 0 ? doneSets : ex.sets.length;
      setsByCat[cat] += effectiveSets;
      if (ex.technicalScore === 1 || ex.technicalScore === 2 || ex.technicalScore === 3) {
        techScoresByCat[cat].push(ex.technicalScore);
      }
    }
  }

  for (const rec of unlockedSkills) {
    const def = SKILL_NODE_MAP[rec.skillId];
    const order = def?.order ?? 1;
    const primaryArea = mapSkillBranchToRadarArea(rec.skillId);
    skillsByArea[primaryArea] += 1;
    skillOrderSumByArea[primaryArea] += order;
    // Also count certified skill tree progress into general "Skill" mastery
    if (primaryArea !== 'Skill') {
      skillsByArea.Skill += 1;
      skillOrderSumByArea.Skill += Math.max(1, order * 0.65);
    }
  }

  const rawStats = AREA_ORDER.map((area) => {
    const completedSets = setsByCat[area.category];
    const techList = techScoresByCat[area.category];
    const avgTech =
      techList.length > 0 ? techList.reduce((a, b) => a + b, 0) / techList.length : null;
    const unlockedCount = skillsByArea[area.key];
    const orderPower = skillOrderSumByArea[area.key];

    // Volume component (up to 58 pts smoothly scaling with completed sets)
    const volumePts =
      completedSets > 0 ? Math.min(58, Math.round(58 * (1 - Math.exp(-completedSets / 22)))) : 0;

    // Technical execution multiplier / bonus (up to 22 pts)
    const techPts =
      avgTech !== null
        ? Math.round(((avgTech - 1) / 2) * 16 + 6)
        : completedSets > 0
        ? 10
        : 0;

    // Skill Tree mastery bonus (up to 35 pts, heavier on Skill vertex)
    const skillPts = Math.min(area.key === 'Skill' ? 60 : 30, Math.round(orderPower * 9));

    const score = Math.min(100, Math.max(0, volumePts + techPts + skillPts));

    return {
      key: area.key,
      label: area.label,
      shortLabel: area.shortLabel,
      score,
      completedSets,
      avgTech,
      unlockedCount,
    };
  });

  const maxScore = Math.max(...rawStats.map((s) => s.score));
  const minScore = Math.min(...rawStats.map((s) => s.score));

  return rawStats.map((st) => {
    let insight = 'Completa serie in quest’area per calibrare il punteggio.';
    if (st.score >= 75) {
      insight = 'Punto di forza: volume e pulizia tecnica eccellenti.';
    } else if (st.score > 0 && st.score === maxScore && maxScore > minScore) {
      insight = 'Reparto leader attuale: continua la progressione o zavorra.';
    } else if (st.score === minScore && maxScore - minScore >= 18) {
      insight = 'Margine di miglioramento: aggiungi 1–2 serie pulite a settimana.';
    } else if (st.avgTech !== null && st.avgTech < 2.1) {
      insight = 'Priorità alla qualità tecnica (punta al voto 3 · Pulita).';
    } else if (st.score > 0) {
      insight = 'Crescita costante: consolida le serie completate e testa una skill.';
    }

    return {
      ...st,
      insight,
    };
  });
}
