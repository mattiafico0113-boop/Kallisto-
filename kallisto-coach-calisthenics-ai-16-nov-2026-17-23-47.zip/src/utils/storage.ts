import type {
  AuthSession,
  AthleteProfile,
  BodyWeightEntry,
  CoachMessage,
  ComboFlowPreset,
  DailyNutritionLog,
  ManualWorkoutIntensity,
  MorningCheckinRecord,
  StretchExerciseItem,
  UnlockedSkillRecord,
  UserAccount,
  WarmupExerciseItem,
  WorkoutDayPlan,
  WorkoutSessionLog,
} from '../types/calisthenics';
import { getWeekdayShort } from './notifications';
import type { ProgressPhotoEntry } from './photoDiaryDB';

const LEGACY_STORAGE_KEY = 'kallisto_calisthenics_v1';
const ACCOUNTS_KEY = 'kallisto_accounts_v1';
const SESSION_KEY = 'kallisto_active_session_v1';
const DATA_PREFIX = 'kallisto_data_v1_';
const LAST_NOTIFIED_PREFIX = 'kallisto_last_notified_v1_';

export interface ActiveWorkoutDraft {
  dayId: string;
  startedAtISO: string;
  warmup?: WarmupExerciseItem[];
  stretch?: StretchExerciseItem[];
  exercises: WorkoutDayPlan['exercises'];
}

export interface PersistedAppState {
  profile: AthleteProfile | null;
  weeklyPlan: WorkoutDayPlan[];
  selectedDayIndex: number;
  activeDraft: ActiveWorkoutDraft | null;
  history: WorkoutSessionLog[];
  coachMessages: CoachMessage[];
  unlockedSkills?: UnlockedSkillRecord[];
  prehabCompletedDates?: string[];
  claimedMissionKeys?: string[];
  morningCheckins?: MorningCheckinRecord[];
  nutritionLogs?: DailyNutritionLog[];
  exerciseNotes?: Record<string, string>;
  weightLog?: BodyWeightEntry[];
  totalVoiceGuide?: boolean;
  manualWorkoutDays?: Record<string, ManualWorkoutIntensity>;
  savedCombos?: ComboFlowPreset[];
}

export interface KallistoBackupPayload {
  app: 'Kallisto';
  version: 1 | 2;
  exportedAt: string;
  data: PersistedAppState;
  photoDiary?: ProgressPhotoEntry[];
}

const DEFAULT_STATE: PersistedAppState = {
  profile: null,
  weeklyPlan: [],
  selectedDayIndex: 0,
  activeDraft: null,
  history: [],
  coachMessages: [],
  unlockedSkills: [],
  prehabCompletedDates: [],
  claimedMissionKeys: [],
  morningCheckins: [],
  nutritionLogs: [],
  exerciseNotes: {},
  weightLog: [],
  totalVoiceGuide: false,
  manualWorkoutDays: {},
  savedCombos: [],
};

function normalizeProfile(raw: AthleteProfile | null): AthleteProfile | null {
  if (!raw) return null;
  const fallbackDays = ['lun', 'mer', 'ven', 'sab'] as AthleteProfile['trainingDays'];
  const trainingDays =
    Array.isArray(raw.trainingDays) && raw.trainingDays.length > 0
      ? raw.trainingDays
      : fallbackDays.slice(0, Math.max(1, Math.min(4, raw.daysPerWeek || 4)));

  return {
    ...raw,
    trainingDays,
    daysPerWeek: trainingDays.length,
    reminderEnabled: typeof raw.reminderEnabled === 'boolean' ? raw.reminderEnabled : false,
    reminderTime: typeof raw.reminderTime === 'string' && raw.reminderTime ? raw.reminderTime : '18:00',
  };
}

function normalizeState(parsed: Partial<PersistedAppState>): PersistedAppState {
  const profile = normalizeProfile(parsed.profile ?? null);
  const weeklyPlan = Array.isArray(parsed.weeklyPlan)
    ? parsed.weeklyPlan.map((d, idx) => {
        const weekday = d.weekday ?? profile?.trainingDays?.[idx];
        return {
          ...d,
          weekday,
          splitLabel: weekday ? `${getWeekdayShort(weekday)} · ${d.splitLabel.replace(/^(Lun|Mar|Mer|Gio|Ven|Sab|Dom)\s·\s/i, '')}` : d.splitLabel,
        };
      })
    : [];

  return {
    profile,
    weeklyPlan,
    selectedDayIndex: typeof parsed.selectedDayIndex === 'number' ? parsed.selectedDayIndex : 0,
    activeDraft: parsed.activeDraft ?? null,
    history: Array.isArray(parsed.history) ? parsed.history : [],
    coachMessages: Array.isArray(parsed.coachMessages) ? parsed.coachMessages : [],
    unlockedSkills: Array.isArray(parsed.unlockedSkills) ? parsed.unlockedSkills : [],
    prehabCompletedDates: Array.isArray(parsed.prehabCompletedDates)
      ? parsed.prehabCompletedDates
      : [],
    claimedMissionKeys: Array.isArray(parsed.claimedMissionKeys)
      ? parsed.claimedMissionKeys
      : [],
    morningCheckins: Array.isArray(parsed.morningCheckins) ? parsed.morningCheckins : [],
    nutritionLogs: Array.isArray(parsed.nutritionLogs) ? parsed.nutritionLogs : [],
    exerciseNotes:
      parsed.exerciseNotes && typeof parsed.exerciseNotes === 'object'
        ? parsed.exerciseNotes
        : {},
    weightLog: Array.isArray(parsed.weightLog) ? parsed.weightLog : [],
    totalVoiceGuide: Boolean(parsed.totalVoiceGuide),
    manualWorkoutDays:
      parsed.manualWorkoutDays && typeof parsed.manualWorkoutDays === 'object'
        ? parsed.manualWorkoutDays
        : {},
    savedCombos: Array.isArray(parsed.savedCombos) ? parsed.savedCombos : [],
  };
}

export function getDataStorageKey(accountId: string): string {
  return `${DATA_PREFIX}${accountId}`;
}

export function loadPersistedState(accountId: string): PersistedAppState {
  if (typeof window === 'undefined') return DEFAULT_STATE;
  try {
    const key = getDataStorageKey(accountId);
    let raw = window.localStorage.getItem(key);
    if (!raw && accountId === 'guest') {
      // Seamless migration from legacy single-user key
      raw = window.localStorage.getItem(LEGACY_STORAGE_KEY);
    }
    if (!raw) return DEFAULT_STATE;
    const parsed = JSON.parse(raw) as Partial<PersistedAppState>;
    return normalizeState(parsed);
  } catch {
    return DEFAULT_STATE;
  }
}

export function savePersistedState(accountId: string, state: PersistedAppState): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(getDataStorageKey(accountId), JSON.stringify(state));
  } catch {
    // Ignore storage quota errors
  }
}

export function clearPersistedState(accountId: string): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.removeItem(getDataStorageKey(accountId));
  } catch {
    // Ignore errors
  }
}

// ==================== AUTH & ACCOUNT REGISTRY ====================

export function loadAccounts(): UserAccount[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = window.localStorage.getItem(ACCOUNTS_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function saveAccounts(accounts: UserAccount[]): void {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
}

export function loadAuthSession(): AuthSession | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = window.localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    return JSON.parse(raw) as AuthSession;
  } catch {
    return null;
  }
}

export function saveAuthSession(session: AuthSession | null): void {
  if (typeof window === 'undefined') return;
  if (!session) {
    window.localStorage.removeItem(SESSION_KEY);
  } else {
    window.localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  }
}

async function hashPassword(password: string, salt: string): Promise<string> {
  const input = `${salt}:${password}`;
  if (typeof window !== 'undefined' && window.crypto?.subtle) {
    const data = new TextEncoder().encode(input);
    const hashBuffer = await window.crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  // Deterministic fallback hash if subtle crypto unavailable
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

export async function registerAccount(
  email: string,
  password: string
): Promise<{ ok: true; session: AuthSession } | { ok: false; error: string }> {
  const normalizedEmail = email.trim().toLowerCase();
  if (!normalizedEmail || !normalizedEmail.includes('@')) {
    return { ok: false, error: 'Inserisci un indirizzo email valido.' };
  }
  if (password.length < 6) {
    return { ok: false, error: 'La password deve avere almeno 6 caratteri.' };
  }

  const accounts = loadAccounts();
  if (accounts.some((a) => a.email === normalizedEmail)) {
    return { ok: false, error: 'Esiste già un account con questa email.' };
  }

  const salt = Math.random().toString(36).slice(2, 12);
  const passwordHash = await hashPassword(password, salt);
  const account: UserAccount = {
    id: `usr_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    email: normalizedEmail,
    passwordHash,
    salt,
    createdAt: new Date().toISOString(),
  };

  saveAccounts([...accounts, account]);
  const session: AuthSession = {
    accountId: account.id,
    email: account.email,
    isGuest: false,
  };
  saveAuthSession(session);
  return { ok: true, session };
}

export async function loginAccount(
  email: string,
  password: string
): Promise<{ ok: true; session: AuthSession } | { ok: false; error: string }> {
  const normalizedEmail = email.trim().toLowerCase();
  const accounts = loadAccounts();
  const found = accounts.find((a) => a.email === normalizedEmail);
  if (!found) {
    return { ok: false, error: 'Nessun account trovato con questa email.' };
  }

  const candidateHash = await hashPassword(password, found.salt);
  if (candidateHash !== found.passwordHash) {
    return { ok: false, error: 'Password non corretta.' };
  }

  const session: AuthSession = {
    accountId: found.id,
    email: found.email,
    isGuest: false,
  };
  saveAuthSession(session);
  return { ok: true, session };
}

export function loginAsGuest(): AuthSession {
  const session: AuthSession = {
    accountId: 'guest',
    email: null,
    isGuest: true,
  };
  saveAuthSession(session);
  return session;
}

// ==================== BACKUP EXPORT / IMPORT & STORAGE METRICS ====================

export function createBackupPayload(
  state: PersistedAppState,
  extras?: {
    photoDiary?: ProgressPhotoEntry[];
  }
): KallistoBackupPayload {
  return {
    app: 'Kallisto',
    version: 2,
    exportedAt: new Date().toISOString(),
    data: state,
    photoDiary: extras?.photoDiary,
  };
}

export interface ParsedBackupBundle {
  state: PersistedAppState;
  photoDiary?: ProgressPhotoEntry[];
}

export function parseBackupPayload(jsonText: string): ParsedBackupBundle | null {
  try {
    const parsed = JSON.parse(jsonText) as Partial<KallistoBackupPayload> &
      Partial<PersistedAppState>;
    const candidate = parsed.app === 'Kallisto' && parsed.data ? parsed.data : parsed;
    if (!candidate || typeof candidate !== 'object') return null;
    if (!('profile' in candidate) && !('weeklyPlan' in candidate) && !('history' in candidate)) {
      return null;
    }
    return {
      state: normalizeState(candidate),
      photoDiary: Array.isArray(parsed.photoDiary) ? parsed.photoDiary : undefined,
    };
  } catch {
    return null;
  }
}

export interface LocalStorageUsageStats {
  usedBytes: number;
  usedMB: number;
  quotaMB: number;
  percentUsed: number;
}

export function measureLocalStorageUsage(): LocalStorageUsageStats {
  const quotaMB = 5;
  const quotaBytes = quotaMB * 1024 * 1024;
  if (typeof window === 'undefined') {
    return { usedBytes: 0, usedMB: 0, quotaMB, percentUsed: 0 };
  }
  try {
    let totalChars = 0;
    for (let i = 0; i < window.localStorage.length; i++) {
      const k = window.localStorage.key(i);
      if (!k) continue;
      const v = window.localStorage.getItem(k) ?? '';
      totalChars += k.length + v.length;
    }
    // UTF-16 characters occupy 2 bytes in browser localStorage quota calculations
    const usedBytes = totalChars * 2;
    const usedMB = Math.round((usedBytes / (1024 * 1024)) * 100) / 100;
    const percentUsed = Math.min(
      100,
      Math.max(usedBytes > 0 ? 1 : 0, Math.round((usedBytes / quotaBytes) * 100))
    );
    return { usedBytes, usedMB, quotaMB, percentUsed };
  } catch {
    return { usedBytes: 0, usedMB: 0, quotaMB, percentUsed: 0 };
  }
}

export function getLastNotifiedDate(accountId: string): string | null {
  if (typeof window === 'undefined') return null;
  return window.localStorage.getItem(`${LAST_NOTIFIED_PREFIX}${accountId}`);
}

export function setLastNotifiedDate(accountId: string, dateStr: string): void {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(`${LAST_NOTIFIED_PREFIX}${accountId}`, dateStr);
}
