export type ThemePresetId =
  | 'cyber-blue'
  | 'emerald-neon'
  | 'crimson-power'
  | 'outdoor-daylight';

export interface ThemePresetDefinition {
  id: ThemePresetId;
  name: string;
  description: string;
  isDark: boolean;
  swatchPrimary: string;
  swatchAccent: string;
  swatchBg: string;
  vars: {
    '--bg-main': string;
    '--bg-elevated': string;
    '--bg-card': string;
    '--bg-card-alt': string;
    '--border-subtle': string;
    '--primary': string;
    '--primary-hover': string;
    '--accent': string;
    '--accent-soft': string;
    '--text-main': string;
    '--text-secondary': string;
    '--text-muted': string;
  };
}

export const THEME_PRESETS: ThemePresetDefinition[] = [
  {
    id: 'cyber-blue',
    name: 'Cyber Blue',
    description: 'Nero profondo, blu elettrico e azzurro neon (Predefinito)',
    isDark: true,
    swatchBg: '#05070A',
    swatchPrimary: '#2563EB',
    swatchAccent: '#00D2FF',
    vars: {
      '--bg-main': '#05070A',
      '--bg-elevated': '#090D16',
      '--bg-card': '#0F172A',
      '--bg-card-alt': '#131C31',
      '--border-subtle': '#1E293B',
      '--primary': '#2563EB',
      '--primary-hover': '#3B82F6',
      '--accent': '#00D2FF',
      '--accent-soft': '#38BDF8',
      '--text-main': '#FFFFFF',
      '--text-secondary': '#CBD5E1',
      '--text-muted': '#94A3B8',
    },
  },
  {
    id: 'emerald-neon',
    name: 'Emerald Neon',
    description: 'Nero profondo, card verde scuro e accenti verde lime brillante',
    isDark: true,
    swatchBg: '#030A06',
    swatchPrimary: '#059669',
    swatchAccent: '#84CC16',
    vars: {
      '--bg-main': '#030A06',
      '--bg-elevated': '#06130C',
      '--bg-card': '#0B2216',
      '--bg-card-alt': '#0F2D1E',
      '--border-subtle': '#19442D',
      '--primary': '#059669',
      '--primary-hover': '#10B981',
      '--accent': '#84CC16',
      '--accent-soft': '#A3E635',
      '--text-main': '#FFFFFF',
      '--text-secondary': '#D1FAE5',
      '--text-muted': '#86EFAC',
    },
  },
  {
    id: 'crimson-power',
    name: 'Crimson Power',
    description: 'Nero carbone, rosso intenso e accenti arancione fuoco',
    isDark: true,
    swatchBg: '#0A0506',
    swatchPrimary: '#DC2626',
    swatchAccent: '#F97316',
    vars: {
      '--bg-main': '#0A0506',
      '--bg-elevated': '#14090B',
      '--bg-card': '#1F1114',
      '--bg-card-alt': '#281519',
      '--border-subtle': '#3E2027',
      '--primary': '#DC2626',
      '--primary-hover': '#EF4444',
      '--accent': '#F97316',
      '--accent-soft': '#FB923C',
      '--text-main': '#FFFFFF',
      '--text-secondary': '#FED7AA',
      '--text-muted': '#FCA5A5',
    },
  },
  {
    id: 'outdoor-daylight',
    name: 'Outdoor Daylight',
    description: 'Alta visibilità al sole: bianco/ghiaccio, testo nero e blu scuro',
    isDark: false,
    swatchBg: '#F1F5F9',
    swatchPrimary: '#1D4ED8',
    swatchAccent: '#0369A1',
    vars: {
      '--bg-main': '#F1F5F9',
      '--bg-elevated': '#E2E8F0',
      '--bg-card': '#FFFFFF',
      '--bg-card-alt': '#F8FAFC',
      '--border-subtle': '#94A3B8',
      '--primary': '#1D4ED8',
      '--primary-hover': '#2563EB',
      '--accent': '#0369A1',
      '--accent-soft': '#0284C7',
      '--text-main': '#020617',
      '--text-secondary': '#1E293B',
      '--text-muted': '#475569',
    },
  },
];

const THEME_STORAGE_KEY = 'kallisto_theme_id';

export function loadSavedThemeId(): ThemePresetId {
  try {
    const saved = localStorage.getItem(THEME_STORAGE_KEY);
    if (THEME_PRESETS.some((p) => p.id === saved)) {
      return saved as ThemePresetId;
    }
  } catch {
    // ignore storage errors
  }
  return 'cyber-blue';
}

export function getThemePreset(id: ThemePresetId): ThemePresetDefinition {
  return THEME_PRESETS.find((p) => p.id === id) ?? THEME_PRESETS[0];
}

export function applyThemePreset(id: ThemePresetId): ThemePresetDefinition {
  const preset = getThemePreset(id);
  const root = document.documentElement;
  root.setAttribute('data-theme', preset.id);
  if (preset.isDark) {
    root.classList.add('dark');
    root.classList.remove('light');
  } else {
    root.classList.remove('dark');
    root.classList.add('light');
  }

  for (const [varName, value] of Object.entries(preset.vars)) {
    root.style.setProperty(varName, value);
  }

  const metaTheme = document.querySelector('meta[name="theme-color"]');
  if (metaTheme) {
    metaTheme.setAttribute('content', preset.vars['--bg-main']);
  }

  try {
    localStorage.setItem(THEME_STORAGE_KEY, preset.id);
  } catch {
    // ignore storage errors
  }

  return preset;
}
