import { useCallback, useEffect, useRef, useState } from 'react';
import { parseItalianVoiceCommand, type ParsedVoiceCommand } from './voiceCoach';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
  confidence: number;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  length: number;
  [index: number]: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionErrorEventLike {
  error: string;
}

interface SpeechRecognitionInstanceLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((ev: SpeechRecognitionEventLike) => void) | null;
  onerror: ((ev: SpeechRecognitionErrorEventLike) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
}

type SpeechRecognitionConstructorLike = new () => SpeechRecognitionInstanceLike;

function getSpeechRecognitionCtor(): SpeechRecognitionConstructorLike | null {
  if (typeof window === 'undefined') return null;
  const win = window as unknown as {
    SpeechRecognition?: SpeechRecognitionConstructorLike;
    webkitSpeechRecognition?: SpeechRecognitionConstructorLike;
  };
  return win.SpeechRecognition || win.webkitSpeechRecognition || null;
}

export function useVoiceCommands(onCommand: (cmd: Exclude<ParsedVoiceCommand, null>, raw: string) => void) {
  const [enabled, setEnabled] = useState(false);
  const [supported] = useState(() => Boolean(getSpeechRecognitionCtor()));
  const [lastTranscript, setLastTranscript] = useState<string>('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const onCommandRef = useRef(onCommand);
  onCommandRef.current = onCommand;

  const enabledRef = useRef(enabled);
  enabledRef.current = enabled;

  const recognitionRef = useRef<SpeechRecognitionInstanceLike | null>(null);
  const lastFiredRef = useRef<{ key: string; ts: number }>({ key: '', ts: 0 });
  const restartTimerRef = useRef<number | null>(null);

  const stopRecognition = useCallback(() => {
    if (restartTimerRef.current !== null) {
      window.clearTimeout(restartTimerRef.current);
      restartTimerRef.current = null;
    }
    if (recognitionRef.current) {
      try {
        recognitionRef.current.onend = null;
        recognitionRef.current.onresult = null;
        recognitionRef.current.onerror = null;
        recognitionRef.current.stop();
      } catch {
        // Ignore stop errors
      }
      recognitionRef.current = null;
    }
  }, []);

  const startRecognition = useCallback(() => {
    const Ctor = getSpeechRecognitionCtor();
    if (!Ctor) {
      setErrorMsg('Riconoscimento vocale non supportato da questo browser.');
      setEnabled(false);
      return;
    }

    stopRecognition();

    try {
      const rec = new Ctor();
      rec.lang = 'it-IT';
      rec.continuous = true;
      rec.interimResults = true;
      rec.maxAlternatives = 1;

      rec.onresult = (event) => {
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const res = event.results[i];
          const alt = res[0];
          if (!alt?.transcript) continue;

          const transcript = alt.transcript.trim();
          setLastTranscript(transcript);

          const parsed = parseItalianVoiceCommand(transcript);
          if (!parsed) continue;

          const key =
            parsed.type === 'rep'
              ? `rep:${parsed.value}:res${i}`
              : `${parsed.type}:res${i}`;
          const now = Date.now();

          if (
            lastFiredRef.current.key === key &&
            now - lastFiredRef.current.ts < 900
          ) {
            continue;
          }

          // For rep updates, also debounce identical rep number across consecutive interim frames
          const valueKey =
            parsed.type === 'rep' ? `rep:${parsed.value}` : parsed.type;
          if (
            lastFiredRef.current.key === valueKey &&
            now - lastFiredRef.current.ts < 550
          ) {
            continue;
          }

          lastFiredRef.current = { key, ts: now };
          onCommandRef.current(parsed, transcript);
        }
      };

      rec.onerror = (ev) => {
        if (ev.error === 'not-allowed' || ev.error === 'service-not-allowed') {
          setErrorMsg('Permesso microfono negato. Abilita il microfono nel browser.');
          setEnabled(false);
          stopRecognition();
        } else if (ev.error !== 'no-speech' && ev.error !== 'aborted') {
          setErrorMsg(`Errore microfono: ${ev.error}`);
        }
      };

      rec.onend = () => {
        // Keep listening continuously while toggle stays ON
        if (enabledRef.current) {
          restartTimerRef.current = window.setTimeout(() => {
            if (enabledRef.current) {
              startRecognition();
            }
          }, 250);
        }
      };

      recognitionRef.current = rec;
      rec.start();
      setErrorMsg(null);
    } catch {
      setErrorMsg('Impossibile avviare il microfono in questo contesto.');
      setEnabled(false);
    }
  }, [stopRecognition]);

  const toggle = useCallback(() => {
    setEnabled((prev) => {
      const next = !prev;
      if (next) {
        startRecognition();
      } else {
        stopRecognition();
        setLastTranscript('');
      }
      return next;
    });
  }, [startRecognition, stopRecognition]);

  useEffect(() => {
    return () => {
      stopRecognition();
    };
  }, [stopRecognition]);

  return {
    voiceCommandsEnabled: enabled,
    speechSupported: supported,
    lastTranscript,
    voiceError: errorMsg,
    toggleVoiceCommands: toggle,
  };
}
