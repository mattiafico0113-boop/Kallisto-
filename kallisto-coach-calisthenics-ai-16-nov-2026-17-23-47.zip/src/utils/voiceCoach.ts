export function speakItalian(
  text: string,
  options?: { interrupt?: boolean; rate?: number; pitch?: number }
): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    const synth = window.speechSynthesis;
    if (options?.interrupt !== false) {
      synth.cancel();
    }
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'it-IT';
    utterance.rate = options?.rate ?? 1.0;
    utterance.pitch = options?.pitch ?? 1.0;

    // Pick an Italian voice if available
    const voices = synth.getVoices();
    const italianVoice = voices.find((v) => v.lang.toLowerCase().startsWith('it'));
    if (italianVoice) {
      utterance.voice = italianVoice;
    }

    synth.speak(utterance);
  } catch {
    // Ignore speech synthesis errors on restricted browsers
  }
}

export function stopSpeaking(): void {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
  try {
    window.speechSynthesis.cancel();
  } catch {
    // Ignore errors
  }
}

export function formatDurationHMS(totalSeconds: number): string {
  const safe = Math.max(0, Math.floor(totalSeconds));
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = safe % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

export function formatDurationShort(totalSeconds: number): string {
  const safe = Math.max(0, Math.round(totalSeconds));
  const m = Math.floor(safe / 60);
  const s = safe % 60;
  if (m === 0) return `${s}s`;
  if (s === 0) return `${m} min`;
  return `${m} min ${s}s`;
}

const ITALIAN_NUMBER_WORDS: Record<string, number> = {
  zero: 0,
  uno: 1,
  una: 1,
  due: 2,
  tre: 3,
  quattro: 4,
  cinque: 5,
  sei: 6,
  sette: 7,
  otto: 8,
  nove: 9,
  dieci: 10,
  undici: 11,
  dodici: 12,
  tredici: 13,
  quattordici: 14,
  quindici: 15,
  sedici: 16,
  diciassette: 17,
  diciotto: 18,
  diciannove: 19,
  venti: 20,
  ventuno: 21,
  ventidue: 22,
  ventitre: 23,
  ventiquattro: 24,
  venticinque: 25,
  ventisei: 26,
  ventisette: 27,
  ventotto: 28,
  ventinove: 29,
  trenta: 30,
  trentuno: 31,
  trentadue: 32,
  trentatre: 33,
  trentaquattro: 34,
  trentacinque: 35,
  trentasei: 36,
  trentasette: 37,
  trentotto: 38,
  trentanove: 39,
  quaranta: 40,
  quarantuno: 41,
  quarantadue: 42,
  quarantatre: 43,
  quarantaquattro: 44,
  quarantacinque: 45,
  quarantasei: 46,
  quarantasette: 47,
  quarantotto: 48,
  quarantanove: 49,
  cinquanta: 50,
};

const TENS_WORDS: Record<string, number> = {
  venti: 20,
  trenta: 30,
  quaranta: 40,
};

const UNIT_WORDS: Record<string, number> = {
  uno: 1,
  una: 1,
  due: 2,
  tre: 3,
  quattro: 4,
  cinque: 5,
  sei: 6,
  sette: 7,
  otto: 8,
  nove: 9,
};

function normalizeItalianText(raw: string): string {
  return raw
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();
}

export function parseItalianSpokenNumber(transcript: string): number | null {
  const norm = normalizeItalianText(transcript);
  if (!norm) return null;

  // Check explicit digits first (take the last spoken number in the phrase)
  const digitMatches = norm.match(/\b(\d{1,3})\b/g);
  if (digitMatches && digitMatches.length > 0) {
    const val = parseInt(digitMatches[digitMatches.length - 1], 10);
    if (!Number.isNaN(val) && val >= 0 && val <= 200) {
      return val;
    }
  }

  // Check Italian number words (scan tokens from right to left so latest number wins)
  const tokens = norm.split(/[^a-z0-9]+/).filter(Boolean);
  for (let i = tokens.length - 1; i >= 0; i--) {
    const tok = tokens[i];
    if (i > 0 && tokens[i - 1] in TENS_WORDS && tok in UNIT_WORDS) {
      return TENS_WORDS[tokens[i - 1]] + UNIT_WORDS[tok];
    }
    if (tok in ITALIAN_NUMBER_WORDS) {
      return ITALIAN_NUMBER_WORDS[tok];
    }
  }

  return null;
}

export type ParsedVoiceCommand =
  | { type: 'start' }
  | { type: 'stop' }
  | { type: 'finish_set' }
  | { type: 'rep'; value: number }
  | null;

export function parseItalianVoiceCommand(transcript: string): ParsedVoiceCommand {
  const norm = normalizeItalianText(transcript);
  if (!norm) return null;

  // Check end of set before other phrases
  if (
    /\b(fine serie|finita|serie completata|basta|completa serie|chiudi serie)\b/.test(norm)
  ) {
    return { type: 'finish_set' };
  }

  if (/\b(stop|pausa|ferma|fermati|alt)\b/.test(norm)) {
    return { type: 'stop' };
  }

  if (/\b(via|start|inizia|parti|avvia|riprendi)\b/.test(norm)) {
    return { type: 'start' };
  }

  const num = parseItalianSpokenNumber(norm);
  if (num !== null && num > 0) {
    return { type: 'rep', value: num };
  }

  return null;
}

export type VoiceSetEvent =
  | { type: 'finish' }
  | { type: 'rep'; value: number }
  | null;

export function parseVoiceSetEvent(transcript: string): VoiceSetEvent {
  const norm = normalizeItalianText(transcript);
  if (!norm) return null;

  if (
    /\b(fine|fine serie|finita|finito|serie completata|basta|stop|ferma|fermati|alt|fatto)\b/.test(
      norm
    )
  ) {
    return { type: 'finish' };
  }

  const num = parseItalianSpokenNumber(norm);
  if (num !== null && num > 0) {
    return { type: 'rep', value: num };
  }

  return null;
}

